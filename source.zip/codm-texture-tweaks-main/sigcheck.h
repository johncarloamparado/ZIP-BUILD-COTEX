/* sigcheck.h - v1.12 (B5). Self-contained SHA-256 / SHA-512 / Ed25519 verify and the check of a signed module folder, written so the
   Zygisk COMPANION (a root process, so it CAN read /data/adb/modules/...) can verify the owner's release signature natively. Most phones
   have no openssl, so webroot/check.sh cannot do this there; the game process itself cannot read the module folder.
   Only VERIFY code (no signing, no private key anywhere). The Ed25519 part follows TweetNaCl (public domain); the constants below were
   computed from their definitions (not copied) and the whole file is tested against openssl signatures in tests/host_test_v112.cpp.

   Verdicts of sig_check_dir():
     "verified"  signature valid for the PINNED owner key and every listed file matches
     "tampered"  AFFIRMATIVE failure only: the release files are there and readable and (pubkey_mismatch | signature_invalid |
                 signed_file_mismatch)
     "unsigned"  one of RELEASE.sig / RELEASE.sha256 / RELEASE.pub is not there (not a signature failure; check.sh decides about that)
     "unknown"   anything else: folder or file not readable, short read, parse trouble. FAIL OPEN: never blocks the game. */
#pragma once
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <string>
#include <vector>
#include <sys/stat.h>
#include <unistd.h>
#include <ctype.h>

namespace sigc {

typedef uint8_t u8; typedef uint32_t u32; typedef uint64_t u64; typedef long long i64;

/* ---------------- SHA-256 ---------------- */
struct Sha256 {
    u32 h[8]; u8 buf[64]; u64 len; size_t nb;
    Sha256() { init(); }
    void init() { static const u32 H[8] = {0x6a09e667,0xbb67ae85,0x3c6ef372,0xa54ff53a,0x510e527f,0x9b05688c,0x1f83d9ab,0x5be0cd19}; memcpy(h, H, sizeof h); len = 0; nb = 0; }
    static u32 ror(u32 x, int n) { return (x >> n) | (x << (32 - n)); }
    void block(const u8 *p) {
        static const u32 K[64] = {0x428a2f98,0x71374491,0xb5c0fbcf,0xe9b5dba5,0x3956c25b,0x59f111f1,0x923f82a4,0xab1c5ed5,0xd807aa98,0x12835b01,0x243185be,0x550c7dc3,0x72be5d74,0x80deb1fe,0x9bdc06a7,0xc19bf174,0xe49b69c1,0xefbe4786,0x0fc19dc6,0x240ca1cc,0x2de92c6f,0x4a7484aa,0x5cb0a9dc,0x76f988da,0x983e5152,0xa831c66d,0xb00327c8,0xbf597fc7,0xc6e00bf3,0xd5a79147,0x06ca6351,0x14292967,0x27b70a85,0x2e1b2138,0x4d2c6dfc,0x53380d13,0x650a7354,0x766a0abb,0x81c2c92e,0x92722c85,0xa2bfe8a1,0xa81a664b,0xc24b8b70,0xc76c51a3,0xd192e819,0xd6990624,0xf40e3585,0x106aa070,0x19a4c116,0x1e376c08,0x2748774c,0x34b0bcb5,0x391c0cb3,0x4ed8aa4a,0x5b9cca4f,0x682e6ff3,0x748f82ee,0x78a5636f,0x84c87814,0x8cc70208,0x90befffa,0xa4506ceb,0xbef9a3f7,0xc67178f2};
        u32 w[64], a, b, c, d, e, f, g, hh;
        for (int i = 0; i < 16; i++) w[i] = ((u32)p[4*i] << 24) | ((u32)p[4*i+1] << 16) | ((u32)p[4*i+2] << 8) | p[4*i+3];
        for (int i = 16; i < 64; i++) { u32 s0 = ror(w[i-15], 7) ^ ror(w[i-15], 18) ^ (w[i-15] >> 3), s1 = ror(w[i-2], 17) ^ ror(w[i-2], 19) ^ (w[i-2] >> 10); w[i] = w[i-16] + s0 + w[i-7] + s1; }
        a = h[0]; b = h[1]; c = h[2]; d = h[3]; e = h[4]; f = h[5]; g = h[6]; hh = h[7];
        for (int i = 0; i < 64; i++) {
            u32 S1 = ror(e, 6) ^ ror(e, 11) ^ ror(e, 25), ch = (e & f) ^ (~e & g), t1 = hh + S1 + ch + K[i] + w[i];
            u32 S0 = ror(a, 2) ^ ror(a, 13) ^ ror(a, 22), mj = (a & b) ^ (a & c) ^ (b & c), t2 = S0 + mj;
            hh = g; g = f; f = e; e = d + t1; d = c; c = b; b = a; a = t1 + t2;
        }
        h[0] += a; h[1] += b; h[2] += c; h[3] += d; h[4] += e; h[5] += f; h[6] += g; h[7] += hh;
    }
    void update(const void *vp, size_t n) {
        const u8 *p = (const u8 *)vp; len += n;
        while (n) { size_t k = 64 - nb; if (k > n) k = n; memcpy(buf + nb, p, k); nb += k; p += k; n -= k; if (nb == 64) { block(buf); nb = 0; } }
    }
    void final(u8 out[32]) {
        u64 bits = len * 8; u8 pad = 0x80; update(&pad, 1); u8 z = 0; while (nb != 56) update(&z, 1);
        u8 lb[8]; for (int i = 0; i < 8; i++) lb[i] = (u8)(bits >> (56 - 8 * i)); update(lb, 8);
        for (int i = 0; i < 8; i++) { out[4*i] = (u8)(h[i] >> 24); out[4*i+1] = (u8)(h[i] >> 16); out[4*i+2] = (u8)(h[i] >> 8); out[4*i+3] = (u8)h[i]; }
    }
};
/* ---------------- SHA-512 ---------------- */
struct Sha512 {
    u64 h[8]; u8 buf[128]; u64 len; size_t nb;
    Sha512() { init(); }
    void init() { static const u64 H[8] = {0x6a09e667f3bcc908ULL,0xbb67ae8584caa73bULL,0x3c6ef372fe94f82bULL,0xa54ff53a5f1d36f1ULL,0x510e527fade682d1ULL,0x9b05688c2b3e6c1fULL,0x1f83d9abfb41bd6bULL,0x5be0cd19137e2179ULL}; memcpy(h, H, sizeof h); len = 0; nb = 0; }
    static u64 ror(u64 x, int n) { return (x >> n) | (x << (64 - n)); }
    void block(const u8 *p) {
        static const u64 K[80] = {0x428a2f98d728ae22ULL,0x7137449123ef65cdULL,0xb5c0fbcfec4d3b2fULL,0xe9b5dba58189dbbcULL,0x3956c25bf348b538ULL,0x59f111f1b605d019ULL,0x923f82a4af194f9bULL,0xab1c5ed5da6d8118ULL,0xd807aa98a3030242ULL,0x12835b0145706fbeULL,0x243185be4ee4b28cULL,0x550c7dc3d5ffb4e2ULL,0x72be5d74f27b896fULL,0x80deb1fe3b1696b1ULL,0x9bdc06a725c71235ULL,0xc19bf174cf692694ULL,0xe49b69c19ef14ad2ULL,0xefbe4786384f25e3ULL,0x0fc19dc68b8cd5b5ULL,0x240ca1cc77ac9c65ULL,0x2de92c6f592b0275ULL,0x4a7484aa6ea6e483ULL,0x5cb0a9dcbd41fbd4ULL,0x76f988da831153b5ULL,0x983e5152ee66dfabULL,0xa831c66d2db43210ULL,0xb00327c898fb213fULL,0xbf597fc7beef0ee4ULL,0xc6e00bf33da88fc2ULL,0xd5a79147930aa725ULL,0x06ca6351e003826fULL,0x142929670a0e6e70ULL,0x27b70a8546d22ffcULL,0x2e1b21385c26c926ULL,0x4d2c6dfc5ac42aedULL,0x53380d139d95b3dfULL,0x650a73548baf63deULL,0x766a0abb3c77b2a8ULL,0x81c2c92e47edaee6ULL,0x92722c851482353bULL,0xa2bfe8a14cf10364ULL,0xa81a664bbc423001ULL,0xc24b8b70d0f89791ULL,0xc76c51a30654be30ULL,0xd192e819d6ef5218ULL,0xd69906245565a910ULL,0xf40e35855771202aULL,0x106aa07032bbd1b8ULL,0x19a4c116b8d2d0c8ULL,0x1e376c085141ab53ULL,0x2748774cdf8eeb99ULL,0x34b0bcb5e19b48a8ULL,0x391c0cb3c5c95a63ULL,0x4ed8aa4ae3418acbULL,0x5b9cca4f7763e373ULL,0x682e6ff3d6b2b8a3ULL,0x748f82ee5defb2fcULL,0x78a5636f43172f60ULL,0x84c87814a1f0ab72ULL,0x8cc702081a6439ecULL,0x90befffa23631e28ULL,0xa4506cebde82bde9ULL,0xbef9a3f7b2c67915ULL,0xc67178f2e372532bULL,0xca273eceea26619cULL,0xd186b8c721c0c207ULL,0xeada7dd6cde0eb1eULL,0xf57d4f7fee6ed178ULL,0x06f067aa72176fbaULL,0x0a637dc5a2c898a6ULL,0x113f9804bef90daeULL,0x1b710b35131c471bULL,0x28db77f523047d84ULL,0x32caab7b40c72493ULL,0x3c9ebe0a15c9bebcULL,0x431d67c49c100d4cULL,0x4cc5d4becb3e42b6ULL,0x597f299cfc657e2aULL,0x5fcb6fab3ad6faecULL,0x6c44198c4a475817ULL};
        u64 w[80], a, b, c, d, e, f, g, hh;
        for (int i = 0; i < 16; i++) { w[i] = 0; for (int j = 0; j < 8; j++) w[i] = (w[i] << 8) | p[8*i+j]; }
        for (int i = 16; i < 80; i++) { u64 s0 = ror(w[i-15], 1) ^ ror(w[i-15], 8) ^ (w[i-15] >> 7), s1 = ror(w[i-2], 19) ^ ror(w[i-2], 61) ^ (w[i-2] >> 6); w[i] = w[i-16] + s0 + w[i-7] + s1; }
        a = h[0]; b = h[1]; c = h[2]; d = h[3]; e = h[4]; f = h[5]; g = h[6]; hh = h[7];
        for (int i = 0; i < 80; i++) {
            u64 S1 = ror(e, 14) ^ ror(e, 18) ^ ror(e, 41), ch = (e & f) ^ (~e & g), t1 = hh + S1 + ch + K[i] + w[i];
            u64 S0 = ror(a, 28) ^ ror(a, 34) ^ ror(a, 39), mj = (a & b) ^ (a & c) ^ (b & c), t2 = S0 + mj;
            hh = g; g = f; f = e; e = d + t1; d = c; c = b; b = a; a = t1 + t2;
        }
        h[0] += a; h[1] += b; h[2] += c; h[3] += d; h[4] += e; h[5] += f; h[6] += g; h[7] += hh;
    }
    void update(const void *vp, size_t n) {
        const u8 *p = (const u8 *)vp; len += n;
        while (n) { size_t k = 128 - nb; if (k > n) k = n; memcpy(buf + nb, p, k); nb += k; p += k; n -= k; if (nb == 128) { block(buf); nb = 0; } }
    }
    void final(u8 out[64]) {
        u64 bits = len * 8; u8 pad = 0x80; update(&pad, 1); u8 z = 0; while (nb != 112) update(&z, 1);
        u8 lb[16]; memset(lb, 0, 8); for (int i = 0; i < 8; i++) lb[8 + i] = (u8)(bits >> (56 - 8 * i)); update(lb, 16);
        for (int i = 0; i < 8; i++) for (int j = 0; j < 8; j++) out[8*i+j] = (u8)(h[i] >> (56 - 8 * j));
    }
};

/* ---------------- Ed25519 verify (TweetNaCl layout) ---------------- */
typedef i64 gf[16];
static const gf gf0 = {0}, gf1 = {1};
static const gf D_ = {0x78a3,0x1359,0x4dca,0x75eb,0xd8ab,0x4141,0x0a4d,0x0070,0xe898,0x7779,0x4079,0x8cc7,0xfe73,0x2b6f,0x6cee,0x5203}, D2_ = {0xf159,0x26b2,0x9b94,0xebd6,0xb156,0x8283,0x149a,0x00e0,0xd130,0xeef3,0x80f2,0x198e,0xfce7,0x56df,0xd9dc,0x2406}, X_ = {0xd51a,0x8f25,0x2d60,0xc956,0xa7b2,0x9525,0xc760,0x692c,0xdc5c,0xfdd6,0xe231,0xc0a4,0x53fe,0xcd6e,0x36d3,0x2169}, Y_ = {0x6658,0x6666,0x6666,0x6666,0x6666,0x6666,0x6666,0x6666,0x6666,0x6666,0x6666,0x6666,0x6666,0x6666,0x6666,0x6666}, I_ = {0xa0b0,0x4a0e,0x1b27,0xc4ee,0xe478,0xad2f,0x1806,0x2f43,0xd7a7,0x3dfb,0x0099,0x2b4d,0xdf0b,0x4fc1,0x2480,0x2b83};
static const u8 L_[32] = {0xed,0xd3,0xf5,0x5c,0x1a,0x63,0x12,0x58,0xd6,0x9c,0xf7,0xa2,0xde,0xf9,0xde,0x14,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x10};
static void set25519(gf r, const gf a) { for (int i = 0; i < 16; i++) r[i] = a[i]; }
static void car25519(gf o) { for (int i = 0; i < 16; i++) { o[i] += (1LL << 16); i64 c = o[i] >> 16; o[(i + 1) * (i < 15)] += c - 1 + 37 * (c - 1) * (i == 15); o[i] -= c << 16; } }
static void sel25519(gf p, gf q, int b) { i64 c = ~((i64)b - 1); for (int i = 0; i < 16; i++) { i64 t = c & (p[i] ^ q[i]); p[i] ^= t; q[i] ^= t; } }
static void pack25519(u8 *o, const gf n) {
    gf m, t; set25519(t, n); car25519(t); car25519(t); car25519(t);
    for (int j = 0; j < 2; j++) {
        m[0] = t[0] - 0xffed;
        for (int i = 1; i < 15; i++) { m[i] = t[i] - 0xffff - ((m[i-1] >> 16) & 1); m[i-1] &= 0xffff; }
        m[15] = t[15] - 0x7fff - ((m[14] >> 16) & 1);
        int b = (int)((m[15] >> 16) & 1); m[14] &= 0xffff; sel25519(t, m, 1 - b);
    }
    for (int i = 0; i < 16; i++) { o[2*i] = (u8)(t[i] & 0xff); o[2*i+1] = (u8)(t[i] >> 8); }
}
static int vn32(const u8 *x, const u8 *y) { u32 d = 0; for (int i = 0; i < 32; i++) d |= x[i] ^ y[i]; return (int)((1 & ((d - 1) >> 8)) - 1); }   /* 0 = equal, -1 = different */
static int neq25519(const gf a, const gf b) { u8 c[32], d[32]; pack25519(c, a); pack25519(d, b); return vn32(c, d); }
static u8 par25519(const gf a) { u8 d[32]; pack25519(d, a); return d[0] & 1; }
static void unpack25519(gf o, const u8 *n) { for (int i = 0; i < 16; i++) o[i] = n[2*i] + ((i64)n[2*i+1] << 8); o[15] &= 0x7fff; }
static void A(gf o, const gf a, const gf b) { for (int i = 0; i < 16; i++) o[i] = a[i] + b[i]; }
static void Z(gf o, const gf a, const gf b) { for (int i = 0; i < 16; i++) o[i] = a[i] - b[i]; }
static void M(gf o, const gf a, const gf b) {
    i64 t[31]; for (int i = 0; i < 31; i++) t[i] = 0;
    for (int i = 0; i < 16; i++) for (int j = 0; j < 16; j++) t[i + j] += a[i] * b[j];
    for (int i = 0; i < 15; i++) t[i] += 38 * t[i + 16];
    for (int i = 0; i < 16; i++) o[i] = t[i];
    car25519(o); car25519(o);
}
static void S(gf o, const gf a) { M(o, a, a); }
static void inv25519(gf o, const gf in) { gf c; for (int a = 0; a < 16; a++) c[a] = in[a]; for (int a = 253; a >= 0; a--) { S(c, c); if (a != 2 && a != 4) M(c, c, in); } for (int a = 0; a < 16; a++) o[a] = c[a]; }
static void pow2523(gf o, const gf in) { gf c; for (int a = 0; a < 16; a++) c[a] = in[a]; for (int a = 250; a >= 0; a--) { S(c, c); if (a != 1) M(c, c, in); } for (int a = 0; a < 16; a++) o[a] = c[a]; }
static void ptadd(gf p[4], gf q[4]) {
    gf a, b, c, d, t, e, f, g, h;
    Z(a, p[1], p[0]); Z(t, q[1], q[0]); M(a, a, t); A(b, p[0], p[1]); A(t, q[0], q[1]); M(b, b, t);
    M(c, p[3], q[3]); M(c, c, D2_); M(d, p[2], q[2]); A(d, d, d); Z(e, b, a); Z(f, d, c); A(g, d, c); A(h, b, a);
    M(p[0], e, f); M(p[1], h, g); M(p[2], g, f); M(p[3], e, h);
}
static void cswap(gf p[4], gf q[4], u8 b) { for (int i = 0; i < 4; i++) sel25519(p[i], q[i], b); }
static void pointpack(u8 *r, gf p[4]) { gf tx, ty, zi; inv25519(zi, p[2]); M(tx, p[0], zi); M(ty, p[1], zi); pack25519(r, ty); r[31] ^= (u8)(par25519(tx) << 7); }
static void scalarmult(gf p[4], gf q[4], const u8 *s) {
    set25519(p[0], gf0); set25519(p[1], gf1); set25519(p[2], gf1); set25519(p[3], gf0);
    for (int i = 255; i >= 0; i--) { u8 b = (s[i / 8] >> (i & 7)) & 1; cswap(p, q, b); ptadd(q, p); ptadd(p, p); cswap(p, q, b); }
}
static void scalarbase(gf p[4], const u8 *s) { gf q[4]; set25519(q[0], X_); set25519(q[1], Y_); set25519(q[2], gf1); M(q[3], X_, Y_); scalarmult(p, q, s); }
static void modL(u8 *r, i64 x[64]) {
    i64 carry, i, j;
    for (i = 63; i >= 32; --i) { carry = 0; for (j = i - 32; j < i - 12; ++j) { x[j] += carry - 16 * x[i] * (i64)L_[j - (i - 32)]; carry = (x[j] + 128) >> 8; x[j] -= carry << 8; } x[j] += carry; x[i] = 0; }
    carry = 0; for (j = 0; j < 32; j++) { x[j] += carry - (x[31] >> 4) * (i64)L_[j]; carry = x[j] >> 8; x[j] &= 255; }
    for (j = 0; j < 32; j++) x[j] -= carry * (i64)L_[j];
    for (i = 0; i < 32; i++) { x[i + 1] += x[i] >> 8; r[i] = (u8)(x[i] & 255); }
}
static void reduce64(u8 *r) { i64 x[64]; for (int i = 0; i < 64; i++) x[i] = (u64)r[i]; for (int i = 0; i < 64; i++) r[i] = 0; modL(r, x); }
static int unpackneg(gf r[4], const u8 p[32]) {
    gf t, chk, num, den, den2, den4, den6;
    set25519(r[2], gf1); unpack25519(r[1], p); S(num, r[1]); M(den, num, D_); Z(num, num, r[2]); A(den, r[2], den);
    S(den2, den); S(den4, den2); M(den6, den4, den2); M(t, den6, num); M(t, t, den); pow2523(t, t); M(t, t, num); M(t, t, den); M(t, t, den); M(r[0], t, den);
    S(chk, r[0]); M(chk, chk, den); if (neq25519(chk, num)) M(r[0], r[0], I_);
    S(chk, r[0]); M(chk, chk, den); if (neq25519(chk, num)) return -1;
    if (par25519(r[0]) == (p[31] >> 7)) Z(r[0], gf0, r[0]);
    M(r[3], r[0], r[1]);
    return 0;
}
/* true only for a valid Ed25519 signature (64 bytes) of msg under the 32-byte public key. */
static bool ed25519_verify(const u8 sig[64], const u8 *msg, size_t n, const u8 pk[32]) {
    gf p[4], q[4]; u8 t[32], h[64];
    /* S must be < L (rejects the malleable second encoding) */
    { int lt = 0; for (int i = 31; i >= 0; i--) { if (sig[32 + i] < L_[i]) { lt = 1; break; } if (sig[32 + i] > L_[i]) break; } if (!lt) return false; }
    if (unpackneg(q, pk)) return false;
    Sha512 s; s.update(sig, 32); s.update(pk, 32); s.update(msg, n); s.final(h);
    reduce64(h);
    scalarmult(p, q, h);
    scalarbase(q, sig + 32);
    ptadd(p, q);
    pointpack(t, p);
    return vn32(sig, t) == 0;
}

/* ---------------- helpers: hex, base64, file reading ---------------- */
static std::string hex(const u8 *p, size_t n) { static const char *d = "0123456789abcdef"; std::string s; for (size_t i = 0; i < n; i++) { s.push_back(d[p[i] >> 4]); s.push_back(d[p[i] & 15]); } return s; }
static bool b64dec(const std::string &in, std::vector<u8> &out) {
    out.clear(); u32 acc = 0; int bits = 0;
    for (char ch : in) {
        int v;
        if (ch >= 'A' && ch <= 'Z') v = ch - 'A'; else if (ch >= 'a' && ch <= 'z') v = ch - 'a' + 26; else if (ch >= '0' && ch <= '9') v = ch - '0' + 52;
        else if (ch == '+') v = 62; else if (ch == '/') v = 63; else if (ch == '=') break; else if (ch == '\n' || ch == '\r' || ch == ' ') continue; else return false;
        acc = (acc << 6) | (u32)v; bits += 6; if (bits >= 8) { bits -= 8; out.push_back((u8)(acc >> bits)); acc &= (1u << bits) - 1; }
    }
    return true;
}
/* reads a whole small file; false = could not open / read it completely */
static bool read_all(const std::string &path, std::string &out, size_t max_bytes) {
    out.clear(); FILE *f = fopen(path.c_str(), "rb"); if (!f) return false;
    char b[8192]; bool ok = true;
    for (;;) { size_t n = fread(b, 1, sizeof b, f); if (n) out.append(b, n); if (out.size() > max_bytes) { ok = false; break; } if (n < sizeof b) { if (ferror(f)) ok = false; break; } }
    fclose(f); return ok;
}
/* SHA-256 of a file; false = could not be read */
static bool sha256_file(const std::string &path, std::string &hexout) {
    FILE *f = fopen(path.c_str(), "rb"); if (!f) return false;
    Sha256 s; u8 b[16384]; bool ok = true;
    for (;;) { size_t n = fread(b, 1, sizeof b, f); if (n) s.update(b, n); if (n < sizeof b) { if (ferror(f)) ok = false; break; } }
    fclose(f); if (!ok) return false;
    u8 d[32]; s.final(d); hexout = hex(d, 32); return true;
}
static bool is_hex64(const char *p) { for (int i = 0; i < 64; i++) if (!((p[i] >= '0' && p[i] <= '9') || (p[i] >= 'a' && p[i] <= 'f'))) return false; return true; }

struct Verdict { std::string status = "unknown", reason, key8, rel12; };

/* Same rules as webroot/check.sh, signed-release layer: pinned key fingerprint, signature, then every listed file (META-INF/ and an
   already-deleted ./customize.sh are not checked, exactly as the shell check leaves them out). pinned_fp = SHA-256 of the DER public key. */
static Verdict sig_check_dir(const std::string &dir, const char *pinned_fp) {
    Verdict v; std::string sig, lst, pub;
    struct stat sb; if (stat(dir.c_str(), &sb) != 0 || !S_ISDIR(sb.st_mode)) { v.reason = "nodir"; return v; }
    bool hs = access((dir + "/RELEASE.sig").c_str(), F_OK) == 0, hl = access((dir + "/RELEASE.sha256").c_str(), F_OK) == 0, hp = access((dir + "/RELEASE.pub").c_str(), F_OK) == 0;
    if (!hs && !hl && !hp) { v.status = "unsigned"; v.reason = "no_release_files"; return v; }
    if (!hs || !hl || !hp) { v.status = "unsigned"; v.reason = "partial_release_files"; return v; }
    if (!read_all(dir + "/RELEASE.sig", sig, 256) || !read_all(dir + "/RELEASE.sha256", lst, 8u << 20) || !read_all(dir + "/RELEASE.pub", pub, 4096)) { v.reason = "read_failed"; return v; }
    /* the key: PEM -> 44-byte SubjectPublicKeyInfo of an Ed25519 key */
    static const u8 SPKI[12] = {0x30, 0x2a, 0x30, 0x05, 0x06, 0x03, 0x2b, 0x65, 0x70, 0x03, 0x21, 0x00};
    std::string body; { size_t a = pub.find("-----BEGIN PUBLIC KEY-----"), b = pub.find("-----END PUBLIC KEY-----"); if (a != std::string::npos && b != std::string::npos && b > a) body = pub.substr(a + 26, b - a - 26); }
    std::vector<u8> der; bool pem_ok = !body.empty() && b64dec(body, der) && der.size() == 44 && memcmp(der.data(), SPKI, 12) == 0;
    if (!pem_ok) { v.status = "tampered"; v.reason = "pubkey_mismatch"; return v; }          /* readable but not the owner's kind of key */
    { Sha256 s; s.update(der.data(), der.size()); u8 d[32]; s.final(d); std::string fp = hex(d, 32); v.key8 = fp.substr(0, 8);
      if (!pinned_fp || fp != pinned_fp) { v.status = "tampered"; v.reason = "pubkey_mismatch"; return v; } }
    if (sig.size() != 64 || !ed25519_verify((const u8 *)sig.data(), (const u8 *)lst.data(), lst.size(), der.data() + 12)) { v.status = "tampered"; v.reason = "signature_invalid"; return v; }
    { Sha256 s; s.update(lst.data(), lst.size()); u8 d[32]; s.final(d); v.rel12 = hex(d, 32).substr(0, 12); }
    /* every listed file: "<64 hex>  ./path" */
    bool cz_there = access((dir + "/customize.sh").c_str(), F_OK) == 0; size_t pos = 0, nfiles = 0;
    while (pos < lst.size()) {
        size_t e = lst.find('\n', pos); if (e == std::string::npos) e = lst.size();
        std::string ln = lst.substr(pos, e - pos); pos = e + 1;
        if (ln.empty()) continue;
        if (ln.size() < 68 || !is_hex64(ln.c_str()) || ln[64] != ' ' || ln[65] != ' ') { v.reason = "list_unparsable"; v.rel12.clear(); return v; }   /* signed but odd: not a clear failure, stay open */
        std::string rel = ln.substr(66);
        if (rel.compare(0, 11, "./META-INF/") == 0) continue;
        if (rel == "./customize.sh" && !cz_there) continue;
        if (rel.find("..") != std::string::npos || rel.compare(0, 2, "./") != 0) { v.reason = "list_unparsable"; v.rel12.clear(); return v; }
        std::string got;
        if (!sha256_file(dir + "/" + rel.substr(2), got) || got != ln.substr(0, 64)) { v.status = "tampered"; v.reason = "signed_file_mismatch"; v.rel12.clear(); return v; }
        nfiles++;
    }
    v.status = "verified"; v.reason = ""; (void)nfiles;
    return v;
}
/* one line over the companion socket: "V1 <status> <reason|-> <key8|-> <rel12|->" ; the parser keeps only safe characters */
static std::string verdict_line(const Verdict &v) {
    auto f = [](const std::string &s) { return s.empty() ? std::string("-") : s; };
    return "V1 " + v.status + " " + f(v.reason) + " " + f(v.key8) + " " + f(v.rel12) + "\n";
}
static bool parse_verdict_line(const char *s, Verdict &v) {
    char st[24] = "", rs[40] = "", k8[16] = "", r12[24] = "";
    if (sscanf(s, "V1 %23s %39s %15s %23s", st, rs, k8, r12) != 4) return false;
    auto clean = [](const char *in, bool hexonly) { std::string o; for (const char *p = in; *p; p++) if (hexonly ? ((*p >= '0' && *p <= '9') || (*p >= 'a' && *p <= 'f')) : (isalnum((unsigned char)*p) || *p == '_')) o.push_back(*p); return o; };
    v.status = clean(st, false); v.reason = rs[0] == '-' ? "" : clean(rs, false); v.key8 = k8[0] == '-' ? "" : clean(k8, true); v.rel12 = r12[0] == '-' ? "" : clean(r12, true);
    if (v.status != "verified" && v.status != "tampered" && v.status != "unsigned" && v.status != "unknown") return false;
    return true;
}

}  // namespace sigc
