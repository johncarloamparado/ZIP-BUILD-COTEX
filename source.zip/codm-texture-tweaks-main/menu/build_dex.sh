#!/bin/sh
# v0.77: builds menu/q9/*.java into a dex and writes it as a C header (MENU_DEX / MENU_DEX_LEN).
# It NEVER fails the build: when anything is missing (android.jar, d8, javac) or the Java does not compile, it writes an EMPTY dex.
# The module then still builds and works; only the in-game menu is unavailable ("no dex built" in the log).
# Usage: build_dex.sh <menu dir> <output header>
SRC="$1"; OUT="$2"; W="$(mktemp -d 2>/dev/null || echo /tmp/menu_dex_$$)"; mkdir -p "$W"
empty() { printf 'static const unsigned char MENU_DEX[] = {0};\nstatic const unsigned MENU_DEX_LEN = 0;\n' > "$OUT"; }
fail() { echo "menu dex: $1 -> the in-game menu will not be available in this build"; empty; rm -rf "$W"; exit 0; }
SDK="${ANDROID_HOME:-${ANDROID_SDK_ROOT:-/usr/local/lib/android/sdk}}"
JAR="$(ls -d "$SDK"/platforms/android-*/android.jar 2>/dev/null | sort -V | tail -n 1)"
[ -f "$JAR" ] || fail "no android.jar under $SDK/platforms"
D8="$(ls "$SDK"/build-tools/*/d8 2>/dev/null | sort -V | tail -n 1)"
[ -x "$D8" ] || fail "no d8 under $SDK/build-tools"
command -v javac >/dev/null 2>&1 || fail "no javac"
mkdir -p "$W/cls" "$W/out"
ok=0
for opt in "--release 8" "-source 8 -target 8" "--release 11"; do
  rm -rf "$W/cls"; mkdir -p "$W/cls"
  if javac $opt -nowarn -cp "$JAR" -d "$W/cls" "$SRC"/q9/*.java >"$W/javac.log" 2>&1; then ok=1; break; fi
done
[ "$ok" = 1 ] || { cat "$W/javac.log" | head -30; fail "javac failed"; }
"$D8" --release --min-api 26 --lib "$JAR" --output "$W/out" $(find "$W/cls" -name '*.class') >"$W/d8.log" 2>&1 || { head -30 "$W/d8.log"; fail "d8 failed"; }
[ -s "$W/out/classes.dex" ] || fail "d8 made no classes.dex"
{
  echo 'static const unsigned char MENU_DEX[] = {'
  od -An -v -tu1 "$W/out/classes.dex" | sed 's/^ *//; s/  */,/g; s/$/,/'
  echo '};'
  echo "static const unsigned MENU_DEX_LEN = $(wc -c < "$W/out/classes.dex");"
} > "$OUT"
echo "menu dex: ok ($(wc -c < "$W/out/classes.dex") bytes)"
rm -rf "$W"
exit 0
