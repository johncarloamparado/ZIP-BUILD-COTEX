package q9;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.RandomAccessFile;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * v0.79 (adds states, filters, friendly status text); v0.78: everything the in-game menu does with FILES and LISTS, with no Android classes (so it is unit-tested on a plain JDK,
 * tests/DataTest.java). File formats are the ones the WebUI already uses:
 *   hidden.txt / orig.txt : "fmt w h hash" per line (Hide rules / Restore rules)
 *   texlib.txt            : "fmt w h hash group[~setid][~r]|name"  (My textures; ~r = the entry is a Restore entry)
 */
final class Data {
    private Data() { }

    static final class Row {
        int fmt, w, h, lv;
        long n;
        String hash;
        boolean canHide;
        String key() { return fmt + "|" + w + "|" + h + "|" + hash; }
    }

    static final class Saved {
        String key, grp = "other", set = "", name = "Texture";
        boolean restore;
    }

    // ---------- names / sizes ----------
    static String cleanName(String s) {
        if (s == null) return "";
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if ((c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z') || (c >= '0' && c <= '9') || c == ' ' || c == '_' || c == '.' || c == '-') b.append(c);
        }
        String t = b.toString().replaceAll("\\s+", " ").trim();
        return t.length() > 24 ? t.substring(0, 24).trim() : t;
    }

    static String grpOk(String g) { return "plants".equals(g) || "effects".equals(g) ? g : "other"; }

    static boolean guarded(Row c) {
        if (c.fmt == 37497 && ((c.w == 256 && c.h == 512) || (c.w == 512 && c.h == 1024) || (c.w == 512 && c.h == 256))) return true;
        return c.fmt == 37496 && c.w == 512 && c.h == 512;
    }

    static String fmtName(int f) {
        String[] e = {"R11 EAC", "R11 EAC signed", "RG11 EAC", "RG11 EAC signed", "ETC2 RGB", "ETC2 sRGB", "ETC2 RGB+A1", "ETC2 sRGB+A1", "ETC2 RGBA", "ETC2 sRGBA"};
        String[] a = {"4x4", "5x4", "5x5", "6x5", "6x6", "8x5", "8x6", "8x8", "10x5", "10x6", "10x8", "10x10", "12x10", "12x12"};
        if (f >= 0x9270 && f <= 0x9279) return e[f - 0x9270];
        if (f >= 0x93b0 && f <= 0x93bd) return "ASTC " + a[f - 0x93b0];
        if (f >= 0x93d0 && f <= 0x93dd) return "ASTC " + a[f - 0x93d0] + " sRGB";
        return "Format 0x" + Integer.toHexString(f);
    }

    static String sizeText(long n) {
        return n >= 1048576 ? (n / 104857) / 10.0 + " MB" : (n / 1024) + " KB";
    }

    // ---------- the log ----------
    /** Position of the start of the current game session in the (tail of the) log. */
    static int sessionStart(String s) {
        int from = s.length();
        while (from >= 0) {
            int i = s.lastIndexOf("=== start ", from);
            if (i < 0) return 0;
            if (i == 0 || s.charAt(i - 1) == '\n') return i;
            from = i - 1;
        }
        return 0;
    }

    private static int lastMarkA(String s, int from) {
        int p = s.length();
        while (p >= from) {
            int i = s.lastIndexOf("MARK A ", p);
            if (i < from) return -1;
            if (i == 0 || s.charAt(i - 1) == '\n') return i;
            p = i - 1;
        }
        return -1;
    }

    static boolean hasMarks(String s) { return lastMarkA(s, sessionStart(s)) >= 0; }

    /** marksOnly = false: every candidate since the game started. true: only those between the last MARK A and the next MARK B / X. */
    static ArrayList<Row> parseLog(String s, boolean marksOnly) {
        int a = sessionStart(s), e = s.length();
        if (marksOnly) {
            a = lastMarkA(s, a);
            if (a < 0) return new ArrayList<Row>();
            int b1 = s.indexOf("\nMARK B ", a), b2 = s.indexOf("\nMARK X ", a);
            if (b1 >= 0) e = Math.min(e, b1);
            if (b2 >= 0) e = Math.min(e, b2);
        }
        LinkedHashMap<String, Row> map = new LinkedHashMap<String, Row>();
        for (String line : s.substring(a, e).split("\n")) {
            boolean g = line.startsWith("GRASSCAND ");
            if (!g && !line.startsWith("RESTORECAND ")) continue;
            String[] p = line.trim().split(" ");
            if (p.length < 6) continue;
            try {
                Row r = new Row();
                r.fmt = Integer.parseInt(p[1].substring(4));
                r.w = Integer.parseInt(p[2].substring(2));
                r.h = Integer.parseInt(p[3].substring(2));
                r.n = Long.parseLong(p[4].substring(2));
                r.hash = p[5].substring(2);
                if (r.hash.length() != 16) continue;
                for (int k = 6; k < p.length; k++) if (p[k].startsWith("lv=")) r.lv = Integer.parseInt(p[k].substring(3));
                Row o = map.get(r.key());
                if (o == null) { map.put(r.key(), r); o = r; }
                if (g) o.canHide = true;
            } catch (RuntimeException ignored) {
            }
        }
        ArrayList<Row> res = new ArrayList<Row>(map.values());
        Collections.sort(res, new Comparator<Row>() {
            public int compare(Row x, Row y) { return x.n == y.n ? x.hash.compareTo(y.hash) : (x.n < y.n ? 1 : -1); }
        });
        return res;
    }

    /** which = 0: first half (rounded up), 1: second half. */
    static ArrayList<Row> half(List<Row> l, int which) {
        int c = (l.size() + 1) / 2;
        return new ArrayList<Row>(which == 0 ? l.subList(0, c) : l.subList(c, l.size()));
    }

    static ArrayList<Row> minus(List<Row> all, List<Row> part) {
        ArrayList<Row> r = new ArrayList<Row>();
        for (Row x : all) if (!part.contains(x)) r.add(x);
        return r;
    }

    // ---------- files ----------
    static String read(File f, int max) {
        try {
            RandomAccessFile r = new RandomAccessFile(f, "r");
            try {
                long len = r.length(), st = Math.max(0, len - max);
                r.seek(st);
                byte[] b = new byte[(int) (len - st)];
                r.readFully(b);
                return new String(b, "ISO-8859-1");
            } finally { r.close(); }
        } catch (Exception e) {
            return "";
        }
    }

    static String readSmall(File f) {
        try {
            FileInputStream in = new FileInputStream(f);
            try {
                byte[] b = new byte[16384];
                int n = in.read(b);
                return n > 0 ? new String(b, 0, n, "ISO-8859-1") : "";
            } finally { in.close(); }
        } catch (Exception e) {
            return "";
        }
    }

    /** Writes "<file>.new" and renames it over the file; the real file is never half written. */
    static boolean writeAtomic(File f, String text) {
        File tmp = new File(f.getPath() + ".new");
        try {
            FileOutputStream o = new FileOutputStream(tmp, false);
            try { o.write(text.getBytes("UTF-8")); } finally { o.close(); }
            if (tmp.renameTo(f)) return true;
            tmp.delete();
            return false;
        } catch (Exception e) {
            tmp.delete();
            return false;
        }
    }

    /** "fmt w h hash ..." -> "fmt|w|h|hash" (hash lower case) or null. */
    static String keyOfLine(String line) {
        if (line == null) return null;
        String[] p = line.trim().split("\\s+");
        if (p.length < 4) return null;
        try {
            int a = Integer.parseInt(p[0]), b = Integer.parseInt(p[1]), c = Integer.parseInt(p[2]);
            if (!p[3].matches("[0-9a-fA-F]{1,16}")) return null;
            return a + "|" + b + "|" + c + "|" + p[3].toLowerCase();
        } catch (NumberFormatException e) {
            return null;
        }
    }

    static String lineOfKey(String key) { return key.replace('|', ' '); }

    static String rulesText(File dir, String name) {
        File f = new File(dir, name);
        if (!f.exists() && name.equals("hidden.txt")) f = new File(dir, "grass.txt");     // the module reads the old name when hidden.txt does not exist
        return readSmallBig(f);
    }

    private static String readSmallBig(File f) { return read(f, 400000); }

    static LinkedHashSet<String> readRuleKeys(File dir, String name) {
        LinkedHashSet<String> s = new LinkedHashSet<String>();
        for (String l : rulesText(dir, name).split("\n")) { String k = keyOfLine(l); if (k != null) s.add(k); }
        return s;
    }

    /** Adds (on) or removes (off) these keys in a rule file. Lines this code does not understand are kept as they are. */
    static boolean setRules(File dir, String name, Collection<String> keys, boolean on) {
        ArrayList<String> out = new ArrayList<String>();
        LinkedHashSet<String> have = new LinkedHashSet<String>();
        for (String l : rulesText(dir, name).split("\n")) {
            if (l.trim().length() == 0) continue;
            String k = keyOfLine(l);
            if (k == null) { out.add(l.trim()); continue; }
            if (!on && keys.contains(k)) continue;
            if (have.add(k)) out.add(lineOfKey(k));
        }
        if (on) for (String k : keys) if (have.add(k)) out.add(lineOfKey(k));
        if (out.size() > 4096) return false;
        StringBuilder b = new StringBuilder();
        for (String l : out) b.append(l).append('\n');
        return writeAtomic(new File(dir, name), b.toString());
    }

    // ---------- My textures (texlib.txt) ----------
    static ArrayList<Saved> readLib(File dir) {
        ArrayList<Saved> lib = new ArrayList<Saved>();
        LinkedHashSet<String> seen = new LinkedHashSet<String>();
        for (String l : read(new File(dir, "texlib.txt"), 400000).split("\n")) {
            String k = keyOfLine(l);
            if (k == null || !seen.add(k)) continue;
            Saved s = new Saved();
            s.key = k;
            String[] p = l.trim().split("\\s+", 5);
            String rest = p.length > 4 ? p[4] : "";
            int bar = rest.indexOf('|');
            if (bar >= 0) {
                String[] g = rest.substring(0, bar).trim().split("~");
                s.grp = grpOk(g[0]);
                s.set = g.length > 1 ? g[1].replaceAll("[^a-z0-9]", "") : "";
                s.restore = g.length > 2 && g[2].trim().equals("r");
                s.name = cleanName(rest.substring(bar + 1));
            } else {
                s.name = cleanName(rest);
            }
            if (s.name.length() == 0) s.name = "Texture";
            lib.add(s);
        }
        return lib;
    }

    static boolean writeLib(File dir, List<Saved> lib) {
        StringBuilder b = new StringBuilder();
        for (Saved s : lib) {
            b.append(lineOfKey(s.key)).append(' ').append(grpOk(s.grp));
            if (s.set.length() > 0 || s.restore) b.append('~').append(s.set);
            if (s.restore) b.append("~r");
            b.append('|').append(s.name.length() == 0 ? "Texture" : s.name).append('\n');
        }
        return writeAtomic(new File(dir, "texlib.txt"), b.toString());
    }

    /** One unit = one texture, or the members of one set. */
    static ArrayList<ArrayList<Saved>> units(List<Saved> lib) {
        ArrayList<ArrayList<Saved>> out = new ArrayList<ArrayList<Saved>>();
        LinkedHashMap<String, ArrayList<Saved>> sets = new LinkedHashMap<String, ArrayList<Saved>>();
        for (Saved s : lib) {
            if (s.set.length() == 0) { ArrayList<Saved> u = new ArrayList<Saved>(); u.add(s); out.add(u); continue; }
            ArrayList<Saved> u = sets.get(s.set);
            if (u == null) { u = new ArrayList<Saved>(); sets.put(s.set, u); out.add(u); }
            u.add(s);
        }
        return out;
    }

    // ---------- v0.79: states, filters, text ----------
    static final int ST_NONE = 0, ST_HID = 1, ST_SHOWN = 2, ST_REST = 3;

    /** What the menu knows about a texture: what was sent from the menu in this game (chip H / S / R), else what the saved rules do at load. */
    static int stateOf(String chip, boolean inHid, boolean inOri) {
        if ("H".equals(chip)) return ST_HID;
        if ("S".equals(chip)) return ST_SHOWN;
        if ("R".equals(chip)) return ST_REST;
        if ("O".equals(chip)) return ST_NONE;                 // v0.81: Look on after a Restore: the texture has its look again
        if (inHid) return ST_HID;
        if (inOri) return ST_REST;
        return ST_NONE;
    }

    /** Saved = in My textures, or a rule that is applied at every game start. */
    static boolean isSaved(String key, Collection<String> lib, Collection<String> hid, Collection<String> ori) {
        return lib.contains(key) || hid.contains(key) || ori.contains(key);
    }

    static final class Filtered {
        ArrayList<Row> rows = new ArrayList<Row>();
        int skipped;
    }

    /** The first list of the finder. Hide mode normally leaves out what cannot be hidden and the scope / lobby sizes; "everything" keeps all. */
    static Filtered rootRows(List<Row> all, boolean hideMode, boolean everything) {
        Filtered f = new Filtered();
        for (Row r : all) {
            if (hideMode && !everything) {
                if (!r.canHide) continue;
                if (guarded(r)) { f.skipped++; continue; }
            }
            f.rows.add(r);
        }
        return f;
    }

    /** 0 all, 1 hidden, 2 not hidden, 3 saved, 4 not saved. */
    static ArrayList<Row> filterRows(List<Row> rows, int f, Map<String, String> chip, Set<String> hid, Set<String> ori, Set<String> lib) {
        ArrayList<Row> out = new ArrayList<Row>();
        for (Row r : rows) {
            String k = r.key();
            int st = stateOf(chip.get(k), hid.contains(k), ori.contains(k));
            boolean sv = isSaved(k, lib, hid, ori);
            boolean ok = f == 0 || (f == 1 && st == ST_HID) || (f == 2 && st != ST_HID) || (f == 3 && sv) || (f == 4 && !sv);
            if (ok) out.add(r);
        }
        return out;
    }

    static Row rowOfKey(String key) {
        String[] p = key.split("\\|");
        Row r = new Row();
        r.fmt = Integer.parseInt(p[0]); r.w = Integer.parseInt(p[1]); r.h = Integer.parseInt(p[2]); r.hash = p[3];
        r.canHide = true;
        return r;
    }

    /** Textures hidden from the menu in this game that are not saved anywhere (they come back at the next game start). */
    static ArrayList<Row> unsavedHidden(Map<String, String> chip, Set<String> lib, Set<String> hid, Set<String> ori) {
        ArrayList<Row> out = new ArrayList<Row>();
        for (Map.Entry<String, String> e : chip.entrySet()) {
            if (!"H".equals(e.getValue())) continue;
            if (isSaved(e.getKey(), lib, hid, ori)) continue;
            try { out.add(rowOfKey(e.getKey())); } catch (RuntimeException ignored) { }
        }
        return out;
    }

    /** v0.87 Cancel finder: the "op hash" lines that put every texture the finder touched back to how it was BEFORE the test.
     *  What the saved rules say is the "before": a saved Hide stays hidden, a saved Restore stays restored. The caller then forgets the chips of these keys. */
    static ArrayList<String> cancelOps(Collection<String> keys, Map<String, String> chip, Collection<String> hid, Collection<String> ori) {
        ArrayList<String> out = new ArrayList<String>();
        for (String k : keys) {
            String c = chip.get(k);
            if (c == null) continue;
            boolean h = hid.contains(k), o = ori.contains(k) && !h;
            String op = null;
            if ("H".equals(c) && !h) op = "u";            // the finder hid it, it was visible: show it
            else if ("S".equals(c) && h) op = "h";        // the finder showed it, but a saved rule hides it: hide it again
            else if ("R".equals(c) && !o) op = "f";       // the finder restored it, it had its look: look on
            else if ("O".equals(c) && o) op = "r";        // looked on again, but a saved rule restores it: restore again
            if (op == null) continue;
            try { out.add(op + " " + rowOfKey(k).hash); } catch (RuntimeException ignored) { }
        }
        return out;
    }

    static ArrayList<String> keysWith(Map<String, String> chip, String val) {
        ArrayList<String> out = new ArrayList<String>();
        for (Map.Entry<String, String> e : chip.entrySet()) if (val.equals(e.getValue())) out.add(e.getKey());
        return out;
    }

    /** Value of "key=123" in a space separated text, -1 when it is not there. */
    static int kvInt(String s, String key) {
        if (s == null) return -1;
        for (String t : s.trim().split("[ |]+")) {
            if (t.startsWith(key + "=")) {
                try { return Integer.parseInt(t.substring(key.length() + 1)); } catch (NumberFormatException e) { return -1; }
            }
        }
        return -1;
    }

    /** The module's last result ("hidden=1 shown=0 ... nocopy=15") in words. */
    static String friendlyLast(String s) {
        if (s == null) return "";
        s = s.trim();
        if (s.indexOf('=') < 0) return s;
        String[] k = {"hidden", "shown", "restored", "missing", "nocopy", "backup", "nobackup"};
        String[] n = {"hidden", "shown", "restored", "not loaded now", "can't show", "GPU backups", "no backup"};
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < k.length; i++) {
            int v = kvInt(s, k[i]);
            if (v < 0) continue;
            if (i >= 3 && v == 0) continue;
            if (b.length() > 0) b.append(" · ");
            b.append(n[i]).append(' ').append(v);
        }
        return b.toString();
    }

    static String newSetId() { return "s" + Long.toString(System.currentTimeMillis(), 36); }
}
