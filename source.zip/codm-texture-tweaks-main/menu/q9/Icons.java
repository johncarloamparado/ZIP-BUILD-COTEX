package q9;

import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.drawable.Drawable;
import java.util.HashMap;

/** v1.10: the icons of the live menu (the CODM Blocky Icons pack, the same drawings as the WebUI). Each icon is a Path built from IconData
 *  (absolute M / L / C / Q / Z), drawn as a 24 x 24 outline with a stroke of 2, round caps and joins, in one color. No bitmaps, no resources. */
final class Icons {
    private Icons() { }

    private static final HashMap<String, Path> CACHE = new HashMap<String, Path>();
    private static HashMap<String, Integer> index;

    /** The path of an icon in the 24 x 24 box, or null when the name is unknown. */
    static synchronized Path path(String name) {
        if (name == null) return null;
        Path p = CACHE.get(name);
        if (p != null) return p;
        if (index == null) {
            index = new HashMap<String, Integer>();
            for (int i = 0; i < IconData.NAMES.length; i++) index.put(IconData.NAMES[i], i);
        }
        Integer at = index.get(name);
        if (at == null) return null;
        p = parse(IconData.PATHS[at]);
        CACHE.put(name, p);
        return p;
    }

    /** Parses "M x y L x y C x1 y1 x2 y2 x y Q x1 y1 x y Z" (absolute only, numbers apart by a space, no space needed after a letter). */
    static Path parse(String s) {
        Path p = new Path();
        int n = s.length(), i = 0;
        float[] v = new float[6];
        while (i < n) {
            char c = s.charAt(i++);
            int k = c == 'M' || c == 'L' ? 2 : (c == 'Q' ? 4 : (c == 'C' ? 6 : 0));
            for (int j = 0; j < k; j++) {
                while (i < n && s.charAt(i) == ' ') i++;
                int b = i;
                while (i < n && s.charAt(i) != ' ' && !Character.isLetter(s.charAt(i))) i++;
                v[j] = Float.parseFloat(s.substring(b, i));
            }
            if (c == 'M') p.moveTo(v[0], v[1]);
            else if (c == 'L') p.lineTo(v[0], v[1]);
            else if (c == 'Q') p.quadTo(v[0], v[1], v[2], v[3]);
            else if (c == 'C') p.cubicTo(v[0], v[1], v[2], v[3], v[4], v[5]);
            else if (c == 'Z') p.close();
        }
        return p;
    }

    /** A square drawable of px pixels. setColor recolors it (the button text color changes with the state). */
    static final class Ico extends Drawable {
        private final Path path;
        private final Paint paint = new Paint();
        private final int px;
        Ico(Path path, int px, int color) {
            this.path = path;
            this.px = px;
            paint.setAntiAlias(true);
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(2f);
            paint.setStrokeCap(Paint.Cap.ROUND);
            paint.setStrokeJoin(Paint.Join.ROUND);
            paint.setColor(color);
            setBounds(0, 0, px, px);
        }
        void setColor(int color) { paint.setColor(color); invalidateSelf(); }
        public void draw(Canvas canvas) {
            canvas.save();
            canvas.translate(getBounds().left, getBounds().top);
            canvas.scale(px / 24f, px / 24f);
            canvas.drawPath(path, paint);
            canvas.restore();
        }
        public int getIntrinsicWidth() { return px; }
        public int getIntrinsicHeight() { return px; }
        public void setAlpha(int a) { paint.setAlpha(a); }
        public void setColorFilter(ColorFilter f) { paint.setColorFilter(f); }
        public int getOpacity() { return -3; }        // PixelFormat.TRANSLUCENT
    }

    static Ico make(String name, int px, int color) {
        Path p = path(name);
        return p == null ? null : new Ico(p, px, color);
    }

    /** Which icon goes with a button label (the start of the text decides). null = no icon. The more specific words come first. */
    static String forLabel(String t) {
        if (t == null) return null;
        for (int i = 0; i + 1 < MAP.length; i += 2) {
            String k = MAP[i];
            if (!t.startsWith(k)) continue;
            if (t.length() > k.length() && Character.isLetter(t.charAt(k.length())) && Character.isLetter(k.charAt(k.length() - 1))) continue;   // "No" is not "Normal", "Del" is not "Delay"
            return MAP[i + 1];
        }
        return null;
    }

    private static final String[] MAP = {
        "← Back to", "back", "←", "back", "✕", "close",
        "1st half", "half-first", "2nd half", "half-second",
        "Hide all", "hide", "Show all", "show", "Hide hidden", "hide", "Hide (", "hide", "Hide", "hide",
        "Show hidden", "show-hidden", "Show", "show",
        "Restore (", "restore", "Restore", "restore", "Look on", "look-on",
        "Save as skip", "skip", "Save as set", "save-set", "Save hidden", "save-hidden", "Save", "save",
        "Make group", "make-group", "Group", "group", "Ungroup", "ungroup",
        "Singles", "single", "Folders", "folder", "Skipped", "skipped-list",
        "Cancel finder", "cancel-search", "Cancel", "close",
        "Click again", "delete-armed", "Again", "delete-armed", "Delete", "delete", "Del", "delete",
        "Rename", "rename", "Reload list", "refresh", "NARROW DOWN", "narrow-down",
        "Q9 icon: ON", "icon-on", "Q9 icon: OFF", "icon-off",
        "Window size", "window-size", "Order:", "sort", "Wait after", "wait", "List limit", "limit",
        "Yes", "check", "No", "cross"
    };
}
