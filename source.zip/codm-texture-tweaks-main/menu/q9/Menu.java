package q9;

import android.app.Activity;
import android.app.Application;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;

/**
 * v0.78: in-game menu for the Live test. A movable Q9 button and a movable window with two tabs:
 *   Find         : the list of textures from the log (all since the game started, or only between Mark A and Mark B), a "family" navigator
 *                  (pick the 1st / 2nd half, again and again), Hide / Show / Restore live, and Save.
 *   My textures  : the saved textures (the SAME texlib.txt / hidden.txt / orig.txt the WebUI uses), each with an ON / OFF switch, Rename, Delete.
 * Files and lists are handled by Data.java (unit-tested). This class only draws and sends commands (mark.txt, livecmd.txt).
 * Loaded by main.cpp through InMemoryDexClassLoader; every entry point is wrapped so that an error can never reach the game.
 */
public final class Menu {
    private static final Handler H = new Handler(Looper.getMainLooper());
    private static final int[][] SIZES = {{300, 230}, {360, 290}, {440, 340}};
    private static File dir;
    private static Application app;
    private static Activity act;
    private static FrameLayout overlay;
    private static LinearLayout win, body;
    private static ScrollView scroll;
    private static TextView status, fab;
    private static float density = 2f;
    private static int sw = 1280, sh = 720;
    private static boolean started, firstOk, open;
    private static int fabX = -1, fabY = 60, winX = -1, winY = 8, size = 1;

    // finder state
    private static int tab = 0, mode = 0;
    private static boolean marksOnly = false, listLoaded = false;
    private static ArrayList<Data.Row> root = new ArrayList<Data.Row>();
    private static int skipped = 0;
    private static final ArrayList<Node> path = new ArrayList<Node>();
    private static final HashMap<String, String> chip = new HashMap<String, String>();
    private static ArrayList<Data.Row> qFirst, qSecond;           // the "is it gone?" question (a half was just hidden / restored)
    private static int qKind = 0;                                  // 0 none, 1 hide, 2 restore
    // form (save / rename)
    private static int formKind = 0;                               // 0 none, 1 save, 2 rename
    private static ArrayList<Data.Row> formRows;
    private static ArrayList<Data.Saved> formUnit;
    private static String formGrp = "plants";
    private static boolean formAsSet = false;
    private static EditText nameEt;
    private static String delArm = "";

    static final class Node {
        String label;
        ArrayList<Data.Row> rows;
        Node(String l, ArrayList<Data.Row> r) { label = l; rows = r; }
    }

    /** Called once by the module (any thread). */
    public static synchronized void start(Application a, String d) {
        if (started) return;
        started = true;
        app = a;
        dir = new File(d);
        try {
            app.registerActivityLifecycleCallbacks(new Application.ActivityLifecycleCallbacks() {
                public void onActivityResumed(Activity x) { act = x; }
                public void onActivityCreated(Activity x, Bundle b) { }
                public void onActivityStarted(Activity x) { }
                public void onActivityPaused(Activity x) { }
                public void onActivityStopped(Activity x) { }
                public void onActivitySaveInstanceState(Activity x, Bundle b) { }
                public void onActivityDestroyed(Activity x) { if (act == x) act = null; }
            });
        } catch (Throwable t) {
            err("callbacks", t);
        }
        H.post(TICK);
    }

    private static final Runnable TICK = new Runnable() {
        public void run() {
            try {
                Activity a = findAct();
                if (a != null) attach(a);
                if (open && win != null) refreshStatus();
            } catch (Throwable t) {
                err("tick", t);
            }
            H.postDelayed(this, 3000);
        }
    };

    private static Activity findAct() {
        try {
            Class<?> c = Class.forName("com.unity3d.player.UnityPlayer", true, Menu.class.getClassLoader());
            Object o = c.getField("currentActivity").get(null);
            if (o instanceof Activity && !((Activity) o).isFinishing()) return (Activity) o;
        } catch (Throwable ignored) {
        }
        Activity a = act;
        return (a != null && !a.isFinishing()) ? a : null;
    }

    // ---------- small view helpers ----------
    private static int dp(float v) { return (int) (v * density + 0.5f); }

    private static GradientDrawable box(int color, float radiusDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(radiusDp));
        return g;
    }

    private static Button btn(Activity a, String text, int color) {
        Button b = new Button(a);
        b.setText(text);
        b.setAllCaps(false);
        b.setTextSize(12);
        b.setTextColor(Color.WHITE);
        b.setMinHeight(0);
        b.setMinimumHeight(0);
        b.setMinWidth(0);
        b.setMinimumWidth(0);
        b.setPadding(dp(8), dp(6), dp(8), dp(6));
        b.setBackground(box(color, 8));
        return b;
    }

    private static Button small(Activity a, String text, int color, View.OnClickListener l) {
        Button b = btn(a, text, color);
        b.setTextSize(11);
        b.setPadding(dp(7), dp(4), dp(7), dp(4));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        p.leftMargin = dp(3);
        b.setLayoutParams(p);
        b.setOnClickListener(l);
        return b;
    }

    private static LinearLayout hrow(Activity a) {
        LinearLayout l = new LinearLayout(a);
        l.setOrientation(LinearLayout.HORIZONTAL);
        return l;
    }

    private static LinearLayout.LayoutParams wt(int m) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        p.setMargins(m, m, m, m);
        return p;
    }

    private static TextView txt(Activity a, String s, int size, int color) {
        TextView t = new TextView(a);
        t.setText(s);
        t.setTextSize(size);
        t.setTextColor(color);
        return t;
    }

    private static void line(Activity a, String s) { body.addView(txt(a, s, 11, 0xFF9AA4B0)); }

    // ---------- the overlay ----------
    private static void attach(final Activity a) {
        if (overlay != null && overlay.getParent() != null && overlay.getContext() == a) return;
        if (overlay != null && overlay.getParent() != null) ((ViewGroup) overlay.getParent()).removeView(overlay);
        density = a.getResources().getDisplayMetrics().density;
        sw = a.getResources().getDisplayMetrics().widthPixels;
        sh = a.getResources().getDisplayMetrics().heightPixels;
        loadUi();
        overlay = new FrameLayout(a);

        fab = new TextView(a);
        fab.setText("Q9");
        fab.setTextColor(Color.WHITE);
        fab.setTextSize(12);
        fab.setGravity(Gravity.CENTER);
        GradientDrawable fb = new GradientDrawable();
        fb.setShape(GradientDrawable.OVAL);
        fb.setColor(0xB32F6FED);
        fab.setBackground(fb);
        if (fabX < 0) fabX = sw - dp(56);
        FrameLayout.LayoutParams fl = new FrameLayout.LayoutParams(dp(40), dp(40));
        fl.gravity = Gravity.TOP | Gravity.LEFT;
        fl.leftMargin = clampX(fabX, dp(40));
        fl.topMargin = clampY(fabY, dp(40));
        overlay.addView(fab, fl);
        fab.setOnTouchListener(dragger(fab, true));

        buildWindow(a);
        a.addContentView(overlay, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        if (!firstOk) {
            firstOk = true;
            new File(dir, "menu_try.txt").delete();
            put("menu_state.txt", "ok attached to " + a.getClass().getName() + "\n");
        }
        win.setVisibility(open ? View.VISIBLE : View.GONE);
        refreshStatus();
        renderBody();
    }

    private static int clampX(int x, int w) { return Math.max(0, Math.min(x, sw - w)); }
    private static int clampY(int y, int h) { return Math.max(0, Math.min(y, sh - h)); }

    /** Drag: the touched view moves (title bar moves the window, the Q9 button moves itself). A tap on the Q9 button opens / closes the window. */
    private static View.OnTouchListener dragger(final View target, final boolean isFab) {
        return new View.OnTouchListener() {
            float dx, dy, sx, sy;
            boolean moved;
            public boolean onTouch(View v, MotionEvent e) {
                FrameLayout.LayoutParams lp = (FrameLayout.LayoutParams) target.getLayoutParams();
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        sx = e.getRawX(); sy = e.getRawY(); dx = lp.leftMargin - sx; dy = lp.topMargin - sy; moved = false;
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        if (Math.abs(e.getRawX() - sx) + Math.abs(e.getRawY() - sy) > dp(8)) moved = true;
                        if (moved) {
                            int w = lp.width > 0 ? lp.width : dp(120), h = lp.height > 0 ? lp.height : dp(40);
                            lp.leftMargin = clampX((int) (e.getRawX() + dx), w);
                            lp.topMargin = clampY((int) (e.getRawY() + dy), isFab ? h : dp(40));
                            target.setLayoutParams(lp);
                        }
                        return true;
                    case MotionEvent.ACTION_UP:
                        if (moved) {
                            if (isFab) { fabX = lp.leftMargin; fabY = lp.topMargin; } else { winX = lp.leftMargin; winY = lp.topMargin; }
                            saveUi();
                        } else if (isFab) toggle();
                        return true;
                    default:
                        return true;
                }
            }
        };
    }

    private static void buildWindow(final Activity a) {
        int w = Math.min(dp(SIZES[size][0]), sw - dp(16)), h = Math.min(dp(SIZES[size][1]), sh - dp(16));
        win = new LinearLayout(a);
        win.setOrientation(LinearLayout.VERTICAL);
        win.setPadding(dp(6), dp(6), dp(6), dp(6));
        win.setBackground(box(0xEB121820, 12));
        win.setClickable(true);

        LinearLayout head = hrow(a);
        head.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = txt(a, "≡ Q9 Live test   (drag here)", 12, Color.WHITE);
        head.addView(title, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        head.addView(small(a, "S/M/L", 0xFF2B3544, new View.OnClickListener() { public void onClick(View v) { size = (size + 1) % 3; saveUi(); rebuildWindow(); } }));
        head.addView(small(a, "X", 0xFF2B3544, new View.OnClickListener() { public void onClick(View v) { toggle(); } }));
        win.addView(head);

        LinearLayout tabs = hrow(a);
        tabs.addView(tabBtn(a, "Find", 0), wt(dp(2)));
        tabs.addView(tabBtn(a, "My textures (" + Data.readLib(dir).size() + ")", 1), wt(dp(2)));
        win.addView(tabs);

        status = txt(a, "", 11, 0xFF9AA4B0);
        win.addView(status);

        scroll = new ScrollView(a);
        body = new LinearLayout(a);
        body.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(body);
        win.addView(scroll, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        FrameLayout.LayoutParams pl = new FrameLayout.LayoutParams(w, h);
        pl.gravity = Gravity.TOP | Gravity.LEFT;
        pl.leftMargin = clampX(winX < 0 ? sw - w - dp(56) : winX, w);
        pl.topMargin = clampY(winY, h);
        overlay.addView(win, pl);
        head.setOnTouchListener(dragger(win, false));
    }

    private static void rebuildWindow() {
        if (overlay == null) return;
        overlay.removeView(win);
        buildWindow((Activity) overlay.getContext());
        win.setVisibility(open ? View.VISIBLE : View.GONE);
        refreshStatus();
        renderBody();
    }

    private static Button tabBtn(Activity a, String text, final int t) {
        Button b = btn(a, text, tab == t ? 0xFF2F6FED : 0xFF2B3544);
        b.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { tab = t; formKind = 0; delArm = ""; rebuildWindow(); } });
        return b;
    }

    private static void toggle() {
        if (win == null) return;
        open = win.getVisibility() != View.VISIBLE;
        win.setVisibility(open ? View.VISIBLE : View.GONE);
        if (open) { refreshStatus(); if (!listLoaded) loadList(); else renderBody(); }
    }

    // ---------- files ----------
    private static void loadUi() {
        String s = Data.readSmall(new File(dir, "menu_ui.txt")).trim();
        if (s.length() == 0) return;
        try {
            String[] p = s.split("\\s+");
            fabX = Integer.parseInt(p[0]); fabY = Integer.parseInt(p[1]); winX = Integer.parseInt(p[2]); winY = Integer.parseInt(p[3]);
            size = Math.max(0, Math.min(2, Integer.parseInt(p[4])));
        } catch (Throwable ignored) {
        }
    }

    private static void saveUi() { put("menu_ui.txt", fabX + " " + fabY + " " + winX + " " + winY + " " + size + "\n"); }

    private static boolean put(String name, String text) {
        try {
            java.io.FileOutputStream f = new java.io.FileOutputStream(new File(dir, name), false);
            try { f.write(text.getBytes("UTF-8")); } finally { f.close(); }
            return true;
        } catch (Throwable t) {
            if (!name.equals("menu_state.txt")) err("write " + name, t);
            return false;
        }
    }

    private static void err(String where, Throwable t) {
        try {
            java.io.FileOutputStream f = new java.io.FileOutputStream(new File(dir, "menu_state.txt"), false);
            try { f.write(("err " + where + ": " + t + "\n").getBytes("UTF-8")); } finally { f.close(); }
        } catch (Throwable ignored) {
        }
    }

    private static String kv(String text, String key) {
        int i = text.indexOf(key + "=");
        if (i < 0 || (i > 0 && text.charAt(i - 1) != '\n' && text.charAt(i - 1) != '|')) return null;
        int e = i + key.length() + 1, j = e;
        while (j < text.length() && text.charAt(j) != '\n' && text.charAt(j) != '|') j++;
        return text.substring(e, j).trim();
    }

    private static void refreshStatus() {
        if (status == null) return;
        String live = Data.readSmall(new File(dir, "live.txt")).trim();
        if (!live.startsWith("1")) { status.setText("Live test mode is OFF (WebUI > Advanced). Restart CODM after turning it on."); return; }
        String st = Data.readSmall(new File(dir, "codm_tex.status"));
        String cap = kv(st, "lv_cap"), n = kv(st, "lv_hash"), kb = kv(st, "lv_kb"), last = kv(st, "lv_last");
        if (cap == null) { status.setText("Waiting for the module..."); return; }
        status.setText(("1".equals(cap) ? "Capturing" : "Not capturing") + " · " + (n == null ? "0" : n) + " copies (" + (kb == null ? "0" : kb) + " KB)"
                + (last != null && last.length() > 0 ? " · " + last : ""));
    }

    // ---------- commands ----------
    private static void mark(String lab) {
        if (!put("mark.txt", lab + "\n")) { say("Could not write mark.txt"); return; }
        if ("X".equals(lab)) { say("Copies cleared."); }
        else say(lab.equals("A") ? "Mark A sent. Now do the thing in the game." : "Mark B sent. Updating the list...");
        H.postDelayed(new Runnable() { public void run() { refreshStatus(); } }, 2000);
        if ("B".equals(lab) || "A".equals(lab)) H.postDelayed(new Runnable() { public void run() { loadList(); } }, 2000);
    }

    private static void say(String s) { if (status != null) status.setText(s); }

    /** Sends "op hash" lines; more than 120 lines go out in pieces (the module reads the file once a second). */
    private static void sendLines(final ArrayList<String> lines, final String what) {
        if (lines.isEmpty()) { say("Nothing to send."); return; }
        final int step = 120;
        for (int i = 0; i * step < lines.size(); i++) {
            final int from = i * step;
            Runnable r = new Runnable() {
                public void run() {
                    StringBuilder sb = new StringBuilder();
                    for (int k = from; k < Math.min(lines.size(), from + step); k++) sb.append(lines.get(k)).append('\n');
                    if (!put("livecmd.txt", sb.toString())) say("Could not write livecmd.txt");
                }
            };
            if (i == 0) r.run(); else H.postDelayed(r, 1500L * i);
        }
        say(what + " sent (" + lines.size() + "). Look at the game.");
        H.postDelayed(new Runnable() { public void run() { refreshStatus(); } }, 2500);
    }

    private static void addOps(ArrayList<String> out, String op, List<Data.Row> rows) { for (Data.Row r : rows) out.add(op + " " + r.hash); }

    private static void mark(List<Data.Row> rows, String c) { for (Data.Row r : rows) chip.put(r.key(), c); }

    /** Hide / Restore a part of the current set. Hide: the rest of the set is shown again, so only this part is hidden. */
    private static void doPart(ArrayList<Data.Row> part, ArrayList<Data.Row> setRows, ArrayList<Data.Row> other, String label) {
        ArrayList<String> ls = new ArrayList<String>();
        if (mode == 0) {
            addOps(ls, "h", part);
            if (other != null) addOps(ls, "u", other);
            mark(part, "H");
            if (other != null) mark(other, "S");
        } else {
            addOps(ls, "r", part);
            mark(part, "R");
        }
        sendLines(ls, label);
        renderBody();
    }

    // ---------- the list ----------
    private static void loadList() {
        new Thread(new Runnable() {
            public void run() {
                final String log = Data.read(new File(dir, "codm_tex.log"), 3 * 1024 * 1024);
                final ArrayList<Data.Row> all = Data.parseLog(log, marksOnly);
                final boolean hm = Data.hasMarks(log);
                H.post(new Runnable() {
                    public void run() {
                        setRoot(all);
                        listLoaded = true;
                        if (marksOnly && !hm) say("No Mark A in this game session yet.");
                        renderBody();
                    }
                });
            }
        }).start();
    }

    private static void setRoot(ArrayList<Data.Row> all) {
        root = new ArrayList<Data.Row>();
        skipped = 0;
        for (Data.Row r : all) {
            if (mode == 0) { if (!r.canHide) continue; if (Data.guarded(r)) { skipped++; continue; } }
            root.add(r);
        }
        path.clear();
        path.add(new Node("All " + root.size(), root));
        qKind = 0;
    }

    private static ArrayList<Data.Row> cur() { return path.isEmpty() ? new ArrayList<Data.Row>() : path.get(path.size() - 1).rows; }

    private static void into(ArrayList<Data.Row> part, String name) {
        path.add(new Node(name + " " + part.size(), part));
        qKind = 0;
        renderBody();
    }

    private static void up(int toLevel) {
        while (path.size() > toLevel + 1 && path.size() > 1) path.remove(path.size() - 1);
        qKind = 0;
        renderBody();
    }

    // ---------- drawing ----------
    private static void renderBody() {
        if (body == null || overlay == null) return;
        Activity a = (Activity) overlay.getContext();
        body.removeAllViews();
        try {
            if (formKind != 0) drawForm(a);
            if (tab == 0) drawFind(a); else drawSaved(a);
        } catch (Throwable t) {
            err("draw", t);
        }
    }

    private static void drawFind(final Activity a) {
        // capture row
        LinearLayout r1 = hrow(a);
        Button mA = btn(a, "Mark A", 0xFF2F6FED), mB = btn(a, "Mark B", 0xFF2F6FED), mX = btn(a, "Clear copies", 0xFF2B3544);
        mA.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { mark("A"); } });
        mB.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { mark("B"); } });
        mX.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { mark("X"); chip.clear(); } });
        r1.addView(mA, wt(dp(2))); r1.addView(mB, wt(dp(2))); r1.addView(mX, wt(dp(2)));
        body.addView(r1);
        // source / mode row
        LinearLayout r2 = hrow(a);
        Button md = btn(a, mode == 0 ? "Finder: Hide" : "Finder: Restore", mode == 0 ? 0xFF8A3B3B : 0xFF34507E);
        md.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { mode = 1 - mode; listLoaded = false; loadList(); } });
        Button sc = btn(a, marksOnly ? "List: A to B" : "List: all since start", 0xFF2B3544);
        sc.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { marksOnly = !marksOnly; listLoaded = false; loadList(); } });
        Button rf = btn(a, "Refresh", 0xFF2B3544);
        rf.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { loadList(); } });
        r2.addView(md, wt(dp(2))); r2.addView(sc, wt(dp(2))); r2.addView(rf, wt(dp(2)));
        body.addView(r2);
        if (!listLoaded) { line(a, "Loading the list..."); return; }
        if (root.isEmpty()) { line(a, marksOnly ? "Nothing between Mark A and Mark B." : "Nothing listed yet. Play for a moment (the log needs the game's textures), then Refresh."); return; }

        // family path (tap a step to go back to it)
        HorizontalScrollView hs = new HorizontalScrollView(a);
        LinearLayout crumbs = hrow(a);
        for (int i = 0; i < path.size(); i++) {
            final int lvl = i;
            if (i > 0) crumbs.addView(txt(a, " › ", 12, 0xFF9AA4B0));
            Button c = small(a, path.get(i).label, i == path.size() - 1 ? 0xFF2F6FED : 0xFF2B3544, new View.OnClickListener() { public void onClick(View v) { up(lvl); } });
            crumbs.addView(c);
        }
        hs.addView(crumbs);
        body.addView(hs);

        final ArrayList<Data.Row> set = cur();
        final ArrayList<Data.Row> h1 = Data.half(set, 0), h2 = Data.half(set, 1);
        final String verb = mode == 0 ? "Hide" : "Restore";
        line(a, "Testing " + set.size() + " texture" + (set.size() == 1 ? "" : "s") + (skipped > 0 && mode == 0 ? "  (" + skipped + " scope / lobby sizes are left out)" : ""));

        // question after a half was hidden / restored
        if (qKind != 0 && qFirst != null) {
            LinearLayout q = hrow(a);
            q.addView(txt(a, qKind == 1 ? "Is it gone?  " : "Is it fixed?  ", 12, 0xFFFBBF24));
            q.addView(small(a, "Yes", 0xFF2F6B4F, new View.OnClickListener() { public void onClick(View v) { ArrayList<Data.Row> p = qFirst; into(p, "yes"); } }));
            q.addView(small(a, "No", 0xFF8A3B3B, new View.OnClickListener() { public void onClick(View v) { ArrayList<Data.Row> p = qSecond; into(p, "other"); } }));
            q.addView(small(a, "Skip", 0xFF2B3544, new View.OnClickListener() { public void onClick(View v) { qKind = 0; renderBody(); } }));
            body.addView(q);
        }

        // actions on the current set
        if (set.size() > 0) {
            LinearLayout r3 = hrow(a);
            r3.addView(btn(a, verb + " all", mode == 0 ? 0xFF8A3B3B : 0xFF34507E), wt(dp(2)));
            if (set.size() > 1) {
                r3.addView(btn(a, verb + " 1st half", mode == 0 ? 0xFF8A3B3B : 0xFF34507E), wt(dp(2)));
                r3.addView(btn(a, verb + " 2nd half", mode == 0 ? 0xFF8A3B3B : 0xFF34507E), wt(dp(2)));
            }
            r3.getChildAt(0).setOnClickListener(new View.OnClickListener() { public void onClick(View v) { doPart(set, set, null, verb + " all"); } });
            if (set.size() > 1) {
                r3.getChildAt(1).setOnClickListener(new View.OnClickListener() { public void onClick(View v) {
                    doPart(h1, set, h2, verb + " 1st half"); qKind = mode == 0 ? 1 : 2; qFirst = h1; qSecond = h2; renderBody(); } });
                r3.getChildAt(2).setOnClickListener(new View.OnClickListener() { public void onClick(View v) {
                    doPart(h2, set, h1, verb + " 2nd half"); qKind = mode == 0 ? 1 : 2; qFirst = h2; qSecond = h1; renderBody(); } });
            }
            body.addView(r3);
            if (mode == 0) {
                LinearLayout r4 = hrow(a);
                Button sa = btn(a, "Show all", 0xFF2F6B4F);
                sa.setOnClickListener(new View.OnClickListener() { public void onClick(View v) {
                    ArrayList<String> ls = new ArrayList<String>(); addOps(ls, "u", set); mark(set, "S"); sendLines(ls, "Show all"); renderBody(); } });
                r4.addView(sa, wt(dp(2)));
                if (set.size() > 1) {
                    Button g1 = btn(a, "Go into 1st half (" + h1.size() + ")", 0xFF2B3544), g2 = btn(a, "Go into 2nd half (" + h2.size() + ")", 0xFF2B3544);
                    g1.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { into(h1, "1st"); } });
                    g2.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { into(h2, "2nd"); } });
                    r4.addView(g1, wt(dp(2))); r4.addView(g2, wt(dp(2)));
                }
                body.addView(r4);
            } else if (set.size() > 1) {
                LinearLayout r4 = hrow(a);
                Button g1 = btn(a, "Go into 1st half (" + h1.size() + ")", 0xFF2B3544), g2 = btn(a, "Go into 2nd half (" + h2.size() + ")", 0xFF2B3544);
                g1.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { into(h1, "1st"); } });
                g2.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { into(h2, "2nd"); } });
                r4.addView(g1, wt(dp(2))); r4.addView(g2, wt(dp(2)));
                body.addView(r4);
                line(a, "Restore cannot be undone while playing (restart CODM to reset it).");
            }
            Button sv = btn(a, set.size() == 1 ? "★ Save this texture" : "★ Save these " + set.size() + " together", 0xFF2B3544);
            sv.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { openForm(1, set, null, set.size() > 1); } });
            body.addView(sv, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        }

        line(a, mode == 0 ? "H = hide   S = show   ★ = save" : "R = restore   ★ = save");
        int shown = 0;
        for (final Data.Row c : set) {
            if (shown++ >= 80) { line(a, "... " + (set.size() - 80) + " more. Go into a half to see fewer."); break; }
            LinearLayout rw = hrow(a);
            rw.setGravity(Gravity.CENTER_VERTICAL);
            rw.setPadding(0, dp(3), 0, dp(3));
            String ch = chip.get(c.key());
            String chipText = "H".equals(ch) ? "  [hidden]" : "S".equals(ch) ? "  [shown]" : "R".equals(ch) ? "  [restored]" : "";
            TextView t = txt(a, Data.fmtName(c.fmt) + " " + c.w + "x" + c.h + " · " + Data.sizeText(c.n) + chipText + "\n" + c.hash.substring(0, 8)
                    + (Data.guarded(c) ? "  (scope / lobby size)" : ""), 11, Color.WHITE);
            rw.addView(t, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
            if (mode == 0) {
                rw.addView(small(a, "H", 0xFF8A3B3B, new View.OnClickListener() { public void onClick(View v) { one("h", c, "H"); } }));
                rw.addView(small(a, "S", 0xFF2F6B4F, new View.OnClickListener() { public void onClick(View v) { one("u", c, "S"); } }));
            } else {
                rw.addView(small(a, "R", 0xFF34507E, new View.OnClickListener() { public void onClick(View v) { one("r", c, "R"); } }));
            }
            rw.addView(small(a, "★", 0xFF2B3544, new View.OnClickListener() {
                public void onClick(View v) { ArrayList<Data.Row> l = new ArrayList<Data.Row>(); l.add(c); openForm(1, l, null, false); } }));
            body.addView(rw);
        }
    }

    private static void one(String op, Data.Row c, String ch) {
        ArrayList<String> ls = new ArrayList<String>();
        ls.add(op + " " + c.hash);
        chip.put(c.key(), ch);
        sendLines(ls, op.equals("h") ? "Hide" : op.equals("u") ? "Show" : "Restore");
        renderBody();
    }

    // ---------- save / rename form ----------
    private static void openForm(int kind, ArrayList<Data.Row> rows, ArrayList<Data.Saved> unit, boolean asSet) {
        formKind = kind; formRows = rows; formUnit = unit; formAsSet = asSet;
        if (kind == 1) formGrp = "plants";
        nameEt = null;
        renderBody();
        if (scroll != null) scroll.scrollTo(0, 0);
    }

    private static String autoName() {
        if (formKind == 2 && formUnit != null && !formUnit.isEmpty()) return formUnit.get(0).name;
        if (formRows == null || formRows.isEmpty()) return "Texture";
        Data.Row r = formRows.get(0);
        String base = formRows.size() > 1 ? "Set " + formRows.size() : Data.fmtName(r.fmt) + " " + r.w + "x" + r.h;
        return Data.cleanName(base);
    }

    private static void drawForm(final Activity a) {
        LinearLayout box = new LinearLayout(a);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(6), dp(6), dp(6), dp(6));
        box.setBackground(box(0xFF1F2A38, 8));
        box.addView(txt(a, formKind == 1 ? "Save to My textures (tap the name to type, or just tap Save)" : "Rename", 11, Color.WHITE));
        nameEt = new EditText(a);
        nameEt.setText(autoName());
        nameEt.setTextSize(13);
        nameEt.setTextColor(Color.WHITE);
        nameEt.setSingleLine(true);
        nameEt.setFocusableInTouchMode(true);
        nameEt.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                try {
                    nameEt.requestFocus();
                    InputMethodManager im = (InputMethodManager) a.getSystemService(Context.INPUT_METHOD_SERVICE);
                    if (im != null) im.showSoftInput(nameEt, 0);
                } catch (Throwable ignored) {
                }
            }
        });
        box.addView(nameEt, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        if (formKind == 1) {
            LinearLayout g = hrow(a);
            String[] ids = {"plants", "effects", "other"}, nm = {"Plants", "Effects", "Other"};
            for (int i = 0; i < 3; i++) {
                final String id = ids[i];
                Button b = btn(a, nm[i], formGrp.equals(id) ? 0xFF2F6FED : 0xFF2B3544);
                b.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { String keep = nameEt != null ? nameEt.getText().toString() : ""; formGrp = id; renderBody(); if (nameEt != null && keep.length() > 0) nameEt.setText(keep); } });
                g.addView(b, wt(dp(2)));
            }
            box.addView(g);
            box.addView(txt(a, (mode == 0 ? "It will be a HIDE entry" : "It will be a RESTORE entry") + (formRows != null && formRows.size() > 1 ? " (" + formRows.size() + " textures that work together)" : "") + ", switched ON.", 11, 0xFF9AA4B0));
        }
        LinearLayout r = hrow(a);
        Button ok = btn(a, formKind == 1 ? "Save" : "Rename", 0xFF2F6B4F), no = btn(a, "Cancel", 0xFF2B3544);
        ok.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { submitForm(); } });
        no.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { formKind = 0; renderBody(); } });
        r.addView(ok, wt(dp(2))); r.addView(no, wt(dp(2)));
        box.addView(r);
        body.addView(box);
    }

    private static void submitForm() {
        try {
            String name = Data.cleanName(nameEt != null ? nameEt.getText().toString() : "");
            if (name.length() == 0) name = autoName();
            if (formKind == 1) saveRows(formRows, name, formGrp, mode == 1, formAsSet);
            else if (formKind == 2 && formUnit != null) {
                ArrayList<Data.Saved> lib = Data.readLib(dir);
                for (Data.Saved s : lib) for (Data.Saved u : formUnit) if (s.key.equals(u.key)) s.name = name;
                say(Data.writeLib(dir, lib) ? "Renamed." : "Could not write texlib.txt");
            }
        } catch (Throwable t) {
            err("form", t);
        }
        formKind = 0;
        rebuildWindow();
    }

    private static void saveRows(List<Data.Row> rows, String name, String grp, boolean restore, boolean asSet) {
        ArrayList<Data.Saved> lib = Data.readLib(dir);
        LinkedHashSet<String> have = new LinkedHashSet<String>();
        for (Data.Saved s : lib) have.add(s.key);
        String setId = asSet && rows.size() > 1 ? Data.newSetId() : "";
        ArrayList<String> keys = new ArrayList<String>();
        int added = 0;
        for (Data.Row r : rows) {
            if (!have.add(r.key())) continue;
            Data.Saved s = new Data.Saved();
            s.key = r.key(); s.name = name; s.grp = Data.grpOk(grp); s.set = setId; s.restore = restore;
            lib.add(s); keys.add(r.key()); added++;
        }
        if (added == 0) { say("Already in My textures."); return; }
        boolean ok = Data.writeLib(dir, lib)
                && Data.setRules(dir, restore ? "orig.txt" : "hidden.txt", keys, true)
                && Data.setRules(dir, restore ? "hidden.txt" : "orig.txt", keys, false);
        if (!ok) { say("Could not save (files are not writable)."); return; }
        ArrayList<String> ls = new ArrayList<String>();
        addOps(ls, restore ? "r" : "h", rows);
        sendLines(ls, "Saved " + added + " and switched ON:");
    }

    // ---------- My textures tab ----------
    private static void drawSaved(final Activity a) {
        final ArrayList<Data.Saved> lib = Data.readLib(dir);
        final LinkedHashSet<String> hid = Data.readRuleKeys(dir, "hidden.txt"), ori = Data.readRuleKeys(dir, "orig.txt");
        if (lib.isEmpty()) { line(a, "Nothing saved yet. In Find, tap ★ Save on a texture you found."); return; }
        line(a, "The same list as My textures in the WebUI. ON = the rule is active (it is also applied at every game start). Delete removes it.");
        String[] gid = {"plants", "effects", "other"}, gnm = {"Plants", "Effects", "Other"};
        ArrayList<ArrayList<Data.Saved>> units = Data.units(lib);
        for (int g = 0; g < 3; g++) {
            boolean head = false;
            for (final ArrayList<Data.Saved> u : units) {
                if (!u.get(0).grp.equals(gid[g])) continue;
                if (!head) { body.addView(txt(a, gnm[g], 12, 0xFFFBBF24)); head = true; }
                final boolean restore = u.get(0).restore;
                boolean on = true;
                for (Data.Saved s : u) if (!(restore ? ori : hid).contains(s.key)) on = false;
                final boolean isOn = on;
                LinearLayout rw = hrow(a);
                rw.setGravity(Gravity.CENTER_VERTICAL);
                rw.setPadding(0, dp(3), 0, dp(3));
                rw.addView(txt(a, u.get(0).name + "\n" + (restore ? "Restore" : "Hide") + (u.size() > 1 ? " · " + u.size() + " together" : ""), 11, Color.WHITE), new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
                rw.addView(small(a, isOn ? "ON" : "OFF", isOn ? 0xFF2F6B4F : 0xFF5B3030, new View.OnClickListener() { public void onClick(View v) { toggleUnit(u, restore, !isOn); } }));
                rw.addView(small(a, "Name", 0xFF2B3544, new View.OnClickListener() { public void onClick(View v) { openForm(2, null, u, false); } }));
                final String id = u.get(0).key;
                rw.addView(small(a, delArm.equals(id) ? "Sure?" : "Del", delArm.equals(id) ? 0xFFB23A3A : 0xFF2B3544, new View.OnClickListener() {
                    public void onClick(View v) { if (delArm.equals(id)) deleteUnit(u, restore); else { delArm = id; renderBody(); } } }));
                body.addView(rw);
            }
        }
    }

    private static ArrayList<String> keysOf(List<Data.Saved> u) { ArrayList<String> k = new ArrayList<String>(); for (Data.Saved s : u) k.add(s.key); return k; }

    private static ArrayList<String> opsFor(String op, List<Data.Saved> u) {
        ArrayList<String> l = new ArrayList<String>();
        for (Data.Saved s : u) l.add(op + " " + s.key.substring(s.key.lastIndexOf('|') + 1));
        return l;
    }

    private static void toggleUnit(List<Data.Saved> u, boolean restore, boolean on) {
        if (!Data.setRules(dir, restore ? "orig.txt" : "hidden.txt", keysOf(u), on)) { say("Could not write the rule file."); return; }
        if (on) Data.setRules(dir, restore ? "hidden.txt" : "orig.txt", keysOf(u), false);
        if (restore) { if (on) sendLines(opsFor("r", u), "Restore"); else say("OFF. Restore cannot be undone live; it applies at the next game start."); }
        else sendLines(opsFor(on ? "h" : "u", u), on ? "Hide" : "Show");
        renderBody();
    }

    private static void deleteUnit(List<Data.Saved> u, boolean restore) {
        ArrayList<Data.Saved> lib = Data.readLib(dir);
        ArrayList<String> keys = keysOf(u);
        ArrayList<Data.Saved> keep = new ArrayList<Data.Saved>();
        for (Data.Saved s : lib) if (!keys.contains(s.key)) keep.add(s);
        boolean ok = Data.writeLib(dir, keep) && Data.setRules(dir, "hidden.txt", keys, false) && Data.setRules(dir, "orig.txt", keys, false);
        delArm = "";
        if (!ok) { say("Could not delete."); return; }
        if (!restore) sendLines(opsFor("u", u), "Deleted; Show");
        else say("Deleted.");
        rebuildWindow();
    }
}
