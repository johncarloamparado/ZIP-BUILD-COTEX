package q9;

import android.app.Activity;
import android.app.Application;
import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ScrollView;
import android.widget.TextView;
import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;

/**
 * v0.79: in-game menu for the Live test, three separate movable windows (so nothing is crowded):
 *   Control      : status, Mark A / B, finder mode, the "family" navigator (halves, Yes / No), what is hidden now and whether it is saved.
 *   Textures     : the list of the current set, in its own window (ListView, scrolls smoothly even with thousands of rows), one Hide / Show button per row.
 *   My textures  : the saved textures (the SAME texlib.txt / hidden.txt / orig.txt the WebUI uses): ON / OFF, Name, Delete.
 * Files and lists are handled by Data.java (unit-tested). This class only draws and sends commands (mark.txt, livecmd.txt).
 * Loaded by main.cpp through InMemoryDexClassLoader; every entry point is wrapped so that an error can never reach the game.
 */
public final class Menu {
    private static final Handler H = new Handler(Looper.getMainLooper());

    // palette: dark ink with a sky accent, amber for "careful"
    private static final int INK = 0xF2101720, CARD = 0xFF18222D, CARD2 = 0xFF223040, LINE = 0xFF2C3B4B, SKY = 0xFF38BDF8, SKYTXT = 0xFF05202D;
    private static final int RED = 0xFFEF4444, REDD = 0xFF4A2029, GRN = 0xFF34D399, GRND = 0xFF11473A, AMB = 0xFFFBBF24, AMBD = 0xFF4A3B12;
    private static final int TXT = 0xFFE6EDF3, MUT = 0xFF8B98A8, CLEAR = 0x00000000;

    private static final int[][] BASE = {{292, 340}, {320, 340}, {320, 340}};
    private static final float[] SCALE = {0.85f, 1f, 1.2f};
    private static final String[] WNAME = {"Q9 · Control", "Textures", "My textures"};

    private static File dir;
    private static Application app;
    private static Activity act;
    private static FrameLayout overlay, formCard;
    private static TextView fab, statusC, statusL, statusS;
    private static GradientDrawable fabBg;
    private static float density = 2f;
    private static int sw = 1280, sh = 720;
    private static boolean started, firstOk;
    private static int fabX = -1, fabY = 60, size = 1;

    static final class Win {
        LinearLayout view;
        int x = -1, y = 8;
        boolean open;
    }

    private static final Win[] W = {new Win(), new Win(), new Win()};
    private static LinearLayout cbody, lhead, shead;
    private static ScrollView cscroll;
    private static ListView lview, sview;

    // finder state
    private static int mode = 0, lf = 0;
    private static boolean marksOnly = false, listLoaded = false, everything = false;
    private static ArrayList<Data.Row> allRows = new ArrayList<Data.Row>(), root = new ArrayList<Data.Row>(), lshown = new ArrayList<Data.Row>();
    private static int skipped = 0;
    private static final ArrayList<Node> path = new ArrayList<Node>();
    private static final LinkedHashMap<String, String> chip = new LinkedHashMap<String, String>();   // key -> H hidden / S shown / R restored (this game)
    private static LinkedHashSet<String> rHid = new LinkedHashSet<String>(), rOri = new LinkedHashSet<String>();
    private static final HashMap<String, Data.Saved> libMap = new HashMap<String, Data.Saved>();
    private static ArrayList<Data.Row> qFirst, qSecond;
    private static int qKind = 0;                                  // 0 none, 1 hide, 2 restore
    private static final ArrayList<Object> sitems = new ArrayList<Object>();
    // form (save / rename)
    private static int formKind = 0;                               // 0 none, 1 save, 2 rename
    private static ArrayList<Data.Row> formRows;
    private static ArrayList<Data.Saved> formUnit;
    private static String formGrp = "plants", formKeep = "";
    private static boolean formAsSet = false, formRestore = false;
    private static EditText nameEt;
    private static String delArm = "";
    private static int pollLeft = 0;
    private static boolean polling = false;

    static final class Node {
        String label;
        ArrayList<Data.Row> rows;
        Node(String l, ArrayList<Data.Row> r) { label = l; rows = r; }
    }

    private interface Sel { void on(int i); }

    /** Called once by the module (any thread). */
    public static synchronized void start(Application a, String d) {
        if (started) return;
        started = true;
        app = a;
        dir = new File(d);
        try {
            app.registerActivityLifecycleCallbacks(new Application.ActivityLifecycleCallbacks() {
                public void onActivityResumed(Activity x) { act = x; }
                public void onActivityCreated(Activity x, Bundle b) { }
                public void onActivityStarted(Activity x) { }
                public void onActivityPaused(Activity x) { }
                public void onActivityStopped(Activity x) { }
                public void onActivitySaveInstanceState(Activity x, Bundle b) { }
                public void onActivityDestroyed(Activity x) { if (act == x) act = null; }
            });
        } catch (Throwable t) {
            err("callbacks", t);
        }
        H.post(TICK);
    }

    private static final Runnable TICK = new Runnable() {
        public void run() {
            try {
                Activity a = findAct();
                if (a != null) attach(a);
                if (anyOpen()) refreshStatus();
            } catch (Throwable t) {
                err("tick", t);
            }
            H.postDelayed(this, 3000);
        }
    };

    private static boolean anyOpen() { return W[0].open || W[1].open || W[2].open; }

    private static Activity findAct() {
        try {
            Class<?> c = Class.forName("com.unity3d.player.UnityPlayer", true, Menu.class.getClassLoader());
            Object o = c.getField("currentActivity").get(null);
            if (o instanceof Activity && !((Activity) o).isFinishing()) return (Activity) o;
        } catch (Throwable ignored) {
        }
        Activity a = act;
        return (a != null && !a.isFinishing()) ? a : null;
    }

    // ---------- small view helpers ----------
    private static int dp(float v) { return (int) (v * density + 0.5f); }

    private static GradientDrawable box(int color, float radiusDp, int stroke) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(radiusDp));
        if (stroke != 0) g.setStroke(Math.max(1, dp(1)), stroke);
        return g;
    }

    private static Button btn(Activity a, String text, int fill, int fg) {
        Button b = new Button(a);
        b.setText(text);
        b.setAllCaps(false);
        b.setTextSize(12);
        b.setTextColor(fg);
        b.setMinHeight(0);
        b.setMinimumHeight(0);
        b.setMinWidth(0);
        b.setMinimumWidth(0);
        b.setPadding(dp(10), dp(6), dp(10), dp(6));
        b.setBackground(box(fill, 14, 0));
        return b;
    }

    private static Button sm(Activity a, String text, int fill, int fg, View.OnClickListener l) {
        Button b = btn(a, text, fill, fg);
        b.setTextSize(11);
        b.setPadding(dp(9), dp(4), dp(9), dp(4));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        p.leftMargin = dp(4);
        b.setLayoutParams(p);
        if (l != null) b.setOnClickListener(l);
        return b;
    }

    private static Button prim(Activity a, String t, View.OnClickListener l) { Button b = btn(a, t, SKY, SKYTXT); b.setOnClickListener(l); return b; }
    private static Button neut(Activity a, String t, View.OnClickListener l) { Button b = btn(a, t, CARD2, TXT); b.setOnClickListener(l); return b; }
    private static Button dang(Activity a, String t, View.OnClickListener l) { Button b = btn(a, t, REDD, 0xFFFFB4B4); b.setOnClickListener(l); return b; }
    private static Button good(Activity a, String t, View.OnClickListener l) { Button b = btn(a, t, GRND, 0xFFA7F3D0); b.setOnClickListener(l); return b; }

    private static LinearLayout hrow(Activity a) {
        LinearLayout l = new LinearLayout(a);
        l.setOrientation(LinearLayout.HORIZONTAL);
        l.setGravity(Gravity.CENTER_VERTICAL);
        return l;
    }

    private static LinearLayout vcol(Activity a) {
        LinearLayout l = new LinearLayout(a);
        l.setOrientation(LinearLayout.VERTICAL);
        return l;
    }

    private static LinearLayout.LayoutParams wt(int m) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        p.setMargins(m, m, m, m);
        return p;
    }

    private static LinearLayout.LayoutParams fullW(int top) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        p.topMargin = top;
        return p;
    }

    private static TextView txt(Activity a, String s, int sp, int color, boolean bold) {
        TextView t = new TextView(a);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    private static LinearLayout card(Activity a, int stroke) {
        LinearLayout c = vcol(a);
        c.setPadding(dp(8), dp(7), dp(8), dp(7));
        c.setBackground(box(CARD, 12, stroke));
        cbody.addView(c, fullW(dp(6)));
        return c;
    }

    private static void label(Activity a, LinearLayout c, String s) {
        TextView t = txt(a, s, 9, MUT, true);
        t.setPadding(dp(2), 0, 0, dp(3));
        c.addView(t);
    }

    private static LinearLayout seg(Activity a, String[] labels, int sel, final Sel cb) {
        LinearLayout c = hrow(a);
        c.setPadding(dp(2), dp(2), dp(2), dp(2));
        c.setBackground(box(CARD2, 16, 0));
        for (int i = 0; i < labels.length; i++) {
            final int k = i;
            Button b = btn(a, labels[i], i == sel ? SKY : CLEAR, i == sel ? SKYTXT : MUT);
            b.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { cb.on(k); } });
            c.addView(b, wt(0));
        }
        return c;
    }

    private static String shortHash(String h) { return h.length() > 8 ? h.substring(0, 8) : h; }

    // ---------- the overlay and the three windows ----------
    private static void attach(final Activity a) {
        if (overlay != null && overlay.getParent() != null && overlay.getContext() == a) return;
        if (overlay != null && overlay.getParent() != null) ((ViewGroup) overlay.getParent()).removeView(overlay);
        formCard = null;
        density = a.getResources().getDisplayMetrics().density;
        sw = a.getResources().getDisplayMetrics().widthPixels;
        sh = a.getResources().getDisplayMetrics().heightPixels;
        loadUi();
        reloadRules();
        overlay = new FrameLayout(a);

        fab = new TextView(a);
        fab.setText("Q9");
        fab.setTextColor(SKYTXT);
        fab.setTextSize(12);
        fab.setTypeface(Typeface.DEFAULT_BOLD);
        fab.setGravity(Gravity.CENTER);
        fabBg = new GradientDrawable();
        fabBg.setShape(GradientDrawable.OVAL);
        fabBg.setColor(0xE638BDF8);
        fabBg.setStroke(Math.max(2, dp(2)), 0xFF0B2A3A);
        fab.setBackground(fabBg);
        if (fabX < 0) fabX = sw - dp(56);
        FrameLayout.LayoutParams fl = new FrameLayout.LayoutParams(dp(40), dp(40));
        fl.gravity = Gravity.TOP | Gravity.LEFT;
        fl.leftMargin = clampX(fabX, dp(40));
        fl.topMargin = clampY(fabY, dp(40));
        fab.setOnTouchListener(dragger(fab, null));

        for (int i = 0; i < 3; i++) buildWin(a, i);
        overlay.addView(fab, fl);
        a.addContentView(overlay, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        if (!firstOk) {
            firstOk = true;
            new File(dir, "menu_try.txt").delete();
            put("menu_state.txt", "ok attached to " + a.getClass().getName() + "\n");
        }
        refreshStatus();
        renderAll();
    }

    private static int clampX(int x, int w) { return Math.max(0, Math.min(x, sw - w)); }
    private static int clampY(int y, int h) { return Math.max(0, Math.min(y, sh - h)); }

    private static int winW(int id) { return Math.min(dp(BASE[id][0] * SCALE[size]), sw - dp(16)); }
    private static int winH(int id) { return Math.min(dp(BASE[id][1] * SCALE[size]), sh - dp(16)); }

    /** Drag: the touched view moves (a window's title bar moves the window, the Q9 button moves itself). A tap on the Q9 button opens / closes Control. */
    private static View.OnTouchListener dragger(final View target, final Win w) {
        return new View.OnTouchListener() {
            float dx, dy, sx, sy;
            boolean moved;
            public boolean onTouch(View v, MotionEvent e) {
                FrameLayout.LayoutParams lp = (FrameLayout.LayoutParams) target.getLayoutParams();
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        sx = e.getRawX(); sy = e.getRawY(); dx = lp.leftMargin - sx; dy = lp.topMargin - sy; moved = false;
                        target.bringToFront();
                        if (fab != null) fab.bringToFront();
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        if (Math.abs(e.getRawX() - sx) + Math.abs(e.getRawY() - sy) > dp(8)) moved = true;
                        if (moved) {
                            int ww = lp.width > 0 ? lp.width : dp(40), hh = lp.height > 0 ? lp.height : dp(40);
                            lp.leftMargin = clampX((int) (e.getRawX() + dx), ww);
                            lp.topMargin = clampY((int) (e.getRawY() + dy), w == null ? hh : dp(40));
                            target.setLayoutParams(lp);
                        }
                        return true;
                    case MotionEvent.ACTION_UP:
                        if (moved) {
                            if (w == null) { fabX = lp.leftMargin; fabY = lp.topMargin; } else { w.x = lp.leftMargin; w.y = lp.topMargin; }
                            saveUi();
                        } else if (w == null) setOpen(0, !W[0].open);
                        return true;
                    default:
                        return true;
                }
            }
        };
    }

    private static void buildWin(final Activity a, final int id) {
        Win w = W[id];
        if (w.view != null && w.view.getParent() != null) overlay.removeView(w.view);
        int ww = winW(id), hh = winH(id);
        LinearLayout v = vcol(a);
        v.setPadding(dp(8), dp(6), dp(8), dp(8));
        v.setBackground(box(INK, 16, LINE));
        v.setClickable(true);
        w.view = v;

        LinearLayout head = hrow(a);
        head.setPadding(0, 0, 0, dp(4));
        View dot = new View(a);
        dot.setBackground(box(id == 0 ? SKY : id == 1 ? AMB : GRN, 4, 0));
        head.addView(dot, new LinearLayout.LayoutParams(dp(8), dp(8)));
        TextView title = txt(a, "  " + WNAME[id] + "     ⠿ drag", 12, TXT, true);
        head.addView(title, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        if (id == 0) head.addView(sm(a, "S·M·L", CARD2, MUT, new View.OnClickListener() { public void onClick(View x) { size = (size + 1) % 3; saveUi(); rebuildAll(); } }));
        head.addView(sm(a, "✕", CARD2, TXT, new View.OnClickListener() { public void onClick(View x) { setOpen(id, false); } }));
        v.addView(head);
        head.setOnTouchListener(dragger(v, w));

        if (id == 0) {
            statusC = txt(a, "", 11, MUT, false);
            statusC.setPadding(dp(2), 0, dp(2), dp(2));
            v.addView(statusC);
            cscroll = new ScrollView(a);
            cscroll.setVerticalScrollBarEnabled(false);
            cbody = vcol(a);
            cscroll.addView(cbody);
            v.addView(cscroll, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        } else if (id == 1) {
            lhead = vcol(a);
            v.addView(lhead);
            lview = newList(a, LAD);
            v.addView(lview, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        } else {
            shead = vcol(a);
            v.addView(shead);
            sview = newList(a, SAD);
            v.addView(sview, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        }

        FrameLayout.LayoutParams pl = new FrameLayout.LayoutParams(ww, hh);
        pl.gravity = Gravity.TOP | Gravity.LEFT;
        int defX = id == 0 ? sw - ww - dp(52) : id == 1 ? dp(8) : dp(8) + dp(26);
        int defY = id == 2 ? dp(8) + dp(22) : dp(8);
        pl.leftMargin = clampX(w.x < 0 ? defX : w.x, ww);
        pl.topMargin = clampY(w.y == 8 && id == 2 ? defY : w.y, hh);
        overlay.addView(v, pl);
        v.setVisibility(w.open ? View.VISIBLE : View.GONE);
    }

    private static ListView newList(Activity a, BaseAdapter ad) {
        ListView l = new ListView(a);
        l.setDivider(box(LINE, 0, 0));
        l.setDividerHeight(dp(1));
        l.setSelector(box(CLEAR, 0, 0));
        l.setCacheColorHint(CLEAR);
        l.setVerticalScrollBarEnabled(false);
        l.setAdapter(ad);
        return l;
    }

    private static void rebuildAll() {
        if (overlay == null) return;
        Activity a = (Activity) overlay.getContext();
        for (int i = 0; i < 3; i++) buildWin(a, i);
        if (fab != null) fab.bringToFront();
        refreshStatus();
        renderAll();
    }

    private static void setOpen(int id, boolean on) {
        Win w = W[id];
        w.open = on;
        if (w.view != null) w.view.setVisibility(on ? View.VISIBLE : View.GONE);
        if (on) {
            w.view.bringToFront();
            if (fab != null) fab.bringToFront();
            refreshStatus();
            if (!listLoaded) loadList(); else renderAll();
        }
    }

    // ---------- files ----------
    private static void loadUi() {
        String s = Data.readSmall(new File(dir, "menu_ui.txt")).trim();
        if (s.length() == 0) return;
        try {
            String[] p = s.split("\\s+");
            if (p.length == 5) {                       // v0.77 / v0.78: fabX fabY winX winY size
                fabX = Integer.parseInt(p[0]); fabY = Integer.parseInt(p[1]); W[0].x = Integer.parseInt(p[2]); W[0].y = Integer.parseInt(p[3]);
                size = Math.max(0, Math.min(2, Integer.parseInt(p[4])));
            } else if (p.length >= 9) {                // v0.79: fabX fabY size cx cy lx ly mx my
                fabX = Integer.parseInt(p[0]); fabY = Integer.parseInt(p[1]);
                size = Math.max(0, Math.min(2, Integer.parseInt(p[2])));
                for (int i = 0; i < 3; i++) { W[i].x = Integer.parseInt(p[3 + 2 * i]); W[i].y = Integer.parseInt(p[4 + 2 * i]); }
            }
        } catch (Throwable ignored) {
        }
    }

    private static void saveUi() {
        put("menu_ui.txt", fabX + " " + fabY + " " + size + " " + W[0].x + " " + W[0].y + " " + W[1].x + " " + W[1].y + " " + W[2].x + " " + W[2].y + "\n");
    }

    private static boolean put(String name, String text) {
        try {
            java.io.FileOutputStream f = new java.io.FileOutputStream(new File(dir, name), false);
            try { f.write(text.getBytes("UTF-8")); } finally { f.close(); }
            return true;
        } catch (Throwable t) {
            if (!name.equals("menu_state.txt")) err("write " + name, t);
            return false;
        }
    }

    private static void err(String where, Throwable t) {
        try {
            java.io.FileOutputStream f = new java.io.FileOutputStream(new File(dir, "menu_state.txt"), false);
            try { f.write(("err " + where + ": " + t + "\n").getBytes("UTF-8")); } finally { f.close(); }
        } catch (Throwable ignored) {
        }
    }

    private static String kv(String text, String key) {
        int i = text.indexOf(key + "=");
        if (i < 0 || (i > 0 && text.charAt(i - 1) != '\n' && text.charAt(i - 1) != '|')) return null;
        int e = i + key.length() + 1, j = e;
        while (j < text.length() && text.charAt(j) != '\n' && text.charAt(j) != '|') j++;
        return text.substring(e, j).trim();
    }

    /** Reads the saved rules and My textures once (after every change), so drawing a list never reads files. */
    private static void reloadRules() {
        try {
            rHid = Data.readRuleKeys(dir, "hidden.txt");
            rOri = Data.readRuleKeys(dir, "orig.txt");
            libMap.clear();
            for (Data.Saved s : Data.readLib(dir)) libMap.put(s.key, s);
        } catch (Throwable t) {
            err("rules", t);
        }
    }

    private static void refreshStatus() {
        if (statusC == null) return;
        String live = Data.readSmall(new File(dir, "live.txt")).trim();
        if (!live.startsWith("1")) {
            statusC.setText("Live test is OFF. Turn it on in the WebUI (Advanced) and restart CODM.");
            if (statusL != null) statusL.setText("Live test is OFF.");
            return;
        }
        String st = Data.readSmall(new File(dir, "codm_tex.status"));
        String cap = kv(st, "lv_cap"), n = kv(st, "lv_hash"), kb = kv(st, "lv_kb"), last = kv(st, "lv_last"), bk = kv(st, "lv_bk"), bkmb = kv(st, "lv_bkmb");
        if (cap == null) { statusC.setText("Waiting for the module..."); return; }
        int pend = Data.kvInt("p=" + (kv(st, "lv_pend") == null ? "0" : kv(st, "lv_pend")), "p");
        StringBuilder b = new StringBuilder();
        b.append("1".equals(cap) ? "● Capturing" : "○ Not capturing").append(" · ").append(n == null ? "0" : n).append(" copies (").append(kb == null ? "0" : kb).append(" KB)");
        if (bk != null && !"0".equals(bk)) b.append(" · ").append(bk).append(" GPU backups (").append(bkmb == null ? "0" : bkmb).append(" MB)");
        String fl = Data.friendlyLast(last);
        String l2 = "";
        if (pend > 0) l2 = "⏳ applying, " + pend + " left";
        else if (fl.length() > 0) l2 = "Last: " + fl;
        int nocopy = Data.kvInt(last, "nocopy");
        if (pend <= 0 && nocopy > 0) l2 += "\n" + nocopy + " could not come back live (they were already blank when loaded). Turn their rule OFF in My textures, then restart CODM.";
        statusC.setText(b.toString() + (l2.length() > 0 ? "\n" + l2 : ""));
        if (statusL != null) statusL.setText(l2.length() > 0 ? l2 : "Tap Hide / Show on a row.");
        if (fabBg != null) fabBg.setColor(pend > 0 ? 0xE6FBBF24 : 0xE638BDF8);
        if (pend > 0) startPoll();
    }

    private static void say(String s) {
        if (statusC != null) statusC.setText(s);
        if (statusL != null) statusL.setText(s);
    }

    private static void startPoll() {
        pollLeft = 40;
        if (polling) return;
        polling = true;
        H.postDelayed(new Runnable() {
            public void run() {
                try { refreshStatus(); } catch (Throwable t) { err("poll", t); }
                if (--pollLeft > 0) H.postDelayed(this, 1000); else polling = false;
            }
        }, 1000);
    }

    // ---------- commands ----------
    private static void mark(String lab) {
        if (!put("mark.txt", lab + "\n")) { say("Could not write mark.txt"); return; }
        if ("X".equals(lab)) { say("Copies cleared."); }
        else say(lab.equals("A") ? "Mark A sent. Now do the thing in the game." : "Mark B sent. Updating the list...");
        H.postDelayed(new Runnable() { public void run() { refreshStatus(); } }, 2000);
        if ("B".equals(lab) || "A".equals(lab)) H.postDelayed(new Runnable() { public void run() { loadList(); } }, 2000);
    }

    /** Sends "op hash" lines in ONE write (the module takes up to 8192 lines per file and applies them over a few frames). */
    private static void sendLines(final ArrayList<String> lines, final String what) {
        if (lines.isEmpty()) { say("Nothing to send."); return; }
        final int step = 8000;
        for (int i = 0; i * step < lines.size(); i++) {
            final int from = i * step;
            Runnable r = new Runnable() {
                public void run() {
                    StringBuilder sb = new StringBuilder();
                    for (int k = from; k < Math.min(lines.size(), from + step); k++) sb.append(lines.get(k)).append('\n');
                    if (!Data.writeAtomic(new File(dir, "livecmd.txt"), sb.toString())) say("Could not write livecmd.txt");
                }
            };
            if (i == 0) r.run(); else H.postDelayed(r, 3000L * i);
        }
        say(what + ": " + lines.size() + " sent. Look at the game.");
        H.postDelayed(new Runnable() { public void run() { refreshStatus(); } }, 1500);
        startPoll();
    }

    private static void addOps(ArrayList<String> out, String op, List<Data.Row> rows) { for (Data.Row r : rows) out.add(op + " " + r.hash); }

    private static void mark(List<Data.Row> rows, String c) { for (Data.Row r : rows) chip.put(r.key(), c); }

    /** Hide / Restore a part of the current set. Hide: the rest of the set is shown again, so only this part is hidden. */
    private static void doPart(ArrayList<Data.Row> part, ArrayList<Data.Row> other, String label) {
        ArrayList<String> ls = new ArrayList<String>();
        if (mode == 0) {
            addOps(ls, "h", part);
            if (other != null) addOps(ls, "u", other);
            mark(part, "H");
            if (other != null) mark(other, "S");
        } else {
            addOps(ls, "r", part);
            mark(part, "R");
        }
        sendLines(ls, label);
        renderAll();
    }

    private static void one(String op, Data.Row c, String ch) {
        ArrayList<String> ls = new ArrayList<String>();
        ls.add(op + " " + c.hash);
        chip.put(c.key(), ch);
        sendLines(ls, op.equals("h") ? "Hide" : op.equals("u") ? "Show" : "Restore");
        renderAll();
    }

    // ---------- the list ----------
    private static void loadList() {
        new Thread(new Runnable() {
            public void run() {
                final String log = Data.read(new File(dir, "codm_tex.log"), 3 * 1024 * 1024);
                final ArrayList<Data.Row> all = Data.parseLog(log, marksOnly);
                final boolean hm = Data.hasMarks(log);
                H.post(new Runnable() {
                    public void run() {
                        try {
                            allRows = all;
                            reloadRules();
                            recomputeRoot();
                            listLoaded = true;
                            if (marksOnly && !hm) say("No Mark A in this game session yet.");
                            renderAll();
                        } catch (Throwable t) {
                            err("load", t);
                        }
                    }
                });
            }
        }).start();
    }

    private static void recomputeRoot() {
        Data.Filtered f = Data.rootRows(allRows, mode == 0, everything);
        root = f.rows;
        skipped = f.skipped;
        path.clear();
        path.add(new Node("All " + root.size(), root));
        qKind = 0;
    }

    private static ArrayList<Data.Row> cur() { return path.isEmpty() ? new ArrayList<Data.Row>() : path.get(path.size() - 1).rows; }

    private static void into(ArrayList<Data.Row> part, String name) {
        path.add(new Node(name + " " + part.size(), part));
        qKind = 0;
        renderAll();
    }

    private static void up(int toLevel) {
        while (path.size() > toLevel + 1 && path.size() > 1) path.remove(path.size() - 1);
        qKind = 0;
        renderAll();
    }

    private static int stateOf(Data.Row r) {
        String k = r.key();
        return Data.stateOf(chip.get(k), rHid.contains(k), rOri.contains(k));
    }

    // ---------- drawing ----------
    private static void renderAll() {
        if (overlay == null) return;
        try {
            renderList();
            renderSaved();
            renderControl();
        } catch (Throwable t) {
            err("draw", t);
        }
    }

    private static void renderControl() {
        if (cbody == null || overlay == null) return;
        Activity a = (Activity) overlay.getContext();
        cbody.removeAllViews();
        drawControl(a);
    }

    private static void drawControl(final Activity a) {
        // what is hidden now, and is it saved?
        final ArrayList<Data.Row> unsaved = Data.unsavedHidden(chip, libMap.keySet(), rHid, rOri);
        final ArrayList<String> hidKeys = Data.keysWith(chip, "H");
        if (!hidKeys.isEmpty()) {
            LinearLayout c = card(a, unsaved.isEmpty() ? GRN : AMB);
            c.addView(txt(a, hidKeys.size() + " hidden from this menu now", 12, TXT, true));
            if (unsaved.isEmpty()) c.addView(txt(a, "★ all of them are saved: they are hidden again at every game start.", 11, 0xFFA7F3D0, false));
            else c.addView(txt(a, "⚠ " + unsaved.size() + " not saved: they come back when CODM restarts.", 11, AMB, false));
            LinearLayout r = hrow(a);
            if (!unsaved.isEmpty()) r.addView(prim(a, "★ Save hidden (" + unsaved.size() + ")", new View.OnClickListener() {
                public void onClick(View v) { formRestore = false; openForm(1, unsaved, null, unsaved.size() > 1); } }), wt(dp(2)));
            r.addView(good(a, "Show all hidden", new View.OnClickListener() {
                public void onClick(View v) {
                    ArrayList<String> ls = new ArrayList<String>();
                    for (String k : hidKeys) { try { ls.add("u " + Data.rowOfKey(k).hash); chip.put(k, "S"); } catch (RuntimeException ignored) { } }
                    sendLines(ls, "Show all hidden"); renderAll(); } }), wt(dp(2)));
            c.addView(r, fullW(dp(4)));
        }

        // capture
        LinearLayout cap = card(a, 0);
        label(a, cap, "CAPTURE");
        LinearLayout r1 = hrow(a);
        r1.addView(prim(a, "Mark A", new View.OnClickListener() { public void onClick(View v) { mark("A"); } }), wt(dp(2)));
        r1.addView(prim(a, "Mark B", new View.OnClickListener() { public void onClick(View v) { mark("B"); } }), wt(dp(2)));
        r1.addView(neut(a, "Clear", new View.OnClickListener() { public void onClick(View v) { mark("X"); chip.clear(); renderAll(); } }), wt(dp(2)));
        cap.addView(r1);

        // finder
        LinearLayout fd = card(a, 0);
        label(a, fd, "FINDER");
        fd.addView(seg(a, new String[]{"Hide", "Restore"}, mode, new Sel() { public void on(int i) { if (i != mode) { mode = i; recomputeRoot(); renderAll(); } } }));
        fd.addView(seg(a, new String[]{"All since start", "Mark A → B"}, marksOnly ? 1 : 0, new Sel() { public void on(int i) { marksOnly = i == 1; listLoaded = false; loadList(); renderAll(); } }), fullW(dp(4)));
        LinearLayout r2 = hrow(a);
        if (mode == 0) r2.addView(everything ? good(a, "✓ Everything", new View.OnClickListener() { public void onClick(View v) { everything = false; recomputeRoot(); renderAll(); } })
                : neut(a, "Everything: off", new View.OnClickListener() { public void onClick(View v) { everything = true; recomputeRoot(); renderAll(); } }), wt(dp(2)));
        r2.addView(neut(a, "Refresh", new View.OnClickListener() { public void onClick(View v) { loadList(); } }), wt(dp(2)));
        fd.addView(r2, fullW(dp(4)));
        if (mode == 0) fd.addView(txt(a, everything ? "Everything: also scope / lobby sizes and textures the module cannot blank. Use \"Show all hidden\" to undo." : "Left out: scope / lobby sizes" + (skipped > 0 ? " (" + skipped + ")" : "") + ". Turn Everything on to include them.", 10, MUT, false));

        // family
        LinearLayout fm = card(a, 0);
        label(a, fm, "FAMILY");
        if (!listLoaded) fm.addView(txt(a, "Loading the list...", 11, MUT, false));
        else if (root.isEmpty()) fm.addView(txt(a, marksOnly ? "Nothing between Mark A and Mark B." : "Nothing listed yet. Play for a moment (the log needs the game's textures), then Refresh.", 11, MUT, false));
        else drawFamily(a, fm);

        // windows
        LinearLayout nav = hrow(a);
        nav.addView(neut(a, "Textures ▸ " + lshown.size(), new View.OnClickListener() { public void onClick(View v) { setOpen(1, true); } }), wt(dp(2)));
        nav.addView(neut(a, "My textures ▸ " + libMap.size(), new View.OnClickListener() { public void onClick(View v) { setOpen(2, true); } }), wt(dp(2)));
        cbody.addView(nav, fullW(dp(6)));
        TextView hint = txt(a, "Hide works on textures the game already loaded. ★ Save writes the same rules the WebUI uses.", 10, MUT, false);
        hint.setPadding(dp(2), dp(4), dp(2), dp(4));
        cbody.addView(hint);
    }

    private static void drawFamily(final Activity a, LinearLayout fm) {
        HorizontalScrollView hs = new HorizontalScrollView(a);
        hs.setHorizontalScrollBarEnabled(false);
        LinearLayout crumbs = hrow(a);
        for (int i = 0; i < path.size(); i++) {
            final int lvl = i;
            if (i > 0) crumbs.addView(txt(a, " › ", 12, MUT, false));
            boolean last = i == path.size() - 1;
            crumbs.addView(sm(a, path.get(i).label, last ? SKY : CARD2, last ? SKYTXT : TXT, new View.OnClickListener() { public void onClick(View v) { up(lvl); } }));
        }
        hs.addView(crumbs);
        fm.addView(hs);

        final ArrayList<Data.Row> set = cur();
        final ArrayList<Data.Row> h1 = Data.half(set, 0), h2 = Data.half(set, 1);
        final String verb = mode == 0 ? "Hide" : "Restore";
        TextView cnt = txt(a, "Testing " + set.size() + " texture" + (set.size() == 1 ? "" : "s"), 11, TXT, false);
        cnt.setPadding(dp(2), dp(4), 0, dp(2));
        fm.addView(cnt);

        if (qKind != 0 && qFirst != null) {
            LinearLayout q = hrow(a);
            q.setPadding(dp(2), dp(2), 0, dp(2));
            q.addView(txt(a, qKind == 1 ? "Is it gone?" : "Is it fixed?", 12, AMB, true));
            q.addView(sm(a, "Yes", GRND, 0xFFA7F3D0, new View.OnClickListener() { public void onClick(View v) { into(qFirst, "yes"); } }));
            q.addView(sm(a, "No", REDD, 0xFFFFB4B4, new View.OnClickListener() { public void onClick(View v) { into(qSecond, "other"); } }));
            q.addView(sm(a, "Skip", CARD2, MUT, new View.OnClickListener() { public void onClick(View v) { qKind = 0; renderAll(); } }));
            fm.addView(q);
        }
        if (set.size() == 0) return;

        LinearLayout r3 = hrow(a);
        View.OnClickListener allL = new View.OnClickListener() { public void onClick(View v) { doPart(set, null, verb + " all"); } };
        r3.addView(mode == 0 ? dang(a, verb + " all", allL) : prim(a, verb + " all", allL), wt(dp(2)));
        if (set.size() > 1) {
            View.OnClickListener l1 = new View.OnClickListener() { public void onClick(View v) {
                doPart(h1, h2, verb + " 1st half"); qKind = mode == 0 ? 1 : 2; qFirst = h1; qSecond = h2; renderAll(); } };
            View.OnClickListener l2 = new View.OnClickListener() { public void onClick(View v) {
                doPart(h2, h1, verb + " 2nd half"); qKind = mode == 0 ? 1 : 2; qFirst = h2; qSecond = h1; renderAll(); } };
            r3.addView(mode == 0 ? dang(a, "1st half", l1) : prim(a, "1st half", l1), wt(dp(2)));
            r3.addView(mode == 0 ? dang(a, "2nd half", l2) : prim(a, "2nd half", l2), wt(dp(2)));
        }
        fm.addView(r3);

        LinearLayout r4 = hrow(a);
        if (mode == 0) r4.addView(good(a, "Show all", new View.OnClickListener() { public void onClick(View v) {
            ArrayList<String> ls = new ArrayList<String>(); addOps(ls, "u", set); mark(set, "S"); sendLines(ls, "Show all"); renderAll(); } }), wt(dp(2)));
        if (set.size() > 1) {
            r4.addView(neut(a, "Go into 1st (" + h1.size() + ")", new View.OnClickListener() { public void onClick(View v) { into(h1, "1st"); } }), wt(dp(2)));
            r4.addView(neut(a, "Go into 2nd (" + h2.size() + ")", new View.OnClickListener() { public void onClick(View v) { into(h2, "2nd"); } }), wt(dp(2)));
        }
        fm.addView(r4);
        if (mode == 1) fm.addView(txt(a, "Restore cannot be undone while playing (restart CODM to reset it).", 10, MUT, false));
        fm.addView(neut(a, set.size() == 1 ? "★ Save this texture" : "★ Save these " + set.size() + " together", new View.OnClickListener() {
            public void onClick(View v) { formRestore = mode == 1; openForm(1, set, null, set.size() > 1); } }), fullW(dp(3)));
    }

    // ---------- Textures window ----------
    private static void renderList() {
        if (lhead == null || overlay == null) return;
        Activity a = (Activity) overlay.getContext();
        lshown = Data.filterRows(cur(), lf, chip, rHid, rOri, libMap.keySet());
        lhead.removeAllViews();
        TextView t = txt(a, (listLoaded ? lshown.size() + " of " + cur().size() + " textures" : "Loading...") + (path.size() > 1 ? "  ·  " + path.get(path.size() - 1).label : ""), 12, TXT, false);
        t.setPadding(dp(2), 0, 0, dp(3));
        lhead.addView(t);
        HorizontalScrollView hs = new HorizontalScrollView(a);
        hs.setHorizontalScrollBarEnabled(false);
        LinearLayout cr = hrow(a);
        String[] nm = {"All", "Hidden", "Not hidden", "★ Saved", "Not saved"};
        for (int i = 0; i < nm.length; i++) {
            final int k = i;
            Button b = sm(a, nm[i], i == lf ? SKY : CARD2, i == lf ? SKYTXT : MUT, new View.OnClickListener() { public void onClick(View v) { lf = k; renderList(); } });
            cr.addView(b);
        }
        hs.addView(cr);
        lhead.addView(hs);
        statusL = txt(a, statusL == null ? "" : String.valueOf(statusL.getText()), 10, MUT, false);
        statusL.setPadding(dp(2), dp(3), 0, dp(3));
        lhead.addView(statusL);
        LAD.notifyDataSetChanged();
    }

    private static final class LH { View bar; TextView t1, t2; Button b1, b2; }

    private static final BaseAdapter LAD = new BaseAdapter() {
        public int getCount() { return lshown.size(); }
        public Object getItem(int i) { return lshown.get(i); }
        public long getItemId(int i) { return i; }
        public View getView(int i, View cv, ViewGroup p) {
            Activity a = (Activity) overlay.getContext();
            LH h;
            View v = cv;
            if (v == null) {
                h = new LH();
                LinearLayout row = hrow(a);
                row.setPadding(dp(2), dp(6), dp(2), dp(6));
                h.bar = new View(a);
                row.addView(h.bar, new LinearLayout.LayoutParams(dp(4), dp(34)));
                LinearLayout col = vcol(a);
                col.setPadding(dp(8), 0, dp(4), 0);
                h.t1 = txt(a, "", 12, TXT, true);
                h.t2 = txt(a, "", 10, MUT, false);
                h.t1.setSingleLine(true);
                h.t2.setSingleLine(true);
                col.addView(h.t1);
                col.addView(h.t2);
                row.addView(col, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
                h.b1 = sm(a, "", CARD2, TXT, null);
                h.b2 = sm(a, "★", CARD2, MUT, null);
                row.addView(h.b1);
                row.addView(h.b2);
                row.setTag(h);
                v = row;
            } else h = (LH) v.getTag();
            if (i < 0 || i >= lshown.size()) return v;
            final Data.Row r = lshown.get(i);
            final String k = r.key();
            int st = stateOf(r);
            h.bar.setBackground(box(st == Data.ST_HID ? RED : st == Data.ST_SHOWN ? GRN : st == Data.ST_REST ? SKY : LINE, 2, 0));
            h.t1.setText(Data.fmtName(r.fmt) + " · " + r.w + "x" + r.h);
            final Data.Saved sv = libMap.get(k);
            boolean saved = Data.isSaved(k, libMap.keySet(), rHid, rOri);
            String stTxt = st == Data.ST_HID ? "hidden" : st == Data.ST_SHOWN ? "shown" : st == Data.ST_REST ? "restored" : "untouched";
            h.t2.setText(stTxt + " · " + Data.sizeText(r.n) + " · " + shortHash(r.hash) + (sv != null ? " · ★ " + sv.name : saved ? " · ★ rule" : "") + (Data.guarded(r) ? " · scope/lobby" : ""));
            boolean hid = st == Data.ST_HID;
            h.b1.setText(mode == 1 ? "Restore" : hid ? "Show" : "Hide");
            h.b1.setTextColor(mode == 1 ? SKY : hid ? 0xFFA7F3D0 : 0xFFFFB4B4);
            h.b1.setBackground(box(mode == 1 ? CARD2 : hid ? GRND : REDD, 14, 0));
            h.b1.setOnClickListener(new View.OnClickListener() { public void onClick(View x) { toggleRow(r); } });
            h.b2.setTextColor(saved ? AMB : MUT);
            h.b2.setBackground(box(saved ? AMBD : CARD2, 14, 0));
            h.b2.setOnClickListener(new View.OnClickListener() { public void onClick(View x) {
                if (Data.isSaved(k, libMap.keySet(), rHid, rOri)) { say(sv != null ? "Already saved as: " + sv.name : "Already saved (a rule is active)."); return; }
                ArrayList<Data.Row> l = new ArrayList<Data.Row>(); l.add(r); formRestore = mode == 1; openForm(1, l, null, false); } });
            return v;
        }
    };

    private static void toggleRow(Data.Row r) {
        int st = stateOf(r);
        if (mode == 1) one("r", r, "R");
        else if (st == Data.ST_HID) one("u", r, "S");
        else one("h", r, "H");
    }

    // ---------- save / rename form (a small card in the middle of the screen) ----------
    private static void openForm(int kind, ArrayList<Data.Row> rows, ArrayList<Data.Saved> unit, boolean asSet) {
        formKind = kind; formRows = rows; formUnit = unit; formAsSet = asSet;
        if (kind == 1) formGrp = "plants";
        formKeep = "";
        showForm();
    }

    private static String autoName() {
        if (formKind == 2 && formUnit != null && !formUnit.isEmpty()) return formUnit.get(0).name;
        if (formRows == null || formRows.isEmpty()) return "Texture";
        Data.Row r = formRows.get(0);
        String base = formRows.size() > 1 ? "Set " + formRows.size() : Data.fmtName(r.fmt) + " " + r.w + "x" + r.h;
        return Data.cleanName(base);
    }

    private static void closeForm() {
        if (formCard != null && formCard.getParent() != null && overlay != null) overlay.removeView(formCard);
        formCard = null;
        formKind = 0;
        nameEt = null;
    }

    private static void showForm() {
        if (overlay == null || formKind == 0) return;
        final Activity a = (Activity) overlay.getContext();
        if (formCard != null && formCard.getParent() != null) overlay.removeView(formCard);
        LinearLayout box = vcol(a);
        box.setPadding(dp(10), dp(8), dp(10), dp(10));
        box.setBackground(box(INK, 16, SKY));
        box.setClickable(true);
        box.addView(txt(a, formKind == 1 ? "★ Save to My textures" : "Rename", 13, TXT, true));
        box.addView(txt(a, "Tap the name to type, or just tap Save.", 10, MUT, false));
        nameEt = new EditText(a);
        nameEt.setText(formKeep.length() > 0 ? formKeep : autoName());
        nameEt.setTextSize(13);
        nameEt.setTextColor(TXT);
        nameEt.setSingleLine(true);
        nameEt.setFocusableInTouchMode(true);
        nameEt.setBackground(box(CARD2, 10, 0));
        nameEt.setPadding(dp(10), dp(8), dp(10), dp(8));
        nameEt.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                try {
                    nameEt.requestFocus();
                    InputMethodManager im = (InputMethodManager) a.getSystemService(Context.INPUT_METHOD_SERVICE);
                    if (im != null) im.showSoftInput(nameEt, 0);
                } catch (Throwable ignored) {
                }
            }
        });
        box.addView(nameEt, fullW(dp(6)));
        if (formKind == 1) {
            LinearLayout g = hrow(a);
            String[] ids = {"plants", "effects", "other"}, nm = {"Plants", "Effects", "Other"};
            for (int i = 0; i < 3; i++) {
                final String id = ids[i];
                Button b = btn(a, nm[i], formGrp.equals(id) ? SKY : CARD2, formGrp.equals(id) ? SKYTXT : TXT);
                b.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { formKeep = nameEt != null ? nameEt.getText().toString() : ""; formGrp = id; showForm(); } });
                g.addView(b, wt(dp(2)));
            }
            box.addView(g, fullW(dp(4)));
            box.addView(txt(a, (formRestore ? "It will be a RESTORE entry" : "It will be a HIDE entry") + (formRows != null && formRows.size() > 1 ? " (" + formRows.size() + " textures that work together)" : "") + ", switched ON. It is applied at every game start.", 10, MUT, false));
        }
        LinearLayout r = hrow(a);
        r.addView(good(a, formKind == 1 ? "Save" : "Rename", new View.OnClickListener() { public void onClick(View v) { submitForm(); } }), wt(dp(2)));
        r.addView(neut(a, "Cancel", new View.OnClickListener() { public void onClick(View v) { closeForm(); } }), wt(dp(2)));
        box.addView(r, fullW(dp(6)));
        formCard = new FrameLayout(a);
        FrameLayout.LayoutParams bp = new FrameLayout.LayoutParams(Math.min(dp(300), sw - dp(16)), ViewGroup.LayoutParams.WRAP_CONTENT);
        bp.gravity = Gravity.CENTER;
        formCard.addView(box, bp);
        overlay.addView(formCard, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
    }

    private static void submitForm() {
        try {
            String name = Data.cleanName(nameEt != null ? nameEt.getText().toString() : "");
            if (name.length() == 0) name = autoName();
            if (formKind == 1) saveRows(formRows, name, formGrp, formRestore, formAsSet);
            else if (formKind == 2 && formUnit != null) {
                ArrayList<Data.Saved> lib = Data.readLib(dir);
                for (Data.Saved s : lib) for (Data.Saved u : formUnit) if (s.key.equals(u.key)) s.name = name;
                say(Data.writeLib(dir, lib) ? "Renamed." : "Could not write texlib.txt");
            }
        } catch (Throwable t) {
            err("form", t);
        }
        closeForm();
        reloadRules();
        renderAll();
    }

    private static void saveRows(List<Data.Row> rows, String name, String grp, boolean restore, boolean asSet) {
        ArrayList<Data.Saved> lib = Data.readLib(dir);
        LinkedHashSet<String> have = new LinkedHashSet<String>();
        for (Data.Saved s : lib) have.add(s.key);
        String setId = asSet && rows.size() > 1 ? Data.newSetId() : "";
        ArrayList<String> keys = new ArrayList<String>();
        int added = 0;
        for (Data.Row r : rows) {
            if (!have.add(r.key())) continue;
            Data.Saved s = new Data.Saved();
            s.key = r.key(); s.name = name; s.grp = Data.grpOk(grp); s.set = setId; s.restore = restore;
            lib.add(s); keys.add(r.key()); added++;
        }
        if (added == 0) { say("Already in My textures."); return; }
        boolean ok = Data.writeLib(dir, lib)
                && Data.setRules(dir, restore ? "orig.txt" : "hidden.txt", keys, true)
                && Data.setRules(dir, restore ? "hidden.txt" : "orig.txt", keys, false);
        if (!ok) { say("Could not save (files are not writable)."); return; }
        // only send what is not already in that state (a second "hide" of a hidden texture is not needed)
        ArrayList<String> ls = new ArrayList<String>();
        for (Data.Row r : rows) {
            String c = chip.get(r.key());
            if (restore ? !"R".equals(c) : !"H".equals(c)) { ls.add((restore ? "r " : "h ") + r.hash); chip.put(r.key(), restore ? "R" : "H"); }
        }
        say("★ Saved " + added + " (switched ON).");
        if (!ls.isEmpty()) sendLines(ls, "★ Saved " + added + " · " + (restore ? "Restore" : "Hide"));
    }

    // ---------- My textures window ----------
    private static void renderSaved() {
        if (shead == null || overlay == null) return;
        Activity a = (Activity) overlay.getContext();
        final ArrayList<Data.Saved> lib = Data.readLib(dir);
        reloadRules();
        sitems.clear();
        String[] gid = {"plants", "effects", "other"}, gnm = {"Plants", "Effects", "Other"};
        ArrayList<ArrayList<Data.Saved>> units = Data.units(lib);
        int on = 0;
        for (int g = 0; g < 3; g++) {
            boolean head = false;
            for (ArrayList<Data.Saved> u : units) {
                if (!u.get(0).grp.equals(gid[g])) continue;
                if (!head) { sitems.add(gnm[g]); head = true; }
                sitems.add(u);
                if (unitOn(u)) on++;
            }
        }
        shead.removeAllViews();
        TextView t = txt(a, units.size() + " saved · " + on + " ON", 12, TXT, false);
        t.setPadding(dp(2), 0, 0, dp(2));
        shead.addView(t);
        statusS = txt(a, units.isEmpty() ? "Nothing saved yet. In Textures, tap the ★ of a row, or use ★ Save in Control." : "Same list as the WebUI. ON = the rule is active at every game start.", 10, MUT, false);
        statusS.setPadding(dp(2), 0, 0, dp(3));
        shead.addView(statusS);
        SAD.notifyDataSetChanged();
    }

    private static boolean unitOn(ArrayList<Data.Saved> u) {
        boolean restore = u.get(0).restore;
        for (Data.Saved s : u) if (!(restore ? rOri : rHid).contains(s.key)) return false;
        return true;
    }

    private static final class SH { View bar; TextView t1, t2; Button on, nm, del; }

    private static final BaseAdapter SAD = new BaseAdapter() {
        public int getCount() { return sitems.size(); }
        public Object getItem(int i) { return sitems.get(i); }
        public long getItemId(int i) { return i; }
        public int getViewTypeCount() { return 2; }
        public int getItemViewType(int i) { return sitems.get(i) instanceof String ? 0 : 1; }
        @SuppressWarnings("unchecked")
        public View getView(int i, View cv, ViewGroup p) {
            Activity a = (Activity) overlay.getContext();
            Object it = sitems.get(i);
            if (it instanceof String) {
                TextView t = cv instanceof TextView ? (TextView) cv : txt(a, "", 10, AMB, true);
                t.setText(((String) it).toUpperCase());
                t.setPadding(dp(4), dp(8), 0, dp(3));
                return t;
            }
            final ArrayList<Data.Saved> u = (ArrayList<Data.Saved>) it;
            SH h;
            View v = cv;
            if (v == null) {
                h = new SH();
                LinearLayout row = vcol(a);
                row.setPadding(dp(2), dp(6), dp(2), dp(6));
                LinearLayout l1 = hrow(a);
                h.bar = new View(a);
                l1.addView(h.bar, new LinearLayout.LayoutParams(dp(4), dp(16)));
                h.t1 = txt(a, "", 12, TXT, true);
                h.t1.setSingleLine(true);
                h.t1.setPadding(dp(8), 0, dp(4), 0);
                l1.addView(h.t1, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
                h.on = sm(a, "", CARD2, TXT, null);
                l1.addView(h.on);
                row.addView(l1);
                LinearLayout l2 = hrow(a);
                h.t2 = txt(a, "", 10, MUT, false);
                h.t2.setSingleLine(true);
                h.t2.setPadding(dp(12), 0, dp(4), 0);
                l2.addView(h.t2, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
                h.nm = sm(a, "Name", CARD2, TXT, null);
                h.del = sm(a, "Del", CARD2, TXT, null);
                l2.addView(h.nm);
                l2.addView(h.del);
                row.addView(l2);
                row.setTag(h);
                v = row;
            } else h = (SH) v.getTag();
            final boolean restore = u.get(0).restore;
            final boolean isOn = unitOn(u);
            final String id = u.get(0).key;
            h.bar.setBackground(box(isOn ? GRN : LINE, 2, 0));
            h.t1.setText(u.get(0).name);
            h.t2.setText((restore ? "Restore" : "Hide") + (u.size() > 1 ? " · " + u.size() + " together" : " · " + Data.fmtName(Data.rowOfKey(id).fmt) + " " + Data.rowOfKey(id).w + "x" + Data.rowOfKey(id).h));
            h.on.setText(isOn ? "ON" : "OFF");
            h.on.setTextColor(isOn ? 0xFFA7F3D0 : 0xFFFFB4B4);
            h.on.setBackground(box(isOn ? GRND : REDD, 14, 0));
            h.on.setOnClickListener(new View.OnClickListener() { public void onClick(View x) { toggleUnit(u, restore, !isOn); } });
            h.nm.setOnClickListener(new View.OnClickListener() { public void onClick(View x) { openForm(2, null, u, false); } });
            boolean arm = delArm.equals(id);
            h.del.setText(arm ? "Sure?" : "Del");
            h.del.setTextColor(arm ? 0xFFFFB4B4 : TXT);
            h.del.setBackground(box(arm ? REDD : CARD2, 14, 0));
            h.del.setOnClickListener(new View.OnClickListener() { public void onClick(View x) {
                if (delArm.equals(id)) deleteUnit(u, restore); else { delArm = id; SAD.notifyDataSetChanged(); } } });
            return v;
        }
    };

    private static ArrayList<String> keysOf(List<Data.Saved> u) { ArrayList<String> k = new ArrayList<String>(); for (Data.Saved s : u) k.add(s.key); return k; }

    private static ArrayList<String> opsFor(String op, List<Data.Saved> u) {
        ArrayList<String> l = new ArrayList<String>();
        for (Data.Saved s : u) l.add(op + " " + s.key.substring(s.key.lastIndexOf('|') + 1));
        return l;
    }

    private static void toggleUnit(List<Data.Saved> u, boolean restore, boolean on) {
        if (!Data.setRules(dir, restore ? "orig.txt" : "hidden.txt", keysOf(u), on)) { say("Could not write the rule file."); return; }
        if (on) Data.setRules(dir, restore ? "hidden.txt" : "orig.txt", keysOf(u), false);
        reloadRules();
        String c = restore ? "R" : "H";
        for (Data.Saved s : u) { if (on) chip.put(s.key, c); else if (!restore) chip.put(s.key, "S"); }
        if (restore) { if (on) sendLines(opsFor("r", u), "Restore"); else say("OFF. Restore cannot be undone live; it applies at the next game start."); }
        else sendLines(opsFor(on ? "h" : "u", u), on ? "Hide" : "Show");
        renderAll();
    }

    private static void deleteUnit(List<Data.Saved> u, boolean restore) {
        ArrayList<Data.Saved> lib = Data.readLib(dir);
        ArrayList<String> keys = keysOf(u);
        ArrayList<Data.Saved> keep = new ArrayList<Data.Saved>();
        for (Data.Saved s : lib) if (!keys.contains(s.key)) keep.add(s);
        boolean ok = Data.writeLib(dir, keep) && Data.setRules(dir, "hidden.txt", keys, false) && Data.setRules(dir, "orig.txt", keys, false);
        delArm = "";
        if (!ok) { say("Could not delete."); return; }
        reloadRules();
        if (!restore) { for (String k : keys) chip.put(k, "S"); sendLines(opsFor("u", u), "Deleted; Show"); }
        else say("Deleted.");
        renderAll();
    }
}
