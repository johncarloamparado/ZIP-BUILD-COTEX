package q9;

import android.app.Activity;
import android.app.Application;
import android.content.Context;
import android.graphics.Rect;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.text.InputType;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ScrollView;
import android.widget.TextView;
import android.text.TextUtils;
import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;

/**
 * v0.80: ONE window with a side rail instead of three separate windows. v0.81: docked to the Q9 button (it follows the button, and the button follows the window), short button names.
 *   Test   : status, Mark A / B, finder mode, the "narrow down" navigator (halves, Yes / No), what is hidden now and whether it is saved.
 *   List   : every texture of the current set (ListView, smooth with thousands of rows), one Hide / Show button per row.
 *   Saved  : My textures (the SAME texlib.txt / hidden.txt / orig.txt the WebUI uses): ON / OFF, Name, Delete.
 *   Save   : the name / group form is a page of the same window (no floating card).
 * Files and lists are handled by Data.java (unit-tested). This class only draws and sends commands (mark.txt, livecmd.txt).
 * Loaded by main.cpp through InMemoryDexClassLoader; every entry point and every tap is wrapped so that an error can never reach the game.
 */
public final class Menu {
    private static final Handler H = new Handler(Looper.getMainLooper());

    // palette (same as the WebUI): deep navy, sky-blue accent, violet for "busy" (no orange / yellow); red / green only mean state
    private static final int BG = 0xF5050A18, RAIL = 0xFF0A1020, SURF = 0xFF0B1226, SURF2 = 0xFF121B36, LINE = 0xFF1C2A4A;
    private static final int ACC = 0xFF4CC3FF, ACCTXT = 0xFF04202C;
    private static final int AMBFILL = 0xFFFBBF24;
    private static final int RED = 0xFFFB7185, REDD = 0xFF2A1220, REDL = 0x55FB7185;
    private static final int GRN = 0xFF34D399, GRND = 0xFF0D2A26, GRNL = 0x5534D399;
    private static final int AMB = 0xFFA78BFA, AMBD = 0xFF1C1840, AMBL = 0x55A78BFA;
    private static final int TXT = 0xFFEAF2FF, MUT = 0xFF8FA3C4, DIM = 0xFF55678A, CLEAR = 0x00000000;

    private static final int BASE_W = 456, BASE_H = 316, RAIL_W = 82;
    // v0.90: the owner's name, kept XOR-encoded (not a plain string) so it cannot be found and hex-patched to another
    // name of the same length as easily as a plain string could; decoded once, only to show it in the menu / first message.
    private static final int[] OWNER_ENC = {0x0B, 0x58, 0x48, 0x3F, 0x17, 0x0D, 0xFD, 0xF9, 0xE7, 0xEA};
    private static String ownerName() {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < OWNER_ENC.length; i++) sb.append((char) (OWNER_ENC[i] ^ ((0x5A + i * 7) & 0xFF)));
        return sb.toString();
    }
    private static final float[] SCALE = {0.64f, 0.86f, 1f, 1.2f};      // v0.95: XS, S, M, L
    private static final int[] LIMITS = {1000, 2000, 4000, 8000, 16000};   // v0.95: the most textures the module lists (listcap.txt)
    private static final String[] TABN = {"Test", "List", "Saved", "Settings"};
    private static final String[] TABT = {"Test", "Textures", "My textures", "Save", "Settings"};      // v1.03: index 4 = Settings (3 stays the save / rename page)
    private static final String[] TABD = {"Find one texture, step by step", "Everything the game loaded", "Your saved Hide and Restore list", "Name it and save", "How the menu works"};

    private static File dir;
    private static Application app;
    private static Activity act;
    private static FrameLayout overlay;
    private static TextView fab;
    private static GradientDrawable fabBg;
    private static float density = 2f;
    private static int sw = 1280, sh = 720;
    private static boolean started, firstOk;
    private static int fabX = -1, fabY = 60, size = 2;
    /** v0.95: the Q9 button can be hidden: it is invisible (still there, still tappable) until it is tapped; it shows while the window is open. */
    private static boolean iconHidden = false;
    private static TextView iconBtn, toastView;
    private static long toastUntil = 0;

    // the one window
    private static LinearLayout winView;
    private static int winX = -1, winY = -1, dockRight = 1;      // dockRight 1: the window sits left of the Q9 button
    private static boolean winOpen;
    private static boolean svRestore = false;          // v0.95: Saved tab shows the Restore container (true) or the Hide container (false)
    private static final View[] railBar = new View[4];
    private static final TextView[] railTxt = new TextView[4], railCnt = new TextView[4];
    private static TextView railState, sizeBtn, hdrTitle, hdrSub, status;
    private static View railDot;
    private static final View[] pane = new View[5];
    private static ScrollView sscroll;
    private static LinearLayout sbody;                             // v1.03: the Settings page
    private static int tab = 0, formBack = 0;
    private static long sayUntil = 0;
    private static LinearLayout cbody, lhead, shead, formBox;
    private static ScrollView cscroll;
    private static ListView lview, sview;

    // finder state
    private static int mode = 0, lf = 0;
    private static boolean listLoaded = false;
    /** v0.95: what the module says about its list (codm_tex.status): how many it listed, how many did not fit under the limit, the limit. -1 = not known yet. */
    private static int candN = -1, candR = -1, candOver = 0, candCap = -1;
    /** v0.99: the finder list holds every texture of this run, and about half are already gone from the game (Hide / Restore on them does nothing, so the test cannot tell). The module can say which ones are alive.
     *  v1.00: no toggle. The List shows ALL of them (the gone ones are dim, marked "gone", and can still be saved); the TEST (halves, Yes / No) uses only the alive ones. */
    private static java.util.HashSet<String> aliveSet = null;          // null = the module did not answer (older module / live off): nothing is marked gone, everything is in the test
    private static int goneN = 0;
    private static long cancelAt = 0;                              // v0.95: Cancel finder needs a second tap (v1.02: within 2 seconds, then the button goes back to normal by itself)
    private static ArrayList<Data.Row> allRows = new ArrayList<Data.Row>(), root = new ArrayList<Data.Row>(), allRoot = new ArrayList<Data.Row>(), lshown = new ArrayList<Data.Row>();
    private static int savedUnits = 0;
    /** v0.93: keys of the textures the finder is applying right now (the part last sent as Hide / Restore); null = nothing. Used for the "using" marks. */
    private static java.util.HashSet<String> usedKeys = null;
    private static final ArrayList<Node> path = new ArrayList<Node>();
    private static final LinkedHashMap<String, String> chip = new LinkedHashMap<String, String>();   // key -> H hidden / S shown / R restored (this game)
    private static LinkedHashSet<String> rHid = new LinkedHashSet<String>(), rOri = new LinkedHashSet<String>();
    private static final HashMap<String, Data.Saved> libMap = new HashMap<String, Data.Saved>();
    private static ArrayList<Data.Row> qFirst, qSecond;
    private static int qKind = 0;                                  // 0 none, 1 hide, 2 restore
    private static int qFirstIdx = 0;                              // v0.98: which half was applied for the question (0 = 1st, 1 = 2nd): the answer is named after it
    private static final LinkedHashSet<String> finderKeys = new LinkedHashSet<String>();   // v0.87: every texture the finder buttons touched (for Cancel finder)
    private static final ArrayList<Object> sitems = new ArrayList<Object>();
    // form (save / rename)
    private static int formKind = 0;                               // 0 none, 1 save, 2 rename, 3 group name (v0.89)
    private static boolean grpMode = false;                        // v0.89: Saved tab, picking textures to put in one group
    private static final LinkedHashSet<String> grpSel = new LinkedHashSet<String>();
    private static ArrayList<Data.Row> formRows;
    private static ArrayList<Data.Saved> formUnit;
    private static String formGrp = "plants", formKeep = "";
    private static boolean formAsSet = false, formRestore = false;
    private static EditText nameEt;
    private static String delArm = "";
    private static String grpPage = null;                          // v1.03: the group whose page is open in the Saved tab (its set id); null = the list of saved textures
    private static int pollLeft = 0;
    private static boolean polling = false;

    static final class Node {
        String label;
        ArrayList<Data.Row> rows;
        Node(String l, ArrayList<Data.Row> r) { label = l; rows = r; }
    }

    private interface Sel { void on(int i); }

    /** Called once by the module (any thread). */
    public static synchronized void start(Application a, String d) {
        if (started) return;
        started = true;
        app = a;
        dir = new File(d);
        try {
            app.registerActivityLifecycleCallbacks(new Application.ActivityLifecycleCallbacks() {
                public void onActivityResumed(Activity x) { act = x; }
                public void onActivityCreated(Activity x, Bundle b) { }
                public void onActivityStarted(Activity x) { }
                public void onActivityPaused(Activity x) { }
                public void onActivityStopped(Activity x) { }
                public void onActivitySaveInstanceState(Activity x, Bundle b) { }
                public void onActivityDestroyed(Activity x) { if (act == x) act = null; }
            });
        } catch (Throwable t) {
            err("callbacks", t);
        }
        H.post(TICK);
    }

    private static final Runnable TICK = new Runnable() {
        public void run() {
            try {
                Activity a = findAct();
                if (a != null) attach(a);
                if (overlay != null && overlay.getParent() instanceof ViewGroup) {      // v0.89: another view the game added later may cover the Q9 button: put the overlay back on top
                    ViewGroup pg = (ViewGroup) overlay.getParent();
                    if (pg.getChildCount() > 0 && pg.getChildAt(pg.getChildCount() - 1) != overlay) overlay.bringToFront();
                }
                if (winOpen) refreshStatus();
            } catch (Throwable t) {
                err("tick", t);
            }
            H.postDelayed(this, 3000);
        }
    };

    private static Activity findAct() {
        try {
            Class<?> c = Class.forName("com.unity3d.player.UnityPlayer", true, Menu.class.getClassLoader());
            Object o = c.getField("currentActivity").get(null);
            if (o instanceof Activity && !((Activity) o).isFinishing()) return (Activity) o;
        } catch (Throwable ignored) {
        }
        Activity a = act;
        return (a != null && !a.isFinishing()) ? a : null;
    }

    // ---------- small view helpers ----------
    /** v0.97: the content (text, buttons, paddings) is scaled with the window size (XS S M L); dpx() is the raw size for the window, the Q9 button and the toast. */
    private static final float[] KS = {0.80f, 0.86f, 0.92f, 1.02f};
    private static final int[] MINH = {30, 32, 34, 38}, MINS = {28, 30, 32, 34}, RAILS = {56, 66, 76, 84};
    private static int dp(float v) { return (int) (v * density * KS[size] + 0.5f); }
    private static int dpx(float v) { return (int) (v * density + 0.5f); }
    private static float ts(float sp) { return Math.max(8f, sp * KS[size]); }

    private static GradientDrawable box(int color, float radiusDp, int stroke) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(radiusDp));
        if (stroke != 0) g.setStroke(Math.max(1, dp(1)), stroke);
        return g;
    }

    /** Every tap goes through here: an exception in our code must never crash the game. */
    private static View.OnClickListener tap(final Runnable r) {
        return new View.OnClickListener() {
            public void onClick(View v) {
                try { r.run(); } catch (Throwable t) { err("tap", t); }
            }
        };
    }

    /** v0.95: every button shrinks a little and dims while it is pressed, and stays that way for a moment after the finger leaves, so a tap can always be seen.
     *  The listener never consumes the touch (returns false): the click works as before. */
    private static final View.OnTouchListener PRESS = new View.OnTouchListener() {
        public boolean onTouch(View v, MotionEvent e) {
            try {
                int m = e.getActionMasked();
                if (m == MotionEvent.ACTION_DOWN) pressAnim(v, true, true);
                else if (m == MotionEvent.ACTION_UP || m == MotionEvent.ACTION_CANCEL) pressAnim(v, false, true);
            } catch (Throwable ignored) { }
            return false;
        }
    };

    private static void pressAnim(View v, boolean down, boolean dim) {
        v.animate().cancel();
        if (down) {
            v.setScaleX(0.90f); v.setScaleY(0.90f);
            if (dim) v.setAlpha(0.65f);
        } else {
            float end = (v == fab && iconHidden && !winOpen) ? 0.02f : 1f;
            v.animate().scaleX(1f).scaleY(1f).alpha(end).setStartDelay(110).setDuration(140).start();
        }
    }

    private static Button btn(Activity a, String text, int fill, int fg, int stroke) {
        Button b = new Button(a);
        b.setOnTouchListener(PRESS);
        b.setText(text);
        b.setAllCaps(false);
        b.setTextSize(ts(12));
        b.setTextColor(fg);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setMinHeight(dpx(MINH[size]));
        b.setMinimumHeight(dpx(MINH[size]));
        b.setMinWidth(0);
        b.setMinimumWidth(0);
        b.setPadding(dp(8), dp(2), dp(8), dp(2));              // v1.03: compact (was 10 / 4)
        b.setBackground(box(fill, 6, stroke));
        return b;
    }

    private static Button sm(Activity a, String text, int fill, int fg, int stroke, Runnable r) {
        Button b = btn(a, text, fill, fg, stroke);
        b.setTextSize(ts(11));
        b.setMinHeight(dpx(MINS[size]));
        b.setMinimumHeight(dpx(MINS[size]));
        b.setPadding(dp(6), dp(2), dp(6), dp(2));              // v1.03: compact (was 7 / 3)
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        p.leftMargin = dp(3);                                  // v0.95: a little more room around the small buttons (was 4)
        p.topMargin = dp(1); p.bottomMargin = dp(1);
        b.setLayoutParams(p);
        if (r != null) b.setOnClickListener(tap(r));
        return b;
    }

    private static Button prim(Activity a, String t, Runnable r) { Button b = btn(a, t, ACC, ACCTXT, 0); b.setOnClickListener(tap(r)); return b; }
    private static Button neut(Activity a, String t, Runnable r) { Button b = btn(a, t, SURF2, TXT, LINE); b.setOnClickListener(tap(r)); return b; }
    private static Button dang(Activity a, String t, Runnable r) { Button b = btn(a, t, REDD, RED, REDL); b.setOnClickListener(tap(r)); return b; }
    private static Button good(Activity a, String t, Runnable r) { Button b = btn(a, t, GRND, GRN, GRNL); b.setOnClickListener(tap(r)); return b; }

    private static LinearLayout hrow(Activity a) {
        LinearLayout l = new LinearLayout(a);
        l.setOrientation(LinearLayout.HORIZONTAL);
        l.setGravity(Gravity.CENTER_VERTICAL);
        return l;
    }

    private static LinearLayout vcol(Activity a) {
        LinearLayout l = new LinearLayout(a);
        l.setOrientation(LinearLayout.VERTICAL);
        return l;
    }

    private static LinearLayout.LayoutParams wt(int m) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        int g = m == 0 ? dp(1) : m / 2 + dp(1);                // v1.03: tighter (was m + 1 dp: 3 dp each side, 6 between two buttons; now 2 dp each side)
        p.setMargins(g, g, g, g);
        return p;
    }

    private static LinearLayout.LayoutParams fullW(int top) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        p.topMargin = top / 2 + dp(1);                         // v1.03: half the gap above (was top + 2 dp)
        return p;
    }

    private static TextView txt(Activity a, String s, int sp, int color, boolean bold) {
        TextView t = new TextView(a);
        t.setText(s);
        t.setTextSize(ts(sp));
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    private static TextView mono(Activity a, String s, int sp, int color) {
        TextView t = txt(a, s, sp, color, false);
        t.setTypeface(Typeface.MONOSPACE);
        return t;
    }

    private static LinearLayout card(Activity a, int stroke) {
        LinearLayout c = vcol(a);
        c.setPadding(dp(6), dp(4), dp(6), dp(5));              // v1.03: compact (was 8 / 6 / 8 / 7)
        c.setBackground(box(SURF, 8, stroke == 0 ? LINE : stroke));
        cbody.addView(c, fullW(dp(4)));
        return c;
    }

    /** v1.03: the same card in another page (Settings). */
    private static LinearLayout cardIn(Activity a, LinearLayout parent) {
        LinearLayout c = vcol(a);
        c.setPadding(dp(6), dp(4), dp(6), dp(5));
        c.setBackground(box(SURF, 8, LINE));
        parent.addView(c, fullW(dp(4)));
        return c;
    }

    private static void label(Activity a, LinearLayout c, String s) {
        TextView t = txt(a, s.toUpperCase(), 9, DIM, true);
        t.setLetterSpacing(0.14f);
        t.setPadding(0, 0, 0, dp(3));
        c.addView(t);
    }

    private static LinearLayout seg(Activity a, String[] labels, int sel, final Sel cb) {
        LinearLayout c = hrow(a);
        c.setPadding(dp(1), dp(1), dp(1), dp(1));
        c.setBackground(box(SURF2, 7, 0));
        for (int i = 0; i < labels.length; i++) {
            final int k = i;
            Button b = btn(a, labels[i], i == sel ? ACC : CLEAR, i == sel ? ACCTXT : MUT, 0);
            b.setPadding(dp(5), dp(2), dp(5), dp(2));
            b.setOnClickListener(tap(new Runnable() { public void run() { cb.on(k); } }));
            c.addView(b, wt(0));
        }
        return c;
    }

    private static String shortHash(String h) { return h.length() > 8 ? h.substring(0, 8) : h; }

    private static String dims(Data.Row r) { return r.w + "\u00D7" + r.h; }

    /** v0.95: a small popup for a moment ("Saved", "List reloaded"). It sits at the bottom of the screen, takes no touches, and never needs a permission. */
    private static void toast(String s) {
        try {
            if (toastView == null || overlay == null) { say(s); return; }
            toastView.setText(s);
            toastView.setVisibility(View.VISIBLE);
            toastView.bringToFront();
            final long until = System.currentTimeMillis() + 1800;
            toastUntil = until;
            H.postDelayed(new Runnable() { public void run() { try { if (toastUntil == until && toastView != null) toastView.setVisibility(View.GONE); } catch (Throwable t) { } } }, 1850);
        } catch (Throwable t) { err("toast", t); }
    }

    // ---------- the overlay and the window ----------
    private static void attach(final Activity a) {
        if (overlay != null && overlay.getParent() != null && overlay.getContext() == a) return;
        if (overlay != null && overlay.getParent() != null) ((ViewGroup) overlay.getParent()).removeView(overlay);
        density = a.getResources().getDisplayMetrics().density;
        sw = a.getResources().getDisplayMetrics().widthPixels;
        sh = a.getResources().getDisplayMetrics().heightPixels;
        loadUi();
        loadSettle();
        reloadRules();
        overlay = new FrameLayout(a);

        fab = new TextView(a);
        fab.setText("Q9");
        fab.setTextColor(ACCTXT);
        fab.setTextSize(12);
        fab.setTypeface(Typeface.DEFAULT_BOLD);
        fab.setGravity(Gravity.CENTER);
        fabBg = new GradientDrawable();
        fabBg.setShape(GradientDrawable.OVAL);
        fabBg.setColor(0xE64CC3FF);
        fabBg.setStroke(Math.max(2, dpx(2)), 0xFF04202C);
        fab.setBackground(fabBg);
        if (fabX < 0) fabX = sw - dpx(56);
        FrameLayout.LayoutParams fl = new FrameLayout.LayoutParams(dpx(40), dpx(40));
        fl.gravity = Gravity.TOP | Gravity.LEFT;
        fl.leftMargin = clampX(fabX, dpx(40));
        fl.topMargin = clampY(fabY, dpx(40));
        fab.setOnTouchListener(dragger(fab, false));
        overlay.addView(fab, fl);
        buildWin(a);
        toastView = txt(a, "", 12, TXT, true);
        toastView.setBackground(box(0xEE0B1226, 10, ACC));
        toastView.setPadding(dp(14), dp(8), dp(14), dp(8));
        toastView.setGravity(Gravity.CENTER);
        toastView.setVisibility(View.GONE);
        FrameLayout.LayoutParams tl = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        tl.gravity = Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL;
        tl.bottomMargin = dpx(24);
        overlay.addView(toastView, tl);
        undoView = txt(a, "", 12, TXT, true);                                      // v1.03: Undo chip (touchable), a little above the toast
        undoView.setBackground(box(0xF01B2A4A, 10, AMB));
        undoView.setTextColor(AMB);
        undoView.setPadding(dp(14), dp(8), dp(14), dp(8));
        undoView.setGravity(Gravity.CENTER);
        undoView.setVisibility(View.GONE);
        undoView.setOnTouchListener(PRESS);
        undoView.setOnClickListener(tap(new Runnable() { public void run() { doUndo(); } }));
        FrameLayout.LayoutParams ul = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        ul.gravity = Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL;
        ul.bottomMargin = dpx(70);
        overlay.addView(undoView, ul);
        fab.bringToFront();
        paintFab();
        a.addContentView(overlay, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        if (!firstOk) {
            firstOk = true;
            new File(dir, "menu_try.txt").delete();
            put("menu_state.txt", "ok attached to " + a.getClass().getName() + "\n");
            say("CODM Blocky Textures \u2014 " + ownerName());    // v0.90: first short message, once per launch
        }
        refreshStatus();
        renderAll();
    }

    /** v0.95: the Q9 button is invisible when "Hide icon" is on and the window is closed; it is still there and a tap on its place opens the window. */
    private static void paintFab() {
        if (fab == null) return;
        boolean hide = iconHidden && !winOpen;
        fab.animate().cancel();
        fab.setScaleX(1f); fab.setScaleY(1f);
        fab.setAlpha(hide ? 0.02f : 1f);
    }

    private static int clampX(int x, int w) { return Math.max(0, Math.min(x, sw - w)); }
    private static int clampY(int y, int h) { return Math.max(0, Math.min(y, sh - h)); }

    private static int railW() { return RAILS[size]; }
    private static int winW() { return Math.min(dpx(BASE_W * SCALE[size]), sw - dpx(12)); }
    private static int winH() { return Math.min(dpx(BASE_H * SCALE[size]), sh - dpx(12)); }

    /** Drag: the touched view moves (the window header moves the window, the Q9 button moves itself). A tap on the Q9 button opens / closes the window. */
    private static View.OnTouchListener dragger(final View target, final boolean isWin) {
        return new View.OnTouchListener() {
            float dx, dy, sx, sy;
            boolean moved;
            public boolean onTouch(View v, MotionEvent e) {
                try {
                    FrameLayout.LayoutParams lp = (FrameLayout.LayoutParams) target.getLayoutParams();
                    switch (e.getActionMasked()) {
                        case MotionEvent.ACTION_DOWN:
                            sx = e.getRawX(); sy = e.getRawY(); dx = lp.leftMargin - sx; dy = lp.topMargin - sy; moved = false;
                            target.bringToFront();
                            if (fab != null) fab.bringToFront();
                            if (!isWin) pressAnim(target, true, false);          // v0.95: the Q9 button shrinks while it is touched
                            return true;
                        case MotionEvent.ACTION_MOVE:
                            if (Math.abs(e.getRawX() - sx) + Math.abs(e.getRawY() - sy) > dpx(8)) moved = true;
                            if (moved) {
                                int ww = lp.width > 0 ? lp.width : dpx(40), hh = lp.height > 0 ? lp.height : dpx(40);
                                lp.leftMargin = clampX((int) (e.getRawX() + dx), ww);
                                lp.topMargin = clampY((int) (e.getRawY() + dy), hh);
                                target.setLayoutParams(lp);
                                if (isWin) fabFollow(); else if (winOpen) dockWin();
                            }
                            return true;
                        case MotionEvent.ACTION_UP:
                            if (!isWin) pressAnim(target, false, false);
                            if (moved) {
                                if (!isWin) { fabX = lp.leftMargin; fabY = lp.topMargin; } else { winX = lp.leftMargin; winY = lp.topMargin; }
                                saveUi();
                            } else if (!isWin) setOpen(!winOpen);
                            return true;
                        case MotionEvent.ACTION_CANCEL:
                            if (!isWin) pressAnim(target, false, false);
                            return true;
                        default:
                            return true;
                    }
                } catch (Throwable t) {
                    err("drag", t);
                    return true;
                }
            }
        };
    }

    /** The window sits beside the Q9 button (on the side with room) and follows it. */
    private static void dockWin() {
        if (winView == null || fab == null) return;
        FrameLayout.LayoutParams fl = (FrameLayout.LayoutParams) fab.getLayoutParams(), wl = (FrameLayout.LayoutParams) winView.getLayoutParams();
        int fw = dpx(40), gap = dpx(6), ww = wl.width, hh = wl.height;
        int leftRoom = fl.leftMargin - gap, rightRoom = sw - (fl.leftMargin + fw) - gap;
        if (leftRoom >= ww && rightRoom >= ww) dockRight = fl.leftMargin + fw / 2 > sw / 2 ? 1 : 0;
        else if (leftRoom >= ww) dockRight = 1;
        else if (rightRoom >= ww) dockRight = 0;
        else dockRight = leftRoom >= rightRoom ? 1 : 0;
        int x = dockRight == 1 ? fl.leftMargin - gap - ww : fl.leftMargin + fw + gap;
        wl.leftMargin = clampX(x, ww);
        wl.topMargin = clampY(fl.topMargin - dpx(8), hh);
        winView.setLayoutParams(wl);
        winX = wl.leftMargin; winY = wl.topMargin;
    }

    /** The window was dragged: the button stays beside it, on the same side. */
    private static void fabFollow() {
        if (winView == null || fab == null) return;
        FrameLayout.LayoutParams fl = (FrameLayout.LayoutParams) fab.getLayoutParams(), wl = (FrameLayout.LayoutParams) winView.getLayoutParams();
        int fw = dpx(40), gap = dpx(6);
        fl.leftMargin = clampX(dockRight == 1 ? wl.leftMargin + wl.width + gap : wl.leftMargin - gap - fw, fw);
        fl.topMargin = clampY(wl.topMargin + dpx(8), fw);
        fab.setLayoutParams(fl);
        fabX = fl.leftMargin; fabY = fl.topMargin;
    }

    private static GradientDrawable railBg() {
        GradientDrawable g = new GradientDrawable();
        g.setColor(RAIL);
        float r = dp(12);
        g.setCornerRadii(new float[]{r, r, 0, 0, 0, 0, r, r});
        return g;
    }

    private static void buildWin(final Activity a) {
        if (winView != null && winView.getParent() != null) overlay.removeView(winView);
        int ww = winW(), hh = winH();
        LinearLayout v = hrow(a);
        v.setPadding(Math.max(1, dp(1)), Math.max(1, dp(1)), Math.max(1, dp(1)), Math.max(1, dp(1)));
        v.setBackground(box(BG, 12, LINE));
        v.setClickable(true);
        winView = v;

        // ----- rail: brand, three tabs, state, size -----
        LinearLayout rail = vcol(a);
        rail.setBackground(railBg());
        rail.setPadding(0, dp(8), 0, dp(8));
        LinearLayout brand = hrow(a);
        brand.setPadding(size == 0 ? dp(8) : dp(12), dp(2), dp(6), dp(size == 0 ? 6 : 10));
        TextView q = txt(a, "Q9", 15, TXT, true);
        q.setLetterSpacing(0.08f);
        brand.addView(q);
        if (size != 0) brand.addView(txt(a, "  textures", 9, DIM, false));
        brand.setOnTouchListener(dragger(v, true));
        rail.addView(brand);
        for (int i = 0; i < 4; i++) rail.addView(railBtn(a, i));       // v1.03: Test, List, Saved, Settings (rail position 3 = tab 4)
        View gap = new View(a);
        rail.addView(gap, new LinearLayout.LayoutParams(1, 0, 1f));
        LinearLayout st = hrow(a);
        st.setPadding(dp(12), dp(4), dp(6), dp(6));
        railDot = new View(a);
        railDot.setBackground(box(DIM, 4, 0));
        st.addView(railDot, new LinearLayout.LayoutParams(dp(7), dp(7)));
        railState = txt(a, "", 10, MUT, false);
        railState.setPadding(dp(6), 0, 0, 0);
        st.addView(railState);
        rail.addView(st);
        sizeBtn = txt(a, (size == 0 ? "" : "Size ") + sizeName() + " \u25BE", 10, TXT, false);
        sizeBtn.setPadding(size == 0 ? dp(8) : dp(12), dp(6), dp(6), dp(6));
        sizeBtn.setBackground(box(SURF2, 6, LINE));
        sizeBtn.setOnTouchListener(PRESS);
        sizeBtn.setOnClickListener(tap(new Runnable() { public void run() {
            showPicker("Window size", new String[]{"XS  extra small", "S  small", "M  medium", "L  large"}, null, size, "Text and buttons grow with it.", new Sel() { public void on(int i) {
                if (i == size) return; size = i; saveUi(); rebuildAll(); toast("Window size " + sizeName()); } });
        } }));
        LinearLayout.LayoutParams sbp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        sbp.setMargins(dp(6), dp(2), dp(6), dp(2));
        rail.addView(sizeBtn, sbp);
        iconBtn = txt(a, size == 0 ? (iconHidden ? "Icon off" : "Icon on") : (iconHidden ? "Icon: hidden" : "Icon: shown"), 10, TXT, false);
        iconBtn.setPadding(size == 0 ? dp(8) : dp(12), dp(6), dp(6), dp(6));
        iconBtn.setBackground(box(SURF2, 6, LINE));
        iconBtn.setOnTouchListener(PRESS);
        iconBtn.setOnClickListener(tap(new Runnable() { public void run() {
            iconHidden = !iconHidden; saveUi();
            if (iconBtn != null) iconBtn.setText(size == 0 ? (iconHidden ? "Icon off" : "Icon on") : (iconHidden ? "Icon: hidden" : "Icon: shown"));
            toast(iconHidden ? "Icon hides when you close this. Tap where it was to open." : "Icon stays visible.");
        } }));
        LinearLayout.LayoutParams ibp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        ibp.setMargins(dp(6), dp(2), dp(6), dp(2));
        rail.addView(iconBtn, ibp);
        TextView ownerLbl = txt(a, ownerName(), 8, DIM, false);        // v0.90: always-visible credit, every tab
        ownerLbl.setPadding(dp(12), dp(2), dp(6), dp(5));
        rail.addView(ownerLbl);
        v.addView(rail, new LinearLayout.LayoutParams(dpx(railW()), ViewGroup.LayoutParams.MATCH_PARENT));

        // ----- content: header (drag) + status + panes -----
        LinearLayout content = vcol(a);
        content.setPadding(dp(8), dp(4), dp(6), dp(6));         // v1.03: compact (was 10 / 6 / 8 / 8)
        LinearLayout head = hrow(a);
        head.setPadding(0, 0, 0, dp(2));
        hdrTitle = txt(a, TABT[tab], 14, TXT, true);
        head.addView(hdrTitle, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        // v1.03: the word "drag" is gone (the header still drags the window)
        head.addView(sm(a, "\u2715", SURF2, TXT, LINE, new Runnable() { public void run() { setOpen(false); } }));
        head.setOnTouchListener(dragger(v, true));
        content.addView(head);
        hdrSub = txt(a, TABD[tab], 10, DIM, false);
        hdrSub.setPadding(0, 0, 0, dp(3));
        if (size != 0) content.addView(hdrSub);                    // v0.95: the extra small window has no sub title (more room for the list)
        status = txt(a, "", 10, MUT, false);
        status.setMinLines(size == 0 ? 1 : 2);    // v0.93: always two lines high, so a short message does not move everything below it up and down (v0.95: one line in XS)
        status.setMaxLines(size == 0 ? 1 : 2);
        status.setPadding(0, 0, 0, dp(3));
        content.addView(status);

        FrameLayout body = new FrameLayout(a);
        // pane 0: Find (scrolling cards)
        cscroll = new ScrollView(a);
        cscroll.setVerticalScrollBarEnabled(false);
        cbody = vcol(a);
        cscroll.addView(cbody);
        body.addView(cscroll, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        pane[0] = cscroll;
        // pane 1: List
        LinearLayout lp1 = vcol(a);
        lhead = vcol(a);
        lp1.addView(lhead);
        lview = newList(a, LAD);
        lp1.addView(lview, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        body.addView(lp1, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        pane[1] = lp1;
        // pane 2: Saved
        LinearLayout lp2 = vcol(a);
        shead = vcol(a);
        lp2.addView(shead);
        sview = newList(a, SAD);
        lp2.addView(sview, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        body.addView(lp2, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        pane[2] = lp2;
        // pane 3: the save / rename form (a page of this window)
        ScrollView fs = new ScrollView(a);
        fs.setVerticalScrollBarEnabled(false);
        formBox = vcol(a);
        fs.addView(formBox);
        formScroll = fs;
        body.addView(fs, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        pane[3] = fs;
        // pane 4: Settings (v1.03)
        sscroll = new ScrollView(a);
        sscroll.setVerticalScrollBarEnabled(false);
        sbody = vcol(a);
        sscroll.addView(sbody);
        body.addView(sscroll, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        pane[4] = sscroll;
        content.addView(body, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        v.addView(content, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f));

        FrameLayout.LayoutParams pl = new FrameLayout.LayoutParams(ww, hh);
        pl.gravity = Gravity.TOP | Gravity.LEFT;
        pl.leftMargin = 0;
        pl.topMargin = 0;
        overlay.addView(v, pl);
        dockWin();
        v.setVisibility(winOpen ? View.VISIBLE : View.GONE);
        showTab(formKind != 0 ? 3 : tab);
    }

    // ---------- v0.97: a small list window to pick from (Size, List limit, search type): tap the button, tap a line ----------
    private static FrameLayout pickerView;

    private static void dismissPicker() {
        try { if (pickerView != null && overlay != null) overlay.removeView(pickerView); } catch (Throwable t) { }
        pickerView = null;
    }

    private static void showPicker(String title, final String[] opts, final boolean[] enabled, int sel, String note, final Sel cb) {
        if (overlay == null || winView == null) return;
        dismissPicker();
        Activity a = (Activity) overlay.getContext();
        FrameLayout scrim = new FrameLayout(a);
        scrim.setClickable(true);
        scrim.setBackground(box(0x66000000, 0, 0));
        scrim.setOnClickListener(tap(new Runnable() { public void run() { dismissPicker(); } }));
        LinearLayout panel = vcol(a);
        panel.setClickable(true);
        panel.setBackground(box(SURF, 10, ACC));
        panel.setPadding(dp(8), dp(6), dp(8), dp(8));
        TextView tt = txt(a, title.toUpperCase(), 9, DIM, true);
        tt.setLetterSpacing(0.12f);
        tt.setPadding(dp(4), 0, 0, dp(4));
        panel.addView(tt);
        LinearLayout col = vcol(a);
        for (int i = 0; i < opts.length; i++) {
            final int k = i;
            boolean en = enabled == null || enabled[i];
            TextView r = txt(a, (i == sel ? "\u2713  " : "     ") + opts[i], 12, !en ? DIM : (i == sel ? ACC : TXT), i == sel);
            r.setGravity(Gravity.CENTER_VERTICAL);
            r.setMinimumHeight(dpx(MINS[size] + 4));
            r.setPadding(dp(8), 0, dp(8), 0);
            r.setBackground(box(i == sel ? SURF2 : CLEAR, 6, 0));
            if (en) {
                r.setOnTouchListener(PRESS);
                r.setOnClickListener(tap(new Runnable() { public void run() { dismissPicker(); cb.on(k); } }));
            }
            col.addView(r, fullW(0));
        }
        FrameLayout.LayoutParams wl = (FrameLayout.LayoutParams) winView.getLayoutParams();
        int pw = Math.min(wl.width - dpx(16), dpx(230));
        int maxH = Math.max(dpx(80), wl.height - dpx(76));
        ScrollView sv = new ScrollView(a);
        sv.setVerticalScrollBarEnabled(false);
        sv.addView(col);
        int rowsH = opts.length * (dpx(MINS[size] + 4) + dp(2) + 2);
        panel.addView(sv, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Math.min(rowsH, maxH)));
        if (note != null && note.length() > 0) {
            TextView nt = txt(a, note, 9, DIM, false);
            nt.setPadding(dp(4), dp(4), 0, 0);
            panel.addView(nt);
        }
        FrameLayout.LayoutParams pl = new FrameLayout.LayoutParams(pw, ViewGroup.LayoutParams.WRAP_CONTENT);
        pl.gravity = Gravity.TOP | Gravity.LEFT;
        pl.leftMargin = clampX(wl.leftMargin + (wl.width - pw) / 2, pw);
        pl.topMargin = clampY(wl.topMargin + dpx(26), Math.min(wl.height - dpx(26), Math.min(rowsH, maxH) + dpx(60)));
        scrim.addView(panel, pl);
        overlay.addView(scrim, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        pickerView = scrim;
    }

    private static String sizeName() { return size == 0 ? "XS" : size == 1 ? "S" : size == 3 ? "L" : "M"; }

    private static View railBtn(final Activity a, final int i) {
        LinearLayout r = hrow(a);
        r.setPadding(0, dp(7), dp(6), dp(7));
        View bar = new View(a);
        bar.setBackground(box(CLEAR, 2, 0));
        r.addView(bar, new LinearLayout.LayoutParams(dp(3), dp(18)));
        TextView t = txt(a, TABN[i], 13, MUT, true);
        t.setPadding(dp(9), 0, 0, 0);
        r.addView(t, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        TextView c = mono(a, "", 10, DIM);
        r.addView(c);
        r.setOnTouchListener(PRESS);
        final int tabIdx = i == 3 ? 4 : i;
        r.setOnClickListener(tap(new Runnable() { public void run() { if (formKind != 0) closeForm(); showTab(tabIdx); } }));
        railBar[i] = bar;
        railTxt[i] = t;
        railCnt[i] = c;
        return r;
    }

    private static void showTab(int t) {
        tab = t == 3 ? tab : t;
        int hl = t == 3 ? formBack : t;
        for (int i = 0; i < 5; i++) if (pane[i] != null) pane[i].setVisibility(i == t ? View.VISIBLE : View.GONE);
        for (int i = 0; i < 4; i++) {
            if (railBar[i] == null) continue;
            boolean on = (i == 3 ? 4 : i) == hl;
            railBar[i].setBackground(box(on ? ACC : CLEAR, 2, 0));
            railTxt[i].setTextColor(on ? TXT : MUT);
        }
        if (t == 4) renderSettings();
        if (hdrTitle != null) hdrTitle.setText(t == 3 ? (formKind == 2 ? "Rename" : (formKind == 3 ? "Group" : TABT[3])) : TABT[t]);
        if (hdrSub != null) hdrSub.setText(TABD[t]);
    }

    private static void updateRail() {
        if (railCnt[1] == null) return;
        railCnt[0].setText("");
        railCnt[1].setText(listLoaded ? String.valueOf(shownBase().size()) : "");
        railCnt[2].setText(String.valueOf(savedUnits));
    }

    private static ListView newList(Activity a, BaseAdapter ad) {
        ListView l = new ListView(a);
        l.setDivider(box(LINE, 0, 0));
        l.setDividerHeight(dp(1));
        l.setSelector(box(CLEAR, 0, 0));
        l.setCacheColorHint(CLEAR);
        l.setVerticalScrollBarEnabled(false);
        l.setAdapter(ad);
        return l;
    }

    private static void rebuildAll() {
        if (overlay == null) return;
        dismissPicker();
        typing = false;
        Activity a = (Activity) overlay.getContext();
        buildWin(a);
        if (fab != null) fab.bringToFront();
        refreshStatus();
        renderAll();
        if (formKind != 0) showForm();
    }

    private static void setOpen(boolean on) {
        winOpen = on;
        if (!on) { dismissPicker(); try { hideKeyboard(); } catch (Throwable t) { } typingOff(); }
        if (winView != null) winView.setVisibility(on ? View.VISIBLE : View.GONE);
        paintFab();
        if (on) {
            dockWin();
            winView.bringToFront();
            if (fab != null) fab.bringToFront();
            refreshStatus();
            if (!listLoaded) loadList(); else renderAll();
        }
    }

    // ---------- files ----------
    private static void loadUi() {
        String s = Data.readSmall(new File(dir, "menu_ui.txt")).trim();
        if (s.length() == 0) return;
        try {
            String[] p = s.split("\\s+");
            if (p.length == 5) {                       // v0.77 .. v0.95: fabX fabY winX winY size (old sizes S / M / L = 0 / 1 / 2; the new list starts with XS)
                fabX = Integer.parseInt(p[0]); fabY = Integer.parseInt(p[1]); winX = Integer.parseInt(p[2]); winY = Integer.parseInt(p[3]);
                size = 1 + Math.max(0, Math.min(2, Integer.parseInt(p[4])));
            } else if (p.length == 6) {                // v0.95: fabX fabY winX winY size(XS S M L = 0..3) iconHidden
                fabX = Integer.parseInt(p[0]); fabY = Integer.parseInt(p[1]); winX = Integer.parseInt(p[2]); winY = Integer.parseInt(p[3]);
                size = Math.max(0, Math.min(3, Integer.parseInt(p[4])));
                iconHidden = "1".equals(p[5]);
            } else if (p.length >= 9) {                // v0.79 (three windows): fabX fabY size cx cy ...; the old Control position is kept
                fabX = Integer.parseInt(p[0]); fabY = Integer.parseInt(p[1]);
                size = 1 + Math.max(0, Math.min(2, Integer.parseInt(p[2])));
                winX = Integer.parseInt(p[3]); winY = Integer.parseInt(p[4]);
            }
        } catch (Throwable ignored) {
        }
    }

    private static void saveUi() {
        put("menu_ui.txt", fabX + " " + fabY + " " + winX + " " + winY + " " + size + " " + (iconHidden ? 1 : 0) + "\n");
    }

    private static boolean put(String name, String text) {
        try {
            java.io.FileOutputStream f = new java.io.FileOutputStream(new File(dir, name), false);
            try { f.write(text.getBytes("UTF-8")); } finally { f.close(); }
            return true;
        } catch (Throwable t) {
            if (!name.equals("menu_state.txt")) err("write " + name, t);
            return false;
        }
    }

    private static void err(String where, Throwable t) {
        try {
            java.io.FileOutputStream f = new java.io.FileOutputStream(new File(dir, "menu_state.txt"), false);
            try { f.write(("err " + where + ": " + t + "\n").getBytes("UTF-8")); } finally { f.close(); }
        } catch (Throwable ignored) {
        }
    }

    private static String kv(String text, String key) {
        int i = text.indexOf(key + "=");
        if (i < 0 || (i > 0 && text.charAt(i - 1) != '\n' && text.charAt(i - 1) != '|')) return null;
        int e = i + key.length() + 1, j = e;
        while (j < text.length() && text.charAt(j) != '\n' && text.charAt(j) != '|') j++;
        return text.substring(e, j).trim();
    }

    private static int kvI(String text, String key) {
        String v = kv(text, key);
        if (v == null) return -1;
        try { return Integer.parseInt(v); } catch (NumberFormatException e) { return -1; }
    }

    /** "1234 listed, limit 4000" for the Test and List tabs; says so when textures did not fit. */
    private static String limitText() {
        int lim = candCap > 0 ? candCap : 4000;
        int n = Math.max(candN, candR);
        String t = (n >= 0 ? n + " listed" : "List") + " \u00B7 limit " + lim;
        if (candOver > 0) t += " \u00B7 " + candOver + " did not fit";
        return t;
    }

    private static long sigHid = -1, sigOri = -1, sigLib = -1;
    private static ArrayList<Data.Saved> libC = null;

    private static long fsig(String name) { File f = new File(dir, name); return f.lastModified() * 31 + f.length(); }

    /** Reads the saved rules and My textures (after every change we make ourselves). */
    private static void reloadRules() {
        try {
            rHid = Data.readRuleKeys(dir, "hidden.txt");
            rOri = Data.readRuleKeys(dir, "orig.txt");
            libC = Data.readLib(dir);
            libMap.clear();
            for (Data.Saved s : libC) libMap.put(s.key, s);
            sigHid = fsig("hidden.txt"); sigOri = fsig("orig.txt"); sigLib = fsig("texlib.txt");
        } catch (Throwable t) {
            err("rules", t);
        }
    }

    /** v0.95: drawing used to read three files on the main thread at EVERY tap; now only when one of them changed (the WebUI may have written it). */
    private static void reloadRulesIfChanged() {
        if (libC != null && sigHid == fsig("hidden.txt") && sigOri == fsig("orig.txt") && sigLib == fsig("texlib.txt")) return;
        reloadRules();
    }

    private static void setState(int color, String text) {
        if (railDot != null) railDot.setBackground(box(color, 4, 0));
        if (railState != null) { railState.setText(text); railState.setTextColor(color == DIM ? MUT : color); }
    }

    private static void refreshStatus() {
        if (status == null) return;
        if (System.currentTimeMillis() < sayUntil) return;            // a message from a button is still showing
        String live = Data.readSmall(new File(dir, "live.txt")).trim();
        if (!live.startsWith("1")) {
            status.setText("Live test is off. Turn it on in the WebUI, then restart CODM.");
            setState(DIM, "Live off");
            return;
        }
        String st = Data.readSmall(new File(dir, "codm_tex.status"));
        candN = kvI(st, "cand_n"); candR = kvI(st, "rcand_n"); candOver = Math.max(0, kvI(st, "cand_over")); candCap = kvI(st, "cand_cap");
        String cap = kv(st, "lv_cap"), n = kv(st, "lv_hash"), kb = kv(st, "lv_kb"), last = kv(st, "lv_last"), bk = kv(st, "lv_bk"), bkmb = kv(st, "lv_bkmb");
        if (cap == null) { status.setText("Waiting for the module..."); setState(DIM, "Waiting"); return; }
        int pend = Data.kvInt("p=" + (kv(st, "lv_pend") == null ? "0" : kv(st, "lv_pend")), "p");
        StringBuilder b = new StringBuilder();
        b.append("1".equals(cap) ? "Capturing" : "Not capturing").append(" \u00B7 ").append(n == null ? "0" : n).append(" copies (").append(kb == null ? "0" : kb).append(" KB)");
        if (bk != null && !"0".equals(bk)) b.append(" \u00B7 ").append(bk).append(" GPU backups (").append(bkmb == null ? "0" : bkmb).append(" MB)");
        String fl = Data.friendlyLast(last);
        String l2 = "";
        if (pend > 0) l2 = "Applying, " + pend + " left";
        else if (fl.length() > 0) l2 = "Last: " + fl;
        int nocopy = Data.kvInt(last, "nocopy");
        if (pend <= 0 && nocopy > 0) l2 += " \u00B7 " + nocopy + " cannot return live (blank at load). Turn the rule OFF in Saved, restart CODM.";
        status.setText(l2.length() > 0 ? l2 + "\n" + b : b.toString());
        setState(pend > 0 ? AMB : ("1".equals(cap) ? GRN : DIM), pend > 0 ? "Applying" : ("1".equals(cap) ? "Capturing" : "Ready"));
        if (fabBg != null) fabBg.setColor(pend > 0 ? 0xE6A78BFA : 0xE64CC3FF);
        if (pend > 0) startPoll();
    }

    /** A short message from a button; it stays for a few seconds before the live status comes back. */
    private static void say(String s) {
        sayUntil = System.currentTimeMillis() + 5000;
        if (status != null) status.setText(s);
    }

    private static void startPoll() {
        pollLeft = 40;
        if (polling) return;
        polling = true;
        H.postDelayed(new Runnable() {
            public void run() {
                try { refreshStatus(); } catch (Throwable t) { err("poll", t); }
                if (--pollLeft > 0) H.postDelayed(this, 1000); else polling = false;
            }
        }, 1000);
    }

    // ---------- commands ----------
    /** Sends "op hash" lines in ONE write (the module takes up to 8192 lines per file and applies them over a few frames). */
    private static void sendLines(final ArrayList<String> lines, final String what) {
        if (lines.isEmpty()) { say("Nothing to send."); return; }
        final int step = 8000;
        for (int i = 0; i * step < lines.size(); i++) {
            final int from = i * step;
            Runnable r = new Runnable() {
                public void run() {
                    try {
                        StringBuilder sb = new StringBuilder();
                        for (int k = from; k < Math.min(lines.size(), from + step); k++) sb.append(lines.get(k)).append('\n');
                        if (!Data.writeAtomic(new File(dir, "livecmd.txt"), sb.toString())) say("Could not write livecmd.txt");
                    } catch (Throwable t) { err("send", t); }
                }
            };
            if (i == 0) r.run(); else H.postDelayed(r, 3000L * i);
        }
        say(what + ": " + lines.size() + " sent. Look at the game.");
        H.postDelayed(new Runnable() { public void run() { try { sayUntil = 0; refreshStatus(); } catch (Throwable t) { err("send", t); } } }, 4500);
        startPoll();
    }

    private static void addOps(ArrayList<String> out, String op, List<Data.Row> rows) { for (Data.Row r : rows) out.add(op + " " + r.hash); }

    private static void mark(List<Data.Row> rows, String c) { for (Data.Row r : rows) chip.put(r.key(), c); }

    private static boolean usingRows(List<Data.Row> rows) {
        if (usedKeys == null || rows == null || rows.isEmpty() || rows.size() != usedKeys.size()) return false;
        for (Data.Row r : rows) if (!usedKeys.contains(r.key())) return false;
        return true;
    }

    private static void setUsed(List<Data.Row> rows) {
        usedKeys = new java.util.HashSet<String>();
        if (rows != null) for (Data.Row r : rows) usedKeys.add(r.key());
    }

    /** Hide / Restore a part of the current set. Hide: the rest of the set is shown again, so only this part is hidden. */
    private static void doPart(ArrayList<Data.Row> part, ArrayList<Data.Row> other, String label) {
        ArrayList<String> ls = new ArrayList<String>();
        for (Data.Row r : part) finderKeys.add(r.key());
        if (other != null) for (Data.Row r : other) finderKeys.add(r.key());
        if (mode == 0) {
            addOps(ls, "h", part);
            if (other != null) addOps(ls, "u", other);
            mark(part, "H");
            if (other != null) mark(other, "S");
        } else {
            addOps(ls, "r", part);
            mark(part, "R");
            // v0.87: the other half gets its look back (before, 1st half then 2nd half left BOTH restored, so the answer of the test meant nothing).
            // Only what this finder restored is put back: a texture that is saved as Restore keeps its saved state.
            if (other != null) {
                ArrayList<Data.Row> back = new ArrayList<Data.Row>();
                for (Data.Row r : other) if ("R".equals(chip.get(r.key())) && !rOri.contains(r.key())) back.add(r);
                addOps(ls, "f", back);
                mark(back, "O");
            }
        }
        setUsed(part);
        if (!ls.isEmpty()) busyStart();
        sendLines(ls, label);
        renderAll();
    }

    /** v0.87 Cancel finder: everything the finder hid or restored goes back to how it was before the test; the narrowing starts over. Saved rules are not touched. */
    private static void cancelFinder() {
        ArrayList<String> ls = Data.cancelOps(finderKeys, chip, rHid, rOri);
        for (String k : finderKeys) chip.remove(k);               // what the saved rules say is the state again
        finderKeys.clear();
        usedKeys = null;
        busyStop();
        recomputeRoot();                                           // back to the first list, no question open
        if (ls.isEmpty()) { say("Finder cancelled. Nothing had to be put back."); renderAll(); return; }
        sendLines(ls, "Cancel finder");
        renderAll();
    }

    private static void one(String op, Data.Row c, String ch) {
        ArrayList<String> ls = new ArrayList<String>();
        ls.add(op + " " + c.hash);
        chip.put(c.key(), ch);
        sendLines(ls, op.equals("h") ? "Hide" : op.equals("u") ? "Show" : op.equals("f") ? "Look on" : "Restore");
        renderAll();
    }

    // ---------- the list (finder state) ----------
    private static boolean loading = false;

    /** v0.95: reads the module's own list file (codm_tex.cands: every texture of this game run, not cut by the log cap); an older module without it: the log. */
    private static void loadList() { loadList(false); }

    private static void loadList(final boolean loud) {
        if (loading) return;
        loading = true;
        if (loud) toast("Reloading the list...");
        new Thread(new Runnable() {
            public void run() {
                try {
                    String src = Data.readCands(dir);
                    if (src == null) src = Data.read(new File(dir, "codm_tex.log"), 3 * 1024 * 1024);
                    final ArrayList<Data.Row> all = Data.parseLog(src, false);
                    H.post(new Runnable() {
                        public void run() {
                            try {
                                loading = false;
                                allRows = all;
                                reloadRules();
                                recomputeRoot();
                                listLoaded = true;
                                if (loud) toast("List reloaded: " + all.size() + " textures");
                                renderAll();
                                askAlive(loud);
                            } catch (Throwable t) {
                                loading = false;
                                err("load", t);
                            }
                        }
                    });
                } catch (Throwable t) {
                    loading = false;
                    err("loadList", t);
                }
            }
        }).start();
    }

    /** v0.99: asks the module which listed textures are alive now ("a 0" in livecmd.txt), waits up to ~2.5 s for its answer (a new seq in codm_tex.alive) and then cuts the list. */
    private static void askAlive(final boolean loud) {
        new Thread(new Runnable() {
            public void run() {
                try {
                    int before = Data.readAlive(dir).seq;
                    if (!Data.writeAtomic(new File(dir, "livecmd.txt"), "a 0\n")) return;
                    Data.Alive al = null;
                    for (int i = 0; i < 20; i++) {
                        try { Thread.sleep(130); } catch (InterruptedException e) { return; }
                        Data.Alive x = Data.readAlive(dir);
                        if (x.seq >= 0 && x.seq != before && x.hashes != null) { al = x; break; }
                    }
                    if (al == null) return;
                    final java.util.HashSet<String> hs = al.hashes;
                    H.post(new Runnable() {
                        public void run() {
                            try {
                                aliveSet = hs;
                                recomputeRoot();
                                if (loud) toast("Loaded now: " + root.size() + (goneN > 0 ? " (" + goneN + " gone from the game, marked in the List)" : ""));
                                renderAll();
                            } catch (Throwable t) { err("alive", t); }
                        }
                    });
                } catch (Throwable t) { err("askAlive", t); }
            }
        }).start();
    }

    private static void recomputeRoot() {
        Data.Filtered f = Data.rootRows(allRows, mode == 0);
        goneN = 0;
        allRoot = f.rows;                                                  // v1.00: what the List shows at the first step (alive and gone)
        if (aliveSet != null) { ArrayList<Data.Row> al = Data.onlyAlive(f.rows, aliveSet); goneN = f.rows.size() - al.size(); root = al; }   // what the test works on
        else root = f.rows;
        path.clear();
        path.add(new Node("All " + root.size(), root));
        qKind = 0;
    }

    private static ArrayList<Data.Row> cur() { return path.isEmpty() ? new ArrayList<Data.Row>() : path.get(path.size() - 1).rows; }

    /** v1.00: what the List shows. At the first step: every listed texture (also the ones gone from the game). After narrowing down: the part that is being tested (alive only). */
    private static ArrayList<Data.Row> shownBase() { return path.size() <= 1 ? allRoot : cur(); }

    /** v1.00: the module said this texture is not in the game any more (null answer = nothing is known, so nothing is marked). */
    private static boolean isGone(Data.Row r) { return aliveSet != null && !aliveSet.contains(r.hash); }

    private static void into(ArrayList<Data.Row> part, String name) {
        path.add(new Node(name + "-" + part.size(), part));          // v0.98: "1st-20", "2nd-10" (was yes 20 / other 10)
        qKind = 0;
        renderAll();
    }

    private static void up(int toLevel) {
        while (path.size() > toLevel + 1 && path.size() > 1) path.remove(path.size() - 1);
        qKind = 0;
        renderAll();
    }

    private static int stateOf(Data.Row r) {
        String k = r.key();
        return Data.stateOf(chip.get(k), rHid.contains(k), rOri.contains(k));
    }

    // ---------- drawing ----------
    private static void renderAll() {
        if (overlay == null) return;
        try {
            renderList();
            renderSaved();
            renderControl();
            renderSettings();
            updateRail();
        } catch (Throwable t) {
            err("draw", t);
        }
    }

    private static void renderControl() {
        if (cbody == null || overlay == null) return;
        Activity a = (Activity) overlay.getContext();
        final int keepY = cscroll != null ? cscroll.getScrollY() : 0;      // v0.93: the page is rebuilt on every tap; it stays where the finger left it
        cbody.removeAllViews();
        drawControl(a);
        if (cscroll != null && keepY > 0) {
            cscroll.scrollTo(0, keepY);
            H.post(new Runnable() { public void run() { try { if (cscroll != null) cscroll.scrollTo(0, keepY); } catch (Throwable t) { } } });
        }
    }

    private static void drawControl(final Activity a) {
        // what is hidden now, and is it saved?
        final ArrayList<Data.Row> unsaved = Data.unsavedHidden(chip, libMap.keySet(), rHid, rOri);
        final ArrayList<String> hidKeys = Data.keysWith(chip, "H");
        if (!hidKeys.isEmpty()) {
            LinearLayout c = card(a, unsaved.isEmpty() ? GRNL : AMBL);
            c.addView(txt(a, hidKeys.size() + " hidden now", 12, TXT, true));
            if (unsaved.isEmpty()) c.addView(txt(a, "All saved. Hidden again at every game start.", 10, GRN, false));
            else c.addView(txt(a, unsaved.size() + " not saved. They return when CODM restarts.", 10, AMB, false));
            LinearLayout r = hrow(a);
            if (!unsaved.isEmpty()) r.addView(prim(a, "Save hidden", new Runnable() {
                public void run() { formRestore = false; openForm(1, unsaved, null, unsaved.size() > 1); } }), wt(dp(2)));
            r.addView(good(a, "Show hidden", new Runnable() {
                public void run() {
                    ArrayList<String> ls = new ArrayList<String>();
                    for (String k : hidKeys) { try { ls.add("u " + Data.rowOfKey(k).hash); chip.put(k, "S"); } catch (RuntimeException ignored) { } }
                    sendLines(ls, "Show hidden"); renderAll(); } }), wt(dp(2)));
            c.addView(r, fullW(dp(6)));
        }

        // finder (v0.95: the Marks card is gone; the list is always "All Textures Loaded")
        LinearLayout fd = card(a, 0);
        label(a, fd, "Finder");
        fd.addView(seg(a, new String[]{"Hide", "Restore"}, mode, new Sel() { public void on(int i) { if (i != mode) { mode = i; recomputeRoot(); renderAll(); } } }));
        fd.addView(txt(a, "List: All Textures Loaded", 11, TXT, true), fullW(dp(5)));
        fd.addView(txt(a, limitText(), 10, candOver > 0 ? AMB : MUT, false));
        LinearLayout r2 = hrow(a);
        r2.addView(neut(a, "Reload list", new Runnable() { public void run() { loadList(true); } }), wt(dp(2)));
        fd.addView(r2, fullW(dp(4)));                                              // v1.03: "Limit" and "Wait after apply" are in the Settings tab now
        if (aliveSet != null && goneN > 0)                                        // v1.00: no toggle; the gone ones stay in the List (dim) and are left out of the test
            fd.addView(txt(a, goneN + " gone from the game: dim in the List, not in the test. You can still Save them.", 10, MUT, false));

        // family
        LinearLayout fm = card(a, 0);
        drawKindPick(a, fm);
        if (!listLoaded) fm.addView(txt(a, "Loading...", 11, MUT, false));
        else if (root.isEmpty()) fm.addView(txt(a, allRoot.isEmpty() ? "Nothing yet. Play a moment, then Reload list." : "Everything listed is gone from the game. Play a moment, then Reload list.", 11, MUT, false));
        else drawFamily(a, fm);
        drawCancel(a, fm);

        TextView hint = txt(a, "Works on textures the game already loaded. Saved items use the same rules as the WebUI.", 10, DIM, false);
        hint.setPadding(dp(2), dp(5), dp(2), dp(3));
        if (size >= 2) cbody.addView(hint);
    }

    /** v0.97: "Narrow down" is a choice now (tap it, pick the way to search). Only "Narrow down" works for now; the others are added later. */
    private static void drawKindPick(final Activity a, LinearLayout fm) {
        TextView t = txt(a, "NARROW DOWN  \u25BE", 9, ACC, true);
        t.setLetterSpacing(0.12f);
        t.setPadding(dp(8), dp(4), dp(8), dp(4));
        t.setBackground(box(SURF2, 6, LINE));
        t.setOnTouchListener(PRESS);
        t.setOnClickListener(tap(new Runnable() { public void run() {
            showPicker("Way to search", new String[]{"Narrow down"}, null, 0, "More ways to search come later.", new Sel() { public void on(int i) { } });
        } }));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        p.bottomMargin = dp(4);
        fm.addView(t, p);
    }

    /** v0.95: Cancel finder sits under "Narrow down" and needs two taps: the first changes the button to "Click again", the second does it.
     *  v1.02: "Click again!" stays only CANCEL_ARM_MS (2 s, was 4 s); then the button goes back to "Cancel finder" by itself and nothing is cancelled. */
    private static final long CANCEL_ARM_MS = 2000;
    private static boolean cancelArmed() { return cancelAt > 0 && System.currentTimeMillis() - cancelAt <= CANCEL_ARM_MS; }

    private static void drawCancel(Activity a, LinearLayout fm) {
        // v0.97: armed = solid amber with dark text ("Click again"), so it is clear at a glance that the next tap does it; normal = the red outline
        final boolean armed = cancelArmed();
        final Button b = armed ? btn(a, "Click again!", AMBFILL, 0xFF1A1000, 0) : dang(a, "Cancel finder", null);
        b.setOnClickListener(tap(new Runnable() { public void run() {
            if (cancelArmed()) { cancelAt = 0; cancelFinder(); return; }
            final long mine = System.currentTimeMillis();
            cancelAt = mine;
            renderControl();
            H.postDelayed(new Runnable() { public void run() { try { if (cancelAt == mine) { cancelAt = 0; renderControl(); } } catch (Throwable t) { } } }, CANCEL_ARM_MS + 100);
        } }));
        fm.addView(b, fullW(dp(4)));
        if (size >= 2) fm.addView(txt(a, "Puts back everything the finder hid or restored and starts over. Saved items stay.", 10, DIM, false));
    }

    private static int curLimit() { return candCap > 0 ? candCap : 4000; }

    /** v0.95: the most textures the module lists (1000 / 2000 / 4000 / 8000 / 16000); the module reads it within a second. More textures = more memory. */
    private static void pickLimit() {
        int c = curLimit(), at = 0;
        String[] o = new String[LIMITS.length];
        for (int i = 0; i < LIMITS.length; i++) { o[i] = String.valueOf(LIMITS[i]); if (LIMITS[i] == c) at = i; }
        showPicker("List limit", o, null, at, "More textures = more memory.", new Sel() { public void on(int i) { setLimit(LIMITS[i]); } });
    }

    private static void setLimit(int nx) {
        int c = curLimit();
        if (nx == c) return;
        if (put("listcap.txt", nx + "\n")) {
            candCap = nx;
            toast("List limit " + nx + (nx > c ? ". Textures that did not fit come in when they load again." : ". Applies to textures loaded from now on."));
        } else toast("Could not write listcap.txt");
        renderAll();
    }

    /** v1.03: the Settings tab. Wait after apply and List limit were in the Test tab; they live here now. */
    private static void renderSettings() {
        if (sbody == null || overlay == null) return;
        Activity a = (Activity) overlay.getContext();
        final int keepY = sscroll != null ? sscroll.getScrollY() : 0;
        sbody.removeAllViews();
        LinearLayout c1 = cardIn(a, sbody);
        label(a, c1, "After a test button");
        c1.addView(neut(a, "Wait after apply: " + settleText() + " \u25BE", new Runnable() { public void run() { pickSettle(); } }), fullW(dp(2)));
        c1.addView(txt(a, "The extra wait after the module says it applied, so the game can show the change before you answer. Slow game: pick more.", 10, MUT, false), fullW(dp(2)));
        LinearLayout c2 = cardIn(a, sbody);
        label(a, c2, "List");
        c2.addView(neut(a, "List limit: " + curLimit() + " \u25BE", new Runnable() { public void run() { pickLimit(); } }), fullW(dp(2)));
        c2.addView(txt(a, limitText() + ". More textures = more memory.", 10, candOver > 0 ? AMB : MUT, false), fullW(dp(2)));
        LinearLayout c3 = cardIn(a, sbody);
        label(a, c3, "Window");
        c3.addView(txt(a, "Window size and the icon are the two buttons at the bottom left of this window.", 10, MUT, false));
        if (sscroll != null && keepY > 0) sscroll.scrollTo(0, keepY);
    }

    // ---------- v0.98: wait until the game shows the change (the finder buttons are off meanwhile) ----------
    private static boolean busy = false;
    /** v1.01: the extra wait after the module says "applied", so the game can show it (was a fixed 450 ms guess). Setting "Wait after apply" in the finder card: Off (0) / 250 / 450 / 700 / 1000 / 1500 / 2000 ms; saved in menu_settle.txt. */
    private static final int[] SETTLES = {0, 250, 450, 700, 1000, 1500, 2000};
    private static long busySettle = 450;                                   // = the default (BUSY_SETTLE)

    private static void loadSettle() {
        try {
            String t = Data.readSmall(new File(dir, "menu_settle.txt")).trim();
            if (t.length() == 0) return;
            int v = Integer.parseInt(t.split("\\s+")[0]);
            if (v >= 0 && v <= 5000) busySettle = v;
        } catch (Throwable ignored) { }
    }

    private static String settleText() { return busySettle == 0 ? "Off" : busySettle + " ms"; }

    private static void pickSettle() {
        int at = -1;
        for (int i = 0; i < SETTLES.length; i++) if (SETTLES[i] == busySettle) at = i;
        String[] o = {"Off (no extra wait)", "250 ms", "450 ms (default)", "700 ms", "1000 ms", "1500 ms", "2000 ms"};
        showPicker("Wait after apply", o, null, at, "Extra wait after the module says it applied, so the game can show it. Slow game: pick more.", new Sel() { public void on(int i) { setSettle(SETTLES[i]); } });
    }

    private static void setSettle(int ms) {
        if (put("menu_settle.txt", ms + "\n")) { busySettle = ms; toast("Wait after apply: " + settleText()); }
        else toast("Could not write menu_settle.txt");
        renderAll();
    }
    private static long busyT0 = 0, busyAckAt = 0;
    private static String busyLast = "";
    private static int busySeq = -1, busyN = 0;
    private static TextView busyTv = null;
    private static final String[] BUSY_FR = {"\u25D0", "\u25D3", "\u25D1", "\u25D2"};
    private static final long BUSY_SETTLE = 450, BUSY_NOACK = 2800, BUSY_MAX = 6000;   // BUSY_SETTLE is the default of the 'Wait after apply' setting (busySettle)

    /** A button that does nothing while the last Hide / Restore is still being applied (pressing on, the finder got mixed up). */
    private static Runnable gate(final Runnable r) { return new Runnable() { public void run() { if (!busy) r.run(); } }; }

    private static void busyStart() {
        try {
            String st = Data.readSmall(new File(dir, "codm_tex.status"));
            busyLast = kv(st, "lv_last") == null ? "" : kv(st, "lv_last");
            busySeq = kvI(st, "lv_seq");
        } catch (Throwable t) { busyLast = ""; busySeq = -1; }
        busy = true; busyT0 = System.currentTimeMillis(); busyAckAt = 0; busyN = 0;
        H.postDelayed(new Runnable() { public void run() { busyTick(); } }, 150);
    }

    private static void busyStop() { busy = false; busyTv = null; }

    private static void busyTick() {
        try {
            if (!busy) return;
            long now = System.currentTimeMillis();
            busyN++;
            if (busyAckAt == 0 && busyN % 2 == 0) {                   // read the status file every 300 ms: the module has applied it when lv_seq moved (older module: lv_last changed)
                String st = Data.readSmall(new File(dir, "codm_tex.status"));
                String last = kv(st, "lv_last") == null ? "" : kv(st, "lv_last");
                int sq = kvI(st, "lv_seq");
                boolean working = last.startsWith("working");
                boolean moved = sq >= 0 && busySeq >= 0 ? sq != busySeq : !last.equals(busyLast);
                if (!working && (moved || now - busyT0 >= BUSY_NOACK)) busyAckAt = now;
            }
            if ((busyAckAt != 0 && now - busyAckAt >= busySettle) || now - busyT0 >= BUSY_MAX) {
                busyStop();
                renderControl();
                return;
            }
            if (busyTv != null) busyTv.setText(BUSY_FR[busyN % 4] + "  Applying, wait...");
            H.postDelayed(new Runnable() { public void run() { busyTick(); } }, 150);
        } catch (Throwable t) { busyStop(); err("busy", t); try { renderControl(); } catch (Throwable u) { } }
    }

    private static View usingTag(Activity a, boolean on) {
        LinearLayout c = vcol(a);
        TextView t = txt(a, on ? "\u25B2" : " ", 9, GRN, true);           // v0.98: an arrow under the button that is applied now (was the word "using" + a line); v1.03: smaller and tight (no font padding)
        t.setIncludeFontPadding(false);
        t.setPadding(0, 0, 0, 0);
        t.setGravity(Gravity.CENTER_HORIZONTAL);
        c.addView(t, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        return c;
    }

    private static void drawFamily(final Activity a, LinearLayout fm) {
        HorizontalScrollView hs = new HorizontalScrollView(a);
        hs.setHorizontalScrollBarEnabled(false);
        final LinearLayout crumbs = hrow(a);
        View lastCol = null;
        for (int i = 0; i < path.size(); i++) {
            final int lvl = i;
            if (i > 0) crumbs.addView(txt(a, "  \u203A", 12, DIM, false));
            boolean last = i == path.size() - 1;
            LinearLayout col = vcol(a);
            col.addView(sm(a, path.get(i).label, last ? ACC : SURF2, last ? ACCTXT : TXT, last ? 0 : LINE, gate(new Runnable() { public void run() { up(lvl); } })));
            boolean usedHere = usingRows(path.get(i).rows);
            TextView ut = txt(a, usedHere ? "\u25B2" : " ", 9, GRN, true);        // v0.93: shows which step is the one on the screen now; v1.03: tight
            ut.setIncludeFontPadding(false);
            ut.setGravity(Gravity.CENTER_HORIZONTAL);
            col.addView(ut);
            crumbs.addView(col);
            lastCol = col;
        }
        hs.addView(crumbs);
        fm.addView(hs);
        // v0.93: keep the step we are on in the middle of the strip (it used to start at the far left, so a long path hid the current step)
        final HorizontalScrollView hsF = hs;
        final View lastF = lastCol;
        Runnable centre = new Runnable() { public void run() {
            try { if (lastF != null && hsF.getWidth() > 0) hsF.scrollTo(Math.max(0, lastF.getLeft() + lastF.getWidth() / 2 - hsF.getWidth() / 2), 0); } catch (Throwable t) { } } };
        H.post(centre);
        H.postDelayed(centre, 120);
        H.postDelayed(centre, 400);

        final ArrayList<Data.Row> set = cur();
        final ArrayList<Data.Row> h1 = Data.half(set, 0), h2 = Data.half(set, 1);
        final String verb = mode == 0 ? "Hide" : "Restore";
        TextView cnt = txt(a, set.size() + " texture" + (set.size() == 1 ? "" : "s") + " in this test", 11, TXT, false);
        cnt.setPadding(dp(2), dp(6), 0, dp(3));
        fm.addView(cnt);
        busyTv = null;
        if (busy) {                                                   // v0.98: loading label while the game has not shown the change yet; the buttons are off meanwhile
            busyTv = txt(a, BUSY_FR[0] + "  Applying, wait...", 12, AMB, true);
            busyTv.setPadding(dp(8), dp(4), dp(8), dp(4));
            busyTv.setBackground(box(AMBD, 6, AMBL));
            fm.addView(busyTv, fullW(dp(3)));
        }

        if (qKind != 0 && qFirst != null) {
            LinearLayout q = hrow(a);
            q.setPadding(dp(8), dp(4), dp(4), dp(4));
            q.setBackground(box(AMBD, 6, AMBL));
            q.addView(txt(a, qKind == 1 ? "Is it gone?" : "Is it fixed?", 12, AMB, true), new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
            q.addView(sm(a, "Yes", GRND, GRN, GRNL, gate(new Runnable() { public void run() { into(qFirst, qFirstIdx == 0 ? "1st" : "2nd"); } })));
            q.addView(sm(a, "No", REDD, RED, REDL, gate(new Runnable() { public void run() {
                // v0.93: "No" = it is in the other half. That half is applied right now (so the result can be seen), and the search goes into it.
                ArrayList<Data.Row> was = qFirst, now = qSecond;
                int nowIdx = qFirstIdx == 0 ? 1 : 0;
                doPart(now, was, verb + (nowIdx == 0 ? " 1st half" : " 2nd half"));
                into(now, nowIdx == 0 ? "1st" : "2nd");
            } })));
            q.addView(sm(a, "Skip", SURF2, MUT, LINE, gate(new Runnable() { public void run() { qKind = 0; renderAll(); } })));
            if (busy) q.setAlpha(0.4f);
            fm.addView(q, fullW(dp(3)));
        }
        if (set.size() == 0) return;

        // v1.03: Restore has "Restore all" again, like Hide (one texture left = "Restore"); John asked for it back
        boolean showAll = true;
        LinearLayout r3 = hrow(a);
        final String allName = set.size() == 1 ? verb : verb + " all";            // v0.98: one texture left = "Hide" / "Restore", not "... all"
        Runnable allL = gate(new Runnable() { public void run() { doPart(set, null, allName); } });
        if (showAll) r3.addView(mode == 0 ? dang(a, allName, allL) : prim(a, allName, allL), wt(dp(2)));
        if (set.size() > 1) {
            Runnable l1 = gate(new Runnable() { public void run() {
                doPart(h1, h2, verb + " 1st half"); qKind = mode == 0 ? 1 : 2; qFirst = h1; qSecond = h2; qFirstIdx = 0; renderAll(); } });
            Runnable l2 = gate(new Runnable() { public void run() {
                doPart(h2, h1, verb + " 2nd half"); qKind = mode == 0 ? 1 : 2; qFirst = h2; qSecond = h1; qFirstIdx = 1; renderAll(); } });
            r3.addView(mode == 0 ? dang(a, "1st half", l1) : prim(a, "1st half", l1), wt(dp(2)));
            r3.addView(mode == 0 ? dang(a, "2nd half", l2) : prim(a, "2nd half", l2), wt(dp(2)));
        }
        if (busy) r3.setAlpha(0.4f);
        fm.addView(r3, fullW(dp(3)));
        // v0.93: "using" under the button whose part is applied now
        LinearLayout ur = hrow(a);
        boolean uAll = usingRows(set), uH1 = !uAll && set.size() > 1 && usingRows(h1), uH2 = !uAll && set.size() > 1 && usingRows(h2);
        if (showAll) ur.addView(usingTag(a, uAll), wt(dp(2)));
        if (set.size() > 1) { ur.addView(usingTag(a, uH1), wt(dp(2))); ur.addView(usingTag(a, uH2), wt(dp(2))); }
        fm.addView(ur, fullW(0));

        // v0.98: no "Show all" in Hide. A small button goes back one step of the test (not shown on the first part)
        if (path.size() > 1) {
            Button back = neut(a, "\u2190 Back to " + path.get(path.size() - 2).label, gate(new Runnable() { public void run() { up(path.size() - 2); } }));
            if (busy) back.setAlpha(0.4f);
            fm.addView(back, fullW(dp(3)));
        }
        if (mode == 1 && size >= 2) fm.addView(txt(a, "Restore can be undone with Look on (List or Saved).", 10, DIM, false));
        fm.addView(neut(a, set.size() == 1 ? "Save texture" : "Save as set (" + set.size() + ")", new Runnable() {
            public void run() { formRestore = mode == 1; openForm(1, set, null, set.size() > 1); } }), fullW(dp(4)));
    }

    // ---------- List tab ----------
    private static void renderList() {
        if (lhead == null || overlay == null) return;
        Activity a = (Activity) overlay.getContext();
        ArrayList<Data.Row> base = shownBase();
        lshown = Data.filterRows(base, lf, chip, rHid, rOri, libMap.keySet());
        lhead.removeAllViews();
        String count = listLoaded ? lshown.size() + " of " + base.size() + " textures" + (path.size() <= 1 && goneN > 0 ? " \u00B7 " + goneN + " gone" : "") : "Loading...";
        TextView t = txt(a, count + (path.size() > 1 ? "   " + path.get(path.size() - 1).label : ""), 12, TXT, true);
        t.setPadding(dp(1), 0, 0, dp(1));
        lhead.addView(t);
        TextView s = txt(a, "All Textures Loaded \u00B7 " + limitText(), 10, candOver > 0 ? AMB : MUT, false);
        s.setPadding(dp(1), 0, 0, dp(4));
        lhead.addView(s);
        HorizontalScrollView hs = new HorizontalScrollView(a);
        hs.setHorizontalScrollBarEnabled(false);
        LinearLayout cr = hrow(a);
        String[] nm = {"All", "Hidden", "Visible", "Saved", "Unsaved"};
        for (int i = 0; i < nm.length; i++) {
            final int k = i;
            Button b = sm(a, nm[i], i == lf ? ACC : SURF2, i == lf ? ACCTXT : MUT, i == lf ? 0 : LINE, new Runnable() { public void run() { lf = k; renderList(); } });
            cr.addView(b);
        }
        hs.addView(cr);
        LinearLayout.LayoutParams hp = fullW(dp(5));
        hp.bottomMargin = dp(4);
        lhead.addView(hs, hp);
        LAD.notifyDataSetChanged();
    }

    private static final class LH { View bar; TextView t1, t2; Button b1, b2; }

    private static final BaseAdapter LAD = new BaseAdapter() {
        public int getCount() { return lshown.size(); }
        public Object getItem(int i) { return lshown.get(i); }
        public long getItemId(int i) { return i; }
        public View getView(int i, View cv, ViewGroup p) {
            Activity a = (Activity) overlay.getContext();
            try {
                LH h;
                View v = cv;
                if (v == null) {
                    h = new LH();
                    LinearLayout row = hrow(a);
                    row.setPadding(dp(1), dp(7), dp(1), dp(7));
                    h.bar = new View(a);
                    row.addView(h.bar, new LinearLayout.LayoutParams(dp(3), dp(32)));
                    LinearLayout col = vcol(a);
                    col.setPadding(dp(9), 0, dp(4), 0);
                    h.t1 = txt(a, "", 12, TXT, true);
                    h.t2 = mono(a, "", 10, MUT);
                    h.t1.setSingleLine(true);
                    h.t2.setSingleLine(true);
                    col.addView(h.t1);
                    col.addView(h.t2);
                    row.addView(col, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
                    h.b1 = sm(a, "", SURF2, TXT, LINE, null);
                    h.b2 = sm(a, "Save", SURF2, MUT, LINE, null);
                    row.addView(h.b1);
                    row.addView(h.b2);
                    row.setTag(h);
                    v = row;
                } else h = (LH) v.getTag();
                if (i < 0 || i >= lshown.size()) return v;
                final Data.Row r = lshown.get(i);
                final String k = r.key();
                int st = stateOf(r);
                h.bar.setBackground(box(st == Data.ST_HID ? RED : st == Data.ST_SHOWN ? GRN : st == Data.ST_REST ? ACC : LINE, 2, 0));
                h.t1.setText(Data.fmtName(r.fmt) + "  " + dims(r));
                final Data.Saved sv = libMap.get(k);
                boolean saved = Data.isSaved(k, libMap.keySet(), rHid, rOri);
                String stTxt = st == Data.ST_HID ? "hidden" : st == Data.ST_SHOWN ? "shown" : st == Data.ST_REST ? "restored" : "untouched";
                final boolean gone = isGone(r);                                   // v1.00: not in the game any more: dim, marked, Hide / Restore off, Save still works
                v.setAlpha(gone ? 0.5f : 1f);
                h.t2.setText((gone ? "gone \u00B7 " : "") + stTxt + " \u00B7 " + Data.sizeText(r.n) + " \u00B7 " + shortHash(r.hash) + (sv != null ? " \u00B7 " + sv.name : saved ? " \u00B7 saved rule" : ""));
                boolean hid = st == Data.ST_HID, rest = st == Data.ST_REST;
                boolean neutral = rest || mode == 1;
                if (gone) {
                    h.b1.setText("Gone");
                    h.b1.setTextColor(DIM);
                    h.b1.setBackground(box(SURF2, 6, LINE));
                    h.b1.setOnClickListener(tap(new Runnable() { public void run() { say("Gone from the game: Hide / Restore does nothing on it now. You can still Save it."); } }));
                } else {
                    h.b1.setText(rest ? "Look on" : mode == 1 ? "Restore" : hid ? "Show" : "Hide");
                    h.b1.setTextColor(neutral ? ACC : hid ? GRN : RED);
                    h.b1.setBackground(box(neutral ? SURF2 : hid ? GRND : REDD, 6, neutral ? LINE : hid ? GRNL : REDL));
                    h.b1.setOnClickListener(tap(new Runnable() { public void run() { toggleRow(r); } }));
                }
                h.b2.setText(saved ? "Saved" : "Save");
                h.b2.setTextColor(saved ? AMB : MUT);
                h.b2.setBackground(box(saved ? AMBD : SURF2, 6, saved ? AMBL : LINE));
                h.b2.setOnClickListener(tap(new Runnable() { public void run() {
                    if (Data.isSaved(k, libMap.keySet(), rHid, rOri)) { say(sv != null ? "Already saved as: " + sv.name : "Already saved (a rule is active)."); return; }
                    ArrayList<Data.Row> l = new ArrayList<Data.Row>(); l.add(r); formRestore = mode == 1; openForm(1, l, null, false); } }));
                return v;
            } catch (Throwable t) {
                err("row", t);
                return cv != null ? cv : new View(a);
            }
        }
    };

    /** Restore undone: the texture gets the look again (a saved Restore rule for it is switched OFF first). */
    private static void lookOn(Data.Row r) {
        ArrayList<String> keys = new ArrayList<String>();
        keys.add(r.key());
        if (rOri.contains(r.key())) { Data.setRules(dir, "orig.txt", keys, false); reloadRules(); }
        one("f", r, "O");
    }

    private static void toggleRow(Data.Row r) {
        int st = stateOf(r);
        if (st == Data.ST_REST) lookOn(r);
        else if (mode == 1) one("r", r, "R");
        else if (st == Data.ST_HID) one("u", r, "S");
        else one("h", r, "H");
    }

    // ---------- save / rename form (a page of the same window) ----------
    private static void openForm(int kind, ArrayList<Data.Row> rows, ArrayList<Data.Saved> unit, boolean asSet) {
        formKind = kind; formRows = rows; formUnit = unit; formAsSet = asSet;
        if (kind == 1) formGrp = "plants";
        formKeep = "";
        if (tab != 3) formBack = tab;
        showForm();
    }

    private static String autoName() {
        if (formKind == 2 && formUnit != null && !formUnit.isEmpty()) return formUnit.get(0).name;
        if (formKind == 3) { ArrayList<Data.Saved> l = Data.readLib(dir); int n = 1; boolean again = true; while (again) { again = false; for (Data.Saved s : l) if (s.name.equals("Group " + n)) { again = true; n++; break; } } return "Group " + n; }
        if (formRows == null || formRows.isEmpty()) return "Texture";
        Data.Row r = formRows.get(0);
        String base = formRows.size() > 1 ? "Set " + formRows.size() : Data.fmtName(r.fmt) + " " + r.w + "x" + r.h;
        return Data.cleanName(base);
    }

    /** Closes the keyboard, keeps the text, takes the focus away from the name box. */
    private static void hideKeyboard() {
        if (overlay == null) return;
        Activity a = (Activity) overlay.getContext();
        InputMethodManager im = (InputMethodManager) a.getSystemService(Context.INPUT_METHOD_SERVICE);
        if (nameEt != null) {
            if (im != null) im.hideSoftInputFromWindow(nameEt.getWindowToken(), 0);
            nameEt.clearFocus();
        }
        if (formBox != null) { formBox.setFocusableInTouchMode(true); formBox.requestFocus(); }
        if (im != null && overlay != null) im.hideSoftInputFromWindow(overlay.getWindowToken(), 0);
    }

    /** v0.97: while the name box has the keyboard, the window is made short and put at the top of the screen (above the keyboard), so what you type stays in view. */
    private static boolean typing = false;
    private static ScrollView formScroll;

    private static int kbHeight() {
        try {
            Rect r = new Rect();
            overlay.getWindowVisibleDisplayFrame(r);
            int h = sh - r.bottom;
            if (h > dpx(80)) return h;
        } catch (Throwable t) { }
        return 0;
    }

    private static void applyTyping() {
        if (!typing || winView == null) return;
        int kb = kbHeight();
        if (kb <= 0) kb = (int) (sh * 0.45f);                       // the phone does not tell: assume the usual landscape keyboard
        FrameLayout.LayoutParams wl = (FrameLayout.LayoutParams) winView.getLayoutParams();
        wl.height = Math.max(dpx(120), Math.min(winH(), sh - kb - dpx(4)));
        wl.topMargin = 0;
        winView.setLayoutParams(wl);
        if (hdrSub != null) hdrSub.setVisibility(View.GONE);
        if (status != null) status.setVisibility(View.GONE);
        if (formScroll != null) formScroll.scrollTo(0, 0);
    }

    private static void typingOn() {
        if (typing) return;
        typing = true;
        applyTyping();
        H.postDelayed(new Runnable() { public void run() { try { applyTyping(); } catch (Throwable t) { } } }, 200);
        H.postDelayed(new Runnable() { public void run() { try { applyTyping(); } catch (Throwable t) { } } }, 600);
    }

    private static void typingOff() {
        if (!typing) return;
        typing = false;
        try {
            if (winView != null) {
                FrameLayout.LayoutParams wl = (FrameLayout.LayoutParams) winView.getLayoutParams();
                wl.height = winH();
                winView.setLayoutParams(wl);
            }
            if (hdrSub != null) hdrSub.setVisibility(View.VISIBLE);
            if (status != null) status.setVisibility(View.VISIBLE);
            dockWin();
        } catch (Throwable t) { err("typingOff", t); }
    }

    private static void closeForm() {
        try { hideKeyboard(); } catch (Throwable t) { err("kb", t); }
        typingOff();
        formKind = 0;
        nameEt = null;
        if (overlay != null) showTab(formBack);
    }

    private static void showForm() {
        if (overlay == null || formKind == 0 || formBox == null) return;
        final Activity a = (Activity) overlay.getContext();
        formBox.removeAllViews();
        LinearLayout c = vcol(a);
        c.setPadding(dp(10), dp(8), dp(10), dp(10));
        c.setBackground(box(SURF, 8, LINE));
        c.addView(txt(a, formKind == 1 ? "Name it, or just tap Save." : (formKind == 3 ? "Name the group" : "New name"), 12, TXT, true));
        c.addView(txt(a, "Tap the box to type. Same name as in the WebUI.", 10, DIM, false));
        nameEt = new EditText(a);
        nameEt.setText(formKeep.length() > 0 ? formKeep : autoName());
        nameEt.setTextSize(Math.max(11f, ts(13)));
        nameEt.setTextColor(TXT);
        nameEt.setSingleLine(true);
        nameEt.setInputType(InputType.TYPE_CLASS_TEXT);
        // v0.95: DONE really finishes: the keyboard closes and the text stays. NO_EXTRACT_UI = no full screen editor in landscape (that one has its own Done that did not close).
        nameEt.setImeOptions(EditorInfo.IME_ACTION_DONE | EditorInfo.IME_FLAG_NO_EXTRACT_UI);
        nameEt.setOnEditorActionListener(new android.widget.TextView.OnEditorActionListener() {
            public boolean onEditorAction(android.widget.TextView v, int actionId, KeyEvent ev) {
                boolean done = actionId == EditorInfo.IME_ACTION_DONE || actionId == EditorInfo.IME_ACTION_GO || actionId == EditorInfo.IME_ACTION_NEXT
                        || (ev != null && ev.getKeyCode() == KeyEvent.KEYCODE_ENTER);
                if (!done) return false;
                if (ev != null && ev.getAction() != KeyEvent.ACTION_UP) return true;          // the Enter key sends down and up: act once
                try { hideKeyboard(); } catch (Throwable t) { err("done", t); }
                return true;
            }
        });
        nameEt.setFocusableInTouchMode(true);
        nameEt.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            public void onFocusChange(View v, boolean has) { try { if (has) typingOn(); else typingOff(); } catch (Throwable t) { err("focus", t); } }
        });
        nameEt.setBackground(box(SURF2, 6, LINE));
        nameEt.setPadding(dp(10), dp(8), dp(10), dp(8));
        nameEt.setOnClickListener(tap(new Runnable() {
            public void run() {
                nameEt.requestFocus();
                InputMethodManager im = (InputMethodManager) a.getSystemService(Context.INPUT_METHOD_SERVICE);
                if (im != null) im.showSoftInput(nameEt, 0);
            }
        }));
        c.addView(nameEt, fullW(dp(7)));
        if (formKind == 1) {
            LinearLayout g = hrow(a);
            String[] ids = {"plants", "effects", "other"}, nm = {"Plants", "Effects", "Other"};
            for (int i = 0; i < 3; i++) {
                final String id = ids[i];
                boolean on = formGrp.equals(id);
                Button b = btn(a, nm[i], on ? ACC : SURF2, on ? ACCTXT : TXT, on ? 0 : LINE);
                b.setOnClickListener(tap(new Runnable() { public void run() { formKeep = nameEt != null ? nameEt.getText().toString() : ""; formGrp = id; showForm(); } }));
                g.addView(b, wt(dp(2)));
            }
            c.addView(g, fullW(dp(6)));
            TextView note = txt(a, (formRestore ? "Restore" : "Hide") + " entry" + (formRows != null && formRows.size() > 1 ? " for " + formRows.size() + " textures together" : "") + ", ON at every game start.", 10, DIM, false);
            note.setPadding(0, dp(6), 0, 0);
            c.addView(note);
        }
        LinearLayout r = hrow(a);
        r.addView(good(a, formKind == 1 ? "Save" : (formKind == 3 ? "Make group" : "Rename"), new Runnable() { public void run() { submitForm(); } }), wt(dp(2)));
        r.addView(neut(a, "Cancel", new Runnable() { public void run() { closeForm(); } }), wt(dp(2)));
        c.addView(r, fullW(dp(8)));
        formBox.addView(c, fullW(dp(2)));
        showTab(3);
    }

    private static void submitForm() {
        boolean saved = false, fromFinder = false;       // v0.97: a texture saved from the Test tab ends the finder test by itself
        try {
            try { hideKeyboard(); } catch (Throwable t) { err("kb", t); }
            String name = Data.cleanName(nameEt != null ? nameEt.getText().toString() : "");
            if (name.length() == 0) name = autoName();
            if (formKind == 1) { Snap before = snapNow(); saved = saveRows(formRows, name, formGrp, formRestore, formAsSet); fromFinder = formBack == 0; if (saved) pushUndo(before, "save"); }
            else if (formKind == 2 && formUnit != null) {
                ArrayList<Data.Saved> lib = Data.readLib(dir);
                for (Data.Saved s : lib) for (Data.Saved u : formUnit) if (s.uid().equals(u.uid())) s.name = name;
                say(Data.writeLib(dir, lib) ? "Renamed." : "Could not write texlib.txt");
            } else if (formKind == 3) doGroup(name);
        } catch (Throwable t) {
            err("form", t);
        }
        closeForm();
        reloadRules();
        if (saved && fromFinder) {
            try { cancelFinder(); toast("Saved. Finder cancelled."); } catch (Throwable t) { err("autocancel", t); renderAll(); }
        } else renderAll();
    }

    private static boolean saveRows(List<Data.Row> rows, String name, String grp, boolean restore, boolean asSet) {
        ArrayList<Data.Saved> lib = Data.readLib(dir);
        HashMap<String, Data.Saved> have = new HashMap<String, Data.Saved>();
        for (Data.Saved s : lib) have.put(s.uid(), s);
        String setId = asSet && rows.size() > 1 ? Data.newSetId() : "";
        ArrayList<String> keys = new ArrayList<String>();
        ArrayList<String> wasHid = new ArrayList<String>();
        int added = 0;
        for (Data.Row r : rows) {
            // v0.96: the same texture can be saved once under Hide and once under Restore (they are two entries); twice under the same action is "already"
            String uid = r.key() + (restore ? "~r" : "");
            if (have.containsKey(uid)) continue;
            Data.Saved s = new Data.Saved();
            s.key = r.key(); s.name = name; s.grp = Data.grpOk(grp); s.set = setId; s.restore = restore;
            lib.add(s); have.put(uid, s); keys.add(r.key()); added++;
            if (restore && (rHid.contains(r.key()) || "H".equals(chip.get(r.key())))) wasHid.add(r.key());
        }
        if (added == 0) {
            String m = "Already in " + (restore ? "Restore" : "Hide") + " (Saved).";
            say(m); toast(m); return false;
        }
        // ON for the new entry; the same texture under the other action goes OFF (one at a time)
        boolean ok = Data.writeLib(dir, lib)
                && Data.setRules(dir, restore ? "orig.txt" : "hidden.txt", keys, true)
                && Data.setRules(dir, restore ? "hidden.txt" : "orig.txt", keys, false);
        libC = null;
        if (!ok) { say("Could not save (files are not writable)."); toast("Could not save"); return false; }
        svRestore = restore;                                           // show it where it went
        ArrayList<String> ls = new ArrayList<String>();
        for (Data.Row r : rows) {
            if (!keys.contains(r.key())) continue;
            String c = chip.get(r.key());
            if (wasHid.contains(r.key())) ls.add("u " + r.hash);        // a hidden texture is shown first, then restored
            if (restore ? !"R".equals(c) : !"H".equals(c)) { ls.add((restore ? "r " : "h ") + r.hash); chip.put(r.key(), restore ? "R" : "H"); }
        }
        String act = restore ? "Restore" : "Hide";
        String msg = "Saved " + added + " to " + act + ", ON";
        say(msg); toast(msg);
        if (!ls.isEmpty()) sendLines(ls, "Saved " + added + " \u00B7 " + act);
        return true;
    }

    // ---------- Saved tab (My textures) ----------
    private static void renderSaved() {
        if (shead == null || overlay == null) return;
        Activity a = (Activity) overlay.getContext();
        reloadRulesIfChanged();
        final ArrayList<Data.Saved> lib = libC == null ? new ArrayList<Data.Saved>() : libC;
        sitems.clear();
        String[] gid = {"plants", "effects", "other"}, gnm = {"Plants", "Effects", "Other"};
        ArrayList<ArrayList<Data.Saved>> units = Data.units(lib);
        // v0.95: two containers. Restore (back to the game's original texture, not changed by the Look) and Hide (hide / show) are different things, so each has its own list.
        int nR = 0, nH = 0, on = 0;
        for (ArrayList<Data.Saved> u : units) if (u.get(0).restore) nR++; else nH++;
        ArrayList<ArrayList<Data.Saved>> shown = new ArrayList<ArrayList<Data.Saved>>();
        for (ArrayList<Data.Saved> u : units) if (u.get(0).restore == svRestore) shown.add(u);
        for (int g = 0; g < 3; g++) {
            boolean head = false;
            for (ArrayList<Data.Saved> u : shown) {
                if (!u.get(0).grp.equals(gid[g])) continue;
                if (!head) { sitems.add(gnm[g]); head = true; }
                sitems.add(u);
                if (unitOn(u)) on++;
            }
        }
        savedUnits = units.size();
        if (grpPage != null) {                                                     // v1.03: a group is open as its own page (back arrow, its textures, ON / OFF, Delete, "not found")
            ArrayList<Data.Saved> gu = null;
            for (ArrayList<Data.Saved> u : units) if (u.size() > 1 && u.get(0).set.equals(grpPage)) gu = u;
            if (gu != null) { renderGroupPage(a, gu); SAD.notifyDataSetChanged(); return; }
            grpPage = null;
        }
        shead.removeAllViews();
        if (shown.size() < 2) { grpMode = false; grpSel.clear(); }
        // v0.97: ONE row on top (Restore | Hide and Group...), so the list gets the room; the explaining lines only on M / L
        LinearLayout top = hrow(a);
        if (grpMode) {
            top.addView(good(a, "Make group (" + grpSel.size() + ")", new Runnable() { public void run() { makeGroup(); } }), wt(dp(1)));
            top.addView(neut(a, "Cancel", new Runnable() { public void run() { grpMode = false; grpSel.clear(); renderSaved(); } }), wt(dp(1)));
        } else {
            top.addView(seg(a, new String[]{"Restore (" + nR + ")", "Hide (" + nH + ")"}, svRestore ? 0 : 1, new Sel() { public void on(int i) {
                boolean r = i == 0; if (r != svRestore) { svRestore = r; delArm = ""; grpPage = null; grpMode = false; grpSel.clear(); renderSaved(); } } }),
                new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
            if (shown.size() > 1) top.addView(sm(a, "Group\u2026", SURF2, TXT, LINE, new Runnable() { public void run() { grpMode = true; grpSel.clear(); delArm = ""; renderSaved(); } }));
        }
        shead.addView(top);
        String line = grpMode ? "Tick the textures to put together, then Make group."
                : (shown.isEmpty() ? (svRestore ? "No Restore textures saved yet. Use Save in Test or List (Finder on Restore)." : "No Hide textures saved yet. Use Save in Test or List.")
                : (size >= 2 ? shown.size() + (svRestore ? " restore" : " hide") + " \u00B7 " + on + " ON" : null));
        if (line != null) {
            TextView s = txt(a, line, 10, MUT, false);
            s.setPadding(dp(1), dp(2), 0, dp(2));
            shead.addView(s);
        }
        SAD.notifyDataSetChanged();
    }

    private static boolean unitOn(List<Data.Saved> u) {
        boolean restore = u.get(0).restore;
        for (Data.Saved s : u) if (!(restore ? rOri : rHid).contains(s.key)) return false;
        return true;
    }

    private static final class SH { View bar; TextView t1, t2; Button on, nm, del, sel, ug, ar; View l2; }

    private static final BaseAdapter SAD = new BaseAdapter() {
        public int getCount() { return sitems.size(); }
        public Object getItem(int i) { return sitems.get(i); }
        public long getItemId(int i) { return i; }
        public int getViewTypeCount() { return 3; }
        public int getItemViewType(int i) { Object o = sitems.get(i); return o instanceof String ? 0 : (o instanceof Data.Saved ? 2 : 1); }
        @SuppressWarnings("unchecked")
        public View getView(int i, View cv, ViewGroup p) {
            Activity a = (Activity) overlay.getContext();
            try {
                Object it = sitems.get(i);
                if (it instanceof String) {
                    TextView t = cv instanceof TextView ? (TextView) cv : txt(a, "", 9, DIM, true);
                    t.setText(((String) it).toUpperCase());
                    t.setLetterSpacing(0.14f);
                    t.setPadding(dp(2), dp(6), 0, dp(2));
                    return t;
                }
                if (it instanceof Data.Saved) return memberView((Data.Saved) it, cv, a);
                final ArrayList<Data.Saved> u = (ArrayList<Data.Saved>) it;
                SH h;
                View v = cv;
                if (v == null) {
                    h = new SH();
                    LinearLayout row = vcol(a);
                    row.setPadding(dp(1), dp(3), dp(1), dp(3));
                    LinearLayout l1 = hrow(a);
                    h.sel = sm(a, "", SURF2, GRN, MUT, null);                   // v1.01: a tick box (checklist) at the left, only in group mode
                    LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(dpx(MINS[size]), ViewGroup.LayoutParams.WRAP_CONTENT);
                    sp.rightMargin = dp(4);
                    h.sel.setLayoutParams(sp);
                    h.sel.setPadding(0, 0, 0, 0);
                    l1.addView(h.sel);
                    h.bar = new View(a);
                    l1.addView(h.bar, new LinearLayout.LayoutParams(dp(3), dp(26)));
                    LinearLayout nc = vcol(a);                                   // v0.97: name and info in one column, the buttons on the same line (one row = one line)
                    nc.setPadding(dp(8), 0, dp(2), 0);
                    h.t1 = txt(a, "", 12, TXT, true);
                    h.t1.setSingleLine(true);
                    h.t1.setEllipsize(TextUtils.TruncateAt.END);
                    nc.addView(h.t1);
                    h.t2 = mono(a, "", 9, MUT);
                    h.t2.setSingleLine(true);
                    h.t2.setEllipsize(TextUtils.TruncateAt.END);
                    nc.addView(h.t2);
                    l1.addView(nc, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
                    h.on = sm(a, "", SURF2, TXT, LINE, null);
                    h.nm = sm(a, "Rename", SURF2, TXT, LINE, null);
                    h.del = sm(a, "Delete", SURF2, TXT, LINE, null);
                    l1.addView(h.on);
                    l1.addView(h.nm);
                    l1.addView(h.del);
                    row.addView(l1);
                    LinearLayout l2 = hrow(a);                                   // only a group has a second line: Ungroup
                    l2.setGravity(Gravity.RIGHT);
                    h.ar = sm(a, "", SURF2, TXT, LINE, null);                  // v1.02: small arrow: show / hide the textures inside the group
                    l2.addView(h.ar);
                    View l2gap = new View(a);
                    l2.addView(l2gap, new LinearLayout.LayoutParams(0, 1, 1f));
                    h.ug = sm(a, "Ungroup", SURF2, TXT, LINE, null);
                    l2.addView(h.ug);
                    row.addView(l2);
                    h.l2 = l2;
                    row.setTag(h);
                    v = row;
                } else h = (SH) v.getTag();
                final boolean restore = u.get(0).restore;
                final boolean isOn = unitOn(u);
                final String id = u.get(0).uid();
                final String id0 = u.get(0).key;
                h.bar.setBackground(box(isOn ? GRN : LINE, 2, 0));
                h.t1.setText(u.get(0).name);
                h.t2.setText((restore ? "restore" : "hide") + (u.size() > 1 ? " \u00B7 group of " + u.size() : " \u00B7 " + Data.fmtName(Data.rowOfKey(id0).fmt) + " " + Data.rowOfKey(id0).w + "\u00D7" + Data.rowOfKey(id0).h));
                h.on.setText(isOn ? "ON" : "OFF");
                h.on.setTextColor(isOn ? GRN : RED);
                h.on.setBackground(box(isOn ? GRND : REDD, 6, isOn ? GRNL : REDL));
                h.on.setOnClickListener(tap(new Runnable() { public void run() { toggleUnit(u, restore, !isOn); } }));
                h.nm.setOnClickListener(tap(new Runnable() { public void run() { openForm(2, null, u, false); } }));
                // v0.89: group mode shows only a pick button; a group row has Ungroup
                final boolean picked = grpSel.contains(id);
                h.sel.setVisibility(grpMode ? View.VISIBLE : View.GONE);
                h.on.setVisibility(grpMode ? View.GONE : View.VISIBLE);
                h.nm.setVisibility(grpMode ? View.GONE : View.VISIBLE);
                h.del.setVisibility(grpMode ? View.GONE : View.VISIBLE);
                h.ug.setVisibility(!grpMode && u.size() > 1 ? View.VISIBLE : View.GONE);
                h.l2.setVisibility(!grpMode && u.size() > 1 ? View.VISIBLE : View.GONE);
                h.ar.setText("Open " + u.size() + " \u203A");                // v1.03: the group opens as its own page (was a collapsible list under the row)
                h.ar.setOnClickListener(tap(new Runnable() { public void run() {
                    grpPage = u.get(0).set; delArm = ""; askAlive(false); renderSaved();
                    try { if (sview != null) sview.setSelection(0); } catch (Throwable t) { } } }));
                h.nm.setText(size == 0 ? "Name" : "Rename");
                final Runnable flip = new Runnable() { public void run() { if (!grpSel.remove(id)) grpSel.add(id); renderSaved(); } };
                h.sel.setText(picked ? "\u2713" : "");                            // v1.01: a tick box (checklist) instead of text buttons
                h.sel.setTextColor(picked ? GRN : TXT);
                h.sel.setBackground(box(picked ? GRND : SURF2, 6, picked ? GRNL : MUT));
                h.sel.setOnClickListener(tap(flip));
                v.setClickable(grpMode);                                           // v1.01: in group mode the whole row ticks / unticks
                v.setOnClickListener(grpMode ? tap(flip) : null);
                h.ug.setOnClickListener(tap(new Runnable() { public void run() { ungroupUnit(id); } }));
                boolean arm = delArm.equals(id);
                h.del.setText(arm ? (size == 0 ? "Again!" : "Click again!") : (size == 0 ? "Del" : "Delete"));
                h.del.setTextColor(arm ? 0xFF1A1000 : TXT);
                h.del.setBackground(box(arm ? AMBFILL : SURF2, 6, arm ? AMBFILL : LINE));            // v1.03: the same amber "Click again!" as Cancel finder; it goes back by itself after DEL_ARM_MS
                h.del.setOnClickListener(tap(new Runnable() { public void run() {
                    if (delArm.equals(id)) deleteUnit(u, restore); else armDelete(id); } }));
                return v;
            } catch (Throwable t) {
                err("saved row", t);
                return cv != null ? cv : new View(a);
            }
        }
    };

    // ---------- v1.03: Delete = Click again (goes back by itself) ----------
    private static final long DEL_ARM_MS = 2000, UNDO_MS = 3500;
    private static long delArmAt = 0;

    private static void armDelete(final String id) {
        delArm = id;
        final long mine = delArmAt = System.currentTimeMillis();
        H.postDelayed(new Runnable() { public void run() { try { if (delArmAt == mine && delArm.equals(id)) { delArm = ""; SAD.notifyDataSetChanged(); } } catch (Throwable t) { } } }, DEL_ARM_MS);
        SAD.notifyDataSetChanged();
    }

    // ---------- v1.03: the page of one group ----------
    private static final class MH { View bar; TextView t1, t2; Button on, del; }

    private static boolean memberGone(Data.Saved m) {
        if (aliveSet == null) return false;                         // the module did not answer (live off / older module): nothing is marked
        return !aliveSet.contains(m.key.substring(m.key.lastIndexOf('|') + 1));
    }

    private static void renderGroupPage(Activity a, final ArrayList<Data.Saved> u) {
        final boolean restore = u.get(0).restore;
        sitems.clear();
        for (Data.Saved m : u) sitems.add(m);
        shead.removeAllViews();
        LinearLayout top = hrow(a);
        top.addView(sm(a, "\u2190", SURF2, TXT, LINE, new Runnable() { public void run() { grpPage = null; delArm = ""; renderSaved(); } }));
        TextView nm = txt(a, u.get(0).name, 13, TXT, true);
        nm.setSingleLine(true);
        nm.setEllipsize(TextUtils.TruncateAt.END);
        nm.setPadding(dp(8), 0, dp(4), 0);
        top.addView(nm, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        final boolean allOn = unitOn(u);
        Button g = sm(a, allOn ? "All ON" : "All OFF", SURF2, allOn ? GRN : RED, allOn ? GRNL : REDL, new Runnable() { public void run() { toggleUnit(u, restore, !allOn); } });
        g.setBackground(box(allOn ? GRND : REDD, 6, allOn ? GRNL : REDL));
        top.addView(g);
        shead.addView(top);
        int onN = 0, gone = 0;
        for (Data.Saved m : u) { if ((restore ? rOri : rHid).contains(m.key)) onN++; if (memberGone(m)) gone++; }
        TextView s = txt(a, (restore ? "restore" : "hide") + " \u00B7 " + u.size() + " textures \u00B7 " + onN + " ON" + (gone > 0 ? " \u00B7 " + gone + " not found" : ""), 10, gone > 0 ? AMB : MUT, false);
        s.setPadding(dp(1), dp(2), 0, dp(2));
        shead.addView(s);
    }

    private static View memberView(final Data.Saved m, View cv, Activity a) {
        MH h;
        View v = cv;
        if (v == null || !(v.getTag() instanceof MH)) {
            h = new MH();
            LinearLayout row = vcol(a);
            row.setPadding(dp(1), dp(3), dp(1), dp(3));
            LinearLayout l1 = hrow(a);
            h.bar = new View(a);
            l1.addView(h.bar, new LinearLayout.LayoutParams(dp(3), dp(26)));
            LinearLayout nc = vcol(a);
            nc.setPadding(dp(8), 0, dp(2), 0);
            h.t1 = txt(a, "", 12, TXT, true);
            h.t1.setSingleLine(true);
            h.t1.setEllipsize(TextUtils.TruncateAt.END);
            nc.addView(h.t1);
            h.t2 = mono(a, "", 9, MUT);
            h.t2.setSingleLine(true);
            h.t2.setEllipsize(TextUtils.TruncateAt.END);
            nc.addView(h.t2);
            l1.addView(nc, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
            h.on = sm(a, "", SURF2, TXT, LINE, null);
            h.del = sm(a, "Delete", SURF2, TXT, LINE, null);
            l1.addView(h.on);
            l1.addView(h.del);
            row.addView(l1);
            row.setTag(h);
            v = row;
        } else h = (MH) v.getTag();
        final boolean restore = m.restore;
        final boolean isOn = (restore ? rOri : rHid).contains(m.key);
        final boolean gone = memberGone(m);
        String hash = m.key.substring(m.key.lastIndexOf('|') + 1), info;
        try { Data.Row r = Data.rowOfKey(m.key); info = Data.fmtName(r.fmt) + " " + r.w + "\u00D7" + r.h; } catch (Throwable x) { info = m.key; }
        h.t1.setText(info);
        h.t2.setText(shortHash(hash) + (gone ? " \u00B7 not found" : ""));
        h.t2.setTextColor(gone ? AMB : MUT);
        h.bar.setBackground(box(gone ? AMB : (isOn ? GRN : LINE), 2, 0));
        h.on.setText(isOn ? "ON" : "OFF");
        h.on.setTextColor(isOn ? GRN : RED);
        h.on.setBackground(box(isOn ? GRND : REDD, 6, isOn ? GRNL : REDL));
        final ArrayList<Data.Saved> one = new ArrayList<Data.Saved>(); one.add(m);
        h.on.setOnClickListener(tap(new Runnable() { public void run() { toggleUnit(one, restore, !isOn); } }));
        final String id = m.uid();
        boolean arm = delArm.equals(id);
        h.del.setText(arm ? (size == 0 ? "Again!" : "Click again!") : (size == 0 ? "Del" : "Delete"));
        h.del.setTextColor(arm ? 0xFF1A1000 : TXT);
        h.del.setBackground(box(arm ? AMBFILL : SURF2, 6, arm ? AMBFILL : LINE));
        h.del.setOnClickListener(tap(new Runnable() { public void run() {
            if (delArm.equals(id)) deleteUnit(one, restore); else armDelete(id); } }));
        return v;
    }

    // ---------- v1.03: Undo (a few seconds after a Save or a Delete) ----------
    private static final class Snap { String lib, hid, org; }
    private static Snap undoSnap = null;
    private static long undoAt = 0;
    private static TextView undoView;

    private static String rawOrNull(String n) { File f = new File(dir, n); return f.exists() ? Data.read(f, 600000) : null; }

    private static Snap snapNow() { Snap s = new Snap(); s.lib = rawOrNull("texlib.txt"); s.hid = rawOrNull("hidden.txt"); s.org = rawOrNull("orig.txt"); return s; }

    private static boolean restoreRaw(String n, String text) {
        File f = new File(dir, n);
        if (text == null) { if (f.exists()) return f.delete(); return true; }
        return Data.writeAtomic(f, text);
    }

    private static void pushUndo(Snap before, String what) {
        try {
            if (undoView == null || overlay == null) return;
            undoSnap = before;
            undoView.setText("\u21B6  Undo " + what);
            undoView.setVisibility(View.VISIBLE);
            undoView.bringToFront();
            final long mine = undoAt = System.currentTimeMillis();
            H.postDelayed(new Runnable() { public void run() { try { if (undoAt == mine) { undoSnap = null; if (undoView != null) undoView.setVisibility(View.GONE); } } catch (Throwable t) { } } }, UNDO_MS);
        } catch (Throwable t) { err("pushUndo", t); }
    }

    private static void doUndo() {
        try {
            Snap sn = undoSnap;
            undoSnap = null;
            if (undoView != null) undoView.setVisibility(View.GONE);
            if (sn == null) return;
            LinkedHashSet<String> oh = new LinkedHashSet<String>(rHid), oo = new LinkedHashSet<String>(rOri);
            boolean ok = restoreRaw("texlib.txt", sn.lib);
            ok &= restoreRaw("hidden.txt", sn.hid);
            ok &= restoreRaw("orig.txt", sn.org);
            reloadRules();
            if (!ok) { say("Could not undo (files are not writable)."); toast("Could not undo"); renderAll(); return; }
            ArrayList<String> u = new ArrayList<String>(), f = new ArrayList<String>(), h = new ArrayList<String>(), r = new ArrayList<String>();
            for (String k : oh) if (!rHid.contains(k)) { u.add("u " + k.substring(k.lastIndexOf('|') + 1)); chip.put(k, "S"); }
            for (String k : oo) if (!rOri.contains(k)) { f.add("f " + k.substring(k.lastIndexOf('|') + 1)); chip.put(k, "O"); }
            for (String k : rHid) if (!oh.contains(k)) { h.add("h " + k.substring(k.lastIndexOf('|') + 1)); chip.put(k, "H"); }
            for (String k : rOri) if (!oo.contains(k)) { r.add("r " + k.substring(k.lastIndexOf('|') + 1)); chip.put(k, "R"); }
            ArrayList<String> ls = new ArrayList<String>();
            ls.addAll(u); ls.addAll(f); ls.addAll(h); ls.addAll(r);
            if (!ls.isEmpty()) sendLines(ls, "Undo"); else say("Undone.");
            toast("Undone");
            renderAll();
        } catch (Throwable t) { err("undo", t); }
    }

    /** v0.89: Make group. If one of the picked is already a group the others join it (no name needed); else the name page opens. */
    private static void makeGroup() {
        if (grpSel.size() < 2) { say("Pick at least 2 saved textures."); return; }
        boolean hasGroup = false;
        for (ArrayList<Data.Saved> u : Data.units(Data.readLib(dir))) if (u.size() > 1 && grpSel.contains(u.get(0).uid())) hasGroup = true;
        if (hasGroup) { doGroup(""); renderAll(); return; }
        openForm(3, null, null, false);
    }

    private static void doGroup(String name) {
        try {
            ArrayList<Data.Saved> lib = Data.readLib(dir);
            int n = grpSel.size();
            String why = Data.groupUnits(lib, new ArrayList<String>(grpSel), name);
            if (why.length() > 0) { say(why); return; }
            if (!Data.writeLib(dir, lib)) { say("Could not write texlib.txt"); return; }
            grpMode = false; grpSel.clear();
            say("Group made (" + n + " together). One ON / OFF for all.");
        } catch (Throwable t) { err("group", t); }
    }

    private static void ungroupUnit(String id) {
        try {
            ArrayList<Data.Saved> lib = Data.readLib(dir);
            if (Data.ungroup(lib, id) && Data.writeLib(dir, lib)) say("Group taken apart. ON / OFF stay as they were.");
            else say("Could not take the group apart.");
        } catch (Throwable t) { err("ungroup", t); }
        renderAll();
    }

    private static ArrayList<String> keysOf(List<Data.Saved> u) { ArrayList<String> k = new ArrayList<String>(); for (Data.Saved s : u) k.add(s.key); return k; }

    private static ArrayList<String> opsFor(String op, List<Data.Saved> u) {
        ArrayList<String> l = new ArrayList<String>();
        for (Data.Saved s : u) l.add(op + " " + s.key.substring(s.key.lastIndexOf('|') + 1));
        return l;
    }

    private static void toggleUnit(List<Data.Saved> u, boolean restore, boolean on) {
        if (!Data.setRules(dir, restore ? "orig.txt" : "hidden.txt", keysOf(u), on)) { say("Could not write the rule file."); return; }
        if (on) Data.setRules(dir, restore ? "hidden.txt" : "orig.txt", keysOf(u), false);      // v0.96: one of Hide / Restore at a time, for the same texture
        ArrayList<String> ls = new ArrayList<String>();
        if (restore && on) for (Data.Saved s : u) if (rHid.contains(s.key) || "H".equals(chip.get(s.key))) ls.add("u " + s.key.substring(s.key.lastIndexOf('|') + 1));      // hidden now: shown first, then restored
        reloadRules();
        String c = restore ? "R" : "H";
        for (Data.Saved s : u) chip.put(s.key, on ? c : (restore ? "O" : "S"));
        if (restore) ls.addAll(opsFor(on ? "r" : "f", u));
        else ls.addAll(opsFor(on ? "h" : "u", u));
        sendLines(ls, restore ? (on ? "Restore" : "Look on") : (on ? "Hide" : "Show"));
        renderAll();
    }

    private static void deleteUnit(List<Data.Saved> u, boolean restore) {
        Snap before = snapNow();                                                       // v1.03: for Undo
        ArrayList<Data.Saved> lib = Data.readLib(dir);
        ArrayList<String> keys = keysOf(u);
        ArrayList<String> uids = new ArrayList<String>(); for (Data.Saved s : u) uids.add(s.uid());
        boolean wasOn = unitOn(u);
        ArrayList<Data.Saved> keep = new ArrayList<Data.Saved>();
        for (Data.Saved s : lib) if (!uids.contains(s.uid())) keep.add(s);                  // v0.96: only THIS entry; the same texture under the other action stays
        boolean ok = Data.writeLib(dir, keep) && Data.setRules(dir, restore ? "orig.txt" : "hidden.txt", keys, false);
        delArm = "";
        if (!ok) { say("Could not delete."); return; }
        reloadRules();
        if (wasOn) {
            for (String k : keys) chip.put(k, restore ? "O" : "S");
            sendLines(opsFor(restore ? "f" : "u", u), restore ? "Deleted; Look on" : "Deleted; Show");
        } else say("Deleted.");
        pushUndo(before, "delete");
        renderAll();
    }
}
