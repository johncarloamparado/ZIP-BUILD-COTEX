package q9;

import android.app.Activity;
import android.app.Application;
import android.content.Context;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ScrollView;
import android.widget.TextView;
import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;

/**
 * v0.80: ONE window with a side rail instead of three separate windows. v0.81: docked to the Q9 button (it follows the button, and the button follows the window), short button names.
 *   Test   : status, Mark A / B, finder mode, the "narrow down" navigator (halves, Yes / No), what is hidden now and whether it is saved.
 *   List   : every texture of the current set (ListView, smooth with thousands of rows), one Hide / Show button per row.
 *   Saved  : My textures (the SAME texlib.txt / hidden.txt / orig.txt the WebUI uses): ON / OFF, Name, Delete.
 *   Save   : the name / group form is a page of the same window (no floating card).
 * Files and lists are handled by Data.java (unit-tested). This class only draws and sends commands (mark.txt, livecmd.txt).
 * Loaded by main.cpp through InMemoryDexClassLoader; every entry point and every tap is wrapped so that an error can never reach the game.
 */
public final class Menu {
    private static final Handler H = new Handler(Looper.getMainLooper());

    // palette (same as the WebUI since v0.83): warm graphite, one amber accent; red / green / orange only mean state
    private static final int BG = 0xF50B0C0E, RAIL = 0xFF0F1113, SURF = 0xFF121417, SURF2 = 0xFF1A1D20, LINE = 0xFF272B31;
    private static final int ACC = 0xFFF0B233, ACCTXT = 0xFF17120A;
    private static final int RED = 0xFFEF6B5F, REDD = 0xFF241512, REDL = 0x55EF6B5F;
    private static final int GRN = 0xFF8ECF7B, GRND = 0xFF172214, GRNL = 0x558ECF7B;
    private static final int AMB = 0xFFEF8A4C, AMBD = 0xFF261A10, AMBL = 0x55EF8A4C;
    private static final int TXT = 0xFFEBE8E1, MUT = 0xFF98948A, DIM = 0xFF625F57, CLEAR = 0x00000000;

    private static final int BASE_W = 456, BASE_H = 316, RAIL_W = 82;
    private static final float[] SCALE = {0.86f, 1f, 1.2f};
    private static final String[] TABN = {"Test", "List", "Saved"};
    private static final String[] TABT = {"Test", "Textures", "My textures", "Save"};
    private static final String[] TABD = {"Find one texture, step by step", "Everything the game loaded", "Your saved Hide and Restore list", "Name it and save"};

    private static File dir;
    private static Application app;
    private static Activity act;
    private static FrameLayout overlay;
    private static TextView fab;
    private static GradientDrawable fabBg;
    private static float density = 2f;
    private static int sw = 1280, sh = 720;
    private static boolean started, firstOk;
    private static int fabX = -1, fabY = 60, size = 1;

    // the one window
    private static LinearLayout winView;
    private static int winX = -1, winY = -1, dockRight = 1;      // dockRight 1: the window sits left of the Q9 button
    private static boolean winOpen;
    private static final View[] railBar = new View[3];
    private static final TextView[] railTxt = new TextView[3], railCnt = new TextView[3];
    private static TextView railState, sizeBtn, hdrTitle, hdrSub, status;
    private static View railDot;
    private static final View[] pane = new View[4];
    private static int tab = 0, formBack = 0;
    private static long sayUntil = 0;
    private static LinearLayout cbody, lhead, shead, formBox;
    private static ScrollView cscroll;
    private static ListView lview, sview;

    // finder state
    private static int mode = 0, lf = 0;
    private static boolean marksOnly = false, listLoaded = false, everything = false;
    private static ArrayList<Data.Row> allRows = new ArrayList<Data.Row>(), root = new ArrayList<Data.Row>(), lshown = new ArrayList<Data.Row>();
    private static int skipped = 0, savedUnits = 0;
    private static final ArrayList<Node> path = new ArrayList<Node>();
    private static final LinkedHashMap<String, String> chip = new LinkedHashMap<String, String>();   // key -> H hidden / S shown / R restored (this game)
    private static LinkedHashSet<String> rHid = new LinkedHashSet<String>(), rOri = new LinkedHashSet<String>();
    private static final HashMap<String, Data.Saved> libMap = new HashMap<String, Data.Saved>();
    private static ArrayList<Data.Row> qFirst, qSecond;
    private static int qKind = 0;                                  // 0 none, 1 hide, 2 restore
    private static final ArrayList<Object> sitems = new ArrayList<Object>();
    // form (save / rename)
    private static int formKind = 0;                               // 0 none, 1 save, 2 rename
    private static ArrayList<Data.Row> formRows;
    private static ArrayList<Data.Saved> formUnit;
    private static String formGrp = "plants", formKeep = "";
    private static boolean formAsSet = false, formRestore = false;
    private static EditText nameEt;
    private static String delArm = "";
    private static int pollLeft = 0;
    private static boolean polling = false;

    static final class Node {
        String label;
        ArrayList<Data.Row> rows;
        Node(String l, ArrayList<Data.Row> r) { label = l; rows = r; }
    }

    private interface Sel { void on(int i); }

    /** Called once by the module (any thread). */
    public static synchronized void start(Application a, String d) {
        if (started) return;
        started = true;
        app = a;
        dir = new File(d);
        try {
            app.registerActivityLifecycleCallbacks(new Application.ActivityLifecycleCallbacks() {
                public void onActivityResumed(Activity x) { act = x; }
                public void onActivityCreated(Activity x, Bundle b) { }
                public void onActivityStarted(Activity x) { }
                public void onActivityPaused(Activity x) { }
                public void onActivityStopped(Activity x) { }
                public void onActivitySaveInstanceState(Activity x, Bundle b) { }
                public void onActivityDestroyed(Activity x) { if (act == x) act = null; }
            });
        } catch (Throwable t) {
            err("callbacks", t);
        }
        H.post(TICK);
    }

    private static final Runnable TICK = new Runnable() {
        public void run() {
            try {
                Activity a = findAct();
                if (a != null) attach(a);
                if (winOpen) refreshStatus();
            } catch (Throwable t) {
                err("tick", t);
            }
            H.postDelayed(this, 3000);
        }
    };

    private static Activity findAct() {
        try {
            Class<?> c = Class.forName("com.unity3d.player.UnityPlayer", true, Menu.class.getClassLoader());
            Object o = c.getField("currentActivity").get(null);
            if (o instanceof Activity && !((Activity) o).isFinishing()) return (Activity) o;
        } catch (Throwable ignored) {
        }
        Activity a = act;
        return (a != null && !a.isFinishing()) ? a : null;
    }

    // ---------- small view helpers ----------
    private static int dp(float v) { return (int) (v * density + 0.5f); }

    private static GradientDrawable box(int color, float radiusDp, int stroke) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(radiusDp));
        if (stroke != 0) g.setStroke(Math.max(1, dp(1)), stroke);
        return g;
    }

    /** Every tap goes through here: an exception in our code must never crash the game. */
    private static View.OnClickListener tap(final Runnable r) {
        return new View.OnClickListener() {
            public void onClick(View v) {
                try { r.run(); } catch (Throwable t) { err("tap", t); }
            }
        };
    }

    private static Button btn(Activity a, String text, int fill, int fg, int stroke) {
        Button b = new Button(a);
        b.setText(text);
        b.setAllCaps(false);
        b.setTextSize(12);
        b.setTextColor(fg);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setMinHeight(0);
        b.setMinimumHeight(0);
        b.setMinWidth(0);
        b.setMinimumWidth(0);
        b.setPadding(dp(11), dp(7), dp(11), dp(7));
        b.setBackground(box(fill, 6, stroke));
        return b;
    }

    private static Button sm(Activity a, String text, int fill, int fg, int stroke, Runnable r) {
        Button b = btn(a, text, fill, fg, stroke);
        b.setTextSize(11);
        b.setPadding(dp(9), dp(5), dp(9), dp(5));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        p.leftMargin = dp(4);
        b.setLayoutParams(p);
        if (r != null) b.setOnClickListener(tap(r));
        return b;
    }

    private static Button prim(Activity a, String t, Runnable r) { Button b = btn(a, t, ACC, ACCTXT, 0); b.setOnClickListener(tap(r)); return b; }
    private static Button neut(Activity a, String t, Runnable r) { Button b = btn(a, t, SURF2, TXT, LINE); b.setOnClickListener(tap(r)); return b; }
    private static Button dang(Activity a, String t, Runnable r) { Button b = btn(a, t, REDD, RED, REDL); b.setOnClickListener(tap(r)); return b; }
    private static Button good(Activity a, String t, Runnable r) { Button b = btn(a, t, GRND, GRN, GRNL); b.setOnClickListener(tap(r)); return b; }

    private static LinearLayout hrow(Activity a) {
        LinearLayout l = new LinearLayout(a);
        l.setOrientation(LinearLayout.HORIZONTAL);
        l.setGravity(Gravity.CENTER_VERTICAL);
        return l;
    }

    private static LinearLayout vcol(Activity a) {
        LinearLayout l = new LinearLayout(a);
        l.setOrientation(LinearLayout.VERTICAL);
        return l;
    }

    private static LinearLayout.LayoutParams wt(int m) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        p.setMargins(m, m, m, m);
        return p;
    }

    private static LinearLayout.LayoutParams fullW(int top) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        p.topMargin = top;
        return p;
    }

    private static TextView txt(Activity a, String s, int sp, int color, boolean bold) {
        TextView t = new TextView(a);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    private static TextView mono(Activity a, String s, int sp, int color) {
        TextView t = txt(a, s, sp, color, false);
        t.setTypeface(Typeface.MONOSPACE);
        return t;
    }

    private static LinearLayout card(Activity a, int stroke) {
        LinearLayout c = vcol(a);
        c.setPadding(dp(10), dp(8), dp(10), dp(9));
        c.setBackground(box(SURF, 8, stroke == 0 ? LINE : stroke));
        cbody.addView(c, fullW(dp(7)));
        return c;
    }

    private static void label(Activity a, LinearLayout c, String s) {
        TextView t = txt(a, s.toUpperCase(), 9, DIM, true);
        t.setLetterSpacing(0.14f);
        t.setPadding(0, 0, 0, dp(5));
        c.addView(t);
    }

    private static LinearLayout seg(Activity a, String[] labels, int sel, final Sel cb) {
        LinearLayout c = hrow(a);
        c.setPadding(dp(2), dp(2), dp(2), dp(2));
        c.setBackground(box(SURF2, 7, 0));
        for (int i = 0; i < labels.length; i++) {
            final int k = i;
            Button b = btn(a, labels[i], i == sel ? ACC : CLEAR, i == sel ? ACCTXT : MUT, 0);
            b.setPadding(dp(8), dp(6), dp(8), dp(6));
            b.setOnClickListener(tap(new Runnable() { public void run() { cb.on(k); } }));
            c.addView(b, wt(0));
        }
        return c;
    }

    private static String shortHash(String h) { return h.length() > 8 ? h.substring(0, 8) : h; }

    private static String dims(Data.Row r) { return r.w + "\u00D7" + r.h; }

    // ---------- the overlay and the window ----------
    private static void attach(final Activity a) {
        if (overlay != null && overlay.getParent() != null && overlay.getContext() == a) return;
        if (overlay != null && overlay.getParent() != null) ((ViewGroup) overlay.getParent()).removeView(overlay);
        density = a.getResources().getDisplayMetrics().density;
        sw = a.getResources().getDisplayMetrics().widthPixels;
        sh = a.getResources().getDisplayMetrics().heightPixels;
        loadUi();
        reloadRules();
        overlay = new FrameLayout(a);

        fab = new TextView(a);
        fab.setText("Q9");
        fab.setTextColor(ACCTXT);
        fab.setTextSize(12);
        fab.setTypeface(Typeface.DEFAULT_BOLD);
        fab.setGravity(Gravity.CENTER);
        fabBg = new GradientDrawable();
        fabBg.setShape(GradientDrawable.OVAL);
        fabBg.setColor(0xE6F0B233);
        fabBg.setStroke(Math.max(2, dp(2)), 0xFF17120A);
        fab.setBackground(fabBg);
        if (fabX < 0) fabX = sw - dp(56);
        FrameLayout.LayoutParams fl = new FrameLayout.LayoutParams(dp(40), dp(40));
        fl.gravity = Gravity.TOP | Gravity.LEFT;
        fl.leftMargin = clampX(fabX, dp(40));
        fl.topMargin = clampY(fabY, dp(40));
        fab.setOnTouchListener(dragger(fab, false));
        overlay.addView(fab, fl);
        buildWin(a);
        fab.bringToFront();
        a.addContentView(overlay, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        if (!firstOk) {
            firstOk = true;
            new File(dir, "menu_try.txt").delete();
            put("menu_state.txt", "ok attached to " + a.getClass().getName() + "\n");
        }
        refreshStatus();
        renderAll();
    }

    private static int clampX(int x, int w) { return Math.max(0, Math.min(x, sw - w)); }
    private static int clampY(int y, int h) { return Math.max(0, Math.min(y, sh - h)); }

    private static int winW() { return Math.min(dp(BASE_W * SCALE[size]), sw - dp(12)); }
    private static int winH() { return Math.min(dp(BASE_H * SCALE[size]), sh - dp(12)); }

    /** Drag: the touched view moves (the window header moves the window, the Q9 button moves itself). A tap on the Q9 button opens / closes the window. */
    private static View.OnTouchListener dragger(final View target, final boolean isWin) {
        return new View.OnTouchListener() {
            float dx, dy, sx, sy;
            boolean moved;
            public boolean onTouch(View v, MotionEvent e) {
                try {
                    FrameLayout.LayoutParams lp = (FrameLayout.LayoutParams) target.getLayoutParams();
                    switch (e.getActionMasked()) {
                        case MotionEvent.ACTION_DOWN:
                            sx = e.getRawX(); sy = e.getRawY(); dx = lp.leftMargin - sx; dy = lp.topMargin - sy; moved = false;
                            target.bringToFront();
                            if (fab != null) fab.bringToFront();
                            return true;
                        case MotionEvent.ACTION_MOVE:
                            if (Math.abs(e.getRawX() - sx) + Math.abs(e.getRawY() - sy) > dp(8)) moved = true;
                            if (moved) {
                                int ww = lp.width > 0 ? lp.width : dp(40), hh = lp.height > 0 ? lp.height : dp(40);
                                lp.leftMargin = clampX((int) (e.getRawX() + dx), ww);
                                lp.topMargin = clampY((int) (e.getRawY() + dy), hh);
                                target.setLayoutParams(lp);
                                if (isWin) fabFollow(); else if (winOpen) dockWin();
                            }
                            return true;
                        case MotionEvent.ACTION_UP:
                            if (moved) {
                                if (!isWin) { fabX = lp.leftMargin; fabY = lp.topMargin; } else { winX = lp.leftMargin; winY = lp.topMargin; }
                                saveUi();
                            } else if (!isWin) setOpen(!winOpen);
                            return true;
                        default:
                            return true;
                    }
                } catch (Throwable t) {
                    err("drag", t);
                    return true;
                }
            }
        };
    }

    /** The window sits beside the Q9 button (on the side with room) and follows it. */
    private static void dockWin() {
        if (winView == null || fab == null) return;
        FrameLayout.LayoutParams fl = (FrameLayout.LayoutParams) fab.getLayoutParams(), wl = (FrameLayout.LayoutParams) winView.getLayoutParams();
        int fw = dp(40), gap = dp(6), ww = wl.width, hh = wl.height;
        int leftRoom = fl.leftMargin - gap, rightRoom = sw - (fl.leftMargin + fw) - gap;
        if (leftRoom >= ww && rightRoom >= ww) dockRight = fl.leftMargin + fw / 2 > sw / 2 ? 1 : 0;
        else if (leftRoom >= ww) dockRight = 1;
        else if (rightRoom >= ww) dockRight = 0;
        else dockRight = leftRoom >= rightRoom ? 1 : 0;
        int x = dockRight == 1 ? fl.leftMargin - gap - ww : fl.leftMargin + fw + gap;
        wl.leftMargin = clampX(x, ww);
        wl.topMargin = clampY(fl.topMargin - dp(8), hh);
        winView.setLayoutParams(wl);
        winX = wl.leftMargin; winY = wl.topMargin;
    }

    /** The window was dragged: the button stays beside it, on the same side. */
    private static void fabFollow() {
        if (winView == null || fab == null) return;
        FrameLayout.LayoutParams fl = (FrameLayout.LayoutParams) fab.getLayoutParams(), wl = (FrameLayout.LayoutParams) winView.getLayoutParams();
        int fw = dp(40), gap = dp(6);
        fl.leftMargin = clampX(dockRight == 1 ? wl.leftMargin + wl.width + gap : wl.leftMargin - gap - fw, fw);
        fl.topMargin = clampY(wl.topMargin + dp(8), fw);
        fab.setLayoutParams(fl);
        fabX = fl.leftMargin; fabY = fl.topMargin;
    }

    private static GradientDrawable railBg() {
        GradientDrawable g = new GradientDrawable();
        g.setColor(RAIL);
        float r = dp(12);
        g.setCornerRadii(new float[]{r, r, 0, 0, 0, 0, r, r});
        return g;
    }

    private static void buildWin(final Activity a) {
        if (winView != null && winView.getParent() != null) overlay.removeView(winView);
        int ww = winW(), hh = winH();
        LinearLayout v = hrow(a);
        v.setPadding(Math.max(1, dp(1)), Math.max(1, dp(1)), Math.max(1, dp(1)), Math.max(1, dp(1)));
        v.setBackground(box(BG, 12, LINE));
        v.setClickable(true);
        winView = v;

        // ----- rail: brand, three tabs, state, size -----
        LinearLayout rail = vcol(a);
        rail.setBackground(railBg());
        rail.setPadding(0, dp(8), 0, dp(8));
        LinearLayout brand = hrow(a);
        brand.setPadding(dp(12), dp(2), dp(6), dp(10));
        TextView q = txt(a, "Q9", 15, TXT, true);
        q.setLetterSpacing(0.08f);
        brand.addView(q);
        TextView sub = txt(a, "  textures", 9, DIM, false);
        brand.addView(sub);
        brand.setOnTouchListener(dragger(v, true));
        rail.addView(brand);
        for (int i = 0; i < 3; i++) rail.addView(railBtn(a, i));
        View gap = new View(a);
        rail.addView(gap, new LinearLayout.LayoutParams(1, 0, 1f));
        LinearLayout st = hrow(a);
        st.setPadding(dp(12), dp(4), dp(6), dp(6));
        railDot = new View(a);
        railDot.setBackground(box(DIM, 4, 0));
        st.addView(railDot, new LinearLayout.LayoutParams(dp(7), dp(7)));
        railState = txt(a, "", 10, MUT, false);
        railState.setPadding(dp(6), 0, 0, 0);
        st.addView(railState);
        rail.addView(st);
        sizeBtn = txt(a, "Size " + sizeName(), 10, MUT, false);
        sizeBtn.setPadding(dp(12), dp(5), dp(6), dp(5));
        sizeBtn.setOnClickListener(tap(new Runnable() { public void run() { size = (size + 1) % 3; saveUi(); rebuildAll(); } }));
        rail.addView(sizeBtn);
        v.addView(rail, new LinearLayout.LayoutParams(dp(RAIL_W), ViewGroup.LayoutParams.MATCH_PARENT));

        // ----- content: header (drag) + status + panes -----
        LinearLayout content = vcol(a);
        content.setPadding(dp(10), dp(6), dp(8), dp(8));
        LinearLayout head = hrow(a);
        head.setPadding(0, 0, 0, dp(2));
        hdrTitle = txt(a, TABT[tab], 14, TXT, true);
        head.addView(hdrTitle, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        TextView grip = txt(a, "drag", 9, DIM, false);
        grip.setLetterSpacing(0.12f);
        head.addView(grip);
        head.addView(sm(a, "\u2715", SURF2, TXT, LINE, new Runnable() { public void run() { setOpen(false); } }));
        head.setOnTouchListener(dragger(v, true));
        content.addView(head);
        hdrSub = txt(a, TABD[tab], 10, DIM, false);
        hdrSub.setPadding(0, 0, 0, dp(3));
        content.addView(hdrSub);
        status = txt(a, "", 10, MUT, false);
        status.setMaxLines(2);
        status.setPadding(0, 0, 0, dp(5));
        content.addView(status);

        FrameLayout body = new FrameLayout(a);
        // pane 0: Find (scrolling cards)
        cscroll = new ScrollView(a);
        cscroll.setVerticalScrollBarEnabled(false);
        cbody = vcol(a);
        cscroll.addView(cbody);
        body.addView(cscroll, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        pane[0] = cscroll;
        // pane 1: List
        LinearLayout lp1 = vcol(a);
        lhead = vcol(a);
        lp1.addView(lhead);
        lview = newList(a, LAD);
        lp1.addView(lview, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        body.addView(lp1, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        pane[1] = lp1;
        // pane 2: Saved
        LinearLayout lp2 = vcol(a);
        shead = vcol(a);
        lp2.addView(shead);
        sview = newList(a, SAD);
        lp2.addView(sview, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        body.addView(lp2, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        pane[2] = lp2;
        // pane 3: the save / rename form (a page of this window)
        ScrollView fs = new ScrollView(a);
        fs.setVerticalScrollBarEnabled(false);
        formBox = vcol(a);
        fs.addView(formBox);
        body.addView(fs, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        pane[3] = fs;
        content.addView(body, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        v.addView(content, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f));

        FrameLayout.LayoutParams pl = new FrameLayout.LayoutParams(ww, hh);
        pl.gravity = Gravity.TOP | Gravity.LEFT;
        pl.leftMargin = 0;
        pl.topMargin = 0;
        overlay.addView(v, pl);
        dockWin();
        v.setVisibility(winOpen ? View.VISIBLE : View.GONE);
        showTab(formKind != 0 ? 3 : tab);
    }

    private static String sizeName() { return size == 0 ? "S" : size == 2 ? "L" : "M"; }

    private static View railBtn(final Activity a, final int i) {
        LinearLayout r = hrow(a);
        r.setPadding(0, dp(9), dp(8), dp(9));
        View bar = new View(a);
        bar.setBackground(box(CLEAR, 2, 0));
        r.addView(bar, new LinearLayout.LayoutParams(dp(3), dp(18)));
        TextView t = txt(a, TABN[i], 13, MUT, true);
        t.setPadding(dp(9), 0, 0, 0);
        r.addView(t, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        TextView c = mono(a, "", 10, DIM);
        r.addView(c);
        r.setOnClickListener(tap(new Runnable() { public void run() { if (formKind != 0) closeForm(); showTab(i); } }));
        railBar[i] = bar;
        railTxt[i] = t;
        railCnt[i] = c;
        return r;
    }

    private static void showTab(int t) {
        tab = t == 3 ? tab : t;
        int hl = t == 3 ? formBack : t;
        for (int i = 0; i < 4; i++) if (pane[i] != null) pane[i].setVisibility(i == t ? View.VISIBLE : View.GONE);
        for (int i = 0; i < 3; i++) {
            if (railBar[i] == null) continue;
            railBar[i].setBackground(box(i == hl ? ACC : CLEAR, 2, 0));
            railTxt[i].setTextColor(i == hl ? TXT : MUT);
        }
        if (hdrTitle != null) hdrTitle.setText(t == 3 ? (formKind == 2 ? "Rename" : TABT[3]) : TABT[t]);
        if (hdrSub != null) hdrSub.setText(TABD[t]);
    }

    private static void updateRail() {
        if (railCnt[1] == null) return;
        railCnt[0].setText("");
        railCnt[1].setText(listLoaded ? String.valueOf(cur().size()) : "");
        railCnt[2].setText(String.valueOf(savedUnits));
    }

    private static ListView newList(Activity a, BaseAdapter ad) {
        ListView l = new ListView(a);
        l.setDivider(box(LINE, 0, 0));
        l.setDividerHeight(dp(1));
        l.setSelector(box(CLEAR, 0, 0));
        l.setCacheColorHint(CLEAR);
        l.setVerticalScrollBarEnabled(false);
        l.setAdapter(ad);
        return l;
    }

    private static void rebuildAll() {
        if (overlay == null) return;
        Activity a = (Activity) overlay.getContext();
        buildWin(a);
        if (fab != null) fab.bringToFront();
        refreshStatus();
        renderAll();
        if (formKind != 0) showForm();
    }

    private static void setOpen(boolean on) {
        winOpen = on;
        if (winView != null) winView.setVisibility(on ? View.VISIBLE : View.GONE);
        if (on) {
            dockWin();
            winView.bringToFront();
            if (fab != null) fab.bringToFront();
            refreshStatus();
            if (!listLoaded) loadList(); else renderAll();
        }
    }

    // ---------- files ----------
    private static void loadUi() {
        String s = Data.readSmall(new File(dir, "menu_ui.txt")).trim();
        if (s.length() == 0) return;
        try {
            String[] p = s.split("\\s+");
            if (p.length == 5) {                       // v0.77 / v0.78 / v0.80: fabX fabY winX winY size
                fabX = Integer.parseInt(p[0]); fabY = Integer.parseInt(p[1]); winX = Integer.parseInt(p[2]); winY = Integer.parseInt(p[3]);
                size = Math.max(0, Math.min(2, Integer.parseInt(p[4])));
            } else if (p.length >= 9) {                // v0.79 (three windows): fabX fabY size cx cy ...; the old Control position is kept
                fabX = Integer.parseInt(p[0]); fabY = Integer.parseInt(p[1]);
                size = Math.max(0, Math.min(2, Integer.parseInt(p[2])));
                winX = Integer.parseInt(p[3]); winY = Integer.parseInt(p[4]);
            }
        } catch (Throwable ignored) {
        }
    }

    private static void saveUi() {
        put("menu_ui.txt", fabX + " " + fabY + " " + winX + " " + winY + " " + size + "\n");
    }

    private static boolean put(String name, String text) {
        try {
            java.io.FileOutputStream f = new java.io.FileOutputStream(new File(dir, name), false);
            try { f.write(text.getBytes("UTF-8")); } finally { f.close(); }
            return true;
        } catch (Throwable t) {
            if (!name.equals("menu_state.txt")) err("write " + name, t);
            return false;
        }
    }

    private static void err(String where, Throwable t) {
        try {
            java.io.FileOutputStream f = new java.io.FileOutputStream(new File(dir, "menu_state.txt"), false);
            try { f.write(("err " + where + ": " + t + "\n").getBytes("UTF-8")); } finally { f.close(); }
        } catch (Throwable ignored) {
        }
    }

    private static String kv(String text, String key) {
        int i = text.indexOf(key + "=");
        if (i < 0 || (i > 0 && text.charAt(i - 1) != '\n' && text.charAt(i - 1) != '|')) return null;
        int e = i + key.length() + 1, j = e;
        while (j < text.length() && text.charAt(j) != '\n' && text.charAt(j) != '|') j++;
        return text.substring(e, j).trim();
    }

    /** Reads the saved rules and My textures once (after every change), so drawing a list never reads files. */
    private static void reloadRules() {
        try {
            rHid = Data.readRuleKeys(dir, "hidden.txt");
            rOri = Data.readRuleKeys(dir, "orig.txt");
            libMap.clear();
            for (Data.Saved s : Data.readLib(dir)) libMap.put(s.key, s);
        } catch (Throwable t) {
            err("rules", t);
        }
    }

    private static void setState(int color, String text) {
        if (railDot != null) railDot.setBackground(box(color, 4, 0));
        if (railState != null) { railState.setText(text); railState.setTextColor(color == DIM ? MUT : color); }
    }

    private static void refreshStatus() {
        if (status == null) return;
        if (System.currentTimeMillis() < sayUntil) return;            // a message from a button is still showing
        String live = Data.readSmall(new File(dir, "live.txt")).trim();
        if (!live.startsWith("1")) {
            status.setText("Live test is off. Turn it on in the WebUI, then restart CODM.");
            setState(DIM, "Live off");
            return;
        }
        String st = Data.readSmall(new File(dir, "codm_tex.status"));
        String cap = kv(st, "lv_cap"), n = kv(st, "lv_hash"), kb = kv(st, "lv_kb"), last = kv(st, "lv_last"), bk = kv(st, "lv_bk"), bkmb = kv(st, "lv_bkmb");
        if (cap == null) { status.setText("Waiting for the module..."); setState(DIM, "Waiting"); return; }
        int pend = Data.kvInt("p=" + (kv(st, "lv_pend") == null ? "0" : kv(st, "lv_pend")), "p");
        StringBuilder b = new StringBuilder();
        b.append("1".equals(cap) ? "Capturing" : "Not capturing").append(" \u00B7 ").append(n == null ? "0" : n).append(" copies (").append(kb == null ? "0" : kb).append(" KB)");
        if (bk != null && !"0".equals(bk)) b.append(" \u00B7 ").append(bk).append(" GPU backups (").append(bkmb == null ? "0" : bkmb).append(" MB)");
        String fl = Data.friendlyLast(last);
        String l2 = "";
        if (pend > 0) l2 = "Applying, " + pend + " left";
        else if (fl.length() > 0) l2 = "Last: " + fl;
        int nocopy = Data.kvInt(last, "nocopy");
        if (pend <= 0 && nocopy > 0) l2 += " \u00B7 " + nocopy + " cannot return live (blank at load). Turn the rule OFF in Saved, restart CODM.";
        status.setText(l2.length() > 0 ? l2 + "\n" + b : b.toString());
        setState(pend > 0 ? AMB : ("1".equals(cap) ? GRN : DIM), pend > 0 ? "Applying" : ("1".equals(cap) ? "Capturing" : "Ready"));
        if (fabBg != null) fabBg.setColor(pend > 0 ? 0xE6EF8A4C : 0xE6F0B233);
        if (pend > 0) startPoll();
    }

    /** A short message from a button; it stays for a few seconds before the live status comes back. */
    private static void say(String s) {
        sayUntil = System.currentTimeMillis() + 5000;
        if (status != null) status.setText(s);
    }

    private static void startPoll() {
        pollLeft = 40;
        if (polling) return;
        polling = true;
        H.postDelayed(new Runnable() {
            public void run() {
                try { refreshStatus(); } catch (Throwable t) { err("poll", t); }
                if (--pollLeft > 0) H.postDelayed(this, 1000); else polling = false;
            }
        }, 1000);
    }

    // ---------- commands ----------
    private static void mark(String lab) {
        if (!put("mark.txt", lab + "\n")) { say("Could not write mark.txt"); return; }
        if ("X".equals(lab)) { say("Copies cleared."); }
        else say(lab.equals("A") ? "Mark A sent. Now do the thing in the game, then Mark B." : "Mark B sent. Updating the list...");
        H.postDelayed(new Runnable() { public void run() { try { refreshStatus(); } catch (Throwable t) { err("mark", t); } } }, 2000);
        if ("B".equals(lab) || "A".equals(lab)) H.postDelayed(new Runnable() { public void run() { try { loadList(); } catch (Throwable t) { err("mark", t); } } }, 2000);
    }

    /** Sends "op hash" lines in ONE write (the module takes up to 8192 lines per file and applies them over a few frames). */
    private static void sendLines(final ArrayList<String> lines, final String what) {
        if (lines.isEmpty()) { say("Nothing to send."); return; }
        final int step = 8000;
        for (int i = 0; i * step < lines.size(); i++) {
            final int from = i * step;
            Runnable r = new Runnable() {
                public void run() {
                    try {
                        StringBuilder sb = new StringBuilder();
                        for (int k = from; k < Math.min(lines.size(), from + step); k++) sb.append(lines.get(k)).append('\n');
                        if (!Data.writeAtomic(new File(dir, "livecmd.txt"), sb.toString())) say("Could not write livecmd.txt");
                    } catch (Throwable t) { err("send", t); }
                }
            };
            if (i == 0) r.run(); else H.postDelayed(r, 3000L * i);
        }
        say(what + ": " + lines.size() + " sent. Look at the game.");
        H.postDelayed(new Runnable() { public void run() { try { sayUntil = 0; refreshStatus(); } catch (Throwable t) { err("send", t); } } }, 4500);
        startPoll();
    }

    private static void addOps(ArrayList<String> out, String op, List<Data.Row> rows) { for (Data.Row r : rows) out.add(op + " " + r.hash); }

    private static void mark(List<Data.Row> rows, String c) { for (Data.Row r : rows) chip.put(r.key(), c); }

    /** Hide / Restore a part of the current set. Hide: the rest of the set is shown again, so only this part is hidden. */
    private static void doPart(ArrayList<Data.Row> part, ArrayList<Data.Row> other, String label) {
        ArrayList<String> ls = new ArrayList<String>();
        if (mode == 0) {
            addOps(ls, "h", part);
            if (other != null) addOps(ls, "u", other);
            mark(part, "H");
            if (other != null) mark(other, "S");
        } else {
            addOps(ls, "r", part);
            mark(part, "R");
        }
        sendLines(ls, label);
        renderAll();
    }

    private static void one(String op, Data.Row c, String ch) {
        ArrayList<String> ls = new ArrayList<String>();
        ls.add(op + " " + c.hash);
        chip.put(c.key(), ch);
        sendLines(ls, op.equals("h") ? "Hide" : op.equals("u") ? "Show" : op.equals("f") ? "Look on" : "Restore");
        renderAll();
    }

    // ---------- the list (finder state) ----------
    private static void loadList() {
        new Thread(new Runnable() {
            public void run() {
                try {
                    final String log = Data.read(new File(dir, "codm_tex.log"), 3 * 1024 * 1024);
                    final ArrayList<Data.Row> all = Data.parseLog(log, marksOnly);
                    final boolean hm = Data.hasMarks(log);
                    H.post(new Runnable() {
                        public void run() {
                            try {
                                allRows = all;
                                reloadRules();
                                recomputeRoot();
                                listLoaded = true;
                                if (marksOnly && !hm) say("No Mark A in this game session yet.");
                                renderAll();
                            } catch (Throwable t) {
                                err("load", t);
                            }
                        }
                    });
                } catch (Throwable t) {
                    err("loadList", t);
                }
            }
        }).start();
    }

    private static void recomputeRoot() {
        Data.Filtered f = Data.rootRows(allRows, mode == 0, everything);
        root = f.rows;
        skipped = f.skipped;
        path.clear();
        path.add(new Node("All " + root.size(), root));
        qKind = 0;
    }

    private static ArrayList<Data.Row> cur() { return path.isEmpty() ? new ArrayList<Data.Row>() : path.get(path.size() - 1).rows; }

    private static void into(ArrayList<Data.Row> part, String name) {
        path.add(new Node(name + " " + part.size(), part));
        qKind = 0;
        renderAll();
    }

    private static void up(int toLevel) {
        while (path.size() > toLevel + 1 && path.size() > 1) path.remove(path.size() - 1);
        qKind = 0;
        renderAll();
    }

    private static int stateOf(Data.Row r) {
        String k = r.key();
        return Data.stateOf(chip.get(k), rHid.contains(k), rOri.contains(k));
    }

    private static void setSource(boolean marks) {
        if (marks == marksOnly) return;
        marksOnly = marks;
        listLoaded = false;
        loadList();
        renderAll();
    }

    // ---------- drawing ----------
    private static void renderAll() {
        if (overlay == null) return;
        try {
            renderList();
            renderSaved();
            renderControl();
            updateRail();
        } catch (Throwable t) {
            err("draw", t);
        }
    }

    private static void renderControl() {
        if (cbody == null || overlay == null) return;
        Activity a = (Activity) overlay.getContext();
        cbody.removeAllViews();
        drawControl(a);
    }

    private static void drawControl(final Activity a) {
        // what is hidden now, and is it saved?
        final ArrayList<Data.Row> unsaved = Data.unsavedHidden(chip, libMap.keySet(), rHid, rOri);
        final ArrayList<String> hidKeys = Data.keysWith(chip, "H");
        if (!hidKeys.isEmpty()) {
            LinearLayout c = card(a, unsaved.isEmpty() ? GRNL : AMBL);
            c.addView(txt(a, hidKeys.size() + " hidden now", 12, TXT, true));
            if (unsaved.isEmpty()) c.addView(txt(a, "All saved. Hidden again at every game start.", 10, GRN, false));
            else c.addView(txt(a, unsaved.size() + " not saved. They return when CODM restarts.", 10, AMB, false));
            LinearLayout r = hrow(a);
            if (!unsaved.isEmpty()) r.addView(prim(a, "Save hidden", new Runnable() {
                public void run() { formRestore = false; openForm(1, unsaved, null, unsaved.size() > 1); } }), wt(dp(2)));
            r.addView(good(a, "Show hidden", new Runnable() {
                public void run() {
                    ArrayList<String> ls = new ArrayList<String>();
                    for (String k : hidKeys) { try { ls.add("u " + Data.rowOfKey(k).hash); chip.put(k, "S"); } catch (RuntimeException ignored) { } }
                    sendLines(ls, "Show hidden"); renderAll(); } }), wt(dp(2)));
            c.addView(r, fullW(dp(6)));
        }

        // capture
        LinearLayout cap = card(a, 0);
        label(a, cap, "Marks");
        LinearLayout r1 = hrow(a);
        r1.addView(prim(a, "Mark A", new Runnable() { public void run() { mark("A"); } }), wt(dp(2)));
        r1.addView(prim(a, "Mark B", new Runnable() { public void run() { mark("B"); } }), wt(dp(2)));
        r1.addView(neut(a, "Clear marks", new Runnable() { public void run() { mark("X"); chip.clear(); renderAll(); } }), wt(dp(2)));
        cap.addView(r1);
        cap.addView(txt(a, "Mark A, do it in the game, Mark B.", 10, DIM, false));

        // finder
        LinearLayout fd = card(a, 0);
        label(a, fd, "Finder");
        fd.addView(seg(a, new String[]{"Hide", "Restore"}, mode, new Sel() { public void on(int i) { if (i != mode) { mode = i; recomputeRoot(); renderAll(); } } }));
        fd.addView(seg(a, new String[]{"Since start", "A to B"}, marksOnly ? 1 : 0, new Sel() { public void on(int i) { setSource(i == 1); } }), fullW(dp(5)));
        LinearLayout r2 = hrow(a);
        if (mode == 0) r2.addView(everything ? good(a, "More sizes: on", new Runnable() { public void run() { everything = false; recomputeRoot(); renderAll(); } })
                : neut(a, "More sizes: off", new Runnable() { public void run() { everything = true; recomputeRoot(); renderAll(); } }), wt(dp(2)));
        r2.addView(neut(a, "Reload list", new Runnable() { public void run() { loadList(); } }), wt(dp(2)));
        fd.addView(r2, fullW(dp(5)));
        if (mode == 0) fd.addView(txt(a, everything ? "Also lists scope / lobby sizes and textures that cannot be blanked." : "Scope / lobby sizes are left out" + (skipped > 0 ? " (" + skipped + ")" : "") + ". More sizes includes them.", 10, DIM, false));

        // family
        LinearLayout fm = card(a, 0);
        label(a, fm, "Narrow down");
        if (!listLoaded) fm.addView(txt(a, "Loading...", 11, MUT, false));
        else if (root.isEmpty()) fm.addView(txt(a, marksOnly ? "Nothing between A and B." : "Nothing yet. Play a moment, then Reload list.", 11, MUT, false));
        else drawFamily(a, fm);

        TextView hint = txt(a, "Works on textures the game already loaded. Saved items use the same rules as the WebUI.", 10, DIM, false);
        hint.setPadding(dp(2), dp(7), dp(2), dp(4));
        cbody.addView(hint);
    }

    private static void drawFamily(final Activity a, LinearLayout fm) {
        HorizontalScrollView hs = new HorizontalScrollView(a);
        hs.setHorizontalScrollBarEnabled(false);
        LinearLayout crumbs = hrow(a);
        for (int i = 0; i < path.size(); i++) {
            final int lvl = i;
            if (i > 0) crumbs.addView(txt(a, "  \u203A", 12, DIM, false));
            boolean last = i == path.size() - 1;
            crumbs.addView(sm(a, path.get(i).label, last ? ACC : SURF2, last ? ACCTXT : TXT, last ? 0 : LINE, new Runnable() { public void run() { up(lvl); } }));
        }
        hs.addView(crumbs);
        fm.addView(hs);

        final ArrayList<Data.Row> set = cur();
        final ArrayList<Data.Row> h1 = Data.half(set, 0), h2 = Data.half(set, 1);
        final String verb = mode == 0 ? "Hide" : "Restore";
        TextView cnt = txt(a, set.size() + " texture" + (set.size() == 1 ? "" : "s") + " in this test", 11, TXT, false);
        cnt.setPadding(dp(2), dp(6), 0, dp(3));
        fm.addView(cnt);

        if (qKind != 0 && qFirst != null) {
            LinearLayout q = hrow(a);
            q.setPadding(dp(8), dp(4), dp(4), dp(4));
            q.setBackground(box(AMBD, 6, AMBL));
            q.addView(txt(a, qKind == 1 ? "Is it gone?" : "Is it fixed?", 12, AMB, true), new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
            q.addView(sm(a, "Yes", GRND, GRN, GRNL, new Runnable() { public void run() { into(qFirst, "yes"); } }));
            q.addView(sm(a, "No", REDD, RED, REDL, new Runnable() { public void run() { into(qSecond, "other"); } }));
            q.addView(sm(a, "Skip", SURF2, MUT, LINE, new Runnable() { public void run() { qKind = 0; renderAll(); } }));
            fm.addView(q, fullW(dp(3)));
        }
        if (set.size() == 0) return;

        LinearLayout r3 = hrow(a);
        Runnable allL = new Runnable() { public void run() { doPart(set, null, verb + " all"); } };
        r3.addView(mode == 0 ? dang(a, verb + " all", allL) : prim(a, verb + " all", allL), wt(dp(2)));
        if (set.size() > 1) {
            Runnable l1 = new Runnable() { public void run() {
                doPart(h1, h2, verb + " 1st half"); qKind = mode == 0 ? 1 : 2; qFirst = h1; qSecond = h2; renderAll(); } };
            Runnable l2 = new Runnable() { public void run() {
                doPart(h2, h1, verb + " 2nd half"); qKind = mode == 0 ? 1 : 2; qFirst = h2; qSecond = h1; renderAll(); } };
            r3.addView(mode == 0 ? dang(a, "1st half", l1) : prim(a, "1st half", l1), wt(dp(2)));
            r3.addView(mode == 0 ? dang(a, "2nd half", l2) : prim(a, "2nd half", l2), wt(dp(2)));
        }
        fm.addView(r3, fullW(dp(3)));

        LinearLayout r4 = hrow(a);
        if (mode == 0) r4.addView(good(a, "Show all", new Runnable() { public void run() {
            ArrayList<String> ls = new ArrayList<String>(); addOps(ls, "u", set); mark(set, "S"); sendLines(ls, "Show all"); renderAll(); } }), wt(dp(2)));
        if (set.size() > 1) {
            r4.addView(neut(a, "Focus 1st (" + h1.size() + ")", new Runnable() { public void run() { into(h1, "1st"); } }), wt(dp(2)));
            r4.addView(neut(a, "Focus 2nd (" + h2.size() + ")", new Runnable() { public void run() { into(h2, "2nd"); } }), wt(dp(2)));
        }
        fm.addView(r4);
        if (mode == 1) fm.addView(txt(a, "Restore can be undone with Look on (List or Saved).", 10, DIM, false));
        fm.addView(neut(a, set.size() == 1 ? "Save texture" : "Save as set (" + set.size() + ")", new Runnable() {
            public void run() { formRestore = mode == 1; openForm(1, set, null, set.size() > 1); } }), fullW(dp(4)));
    }

    // ---------- List tab ----------
    private static void renderList() {
        if (lhead == null || overlay == null) return;
        Activity a = (Activity) overlay.getContext();
        lshown = Data.filterRows(cur(), lf, chip, rHid, rOri, libMap.keySet());
        lhead.removeAllViews();
        String count = listLoaded ? lshown.size() + " of " + cur().size() + " textures" : "Loading...";
        TextView t = txt(a, count + (path.size() > 1 ? "   " + path.get(path.size() - 1).label : ""), 12, TXT, true);
        t.setPadding(dp(1), 0, 0, dp(1));
        lhead.addView(t);
        String src = marksOnly ? "Only what appeared between Mark A and B" : "Everything loaded since the game started (not only marks)";
        if (listLoaded && mode == 0 && !everything && skipped > 0) src += " \u00B7 " + skipped + " scope / lobby left out";
        TextView s = txt(a, src, 10, MUT, false);
        s.setPadding(dp(1), 0, 0, dp(4));
        lhead.addView(s);
        lhead.addView(seg(a, new String[]{"Since start", "A to B"}, marksOnly ? 1 : 0, new Sel() { public void on(int i) { setSource(i == 1); } }));
        HorizontalScrollView hs = new HorizontalScrollView(a);
        hs.setHorizontalScrollBarEnabled(false);
        LinearLayout cr = hrow(a);
        String[] nm = {"All", "Hidden", "Visible", "Saved", "Unsaved"};
        for (int i = 0; i < nm.length; i++) {
            final int k = i;
            Button b = sm(a, nm[i], i == lf ? ACC : SURF2, i == lf ? ACCTXT : MUT, i == lf ? 0 : LINE, new Runnable() { public void run() { lf = k; renderList(); } });
            cr.addView(b);
        }
        hs.addView(cr);
        LinearLayout.LayoutParams hp = fullW(dp(5));
        hp.bottomMargin = dp(4);
        lhead.addView(hs, hp);
        LAD.notifyDataSetChanged();
    }

    private static final class LH { View bar; TextView t1, t2; Button b1, b2; }

    private static final BaseAdapter LAD = new BaseAdapter() {
        public int getCount() { return lshown.size(); }
        public Object getItem(int i) { return lshown.get(i); }
        public long getItemId(int i) { return i; }
        public View getView(int i, View cv, ViewGroup p) {
            Activity a = (Activity) overlay.getContext();
            try {
                LH h;
                View v = cv;
                if (v == null) {
                    h = new LH();
                    LinearLayout row = hrow(a);
                    row.setPadding(dp(1), dp(7), dp(1), dp(7));
                    h.bar = new View(a);
                    row.addView(h.bar, new LinearLayout.LayoutParams(dp(3), dp(32)));
                    LinearLayout col = vcol(a);
                    col.setPadding(dp(9), 0, dp(4), 0);
                    h.t1 = txt(a, "", 12, TXT, true);
                    h.t2 = mono(a, "", 10, MUT);
                    h.t1.setSingleLine(true);
                    h.t2.setSingleLine(true);
                    col.addView(h.t1);
                    col.addView(h.t2);
                    row.addView(col, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
                    h.b1 = sm(a, "", SURF2, TXT, LINE, null);
                    h.b2 = sm(a, "Save", SURF2, MUT, LINE, null);
                    row.addView(h.b1);
                    row.addView(h.b2);
                    row.setTag(h);
                    v = row;
                } else h = (LH) v.getTag();
                if (i < 0 || i >= lshown.size()) return v;
                final Data.Row r = lshown.get(i);
                final String k = r.key();
                int st = stateOf(r);
                h.bar.setBackground(box(st == Data.ST_HID ? RED : st == Data.ST_SHOWN ? GRN : st == Data.ST_REST ? ACC : LINE, 2, 0));
                h.t1.setText(Data.fmtName(r.fmt) + "  " + dims(r));
                final Data.Saved sv = libMap.get(k);
                boolean saved = Data.isSaved(k, libMap.keySet(), rHid, rOri);
                String stTxt = st == Data.ST_HID ? "hidden" : st == Data.ST_SHOWN ? "shown" : st == Data.ST_REST ? "restored" : "untouched";
                h.t2.setText(stTxt + " \u00B7 " + Data.sizeText(r.n) + " \u00B7 " + shortHash(r.hash) + (sv != null ? " \u00B7 " + sv.name : saved ? " \u00B7 saved rule" : "") + (Data.guarded(r) ? " \u00B7 scope/lobby" : ""));
                boolean hid = st == Data.ST_HID, rest = st == Data.ST_REST;
                boolean neutral = rest || mode == 1;
                h.b1.setText(rest ? "Look on" : mode == 1 ? "Restore" : hid ? "Show" : "Hide");
                h.b1.setTextColor(neutral ? ACC : hid ? GRN : RED);
                h.b1.setBackground(box(neutral ? SURF2 : hid ? GRND : REDD, 6, neutral ? LINE : hid ? GRNL : REDL));
                h.b1.setOnClickListener(tap(new Runnable() { public void run() { toggleRow(r); } }));
                h.b2.setText(saved ? "Saved" : "Save");
                h.b2.setTextColor(saved ? AMB : MUT);
                h.b2.setBackground(box(saved ? AMBD : SURF2, 6, saved ? AMBL : LINE));
                h.b2.setOnClickListener(tap(new Runnable() { public void run() {
                    if (Data.isSaved(k, libMap.keySet(), rHid, rOri)) { say(sv != null ? "Already saved as: " + sv.name : "Already saved (a rule is active)."); return; }
                    ArrayList<Data.Row> l = new ArrayList<Data.Row>(); l.add(r); formRestore = mode == 1; openForm(1, l, null, false); } }));
                return v;
            } catch (Throwable t) {
                err("row", t);
                return cv != null ? cv : new View(a);
            }
        }
    };

    /** Restore undone: the texture gets the look again (a saved Restore rule for it is switched OFF first). */
    private static void lookOn(Data.Row r) {
        ArrayList<String> keys = new ArrayList<String>();
        keys.add(r.key());
        if (rOri.contains(r.key())) { Data.setRules(dir, "orig.txt", keys, false); reloadRules(); }
        one("f", r, "O");
    }

    private static void toggleRow(Data.Row r) {
        int st = stateOf(r);
        if (st == Data.ST_REST) lookOn(r);
        else if (mode == 1) one("r", r, "R");
        else if (st == Data.ST_HID) one("u", r, "S");
        else one("h", r, "H");
    }

    // ---------- save / rename form (a page of the same window) ----------
    private static void openForm(int kind, ArrayList<Data.Row> rows, ArrayList<Data.Saved> unit, boolean asSet) {
        formKind = kind; formRows = rows; formUnit = unit; formAsSet = asSet;
        if (kind == 1) formGrp = "plants";
        formKeep = "";
        if (tab != 3) formBack = tab;
        showForm();
    }

    private static String autoName() {
        if (formKind == 2 && formUnit != null && !formUnit.isEmpty()) return formUnit.get(0).name;
        if (formRows == null || formRows.isEmpty()) return "Texture";
        Data.Row r = formRows.get(0);
        String base = formRows.size() > 1 ? "Set " + formRows.size() : Data.fmtName(r.fmt) + " " + r.w + "x" + r.h;
        return Data.cleanName(base);
    }

    private static void closeForm() {
        formKind = 0;
        nameEt = null;
        if (overlay != null) showTab(formBack);
    }

    private static void showForm() {
        if (overlay == null || formKind == 0 || formBox == null) return;
        final Activity a = (Activity) overlay.getContext();
        formBox.removeAllViews();
        LinearLayout c = vcol(a);
        c.setPadding(dp(10), dp(8), dp(10), dp(10));
        c.setBackground(box(SURF, 8, LINE));
        c.addView(txt(a, formKind == 1 ? "Name it, or just tap Save." : "New name", 12, TXT, true));
        c.addView(txt(a, "Tap the box to type. Same name as in the WebUI.", 10, DIM, false));
        nameEt = new EditText(a);
        nameEt.setText(formKeep.length() > 0 ? formKeep : autoName());
        nameEt.setTextSize(13);
        nameEt.setTextColor(TXT);
        nameEt.setSingleLine(true);
        nameEt.setFocusableInTouchMode(true);
        nameEt.setBackground(box(SURF2, 6, LINE));
        nameEt.setPadding(dp(10), dp(8), dp(10), dp(8));
        nameEt.setOnClickListener(tap(new Runnable() {
            public void run() {
                nameEt.requestFocus();
                InputMethodManager im = (InputMethodManager) a.getSystemService(Context.INPUT_METHOD_SERVICE);
                if (im != null) im.showSoftInput(nameEt, 0);
            }
        }));
        c.addView(nameEt, fullW(dp(7)));
        if (formKind == 1) {
            LinearLayout g = hrow(a);
            String[] ids = {"plants", "effects", "other"}, nm = {"Plants", "Effects", "Other"};
            for (int i = 0; i < 3; i++) {
                final String id = ids[i];
                boolean on = formGrp.equals(id);
                Button b = btn(a, nm[i], on ? ACC : SURF2, on ? ACCTXT : TXT, on ? 0 : LINE);
                b.setOnClickListener(tap(new Runnable() { public void run() { formKeep = nameEt != null ? nameEt.getText().toString() : ""; formGrp = id; showForm(); } }));
                g.addView(b, wt(dp(2)));
            }
            c.addView(g, fullW(dp(6)));
            TextView note = txt(a, (formRestore ? "Restore" : "Hide") + " entry" + (formRows != null && formRows.size() > 1 ? " for " + formRows.size() + " textures together" : "") + ", ON at every game start.", 10, DIM, false);
            note.setPadding(0, dp(6), 0, 0);
            c.addView(note);
        }
        LinearLayout r = hrow(a);
        r.addView(good(a, formKind == 1 ? "Save" : "Rename", new Runnable() { public void run() { submitForm(); } }), wt(dp(2)));
        r.addView(neut(a, "Cancel", new Runnable() { public void run() { closeForm(); } }), wt(dp(2)));
        c.addView(r, fullW(dp(8)));
        formBox.addView(c, fullW(dp(2)));
        showTab(3);
    }

    private static void submitForm() {
        try {
            String name = Data.cleanName(nameEt != null ? nameEt.getText().toString() : "");
            if (name.length() == 0) name = autoName();
            if (formKind == 1) saveRows(formRows, name, formGrp, formRestore, formAsSet);
            else if (formKind == 2 && formUnit != null) {
                ArrayList<Data.Saved> lib = Data.readLib(dir);
                for (Data.Saved s : lib) for (Data.Saved u : formUnit) if (s.key.equals(u.key)) s.name = name;
                say(Data.writeLib(dir, lib) ? "Renamed." : "Could not write texlib.txt");
            }
        } catch (Throwable t) {
            err("form", t);
        }
        closeForm();
        reloadRules();
        renderAll();
    }

    private static void saveRows(List<Data.Row> rows, String name, String grp, boolean restore, boolean asSet) {
        ArrayList<Data.Saved> lib = Data.readLib(dir);
        LinkedHashSet<String> have = new LinkedHashSet<String>();
        for (Data.Saved s : lib) have.add(s.key);
        String setId = asSet && rows.size() > 1 ? Data.newSetId() : "";
        ArrayList<String> keys = new ArrayList<String>();
        int added = 0;
        for (Data.Row r : rows) {
            if (!have.add(r.key())) continue;
            Data.Saved s = new Data.Saved();
            s.key = r.key(); s.name = name; s.grp = Data.grpOk(grp); s.set = setId; s.restore = restore;
            lib.add(s); keys.add(r.key()); added++;
        }
        if (added == 0) { say("Already in My textures."); return; }
        boolean ok = Data.writeLib(dir, lib)
                && Data.setRules(dir, restore ? "orig.txt" : "hidden.txt", keys, true)
                && Data.setRules(dir, restore ? "hidden.txt" : "orig.txt", keys, false);
        if (!ok) { say("Could not save (files are not writable)."); return; }
        // only send what is not already in that state (a second "hide" of a hidden texture is not needed)
        ArrayList<String> ls = new ArrayList<String>();
        for (Data.Row r : rows) {
            String c = chip.get(r.key());
            if (restore ? !"R".equals(c) : !"H".equals(c)) { ls.add((restore ? "r " : "h ") + r.hash); chip.put(r.key(), restore ? "R" : "H"); }
        }
        say("Saved " + added + " (switched ON).");
        if (!ls.isEmpty()) sendLines(ls, "Saved " + added + " \u00B7 " + (restore ? "Restore" : "Hide"));
    }

    // ---------- Saved tab (My textures) ----------
    private static void renderSaved() {
        if (shead == null || overlay == null) return;
        Activity a = (Activity) overlay.getContext();
        final ArrayList<Data.Saved> lib = Data.readLib(dir);
        reloadRules();
        sitems.clear();
        String[] gid = {"plants", "effects", "other"}, gnm = {"Plants", "Effects", "Other"};
        ArrayList<ArrayList<Data.Saved>> units = Data.units(lib);
        int on = 0;
        for (int g = 0; g < 3; g++) {
            boolean head = false;
            for (ArrayList<Data.Saved> u : units) {
                if (!u.get(0).grp.equals(gid[g])) continue;
                if (!head) { sitems.add(gnm[g]); head = true; }
                sitems.add(u);
                if (unitOn(u)) on++;
            }
        }
        savedUnits = units.size();
        shead.removeAllViews();
        TextView t = txt(a, units.size() + " saved \u00B7 " + on + " ON", 12, TXT, true);
        t.setPadding(dp(1), 0, 0, dp(1));
        shead.addView(t);
        TextView s = txt(a, units.isEmpty() ? "Nothing saved yet. Use Save in List or Test." : "Same list as the WebUI. ON = active at every game start.", 10, MUT, false);
        s.setPadding(dp(1), 0, 0, dp(4));
        shead.addView(s);
        SAD.notifyDataSetChanged();
    }

    private static boolean unitOn(ArrayList<Data.Saved> u) {
        boolean restore = u.get(0).restore;
        for (Data.Saved s : u) if (!(restore ? rOri : rHid).contains(s.key)) return false;
        return true;
    }

    private static final class SH { View bar; TextView t1, t2; Button on, nm, del; }

    private static final BaseAdapter SAD = new BaseAdapter() {
        public int getCount() { return sitems.size(); }
        public Object getItem(int i) { return sitems.get(i); }
        public long getItemId(int i) { return i; }
        public int getViewTypeCount() { return 2; }
        public int getItemViewType(int i) { return sitems.get(i) instanceof String ? 0 : 1; }
        @SuppressWarnings("unchecked")
        public View getView(int i, View cv, ViewGroup p) {
            Activity a = (Activity) overlay.getContext();
            try {
                Object it = sitems.get(i);
                if (it instanceof String) {
                    TextView t = cv instanceof TextView ? (TextView) cv : txt(a, "", 9, DIM, true);
                    t.setText(((String) it).toUpperCase());
                    t.setLetterSpacing(0.14f);
                    t.setPadding(dp(2), dp(9), 0, dp(4));
                    return t;
                }
                final ArrayList<Data.Saved> u = (ArrayList<Data.Saved>) it;
                SH h;
                View v = cv;
                if (v == null) {
                    h = new SH();
                    LinearLayout row = vcol(a);
                    row.setPadding(dp(1), dp(7), dp(1), dp(7));
                    LinearLayout l1 = hrow(a);
                    h.bar = new View(a);
                    l1.addView(h.bar, new LinearLayout.LayoutParams(dp(3), dp(16)));
                    h.t1 = txt(a, "", 12, TXT, true);
                    h.t1.setSingleLine(true);
                    h.t1.setPadding(dp(9), 0, dp(4), 0);
                    l1.addView(h.t1, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
                    h.on = sm(a, "", SURF2, TXT, LINE, null);
                    l1.addView(h.on);
                    row.addView(l1);
                    LinearLayout l2 = hrow(a);
                    h.t2 = mono(a, "", 10, MUT);
                    h.t2.setSingleLine(true);
                    h.t2.setPadding(dp(12), dp(2), dp(4), 0);
                    l2.addView(h.t2, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
                    h.nm = sm(a, "Rename", SURF2, TXT, LINE, null);
                    h.del = sm(a, "Delete", SURF2, TXT, LINE, null);
                    l2.addView(h.nm);
                    l2.addView(h.del);
                    row.addView(l2);
                    row.setTag(h);
                    v = row;
                } else h = (SH) v.getTag();
                final boolean restore = u.get(0).restore;
                final boolean isOn = unitOn(u);
                final String id = u.get(0).key;
                h.bar.setBackground(box(isOn ? GRN : LINE, 2, 0));
                h.t1.setText(u.get(0).name);
                h.t2.setText((restore ? "restore" : "hide") + (u.size() > 1 ? " \u00B7 " + u.size() + " together" : " \u00B7 " + Data.fmtName(Data.rowOfKey(id).fmt) + " " + Data.rowOfKey(id).w + "\u00D7" + Data.rowOfKey(id).h));
                h.on.setText(isOn ? "ON" : "OFF");
                h.on.setTextColor(isOn ? GRN : RED);
                h.on.setBackground(box(isOn ? GRND : REDD, 6, isOn ? GRNL : REDL));
                h.on.setOnClickListener(tap(new Runnable() { public void run() { toggleUnit(u, restore, !isOn); } }));
                h.nm.setOnClickListener(tap(new Runnable() { public void run() { openForm(2, null, u, false); } }));
                boolean arm = delArm.equals(id);
                h.del.setText(arm ? "Confirm" : "Delete");
                h.del.setTextColor(arm ? RED : TXT);
                h.del.setBackground(box(arm ? REDD : SURF2, 6, arm ? REDL : LINE));
                h.del.setOnClickListener(tap(new Runnable() { public void run() {
                    if (delArm.equals(id)) deleteUnit(u, restore); else { delArm = id; SAD.notifyDataSetChanged(); } } }));
                return v;
            } catch (Throwable t) {
                err("saved row", t);
                return cv != null ? cv : new View(a);
            }
        }
    };

    private static ArrayList<String> keysOf(List<Data.Saved> u) { ArrayList<String> k = new ArrayList<String>(); for (Data.Saved s : u) k.add(s.key); return k; }

    private static ArrayList<String> opsFor(String op, List<Data.Saved> u) {
        ArrayList<String> l = new ArrayList<String>();
        for (Data.Saved s : u) l.add(op + " " + s.key.substring(s.key.lastIndexOf('|') + 1));
        return l;
    }

    private static void toggleUnit(List<Data.Saved> u, boolean restore, boolean on) {
        if (!Data.setRules(dir, restore ? "orig.txt" : "hidden.txt", keysOf(u), on)) { say("Could not write the rule file."); return; }
        if (on) Data.setRules(dir, restore ? "hidden.txt" : "orig.txt", keysOf(u), false);
        reloadRules();
        String c = restore ? "R" : "H";
        for (Data.Saved s : u) chip.put(s.key, on ? c : (restore ? "O" : "S"));
        if (restore) sendLines(opsFor(on ? "r" : "f", u), on ? "Restore" : "Look on");
        else sendLines(opsFor(on ? "h" : "u", u), on ? "Hide" : "Show");
        renderAll();
    }

    private static void deleteUnit(List<Data.Saved> u, boolean restore) {
        ArrayList<Data.Saved> lib = Data.readLib(dir);
        ArrayList<String> keys = keysOf(u);
        ArrayList<Data.Saved> keep = new ArrayList<Data.Saved>();
        for (Data.Saved s : lib) if (!keys.contains(s.key)) keep.add(s);
        boolean ok = Data.writeLib(dir, keep) && Data.setRules(dir, "hidden.txt", keys, false) && Data.setRules(dir, "orig.txt", keys, false);
        delArm = "";
        if (!ok) { say("Could not delete."); return; }
        reloadRules();
        for (String k : keys) chip.put(k, restore ? "O" : "S");
        sendLines(opsFor(restore ? "f" : "u", u), restore ? "Deleted; Look on" : "Deleted; Show");
        renderAll();
    }
}
