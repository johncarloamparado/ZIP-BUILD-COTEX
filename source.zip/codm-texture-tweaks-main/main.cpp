/*
 * codm_tex - Zygisk module for Call of Duty: Mobile
 *
 * Installs PLT hooks (LSPlt) on the Unity renderer (libunity.so) to:
 *   - change texture sampling (Pixel Blocks, Detail Cut, Flat, True Pixelated)
 *   - lower the render resolution (render scale) and cap the frame rate
 *   - record frame-time, freeze, thread and CPU-core diagnostics
 *
 * Settings are plain text files in the game's data directory (see the *F
 * macros below). They are read once at launch and are edited through the
 * WebUI in webroot/ (SukiSU Ultra / KernelSU).
 */
#include <cstdarg>
#include <cerrno>
#include <jni.h>
#include <dlfcn.h>
#include <unistd.h>
#include <time.h>
#include <sys/syscall.h>
#include <sys/resource.h>
#include <dirent.h>
#include <fcntl.h>
#include <sched.h>
#include <cstdio>
#include <ctime>
#include <cstring>
#include <cstdint>
#include <thread>
#include <mutex>
#include <atomic>
#include <algorithm>
#include <vector>
#include <deque>
#include <unordered_map>
#include <set>
#include <tuple>
#include <cctype>
#include <map>
#include <string>
#include <EGL/egl.h>
#include <android/native_window.h>
#include <android/dlext.h>
#include <android/log.h>
#include <sys/stat.h>
#include <sys/sysinfo.h>
#include <GLES3/gl3.h>
#include "zygisk.hpp"
#include "lsplt.hpp"

#ifndef RUSAGE_THREAD
#define RUSAGE_THREAD 1
#endif

/* One place for the version. Keep in sync with module.prop (bump +1 every update). */
#define VERSION "v0.83"
#define PKG "com.garena.game.codm"
/* v0.40: the settings folder is chosen at run time. A clone (Dual Apps, work profile, user 999) keeps its data
   under /data/user/<id>/<pkg>, which the old hard-coded /data/data/<pkg> path does not reach. */
#define DEFAULT_DIR "/data/data/" PKG "/files/"
static char g_dir[320] = DEFAULT_DIR;
static char g_app_dir[256] = "";            /* app_data_dir given by Zygisk in preAppSpecialize (without trailing slash) */
static const char *P(const char *name) {    /* ring of buffers so rename(P(a), P(b)) is safe */
    static thread_local char buf[8][400];
    static thread_local unsigned idx = 0;
    char *b = buf[idx++ & 7];
    snprintf(b, 400, "%s%s", g_dir, name);
    return b;
}
static void set_dir(const char *app_data_dir) {
    if (app_data_dir && app_data_dir[0] == '/' && strlen(app_data_dir) < 240) {
        char cand[320];
        size_t n = strlen(app_data_dir);
        while (n > 1 && app_data_dir[n - 1] == '/') n--;
        snprintf(cand, sizeof cand, "%.*s/files/", (int)n, app_data_dir);
        if (access(cand, W_OK) == 0) { snprintf(g_dir, sizeof g_dir, "%s", cand); return; }
        if (access(DEFAULT_DIR, W_OK) == 0) { snprintf(g_dir, sizeof g_dir, "%s", DEFAULT_DIR); return; }
        snprintf(g_dir, sizeof g_dir, "%s", cand);      /* neither is writable: report the one the game really owns */
        return;
    }
    snprintf(g_dir, sizeof g_dir, "%s", DEFAULT_DIR);
}
#define LOGF P("codm_tex.log")
#define CFGF P("bias.txt")
#define FPSF P("fps.txt")
#define SCLF P("scale.txt")
#define MODEF P("mode.txt")
#define FZF P("fz.txt")
#define LIVEF P("live.txt")         /* v0.76: 1 = live test mode (capture window, live hide / restore, rules re-read while playing). Never created by the module. */
#define MARKF P("mark.txt")         /* v0.76: the WebUI writes a label (A / B / X ...); the module logs "MARK <label>" itself */
#define LIVECAPF P("livecap.txt")   /* v0.78: 1 = the capture window is open from the start of the game (so Restore / Show also work without Mark A) */
#define LIVECF P("livecmd.txt")     /* v0.76: live commands "h|u|r <hash>" written by the WebUI */
#define SPREADF P("spread.txt")     /* v0.71 (experimental): KB of texture upload per frame, 0 / missing = OFF (never created by the module) */
#define THF P("th.txt")
#define COREF P("core.txt")
#define NEARF P("near.txt")
#define BLKF P("blk.txt")
#define MINF P("minsz.txt")
#define DLYF P("delay.txt")
#define SKIPF P("skip.txt")
#define BLOFFF P("bltoff.txt")
#define STYF P("style.txt")
#define SEDF P("sedge.txt")
#define FLATF P("flat.txt")
#define TTEXF P("testtex.txt")
#define TTSZF P("ttsize.txt")
#define TTSMF P("ttsm.txt")
#define ALPHAF P("alpha.txt")       /* v0.44: 1 = alpha-channel textures (smoke, dust, muzzle flash, leaves) keep their soft edge (default 1) */
#define ASTCF P("astc.txt")         /* v0.81: 1 = ASTC textures also stay untouched by the look (default 0) */
#define BLF P("boxloot.txt")        /* v0.81: Box loot (device spoof) master switch (default 0) */
#define BLGPUF P("bl_gpu.txt")      /* v0.81: 1 = the GPU name says PowerVR (default 1) */
#define BLRAMF P("bl_ram.txt")      /* v0.81: RAM in MB the game is told (0 = the real RAM) */
#define BLPVRF P("bl_pvr.txt")      /* v0.81: 1 = PVRTC is added to the extension string (default 1) */
#define PROBEF P("probe.txt")       /* v0.81: 1 = log what libunity asks about the device (default 1, log only) */
#define BLRUNF P("boxloot_run.txt") /* v0.81: marker like scale_crash.txt: Box loot is switched OFF when the last launch did not reach 20 frames */
#define GRASSF P("hidden.txt")      /* v0.70: was grass.txt. "format width height hash" lines; that one texture is uploaded fully transparent (hide list) */
#define GRASSOLDF P("grass.txt")    /* v0.70: the old name. Read ONLY when hidden.txt does not exist (a phone that has not opened the WebUI since the update) */
#define ORIGF P("orig.txt")         /* v0.61: "format width height hash" lines; that one texture is left as the game made it (Restore original) */
#define HDLYF P("hookdelay.txt")
#define FGLF P("forcegl.txt")       /* v0.41: 1 = force OpenGL ES: Vulkan is hidden from libunity so Unity falls back to GLES (default 1) */
#define HSAFEF P("hooksafe.txt")      /* v0.40: 1 = hooks skipped (the previous launch died while hooking); the WebUI resets it to 0 */
#define STATF P("codm_tex.status")   /* small key=value file the WebUI reads: how far the module got (written by the game process) */
#define FULLF P("fullsize.txt")      /* largest landscape window size ever seen (so a window shrunk by something else is never taken as "native") */
#define SCRASHF P("scale_crash.txt")   /* marker: written before render scale is applied, cleared after 120 good frames */

static std::mutex mu;
static FILE *lf = nullptr;
static long lf_bytes = 0;
#define LOG_CAP_BYTES (4L * 1024 * 1024)   /* v0.71: was 2 MB; long sessions lost their second half */
static void L(const char *fmt, ...) {
    std::lock_guard<std::mutex> g(mu);
    if (lf && lf_bytes > LOG_CAP_BYTES) {          /* keep shared reports small: start the log over */
        fclose(lf); lf = fopen(LOGF, "w"); lf_bytes = 0;
        if (lf) fputs("=== log truncated (4 MB cap) ===\n", lf);
    }
    if (!lf) { lf = fopen(LOGF, "a"); if (lf) { fseek(lf, 0, SEEK_END); lf_bytes = ftell(lf); } }
    if (!lf && access(LOGF, F_OK) == 0) {          /* file exists but the game cannot append (e.g. created by root): replace it, the folder is ours */
        unlink(LOGF);
        lf = fopen(LOGF, "a"); lf_bytes = 0;
        if (lf) fputs("=== log file was not writable by the game; recreated ===\n", lf);
    }
    va_list a; va_start(a, fmt);
    if (!lf) {                                     /* log file unavailable: make it visible in logcat instead */
        __android_log_vprint(ANDROID_LOG_INFO, "codm_tex", fmt, a);
        va_end(a);
        return;
    }
    int n = vfprintf(lf, fmt, a);
    va_end(a);
    if (n > 0) lf_bytes += n;
    fflush(lf);
}

/* ---------- Status file (codm_tex.status) ----------
   The log can be missing, truncated or unreadable; this tiny file is rewritten atomically
   (tmp + rename) at every stage so the WebUI can tell "module never ran" from "ran, 0 applied". */
static std::mutex st_mu;
static std::map<std::string, std::string> st_kv;
static std::atomic<int> g_hook_state{0};   /* 0 = no hooks yet, 1 = CommitHook ok, 2 = CommitHook failed */
static void st_set(const char *k, const std::string &v) {
    std::lock_guard<std::mutex> g(st_mu);
    st_kv[k] = v;
    st_kv["updated"] = std::to_string((long long)time(nullptr));
    const std::string tmp = std::string(STATF) + ".tmp";
    FILE *f = fopen(tmp.c_str(), "w");
    if (!f) { unlink(tmp.c_str()); f = fopen(tmp.c_str(), "w"); }   /* leftover root-owned .tmp: the folder is the game's, replace it */
    if (!f) {
        static std::atomic<int> warned{0};
        if (!warned.exchange(1)) __android_log_print(ANDROID_LOG_WARN, "codm_tex", "%s status file not writable errno=%d", VERSION, errno);
        return;
    }
    for (auto &kv : st_kv) fprintf(f, "%s=%s\n", kv.first.c_str(), kv.second.c_str());
    fclose(f);
    chmod(tmp.c_str(), 0666);
    rename(tmp.c_str(), STATF);
}
static void st_seti(const char *k, long long v) { st_set(k, std::to_string(v)); }

/* ---------- Original-function safety net (v0.37) ----------
   Every hook calls the "original" through a pointer that LSPlt (or wrap()) fills in. If that pointer is
   still null, or points back at our own hook (another injector chained through us), the old code either
   dropped the GL/EGL call or recursed. orig_or() resolves the real system function instead and caches it. */
static void *real_sym(const char *n) {
    void *p = dlsym(RTLD_DEFAULT, n);
    if (p) return p;
    static std::atomic<int> misses{0};
    if (misses.load() >= 64) return nullptr;      /* symbol really is not there: stop probing on every GL call */
    misses++;
    static const char *libs[] = {"libEGL.so", "libGLESv3.so", "libGLESv2.so", "libandroid.so"};
    for (const char *l : libs) {
        void *h = dlopen(l, RTLD_NOW);
        if (h && (p = dlsym(h, n))) return p;
    }
    return nullptr;
}
/* v0.38: a stored "original" that is not inside any loaded library (for example a trampoline in a /memfd: region that
   another injector later unmapped) must never be called: that is a SEGV_ACCERR. Such pointers are replaced by the
   real system symbol. dladdr() is only run once per distinct pointer; good pointers are cached. */
static std::atomic<void *> g_okp[96];
static std::atomic<int> g_okn{0};
static bool ptr_ok(void *p) {
    if (!p) return false;
    int n = std::min(g_okn.load(), 96);
    for (int i = 0; i < n; i++) if (g_okp[i].load() == p) return true;
    Dl_info di;
    if (!dladdr(p, &di) || !di.dli_fname) return false;
    int i = g_okn.fetch_add(1);
    if (i < 96) g_okp[i] = p;
    return true;
}
template <class F> static F orig_or(F &slot, const char *name, F self) {
    F f = slot;
    if (f && f != self) {
        if (ptr_ok((void *)f)) return f;
        static std::atomic<int> warned{0};
        if (warned++ < 20) L("CHAINFIX %s: original %p is outside every loaded library (foreign/memfd hook?) -> using the system symbol\n", name, (void *)f);
        slot = nullptr;
    }
    void *p = real_sym(name);
    if (p && p != (void *)self) { slot = (F)p; return (F)p; }
    return nullptr;
}
static void maps_report(const char *tag);    /* defined below: lists non-system executable mappings (other injectors) */
static void chain_report(const char *tag);   /* defined below: who owns the "original" function behind each of our hooks */

/* ---------- ANativeWindow calls without our own PLT/GOT (v0.42.1) ----------
   v0.42 crashed on some phones inside ANativeWindow_getWidth(): the GOT slot of THIS module for that libandroid
   import held a stale pointer (SIGSEGV, pc in an unrelated mapping, backtrace #01 = h_sbg). Since v0.39 the calls
   run on every launch even with render scale off. The functions are now looked up with dlsym at the time of use
   (cached once found), so a corrupted or stale import slot can no longer be called. Missing symbol -> harmless 0. */
static void *nw_sym(std::atomic<void *> &c, const char *n) {
    void *p = c.load();
    if (!p) { p = real_sym(n); if (p) c = p; }
    return p;
}
static int32_t nw_width(ANativeWindow *w) {
    static std::atomic<void *> c{nullptr};
    auto f = (int32_t (*)(ANativeWindow *))nw_sym(c, "ANativeWindow_getWidth");
    return (f && w) ? f(w) : 0;
}
static int32_t nw_height(ANativeWindow *w) {
    static std::atomic<void *> c{nullptr};
    auto f = (int32_t (*)(ANativeWindow *))nw_sym(c, "ANativeWindow_getHeight");
    return (f && w) ? f(w) : 0;
}
static int32_t nw_format(ANativeWindow *w) {
    static std::atomic<void *> c{nullptr};
    auto f = (int32_t (*)(ANativeWindow *))nw_sym(c, "ANativeWindow_getFormat");
    return (f && w) ? f(w) : 0;
}
static int32_t nw_sbg(ANativeWindow *w, int32_t ww, int32_t hh, int32_t fmt) {
    static std::atomic<void *> c{nullptr};
    auto f = (int32_t (*)(ANativeWindow *, int32_t, int32_t, int32_t))nw_sym(c, "ANativeWindow_setBuffersGeometry");
    return (f && w) ? f(w, ww, hh, fmt) : -22;
}

/* ---------- Render scale and mip bias ---------- */
static std::atomic<int> g_scale{0};        /* 0 = off, 20-99 = percent of native resolution */
static std::atomic<int> g_scale_marked{0}; /* 1 once scale_crash.txt has been written this session */
static std::atomic<int> g_bias{0};
static std::atomic<int> g_applied{0};
static void (*real_tp)(GLenum, GLenum, GLint) = nullptr;

static bool is_cmp(GLenum f) {
    return (f >= 0x9270 && f <= 0x9279) || (f >= 0x93b0 && f <= 0x93dd);
}

/* ---------- Pixel Blocks (near.txt, blk.txt) ---------- */
/* near.txt: 0 = off, 1 = on (default). Only used by the Pixel Blocks path.
   Textures that get a raised base level are also switched to NEAREST
   filtering, which is what produces the mosaic look. */
static std::atomic<int> g_near{1};
static std::atomic<int> g_blk{0};       /* blk.txt: target edge length in px per texture; 0 = fall back to bias.txt */
static std::atomic<int> g_flagged{0}, g_forced{0}, g_smp{0};
static const GLuint MAXTEX = 1u << 18;
static std::atomic<uint8_t> g_tf[1u << 18];        /* 1 = NEAREST filtering is forced on this texture */
static std::atomic<uint8_t> g_lv[1u << 18];        /* v0.46: mip levels of a texture made with glTexStorage2D (0 = unknown); UI textures have 1, 3D textures have many */
static std::atomic<uint8_t> g_blank[1u << 18];     /* v0.44: 1 = uploads to this texture id are replaced with transparent blocks (Remove grass) */
static std::atomic<uint8_t> g_tr[1u << 18];        /* v0.61: 1 = this module changed the texture parameters of this texture (filters / base level / min LOD) */
static std::atomic<uint16_t> g_omin[1u << 18];     /* v0.61: MIN filter the GAME set (0 = never set: GL default). Only recorded while orig.txt has rules. */
static std::atomic<uint8_t> g_oan[1u << 18];      /* v0.81: anisotropy the GAME asked for (0 = never). Recorded while orig.txt has rules or Live test is on, so Restore can put it back. */
static std::atomic<uint16_t> g_omag[1u << 18];     /* v0.61: MAG filter the GAME set (0 = never set: GL default) */
static std::atomic<int> g_orig_on{0};              /* v0.61: orig.txt has at least one rule */
static std::atomic<int> g_live_on{0}, g_lv_cap{0};  /* v0.76: live test mode / the capture window is open */
static thread_local GLuint tl_bound[32];
static thread_local int tl_unit = 0;
static inline void tr_mark() { GLuint id = tl_bound[tl_unit]; if (id > 0 && id < MAXTEX) g_tr[id] = 1; }   /* v0.61: this module changed this texture's parameters */

static void (*o_act)(GLenum) = nullptr;
static void h_act(GLenum u) {
    int i = (int)u - 0x84C0;
    tl_unit = (i >= 0 && i < 32) ? i : 0;
    if (auto f = orig_or(o_act, "glActiveTexture", h_act)) f(u);
}

static void (*o_bind)(GLenum, GLuint) = nullptr;
static void h_bind(GLenum t, GLuint id) {
    if (t == GL_TEXTURE_2D) tl_bound[tl_unit] = id;
    if (auto f = orig_or(o_bind, "glBindTexture", h_bind)) f(t, id);
}

static void defer_drop(GLuint id);
static void (*o_del)(GLsizei, const GLuint *) = nullptr;
static void tm_del(GLuint id);       /* v0.72 live texture memory estimate */
static void sp_drop(GLuint id);      /* v0.71 upload spreading: forget uploads still queued for a deleted texture */
static void lv_meta_note(GLuint id, GLenum f, int w, int h, uint64_t hh);      /* v0.78: remember (format, size, fingerprint) of every compressed texture, no pixel data */
static void lv_drop(GLuint id);      /* v0.76 live test: forget the copies kept for a deleted texture */
static void lv_capture(GLuint id, GLint l, GLint x, GLint y, GLsizei w, GLsizei h, GLenum f, GLsizei n, const void *p);
static void h_del(GLsizei n, const GLuint *ids) {
    if (ids) {
        for (GLsizei i = 0; i < n; i++) {
            if (ids[i] < MAXTEX) { g_tf[ids[i]] = 0; g_blank[ids[i]] = 0; g_lv[ids[i]] = 0; g_tr[ids[i]] = 0; g_omin[ids[i]] = 0; g_omag[ids[i]] = 0; g_oan[ids[i]] = 0; }
            defer_drop(ids[i]);
            sp_drop(ids[i]);
            if (g_live_on.load()) lv_drop(ids[i]);
            tm_del(ids[i]);
            for (int u = 0; u < 32; u++) if (tl_bound[u] == ids[i]) tl_bound[u] = 0;
        }
    }
    if (auto f = orig_or(o_del, "glDeleteTextures", h_del)) f(n, ids);
}

/* ---------- Detail Cut (style.txt: 0 = off, 1-4 = minimum LOD; sedge.txt: 1 = NEAREST magnification) ---------- */
/* ---------- Flat (flat.txt: 0 = off, 1-4 = strength) ----------
   Locks a texture to its smallest mip levels so it renders as a near-solid color. */
static std::atomic<int> g_style{0};
static std::atomic<int> g_sedge{1};
static std::atomic<int> g_flat{0};
static std::atomic<int> g_astc{0};                 /* v0.81: ASTC textures also stay untouched */
static std::atomic<int> g_bl{0}, g_bl_gpu{1}, g_bl_pvr{1}, g_bl_ram{0}, g_probe{1};   /* v0.81: Box loot spoof switches (all OFF unless boxloot.txt = 1); probe = log only */
static std::atomic<int> g_bl_marked{0};
static std::atomic<int> g_ttsize{0};   /* ttsize.txt: -2 = base level only (shimmers) | -1 = mips capped at level 3 | 0 = normal | 1-3 = coarser pixels (2x, 4x, 8x) */
static std::atomic<int> g_ttsm{0};     /* ttsm.txt: 0 = sharp | 1 = soft blend between mip levels */
static std::atomic<int> g_forcegl{1};  /* v0.41: forcegl.txt 1 = hide Vulkan from libunity (every effect here needs OpenGL ES) */
static std::atomic<int> g_vk_blocked{0}; /* how many Vulkan loads / lookups were refused */
static std::atomic<int> g_testtex{1};  /* testtex.txt: 0 = off | 1 = True Pixelated (NEAREST sampling, full mip chain) */
#define TEX_MIN_LOD 0x813A
#define TEX_MAX_LEVEL 0x813D
#define TEX_ANISO 0x84FE
#ifndef GL_NEAREST_MIPMAP_NEAREST
#define GL_NEAREST_MIPMAP_NEAREST 0x2700
#endif

#ifndef GL_NEAREST_MIPMAP_LINEAR
#define GL_NEAREST_MIPMAP_LINEAR 0x2702
#endif
#ifndef GL_LINEAR_MIPMAP_NEAREST
#define GL_LINEAR_MIPMAP_NEAREST 0x2701
#endif
/* Min/mag filters for True Pixelated, derived from ttsize and ttsm */
static void tt_filters(GLint &mn, GLint &mg) {
    int sz = g_ttsize.load(), sm = g_ttsm.load();
    bool nomip = sz <= -2;
    if (sm >= 1) { mn = nomip ? GL_NEAREST : GL_NEAREST_MIPMAP_LINEAR; mg = GL_NEAREST; }
    else              { mn = nomip ? GL_NEAREST : GL_NEAREST_MIPMAP_NEAREST; mg = GL_NEAREST; }
}

static void h_tp(GLenum t, GLenum p, GLint v) {
    int st = g_style.load();
    int fl = g_flat.load();
    int tt = g_testtex.load();
    if (p == TEX_ANISO && v > 1 && (g_orig_on.load() || g_live_on.load())) { GLuint aid = tl_bound[tl_unit]; if (aid > 0 && aid < MAXTEX) g_oan[aid] = (uint8_t)std::min<GLint>(v, 16); }   /* v0.81: what the game asked for */
    if ((st > 0 || fl > 0 || tt > 0) && p == TEX_ANISO && v > 1) v = 1;
    if (t == GL_TEXTURE_2D && (p == GL_TEXTURE_MIN_FILTER || p == GL_TEXTURE_MAG_FILTER)) {
        GLuint id = tl_bound[tl_unit];
        if (g_orig_on.load() && id > 0 && id < MAXTEX && v >= 0 && v <= 0xFFFF) {    /* v0.61: remember what the GAME asked for, before any override below */
            if (p == GL_TEXTURE_MIN_FILTER) g_omin[id] = (uint16_t)v; else g_omag[id] = (uint16_t)v;
        }
        if (id > 0 && id < MAXTEX && g_tf[id].load()) {
            if (tt > 0) {
                /* True Pixelated: sharp texels, keep the full-resolution mip chain */
                GLint mn, mg; tt_filters(mn, mg);
                v = (p == GL_TEXTURE_MAG_FILTER) ? mg : mn;
                g_forced++;
            } else if (fl > 0) {
                /* Flat: NEAREST for both filters so the small mip stays a solid color */
                v = GL_NEAREST;
                g_forced++;
            } else if (st > 0) {
                /* Detail Cut: only the magnification filter is changed */
                if (p == GL_TEXTURE_MAG_FILTER) { v = GL_NEAREST; g_forced++; }
            } else {
                v = GL_NEAREST;
                g_forced++;
            }
        }
    }
    if (auto f = orig_or(real_tp, "glTexParameteri", h_tp)) f(t, p, v);
}

static void (*o_tpf)(GLenum, GLenum, GLfloat) = nullptr;
static void h_tpf(GLenum t, GLenum p, GLfloat v) {
    if (p == TEX_ANISO && v > 1.0f && (g_orig_on.load() || g_live_on.load())) { GLuint aid = tl_bound[tl_unit]; if (aid > 0 && aid < MAXTEX) g_oan[aid] = (uint8_t)std::min<int>((int)v, 16); }   /* v0.81 */
    if ((g_style.load() > 0 || g_flat.load() > 0 || g_testtex.load() > 0) && p == TEX_ANISO && v > 1.0f) v = 1.0f;
    if (auto f = orig_or(o_tpf, "glTexParameterf", h_tpf)) f(t, p, v);
}

/* v0.81: put the anisotropy the game asked for back on the bound texture (Restore original / Look on after a Restore) */
static void restore_aniso(GLuint id) {
    if (id == 0 || id >= MAXTEX) return;
    int a = g_oan[id].load();
    if (a <= 1) return;
    if (auto f = orig_or(o_tpf, "glTexParameterf", h_tpf)) f(GL_TEXTURE_2D, TEX_ANISO, (GLfloat)a);
}

static void (*o_smp)(GLuint, GLenum, GLint) = nullptr;
static void h_smp(GLuint s, GLenum p, GLint v) {
    g_smp++;
    if (auto f = orig_or(o_smp, "glSamplerParameteri", h_smp)) f(s, p, v);
}

/* ---------- Texture groups, skip rules, minimum size, start delay ---------- */
static inline int64_t now_ns();
static std::atomic<int> g_minsz{64};                 /* minsz.txt: textures smaller than this are left untouched */
static std::atomic<int> g_delay{0};                     /* delay.txt: seconds after launch during which no textures are modified */
static std::atomic<int64_t> g_tstart{0};
struct Sk { int fmt, a, b; int hit = 0; };   /* hit: set once the rule has matched a texture (logged as SKIPHIT) */
static std::vector<Sk> g_bloff;                      /* bltoff.txt: built-in skip rules disabled from the WebUI; read once at startup */
static std::vector<Sk> g_skip;                       /* skip.txt: "fmt size" (size 0 = any) or "fmt w h"; read once at startup */
struct Grp { int fmt; int sz; int n; int ap; };
static const int MAXG = 96;
static Grp g_grp[MAXG];
static int g_ng = 0;
static std::mutex g_gm;
static std::atomic<int> g_gdirty{0};
static std::atomic<int> g_sk_delay{0}, g_sk_minsz{0}, g_sk_rule{0}, g_cand{0}, g_nobound{0};   /* why candidates were left untouched */

static thread_local bool tl_revisit = false;          /* true while a delayed texture is being processed (see revisit_pending) */
static void grp_note(int fmt, int sz, bool applied) {
    std::lock_guard<std::mutex> lk(g_gm);
    for (int i = 0; i < g_ng; i++)
        if (g_grp[i].fmt == fmt && g_grp[i].sz == sz) { if (!tl_revisit) g_grp[i].n++; if (applied) g_grp[i].ap++; g_gdirty = 1; return; }
    if (tl_revisit) return;
    if (g_ng < MAXG) { g_grp[g_ng].fmt = fmt; g_grp[g_ng].sz = sz; g_grp[g_ng].n = 1; g_grp[g_ng].ap = applied ? 1 : 0; g_ng++; g_gdirty = 1; }
}

/* Built-in skip rules, compiled in. Each one can be switched off through
   bltoff.txt, which the WebUI manages.
   37497 256x512                  scope / reticle atlas (Lava Remix)
   37493, 37492, 37497 128x128    small character-detail textures */
static const Sk g_builtin[] = {
    /* Fix scope: scope frame and reticle (sizes change between sessions, so every size seen so far is listed) */
    {37497, 256, 512},
    {37497, 512, 1024},
    {37497, 512, 256},
    {37497, 512, 512},
    /* Fix menu: lobby and menu buttons */
    {37496, 512, 512},
};

static bool in_skip(int fmt, int w, int h) {
    int sz = std::max(w, h);
    for (auto &p : g_builtin) {
        if (p.fmt != fmt || p.a != w || p.b != h) continue;
        bool off = false;
        for (auto &o : g_bloff)
            if (o.fmt == p.fmt && o.a == p.a && o.b == p.b) { off = true; break; }
        if (!off) return true;
    }
    for (auto &p : g_skip) {
        if (p.fmt != 0 && p.fmt != fmt) continue;               /* v0.38: fmt 0 = any format */
        bool m = false;
        if (p.b == 0) m = (p.a == 0 || p.a == sz);
        else m = (p.a == w && p.b == h);
        if (m) {
            if (!p.hit) { p.hit = 1; L("SKIPHIT rule fmt=%d a=%d b=%d matched a texture fmt=%d %dx%d\n", p.fmt, p.a, p.b, fmt, w, h); }
            return true;
        }
    }
    return false;
}

/* TEXN: one log line per created texture, stamped with the wall-clock time.
   Comparing two logs makes it easy to pick out scopes and red-dot sights. */
static std::atomic<int> g_texn{0};
static void texn_log(int w, int h, int lv, int fmt, bool cand) {
    int n = ++g_texn;
    if (n > 6000) return;
    time_t tt = time(nullptr); struct tm tmv; localtime_r(&tt, &tmv);
    L("TEXN %02d:%02d:%02d t=%.1f %dx%d lv=%d fmt=0x%x cand=%d\n", tmv.tm_hour, tmv.tm_min, tmv.tm_sec,
      (now_ns() - g_tstart.load()) / 1e9, w, h, lv, fmt, cand ? 1 : 0);
}

/* v0.38: textures created during the start delay are remembered and processed on the render thread once the
   delay is over (they used to be skipped for good, which is why delay=50 gave applied=0). */
struct Pend { GLuint id; GLsizei lv; GLenum fmt; GLsizei w, h; };
static std::vector<Pend> g_pend;
static size_t g_pend_i = 0;
static std::mutex g_pm;
static std::atomic<int> g_pend_n{0}, g_pend_drop{0}, g_revisited{0};
static std::atomic<int> g_n_ts3{0}, g_n_ts3_cmp{0}, g_n_cti2{0};   /* other texture upload paths (diagnostics) */
static void defer_add(GLuint id, GLsizei lv, GLenum fmt, GLsizei w, GLsizei h) {
    if (id == 0 || id >= MAXTEX) return;
    std::lock_guard<std::mutex> lk(g_pm);
    if (g_pend.size() >= 8192) { g_pend_drop++; return; }
    g_pend.push_back({id, lv, fmt, w, h});
    g_pend_n = (int)(g_pend.size() - g_pend_i);
}
static void defer_drop(GLuint id) {
    if (g_pend_n.load() == 0) return;
    std::lock_guard<std::mutex> lk(g_pm);
    for (size_t i = g_pend_i; i < g_pend.size(); i++) if (g_pend[i].id == id) { g_pend[i].id = 0; }
}

/* ---------- v0.44: Keep alpha soft (alpha.txt) / v0.45: Remove grass by texture fingerprint (grass.txt) ----------
   Keep alpha soft: a compressed texture with an alpha channel (ETC2 punch-through / ETC2 EAC) is left exactly as the game
   made it, so smoke, dust, muzzle flash and leaves are not turned into hard blocks by the pixel look.
   Remove grass: v0.44 matched "format + size" and so also blanked characters and reticles that share them. v0.45 matches ONE
   texture: grass.txt lines are "format width height hash". The hash is a fingerprint of the compressed level-0 data the game
   uploads, so it names exactly one texture and stays the same from match to match. A matching texture keeps its size and
   mips but its pixel data is replaced, at upload time, with fully transparent blocks. Every upload of a format that could be
   made transparent is also written to the log once as a GRASSCAND line; the WebUI finder reads those lines.
   Written for this module from scratch. */
static std::atomic<int> g_alpha{1};
/* v0.57: grass.txt holds EXACT rules only, "format width height hash", at most GRASS_MAX_RULES unique rules. g_grass is built once in
   load_cfg() (deduplicated and sorted by the full key) and never changed afterwards, so the upload path only does a binary search.
   The old "range ..." rules (v0.47 to v0.56) are gone: such lines are skipped and counted (g_grass_range_old), never applied. */
#define GRASS_MAX_RULES 4096
struct GrRule { int fmt; int w; int h; uint64_t hash; };
static std::vector<GrRule> g_grass;                  /* grass.txt, read once at startup, sorted by (fmt, w, h, hash) */
static int g_grass_range_old = 0;                    /* obsolete "range" lines found in grass.txt (ignored) */
static int g_grass_over = 0;                         /* valid unique rules beyond GRASS_MAX_RULES (ignored) */
static int g_grass_dups = 0, g_grass_bad = 0;        /* duplicate exact rules / unreadable lines found in grass.txt */
static std::atomic<int> g_grass_on{0};
static std::atomic<int> g_astc_kept{0};
static std::atomic<int> g_alpha_kept{0}, g_grass_n{0}, g_grass_guard{0}, g_grass_noalpha{0}, g_grass_pbo{0}, g_grass_nobound{0};
static std::atomic<int> g_grass_cand{0}, g_grass_early{0}, g_grass_early_fix{0};

static inline bool fmt_alpha(GLenum f) { return f >= 0x9276 && f <= 0x9279; }   /* ETC2 punch-through (+sRGB), ETC2 EAC RGBA (+sRGB) */
static inline bool fmt_astc(GLenum f) { return (f >= 0x93B0 && f <= 0x93BD) || (f >= 0x93D0 && f <= 0x93DD); }   /* v0.81: ASTC LDR / sRGB */
static inline bool tex_track() { return g_live_on.load() || g_near.load() || g_style.load() || g_flat.load() || g_testtex.load() || g_grass_on.load() || g_orig_on.load(); }

/* One fully transparent block for the format; returns its size in bytes, 0 = this format cannot be made transparent. */
static int blank_block(GLenum f, uint8_t *out) {
    if (f == 0x9276 || f == 0x9277) {            /* punch-through: opaque bit 0, every pixel index 2 (= transparent) */
        static const uint8_t b[8] = {0, 0, 0, 0, 0xFF, 0xFF, 0, 0};
        memcpy(out, b, 8); return 8;
    }
    if (f == 0x9278 || f == 0x9279) {            /* EAC alpha half: base 0, multiplier 0 -> alpha 0 everywhere */
        memset(out, 0, 16); return 16;
    }
    if ((f >= 0x93B0 && f <= 0x93BD) || (f >= 0x93D0 && f <= 0x93DD)) {   /* ASTC: LDR void-extent block, colour 0,0,0,0 */
        static const uint8_t b[16] = {0xFC, 0xFD, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0, 0, 0, 0, 0, 0, 0, 0};
        memcpy(out, b, 16); return 16;
    }
    return 0;
}
/* The scope / reticle atlases and the lobby buttons (exact sizes) are never blanked. */
static bool grass_guard(int fmt, int w, int h) {
    if (fmt == 37497 && ((w == 256 && h == 512) || (w == 512 && h == 1024) || (w == 512 && h == 256))) return true;
    if (fmt == 37496 && w == 512 && h == 512) return true;
    return false;
}
/* Fingerprint of an upload: FNV-1a over the size and three 2 KB windows (start, middle, end). Fast, and the same every match. */
static uint64_t tex_hash(const void *p, int n) {
    const uint8_t *b = (const uint8_t *)p;
    uint64_t h = 1469598103934665603ULL ^ (uint64_t)(uint32_t)n;
    auto win = [&](int off, int len) { for (int i = 0; i < len; i++) { h ^= b[off + i]; h *= 1099511628211ULL; } };
    if (n <= 6144) win(0, n);
    else { win(0, 2048); win(n / 2 - 1024, 2048); win(n - 2048, 2048); }
    return h;
}
/* Rough alpha picture of an ETC2 EAC texture (sampled blocks): mean = average base alpha 0-255, zero = percent of blocks that
   are (almost) fully transparent. Only a hint for ordering the finder's list. -1 = not an EAC format. */
static void eac_stats(GLenum f, const void *p, int n, int *mean, int *zero) {
    *mean = -1; *zero = -1;
    if (f != 0x9278 && f != 0x9279) return;
    int blocks = n / 16; if (blocks <= 0) return;
    int step = std::max(1, blocks / 256), cnt = 0, z = 0; long sum = 0;
    for (int i = 0; i < blocks; i += step) {
        int base = ((const uint8_t *)p)[(size_t)i * 16];
        sum += base; cnt++; if (base < 16) z++;
    }
    if (cnt) { *mean = (int)(sum / cnt); *zero = z * 100 / cnt; }
}
static inline int blank_block_size(GLenum f) { uint8_t t[16]; return blank_block(f, t); }
/* grass.txt line parser. Tokens are separated by spaces / tabs; "#" starts a comment. fmt / w / h are decimal (or 0x hex), the hash is
   1 to 16 hex digits with an optional 0x. Anything else on the line makes it unreadable (never guessed). */
enum { GRL_SKIP = 0, GRL_RULE = 1, GRL_RANGE = 2, GRL_LEGACY = 3, GRL_BAD = 4 };
static bool grass_tok(const char *&p, char *out, size_t cap) {
    while (*p == ' ' || *p == '\t') p++;
    if (*p == '#' || *p == '\n' || *p == '\r' || !*p) return false;
    size_t n = 0;
    while (*p && *p != ' ' && *p != '\t' && *p != '\n' && *p != '\r' && *p != '#') { if (n + 1 < cap) out[n] = *p; n++; p++; }
    if (n + 1 >= cap) { out[0] = 0; return true; }      /* absurdly long token: handed on as an empty (= invalid) one */
    out[n] = 0; return true;
}
static bool grass_int(const char *t, int *v) {
    if (!*t) return false;
    int base = 10;
    if (t[0] == '0' && (t[1] == 'x' || t[1] == 'X')) { base = 16; t += 2; }
    if (!*t) return false;
    for (const char *q = t; *q; q++) if (!isxdigit((unsigned char)*q) || (base == 10 && !isdigit((unsigned char)*q))) return false;
    if (strlen(t) > 9) return false;
    *v = (int)strtol(t, nullptr, base); return true;
}
static bool grass_hex64(const char *t, uint64_t *v) {
    if (t[0] == '0' && (t[1] == 'x' || t[1] == 'X')) t += 2;
    size_t n = strlen(t);
    if (n < 1 || n > 16) return false;
    for (const char *q = t; *q; q++) if (!isxdigit((unsigned char)*q)) return false;
    *v = (uint64_t)strtoull(t, nullptr, 16); return true;
}
static int grass_parse_line(const char *ln, GrRule *r) {
    const char *p = ln; char t[4][40]; int n = 0; char extra[40];
    while (n < 4 && grass_tok(p, t[n], sizeof t[n])) n++;
    if (n == 0) return GRL_SKIP;
    if (strcmp(t[0], "range") == 0) return GRL_RANGE;
    if (grass_tok(p, extra, sizeof extra)) return GRL_BAD;          /* more than 4 fields */
    int a = 0, b = 0, c = 0; uint64_t hh = 0;
    if (n == 2 && grass_int(t[0], &a) && grass_int(t[1], &b)) return GRL_LEGACY;     /* v0.44 "format size" */
    if (n != 4) return GRL_BAD;
    if (!grass_int(t[0], &a) || !grass_int(t[1], &b) || !grass_int(t[2], &c) || !grass_hex64(t[3], &hh)) return GRL_BAD;
    if (a <= 0 || b <= 0 || c <= 0 || b > 65536 || c > 65536) return GRL_BAD;
    *r = GrRule{a, b, c, hh};
    return GRL_RULE;
}
static inline bool grass_rule_less(const GrRule &a, const GrRule &b) {
    if (a.fmt != b.fmt) return a.fmt < b.fmt;
    if (a.w != b.w) return a.w < b.w;
    if (a.h != b.h) return a.h < b.h;
    return a.hash < b.hash;
}
/* Exact match only: format, width, height AND the full 64-bit fingerprint. g_grass is sorted (load_cfg), so this is a binary search
   with no allocation; it is only called while a texture's decision is still open (g_blank is cached per texture id). */
static std::mutex g_rmu;                              /* v0.76: the rule lists can be re-read while playing */
static bool grass_rule_match(int fmt, int w, int h, uint64_t hash) {
    const GrRule key{fmt, w, h, hash};
    std::lock_guard<std::mutex> lk(g_rmu);
    auto it = std::lower_bound(g_grass.begin(), g_grass.end(), key, grass_rule_less);
    return it != g_grass.end() && it->fmt == fmt && it->w == w && it->h == h && it->hash == hash;
}
/* v0.61 Restore original: orig.txt = the RESTORE list, same exact "format width height hash" lines, same parser, its own limit of
   ORIG_MAX_RULES unique rules. A texture in this list is never blanked and never treated by this module (the Hide list wins if a key is in both). */
#define ORIG_MAX_RULES 4096
static std::vector<GrRule> g_orig;                   /* orig.txt, read once at startup, sorted like g_grass */
static int g_orig_over = 0, g_orig_dups = 0, g_orig_bad = 0, g_orig_range_old = 0;
static std::atomic<int> g_orig_n{0}, g_orig_fix{0}, g_orig_conflict{0};
static bool orig_rule_match(int fmt, int w, int h, uint64_t hash) {
    const GrRule key{fmt, w, h, hash};
    std::lock_guard<std::mutex> lk(g_rmu);
    auto it = std::lower_bound(g_orig.begin(), g_orig.end(), key, grass_rule_less);
    return it != g_orig.end() && it->fmt == fmt && it->w == w && it->h == h && it->hash == hash;
}
/* The texture is bound (this runs inside its level-0 upload). Put back what this module changed: the filters the game asked for (GL defaults when
   it never asked), base level 0, no max level, no min LOD. No texture data is read or written here. Only done when this module changed this texture. */
static void restore_texture(GLuint id, GLenum f, int w, int h, uint64_t hh) {
    int c = ++g_orig_n; st_seti("orig_n", c);
    bool was = id > 0 && id < MAXTEX && g_tr[id].load() != 0;
    if (id > 0 && id < MAXTEX) g_tf[id] = 0;
    if (was && real_tp) {
        uint16_t mn = g_omin[id].load(), mg = g_omag[id].load();
        real_tp(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, mn ? (GLint)mn : 0x2702 /* GL default NEAREST_MIPMAP_LINEAR */);
        real_tp(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, mg ? (GLint)mg : 0x2601 /* GL default LINEAR */);
        real_tp(GL_TEXTURE_2D, GL_TEXTURE_BASE_LEVEL, 0);
        real_tp(GL_TEXTURE_2D, TEX_MAX_LEVEL, 1000);
        real_tp(GL_TEXTURE_2D, TEX_MIN_LOD, -1000);
        restore_aniso(id);                         /* v0.81 */
        g_tr[id] = 0;
        int k = ++g_orig_fix; st_seti("orig_fix", k);
    }
    if (c <= 40) L("ORIG kept #%d fmt=0x%x %dx%d h=%016llx tex=%u%s\n", c, (unsigned)f, w, h, (unsigned long long)hh, (unsigned)id, was ? " (parameters put back)" : "");
}
/* true when the current GL_PIXEL_UNPACK_BUFFER binding is non-zero (then the data pointer is an offset, never read it) */
static void (*g_giv_hook)(GLenum, GLint *) = nullptr;     /* host tests only */
static bool unpack_pbo_bound() {
    typedef void (*giv_t)(GLenum, GLint *);
    static giv_t real = (giv_t)real_sym("glGetIntegerv");
    giv_t giv = g_giv_hook ? g_giv_hook : real;
    if (!giv) return true;                                     /* cannot tell: do not touch the data */
    GLint pbo = 0; giv(0x88EF /* GL_PIXEL_UNPACK_BUFFER_BINDING */, &pbo);
    return pbo != 0;
}
static std::mutex g_cmu;
static uint64_t g_cseen[4096];
static int g_cseen_n = 0;
static uint64_t g_rseen[4096];          /* v0.65: Restore finder candidates include every compressed format tex_post may alter */
static int g_rseen_n = 0;
/* Level-0 upload of a compressed texture: write it to the log once (finder list) and decide whether this texture is blanked.
   g_blank[id]: 0 = not decided yet, 1 = blank every upload, 2 = checked, leave it. */
/* returns 0 = nothing to do, 1 = this texture is now blanked, 2 = blanked AND mip levels reached the GPU before level 0 did */
static int grass_level0(GLuint id, GLenum f, int w, int h, int n, const void *p) {
    if (!p || n < 16 || n > (8 << 20) || std::max(w, h) < 64 || !is_cmp(f)) return 0;
    /* Both finders need the fingerprint. A PBO data argument is an offset, never a CPU pointer. */
    if (unpack_pbo_bound()) {
        int c = ++g_grass_pbo; if (c == 1) L("TEXTURE finder cannot fingerprint an upload from a pixel buffer\n"); st_seti("grass_pbo", c);
        return 0;
    }
    uint64_t hh = tex_hash(p, n);
    if (g_live_on.load() && id > 0 && id < MAXTEX) lv_meta_note(id, f, w, h, hh);
    int levels = (id > 0 && id < MAXTEX) ? (int)g_lv[id].load() : 0;
    /* v0.65: RESTORECAND is intentionally broader than GRASSCAND. Restore original can undo
       tex_post's per-texture sampling/mip changes for ETC2 RGB formats too, even though those
       formats cannot be made transparent by the Hide feature. Only list textures with a known
       mip chain that tex_post itself could process. */
    if (id > 0 && id < MAXTEX && levels >= 3) {
        bool rfresh = false;
        {
            std::lock_guard<std::mutex> lk(g_cmu);
            uint64_t key = hh ^ ((uint64_t)(uint32_t)f << 40) ^ ((uint64_t)(uint32_t)w << 20) ^ (uint64_t)(uint32_t)h;
            bool seen = false;
            for (int i = 0, e = std::min(g_rseen_n, 4096); i < e; i++) if (g_rseen[i] == key) { seen = true; break; }
            if (!seen && g_rseen_n < 4096) { g_rseen[g_rseen_n++] = key; rfresh = true; }
            else if (!seen && g_rseen_n == 4096) { g_rseen_n++; L("RESTORECAND list is full (4096 textures): later ones are not listed\n"); }
        }
        if (rfresh) {
            int mean, zero; eac_stats(f, p, n, &mean, &zero);
            L("RESTORECAND fmt=%d w=%d h=%d n=%d h=%016llx a=%d z=%d lv=%d\n", (int)f, w, h, n, (unsigned long long)hh, mean, zero, levels);
        }
    }
    /* Hide needs a transparent replacement block. Keep its existing candidate list unchanged. */
    uint8_t blk[16];
    int bs = blank_block(f, blk);
    if (!bs || (n % bs)) return 0;
    bool fresh = false;
    {
        std::lock_guard<std::mutex> lk(g_cmu);
        uint64_t key = hh ^ ((uint64_t)(uint32_t)f << 40) ^ ((uint64_t)(uint32_t)w << 20) ^ (uint64_t)(uint32_t)h;
        bool seen = false;
        for (int i = 0, e = std::min(g_cseen_n, 4096); i < e; i++) if (g_cseen[i] == key) { seen = true; break; }
        if (!seen && g_cseen_n < 4096) { g_cseen[g_cseen_n++] = key; fresh = true; }
        else if (!seen && g_cseen_n == 4096) { g_cseen_n++; L("GRASSCAND list is full (4096 textures): later ones are not listed\n"); }
    }
    if (fresh) {
        int mean, zero; eac_stats(f, p, n, &mean, &zero);
        int c = ++g_grass_cand; if (c % 20 == 0) st_seti("grass_cand", c);
        L("GRASSCAND fmt=%d w=%d h=%d n=%d h=%016llx a=%d z=%d lv=%d\n", (int)f, w, h, n, (unsigned long long)hh, mean, zero, levels);
    }
    if (id == 0 || id >= MAXTEX) return 0;
    if (!g_grass_on.load() && !g_orig_on.load()) return 0;
    if (g_grass_on.load() && grass_rule_match((int)f, w, h, hh)) {
        if (g_orig_on.load() && orig_rule_match((int)f, w, h, hh) && ++g_orig_conflict == 1) L("ORIGRULE conflict: fmt=%d %dx%d h=%016llx is in grass.txt AND orig.txt, Hide wins\n", (int)f, w, h, (unsigned long long)hh);
        if (grass_guard((int)f, w, h)) {
            int c = ++g_grass_guard; st_seti("grass_guard", c);
            if (c <= 5) L("GRASS kept fmt=%d %dx%d: it is the scope / reticle atlas (or the lobby buttons)\n", (int)f, w, h);
            g_blank[id] = 2; return 0;
        }
        bool early = g_blank[id].load() == 3;
        g_blank[id] = 1;
        int c = ++g_grass_n; st_seti("grass_n", c);
        if (c <= 40) L("GRASS rule hit #%d fmt=0x%x %dx%d h=%016llx tex=%u%s\n", c, (unsigned)f, w, h, (unsigned long long)hh, (unsigned)id, early ? " (mips came first)" : "");
        return early ? 2 : 1;
    } else if (g_orig_on.load() && orig_rule_match((int)f, w, h, hh)) {
        restore_texture(id, f, w, h, hh);
        g_blank[id] = 4;                    /* 4 = Restore original: left as the game made it (also when it is revisited after the start delay) */
    } else {
        g_blank[id] = 2;
    }
    return 0;
}
/* A new texture storage starts the decision over for that texture id. */
static void grass_on_storage(GLenum t, GLsizei lv, GLsizei w, GLsizei h, GLenum fmt) {
    if (t != GL_TEXTURE_2D) return;
    GLuint id = tl_bound[tl_unit];
    if (g_live_on.load() && id > 0) lv_drop(id);
    if (id > 0 && id < MAXTEX) { g_blank[id] = 0; g_tr[id] = 0; g_lv[id] = (uint8_t)std::min<GLsizei>(std::max<GLsizei>(lv, 0), 255); }
}
/* NOTE: only trivially destructible thread_locals are allowed in this file. A thread_local with a destructor (std::vector,
   std::string ...) makes the first use on a thread call __cxa_thread_atexit_impl, and the linker aborts there because this
   module is loaded by Zygisk and has no soinfo ("Couldn't find soinfo by dso_handle"). v0.44.0 crashed the game this way. */
static thread_local uint8_t *tl_blank_p = nullptr;
static thread_local size_t tl_blank_cap = 0;
/* Transparent replacement for `n` bytes of compressed data (same size, same format). Caller has checked there is no pixel buffer. */
static const uint8_t *blank_fill(GLenum fmt, size_t n) {          /* n bytes of transparent blocks in this thread's buffer, null = no */
    uint8_t blk[16];
    int bs = blank_block(fmt, blk);
    if (!bs || n == 0 || n > (8u << 20) || (n % (size_t)bs)) return nullptr;
    if (tl_blank_cap < n) {                            /* plain malloc: freed never (one buffer per thread, at most 8 MB) */
        uint8_t *nb = (uint8_t *)realloc(tl_blank_p, n);
        if (!nb) return nullptr;
        tl_blank_p = nb; tl_blank_cap = n;
    }
    for (size_t i = 0; i < n; i += (size_t)bs) memcpy(tl_blank_p + i, blk, (size_t)bs);
    return tl_blank_p;
}
static const void *grass_data(GLenum fmt, GLsizei n, const void *p) {
    if (n <= 0 || !p || !blank_block_size(fmt)) return p;
    if (unpack_pbo_bound()) { int c = ++g_grass_pbo; if (c == 1) L("GRASS cannot blank an upload that comes from a pixel buffer\n"); st_seti("grass_pbo", c); return p; }
    const uint8_t *b = blank_fill(fmt, (size_t)n);
    return b ? (const void *)b : p;
}
/* The game sent smaller mip levels before level 0 (texture streaming): they are already on the GPU. Once level 0 is known to be
   grass, send every smaller level again as transparent blocks. ETC2 only (4x4 blocks); ASTC textures keep their early mips. */
typedef void (*ctsi2_t)(GLenum, GLint, GLint, GLint, GLsizei, GLsizei, GLenum, GLsizei, const void *);
static void blank_early_mips(ctsi2_t fn, GLenum f, int w0, int h0, int levels) {
    if (!fn || f < 0x9276 || f > 0x9279 || levels < 2) return;
    int bs = (f <= 0x9277) ? 8 : 16, fixed = 0;
    for (int l = 1; l < levels && l < 14; l++) {
        int wl = std::max(1, w0 >> l), hl = std::max(1, h0 >> l);
        size_t n = (size_t)((wl + 3) / 4) * (size_t)((hl + 3) / 4) * (size_t)bs;
        const uint8_t *b = blank_fill(f, n);
        if (b) { fn(GL_TEXTURE_2D, l, 0, 0, wl, hl, f, (GLsizei)n, b); fixed++; }
    }
    int c = ++g_grass_early_fix; if (c <= 5) L("GRASS early mips blanked again (%d levels)\n", fixed);
}

/* ---------- v0.72 live texture memory estimate (diagnostics only) ----------
   Every glTexStorage2D adds the size of all its levels to a running total; glDeleteTextures takes it away again. Tells how much of
   the 4 GB the game's textures use right now, and how much dropping the top mip of every texture of 512 px or more would save. */
static std::atomic<uint32_t> g_tm_kb[MAXTEX];      /* KB of all levels, per texture id (0 = none) */
static std::atomic<uint32_t> g_tm_l0[MAXTEX];      /* KB of level 0 only */
static std::atomic<uint8_t> g_tm_c[MAXTEX];        /* size class 1..4 (1 = 1024 px or more, 2 = 512, 3 = 256, 4 = smaller) */
static std::atomic<uint8_t> g_tm_big[MAXTEX];      /* 1 = counts toward "top mip skip" (512 px or more and 2 or more levels) */
static std::atomic<long long> g_tm_tot{0}, g_tm_cls[5], g_tm_save{0};
static std::atomic<int> g_tm_n{0};
/* block size of a texture format: width, height in pixels and bytes per block (uncompressed formats: 1x1 and 4 bytes, an estimate) */
static void fmt_block(GLenum f, int &bw, int &bh, int &by) {
    bw = bh = 1; by = 4;
    if (f >= 0x9270 && f <= 0x9279) { bw = bh = 4; by = (f == 0x9272 || f == 0x9273 || f == 0x9278 || f == 0x9279) ? 16 : 8; return; }
    static const int AW[14] = {4, 5, 5, 6, 6, 8, 8, 8, 10, 10, 10, 10, 12, 12}, AH[14] = {4, 4, 5, 5, 6, 5, 6, 8, 5, 6, 8, 10, 10, 12};
    int k = -1;
    if (f >= 0x93b0 && f <= 0x93bd) k = (int)(f - 0x93b0); else if (f >= 0x93d0 && f <= 0x93dd) k = (int)(f - 0x93d0);
    if (k >= 0) { bw = AW[k]; bh = AH[k]; by = 16; }
}
static uint64_t tm_level_bytes(GLenum f, int w, int h) {
    int bw, bh, by; fmt_block(f, bw, bh, by);
    return (uint64_t)((w + bw - 1) / bw) * (uint64_t)((h + bh - 1) / bh) * (uint64_t)by;
}
static void tm_del(GLuint id) {
    if (id == 0 || id >= MAXTEX) return;
    uint32_t kb = g_tm_kb[id].exchange(0);
    if (!kb) return;
    uint32_t l0 = g_tm_l0[id].exchange(0);
    int c = g_tm_c[id].exchange(0);
    g_tm_tot -= kb; if (c >= 1 && c <= 4) g_tm_cls[c] -= kb;
    if (g_tm_big[id].exchange(0)) g_tm_save -= l0;
    g_tm_n--;
}
static void tm_add(GLuint id, GLsizei lv, GLenum f, GLsizei w, GLsizei h) {
    if (id == 0 || id >= MAXTEX || w <= 0 || h <= 0 || lv <= 0 || lv > 20) return;
    tm_del(id);
    uint64_t all = 0, l0 = 0;
    for (int l = 0; l < lv; l++) {
        uint64_t b = tm_level_bytes(f, std::max(1, (int)w >> l), std::max(1, (int)h >> l));
        all += b; if (l == 0) l0 = b;
    }
    uint32_t kb = (uint32_t)std::min<uint64_t>((all + 1023) / 1024, 0xFFFFFFFFu), k0 = (uint32_t)std::min<uint64_t>((l0 + 1023) / 1024, 0xFFFFFFFFu);
    int mx = std::max((int)w, (int)h), c = mx >= 1024 ? 1 : mx >= 512 ? 2 : mx >= 256 ? 3 : 4;
    g_tm_kb[id] = kb; g_tm_l0[id] = k0; g_tm_c[id] = (uint8_t)c;
    g_tm_tot += kb; g_tm_cls[c] += kb; g_tm_n++;
    if (mx >= 512 && lv >= 2) { g_tm_big[id] = 1; g_tm_save += k0; }
}

static void tex_post(GLenum t, GLsizei lv, GLenum fmt, GLsizei w, GLsizei h, bool revisit);
static void (*o_st)(GLenum, GLsizei, GLenum, GLsizei, GLsizei) = nullptr;
static void h_st(GLenum t, GLsizei lv, GLenum fmt, GLsizei w, GLsizei h) {
    if (auto f = orig_or(o_st, "glTexStorage2D", h_st)) f(t, lv, fmt, w, h);
    if (t == GL_TEXTURE_2D) tm_add(tl_bound[tl_unit], lv, fmt, w, h);
    tex_post(t, lv, fmt, w, h, false);
}
static void tex_post(GLenum t, GLsizei lv, GLenum fmt, GLsizei w, GLsizei h, bool revisit) {
    int b = g_bias.load(), k = g_blk.load();
    int mx = std::max(w, h);
    if (!revisit) grass_on_storage(t, lv, w, h, fmt);
    bool cand = (t == GL_TEXTURE_2D && lv >= 3 && mx >= 64 && is_cmp(fmt));
    if (!revisit && t == GL_TEXTURE_2D && mx >= 16) texn_log((int)w, (int)h, (int)lv, (int)fmt, cand);
    if (!cand) return;
    if (!revisit) g_cand++;
    bool skip = false;
    if (in_skip((int)fmt, (int)w, (int)h)) { skip = true; if (!revisit) g_sk_rule++; }
    else if (mx < g_minsz.load()) { skip = true; if (!revisit) g_sk_minsz++; }
    else if (g_alpha.load() && fmt_alpha(fmt)) {          /* v0.44: Keep alpha soft */
        skip = true;
        if (!revisit) { int c = ++g_alpha_kept; if (c <= 20 || c % 200 == 0) L("ALPHAKEEP #%d %dx%d lv=%d fmt=0x%x left soft\n", c, (int)w, (int)h, (int)lv, (unsigned)fmt); }
    }
    else if (g_astc.load() && fmt_astc(fmt)) {            /* v0.81: Keep ASTC soft (smoke, trees, light effects may use ASTC) */
        skip = true;
        if (!revisit) { int c = ++g_astc_kept; if (c <= 20 || c % 200 == 0) L("ASTCKEEP #%d %dx%d lv=%d fmt=0x%x left soft\n", c, (int)w, (int)h, (int)lv, (unsigned)fmt); }
    }
    int dl = g_delay.load();
    if (!skip && !revisit && dl > 0 && now_ns() - g_tstart.load() < (int64_t)dl * 1000000000LL) {
        skip = true; g_sk_delay++;
        defer_add(tl_bound[tl_unit], lv, fmt, w, h);       /* v0.38: come back to it after the delay */
    }
    if (!skip && revisit && g_orig_on.load()) { GLuint rid = tl_bound[tl_unit]; if (rid > 0 && rid < MAXTEX && g_blank[rid].load() == 4) skip = true; }   /* v0.61: Restore original */
    if (!skip && !revisit && tl_bound[tl_unit] == 0) g_nobound++;

    /* Test Tex: force NEAREST sampling only — full texture data, sharp pixel look. */
    int tt = g_testtex.load();
    if (tt > 0) {
        grp_note((int)fmt, mx, !skip);
        if (!skip && real_tp) {
            GLuint id = tl_bound[tl_unit];
            if (id > 0 && id < MAXTEX) {
                g_tf[id] = 1; g_tr[id] = 1; g_flagged++;
                GLint mn, mg; tt_filters(mn, mg);
                real_tp(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, mn);
                real_tp(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, mg);
                int sz = g_ttsize.load();
                if (sz == -1) {
                    /* Fine: never sample coarser than mip 3, so distant surfaces stay finer than Normal with less shimmer than Finer */
                    int cap = (int)lv - 1;
                    if (cap > 3) cap = 3;
                    if (cap < 0) cap = 0;
                    real_tp(GL_TEXTURE_2D, TEX_MAX_LEVEL, cap);
                } else if (sz > 0) {
                    /* bigger pixels: start from a coarser mip, keep at least 8 px */
                    int base = sz;
                    while (base > 0 && (mx >> base) < 8) base--;
                    if (base > (int)lv - 1) base = (int)lv - 1;
                    if (base > 0) real_tp(GL_TEXTURE_2D, GL_TEXTURE_BASE_LEVEL, base);
                }
            }
            int n = ++g_applied;
            if (n <= 100 || n % 500 == 0)
                L("TESTTEX #%d %dx%d lv=%d fmt=0x%x size=%d smooth=%d\n", n, w, h, lv, fmt, g_ttsize.load(), g_ttsm.load());
        }
        return;
    }

    /* v19 Flat Color: lock to tiny mips so the surface is near-solid color (lighting still applies). */
    int fl = g_flat.load();
    if (fl > 0) {
        /* v0.81: codes 1..8 → target remaining size ~8, 4, 2, 1 px (the old four) and 32, 16, 12, 6 px (the new four). The WebUI shows them in order of strength as 1..8. */
        static const int FTGT[] = {0, 8, 4, 2, 1, 32, 16, 12, 6};
        int tgt = FTGT[fl < 8 ? fl : 8];
        int base = 0;
        if (!skip && mx > tgt)
            while ((mx >> (base + 1)) >= tgt && base < (int)lv - 1) base++;
        grp_note((int)fmt, mx, base > 0);
        if (base > 0 && real_tp) {
            real_tp(GL_TEXTURE_2D, GL_TEXTURE_BASE_LEVEL, base);
            real_tp(GL_TEXTURE_2D, TEX_MAX_LEVEL, base);   /* lock: no higher mips */
            tr_mark();
            GLuint id = tl_bound[tl_unit];
            if (id > 0 && id < MAXTEX) {
                g_tf[id] = 1; g_tr[id] = 1; g_flagged++;
                real_tp(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
                real_tp(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
            }
            int n = ++g_applied;
            if (n <= 100 || n % 500 == 0)
                L("FLAT #%d %dx%d lv=%d fmt=0x%x base=%d tgt=%d\n", n, w, h, lv, fmt, base, tgt);
        }
        return;
    }

    int sty = g_style.load();
    if (sty > 0) {
        /* Detail Cut: raise min LOD only; original filters kept except optional sharp MAG */
        int lod = skip ? 0 : std::min(sty, (int)lv - 2);
        grp_note((int)fmt, mx, lod > 0);
        if (lod > 0 && real_tp) {
            real_tp(GL_TEXTURE_2D, TEX_MIN_LOD, lod);
            tr_mark();
            if (g_sedge.load()) {
                GLuint id = tl_bound[tl_unit];
                if (id > 0 && id < MAXTEX) {
                    g_tf[id] = 1; g_tr[id] = 1; g_flagged++;
                    real_tp(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
                }
            }
            int n = ++g_applied;
            if (n <= 100 || n % 500 == 0)
                L("STYLE #%d %dx%d lv=%d fmt=0x%x lod=%d edge=%d\n", n, w, h, lv, fmt, lod, g_sedge.load());
        }
        return;
    }
    int base = 0;
    if (!skip) {
        if (k > 0) {
            if (mx > k)
                while ((mx >> (base + 1)) >= k && base < (int)lv - 2) base++;
        } else if (b > 0 && lv >= 4 && mx >= 512) {
            base = std::min(b, (int)lv - 2);
        }
    }
    grp_note((int)fmt, mx, base > 0);
    if (base > 0 && real_tp) {
        real_tp(GL_TEXTURE_2D, GL_TEXTURE_BASE_LEVEL, base);
        tr_mark();
        if (g_near.load()) {
            GLuint id = tl_bound[tl_unit];
            if (id > 0 && id < MAXTEX) {
                g_tf[id] = 1; g_tr[id] = 1; g_flagged++;
                real_tp(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
                real_tp(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
            }
        }
        int n = ++g_applied;
        if (n <= 100 || n % 500 == 0)
            L("APPLIED #%d %dx%d lv=%d fmt=0x%x base=%d blk=%d\n", n, w, h, lv, fmt, base, k);
    }
}

/* Render thread, once per frame: process textures that were created during the start delay. */
static void revisit_pending() {
    if (g_pend_n.load() == 0) return;
    int dl = g_delay.load();
    if (dl > 0 && now_ns() - g_tstart.load() < (int64_t)dl * 1000000000LL) return;
    Pend batch[48]; int nb = 0;
    {
        std::lock_guard<std::mutex> lk(g_pm);
        while (nb < 48 && g_pend_i < g_pend.size()) { Pend p = g_pend[g_pend_i++]; if (p.id) batch[nb++] = p; }
        if (g_pend_i >= g_pend.size()) { g_pend.clear(); g_pend_i = 0; g_pend_n = 0; }
        else g_pend_n = (int)(g_pend.size() - g_pend_i);
    }
    if (!nb) return;
    typedef GLboolean (*is_t)(GLuint);
    typedef void (*giv_t)(GLenum, GLint *);
    static is_t is_tex = (is_t)real_sym("glIsTexture");
    static giv_t giv = (giv_t)real_sym("glGetIntegerv");
    auto bindf = orig_or(o_bind, "glBindTexture", h_bind);
    if (!is_tex || !giv || !bindf || !real_tp) { static int w = 0; if (!w++) L("REVISIT unavailable (is=%d giv=%d bind=%d tp=%d)\n", is_tex != nullptr, giv != nullptr, bindf != nullptr, real_tp != nullptr); return; }
    GLint prev = 0; giv(0x8069 /* GL_TEXTURE_BINDING_2D */, &prev);
    GLuint prev_tl = tl_bound[tl_unit];
    int done = 0;
    for (int i = 0; i < nb; i++) {
        if (!is_tex(batch[i].id)) continue;
        bindf(GL_TEXTURE_2D, batch[i].id);
        tl_bound[tl_unit] = batch[i].id;
        tl_revisit = true;
        tex_post(GL_TEXTURE_2D, batch[i].lv, batch[i].fmt, batch[i].w, batch[i].h, true);
        tl_revisit = false;
        done++;
    }
    bindf(GL_TEXTURE_2D, (GLuint)prev);
    tl_bound[tl_unit] = prev_tl;
    int tot = (g_revisited += done);
    static int logged = 0;
    if (logged++ < 10) L("REVISIT batch=%d done=%d total=%d pending=%d applied=%d\n", nb, done, tot, g_pend_n.load(), g_applied.load());
}

/* Plain-words reason why nothing was changed yet; "none" once at least one texture was applied. */
static std::string why0_reason() {
    if (g_applied.load() > 0) return "none";
    std::string r;
    auto add = [&](const std::string &x) { if (!r.empty()) r += ","; r += x; };
    if (g_hook_state.load() != 1) add("hook_not_active");
    if (!g_near.load() && !g_style.load() && !g_flat.load() && !g_testtex.load()) add("look_off");
    if (g_cand.load() == 0) add("no_candidates");
    if (g_sk_delay.load() > 0) add("delay(" + std::to_string(g_sk_delay.load()) + ")");
    if (g_sk_minsz.load() > 0) add("minsz(" + std::to_string(g_sk_minsz.load()) + ")");
    if (g_sk_rule.load() > 0) add("skip_rule(" + std::to_string(g_sk_rule.load()) + ")");
    if (g_alpha_kept.load() > 0) add("alpha_soft(" + std::to_string(g_alpha_kept.load()) + ")");
    if (g_astc_kept.load() > 0) add("astc_soft(" + std::to_string(g_astc_kept.load()) + ")");
    if (g_nobound.load() > 0) add("unbound(" + std::to_string(g_nobound.load()) + ")");
    return r.empty() ? "unknown" : r;
}

static void grp_dump(double t_s) {
    st_seti("cand", g_cand.load()); st_seti("applied", g_applied.load());
    st_seti("skip_rule", g_sk_rule.load()); st_seti("skip_minsz", g_sk_minsz.load());
    st_seti("skip_delay", g_sk_delay.load()); st_seti("alpha_kept", g_alpha_kept.load()); st_seti("grass_n", g_grass_n.load()); st_seti("grass_cand", g_grass_cand.load()); st_seti("grass_early", g_grass_early.load()); st_seti("grass_early_fix", g_grass_early_fix.load()); st_seti("revisited", g_revisited.load()); st_seti("ts3_cmp", g_n_ts3_cmp.load()); st_set("why0", why0_reason());
    L("TEXSKIP applied=%d cand=%d skip_rule=%d skip_minsz=%d skip_delay=%d unbound=%d revisited=%d pending=%d dropped=%d ts3=%d ts3cmp=%d cti2=%d\n", g_applied.load(), g_cand.load(), g_sk_rule.load(), g_sk_minsz.load(), g_sk_delay.load(), g_nobound.load(), g_revisited.load(), g_pend_n.load(), g_pend_drop.load(), g_n_ts3.load(), g_n_ts3_cmp.load(), g_n_cti2.load());
    Grp tmp[MAXG]; int n;
    { std::lock_guard<std::mutex> lk(g_gm); n = g_ng; for (int i = 0; i < n; i++) tmp[i] = g_grp[i]; g_gdirty = 0; }
    for (int i = 0; i < n; i++)
        L("TEXG t=%.0f fmt=%d hex=0x%x sz=%d n=%d ap=%d\n", t_s, tmp[i].fmt, tmp[i].fmt, tmp[i].sz, tmp[i].n, tmp[i].ap);
}

/* ---------- Frame-time logger and FPS cap ---------- */
static std::atomic<int> g_fps{0};          /* 0 = no cap (logging only) */
static std::atomic<pid_t> g_rt{0};         /* render thread (first thread to call eglSwapBuffers) */

static inline int64_t now_ns() {
    timespec ts; clock_gettime(CLOCK_MONOTONIC, &ts);
    return (int64_t)ts.tv_sec * 1000000000LL + ts.tv_nsec;
}

/* ---------- Freeze logger (diagnostics only, no effect on gameplay) ---------- */
/* fz.txt: 0 = off (no extra hooks installed), 1 = on (default) */
static std::atomic<int> g_fz{1};
static std::atomic<int64_t> g_t0{0};       /* time of the first rendered frame; log timestamps are relative to it */

enum { K_COMP, K_LINK, K_PBIN, K_BUF, K_TEX, K_N };
static std::atomic<int> c_cnt[2][K_N];     /* [0] = render thread, [1] = all other threads */
static std::atomic<int64_t> c_ns[2][K_N];

static thread_local pid_t tl_tid = 0;
static inline bool on_rt() {
    if (!tl_tid) tl_tid = (pid_t)syscall(SYS_gettid);
    return tl_tid == g_rt.load();
}

#define TIMED(K, call) do { \
    int64_t t0_ = now_ns(); call; int64_t d_ = now_ns() - t0_; \
    int i_ = on_rt() ? 0 : 1; c_cnt[i_][K]++; c_ns[i_][K] += d_; } while (0)

static void (*o_comp)(GLuint) = nullptr;
static void h_comp(GLuint s) { auto fn_ = orig_or(o_comp, "glCompileShader", h_comp); if (!fn_) return; TIMED(K_COMP, fn_(s)); }

static void (*o_link)(GLuint) = nullptr;
static void h_link(GLuint p) { auto fn_ = orig_or(o_link, "glLinkProgram", h_link); if (!fn_) return; TIMED(K_LINK, fn_(p)); }

static void (*o_pbin)(GLuint, GLenum, const void *, GLsizei) = nullptr;
static void h_pbin(GLuint p, GLenum f, const void *b, GLsizei n) {
    auto fn_ = orig_or(o_pbin, "glProgramBinary", h_pbin); if (!fn_) return; TIMED(K_PBIN, fn_(p, f, b, n));
}

static void (*o_buf)(GLenum, GLsizeiptr, const void *, GLenum) = nullptr;
static void h_buf(GLenum t, GLsizeiptr sz, const void *d, GLenum u) {
    auto fn_ = orig_or(o_buf, "glBufferData", h_buf); if (!fn_) return; TIMED(K_BUF, fn_(t, sz, d, u));
}

static void (*o_ti2)(GLenum, GLint, GLint, GLsizei, GLsizei, GLint, GLenum, GLenum, const void *) = nullptr;
static void h_ti2(GLenum t, GLint l, GLint ifmt, GLsizei w, GLsizei h, GLint b, GLenum f, GLenum ty, const void *p) {
    auto fn_ = orig_or(o_ti2, "glTexImage2D", h_ti2); if (!fn_) return; TIMED(K_TEX, fn_(t, l, ifmt, w, h, b, f, ty, p));
}

/* ---------- v0.71 upload accounting (diagnostics) ---------- */
static std::atomic<long long> c_ubytes[2];            /* compressed upload bytes since the last frame: [0] render thread, [1] other threads */
static std::atomic<int> c_ucnt[2];
static std::atomic<int> c_umax{0}, c_ufmt{0}, c_uw{0}, c_uh{0};   /* biggest single upload on the render thread */
static inline void upl_note(GLenum f, GLsizei w, GLsizei h, GLsizei n) {
    if (n <= 0) return;
    int i = on_rt() ? 0 : 1;
    c_ubytes[i] += n; c_ucnt[i]++;
    if (i == 0 && n > c_umax.load()) { c_umax = n; c_ufmt = (int)f; c_uw = w; c_uh = h; }
}

/* ---------- v0.71 upload spreading (EXPERIMENTAL, spread.txt = KB per frame, 0 / missing = OFF) ----------
   Big glCompressedTexSubImage2D calls on the render thread beyond the per-frame budget are copied into a queue and replayed
   from eglSwapBuffers, a little each frame. Order per texture is kept (once a texture has queued uploads, all its later uploads
   queue too). Until its upload is replayed a texture shows the game's empty / old content. Never touches uploads from a pixel
   buffer (PBO), small uploads (< 64 KB) or uploads from other threads. */
static std::atomic<int> g_spread_kb{0};
struct SpItem { GLuint id; GLenum f; GLint l, x, y; GLsizei w, h, n; uint8_t *d; int64_t fr; bool dead; };
static std::mutex g_spmu;
static std::deque<SpItem> g_spq;
static std::unordered_map<GLuint, int> g_sppend;      /* texture id -> queued uploads */
static long long g_sp_qbytes = 0;                      /* guarded by g_spmu */
static long long g_sp_used = 0;                        /* render thread only: bytes uploaded or replayed in this frame */
static int64_t g_sp_frame = 0;
static std::atomic<long long> g_sp_nd{0}, g_sp_bd{0}, g_sp_nr{0}, g_sp_flush{0}, g_sp_maxq{0}, g_sp_maxage{0}, g_sp_pbo{0}, g_sp_lost{0};
static const GLsizei SP_MIN = 64 * 1024;
static const long long SP_QCAP = 96LL << 20;
static void sp_flush_all();
static void live_poll(int64_t t);     /* v0.76 */
static void lv_apply();
static GLboolean (*g_sp_is_hook)(GLuint) = nullptr;           /* host tests only */
static void (*g_sp_bb_hook)(GLenum, GLuint) = nullptr;         /* host tests only */

static bool sp_try_defer(GLuint id, GLint l, GLint x, GLint y, GLsizei w, GLsizei h, GLenum f, GLsizei n, const void *p) {
    if (id == 0 || id >= MAXTEX || !p || n <= 0 || n > (16 << 20)) { g_sp_used += n > 0 ? n : 0; return false; }
    long long budget = (long long)g_spread_kb.load() * 1024;
    bool has; long long qb;
    { std::lock_guard<std::mutex> lk(g_spmu); has = g_sppend.count(id) != 0; qb = g_sp_qbytes; }
    if (qb + n > SP_QCAP) { g_sp_flush++; sp_flush_all(); has = false; }
    bool over = n >= SP_MIN && g_sp_used > 0 && g_sp_used + n > budget;
    if (!has && !over) { g_sp_used += n; return false; }
    if (unpack_pbo_bound()) {                          /* data pointer is an offset: never copy it */
        g_sp_pbo++;
        if (has) sp_flush_all();                       /* keep the order for this texture */
        g_sp_used += n; return false;
    }
    uint8_t *d = (uint8_t *)malloc((size_t)n);
    if (!d) { if (has) sp_flush_all(); g_sp_used += n; return false; }
    memcpy(d, p, (size_t)n);
    {
        std::lock_guard<std::mutex> lk(g_spmu);
        g_spq.push_back(SpItem{id, f, l, x, y, w, h, n, d, g_sp_frame, false});
        g_sppend[id]++;
        g_sp_qbytes += n;
        if (g_sp_qbytes > g_sp_maxq.load()) g_sp_maxq = g_sp_qbytes;
    }
    g_sp_nd++; g_sp_bd += n;
    return true;
}
static void sp_drop(GLuint id) {
    if (id == 0 || id >= MAXTEX || g_spread_kb.load() <= 0) return;
    std::lock_guard<std::mutex> lk(g_spmu);
    auto it = g_sppend.find(id);
    if (it == g_sppend.end()) return;
    for (SpItem &q : g_spq) if (q.id == id) q.dead = true;
    g_sppend.erase(it);
}

static void (*o_cti2)(GLenum, GLint, GLenum, GLsizei, GLsizei, GLint, GLsizei, const void *) = nullptr;
static void h_cti2(GLenum t, GLint l, GLenum f, GLsizei w, GLsizei h, GLint b, GLsizei n, const void *p) {
    if (l == 0) g_n_cti2++;
    upl_note(f, w, h, n);
    if (g_spread_kb.load() > 0 && t == GL_TEXTURE_2D && tl_bound[tl_unit] > 0 && on_rt()) {   /* a re-specified texture must not be overtaken by its own queued uploads */
        bool q; { std::lock_guard<std::mutex> lk(g_spmu); q = g_sppend.count(tl_bound[tl_unit]) != 0; }
        if (q) sp_flush_all();
    }
    auto fn_ = orig_or(o_cti2, "glCompressedTexImage2D", h_cti2); if (!fn_) return;
    if (g_lv_cap.load() && p && t == GL_TEXTURE_2D && l >= 0 && l < 14) lv_capture(tl_bound[tl_unit], l, 0, 0, w, h, f, n, p);   /* v0.76: copy of the ORIGINAL data */
    if (p && t == GL_TEXTURE_2D && l >= 0 && l < 14) {                           /* v0.45 Remove grass (texture made without glTexStorage2D) */
        GLuint id = tl_bound[tl_unit];
        if (l == 0) { if (id > 0 && id < MAXTEX) g_lv[id] = 0; grass_level0(id, f, (int)w, (int)h, (int)n, p); }
        if (g_grass_on.load() && id > 0 && id < MAXTEX) {
            if (l > 0 && g_blank[id].load() == 0) g_grass_early++;
            if (g_blank[id].load() == 1) p = grass_data(f, n, p);
        }
    }
    TIMED(K_TEX, fn_(t, l, f, w, h, b, n, p));
}

static void (*o_tsi2)(GLenum, GLint, GLint, GLint, GLsizei, GLsizei, GLenum, GLenum, const void *) = nullptr;
static void h_tsi2(GLenum t, GLint l, GLint x, GLint y, GLsizei w, GLsizei h, GLenum f, GLenum ty, const void *p) {
    auto fn_ = orig_or(o_tsi2, "glTexSubImage2D", h_tsi2); if (!fn_) return; TIMED(K_TEX, fn_(t, l, x, y, w, h, f, ty, p));
}

static void (*o_ctsi2)(GLenum, GLint, GLint, GLint, GLsizei, GLsizei, GLenum, GLsizei, const void *) = nullptr;
static void h_ctsi2(GLenum t, GLint l, GLint x, GLint y, GLsizei w, GLsizei h, GLenum f, GLsizei n, const void *p) {
    auto fn_ = orig_or(o_ctsi2, "glCompressedTexSubImage2D", h_ctsi2); if (!fn_) return;
    if (g_lv_cap.load() && p && t == GL_TEXTURE_2D && l >= 0 && l < 14) lv_capture(tl_bound[tl_unit], l, x, y, w, h, f, n, p);   /* v0.76 */
    if (p && t == GL_TEXTURE_2D) {                                                /* v0.45 Remove grass */
        GLuint id = tl_bound[tl_unit];
        int dec = 0;
        if (l == 0 && x == 0 && y == 0) dec = grass_level0(id, f, (int)w, (int)h, (int)n, p);
        if (g_grass_on.load() && id > 0 && id < MAXTEX) {
            if (l > 0 && g_blank[id].load() == 0 && blank_block_size(f)) { g_grass_early++; g_blank[id] = 3; }   /* 3 = a mip came before level 0 */
            if (dec == 2 && g_lv[id].load() > 1) blank_early_mips(fn_, f, (int)w, (int)h, (int)g_lv[id].load());
            if (g_blank[id].load() == 1) p = grass_data(f, n, p);
        }
    }
    upl_note(f, w, h, n);
    if (p && t == GL_TEXTURE_2D && g_spread_kb.load() > 0 && on_rt() && sp_try_defer(tl_bound[tl_unit], l, x, y, w, h, f, n, p)) return;   /* v0.71: replayed from eglSwapBuffers */
    TIMED(K_TEX, fn_(t, l, x, y, w, h, f, n, p));
}

/* v0.71: replay queued uploads on the render thread (inside eglSwapBuffers, GL context current). max_bytes = this frame's budget; all = drain everything. */
static void sp_replay(long long max_bytes, bool all) {
    typedef void (*giv_t)(GLenum, GLint *);
    typedef GLboolean (*is_t)(GLuint);
    typedef void (*bb_t)(GLenum, GLuint);
    static giv_t giv_r = (giv_t)real_sym("glGetIntegerv");
    static is_t is_r = (is_t)real_sym("glIsTexture");
    static bb_t bb_r = (bb_t)real_sym("glBindBuffer");
    giv_t giv = g_giv_hook ? g_giv_hook : giv_r;                 /* the three hooks are for host tests only */
    is_t is_tex = g_sp_is_hook ? g_sp_is_hook : is_r;
    bb_t bindbuf = g_sp_bb_hook ? g_sp_bb_hook : bb_r;
    { std::lock_guard<std::mutex> lk(g_spmu); if (g_spq.empty()) return; }
    auto bindf = orig_or(o_bind, "glBindTexture", h_bind);
    auto subf = orig_or(o_ctsi2, "glCompressedTexSubImage2D", h_ctsi2);
    GLint prev_tex = 0, prev_pbo = 0;
    if (giv && is_tex && bindbuf && bindf && subf) { giv(0x8069 /* GL_TEXTURE_BINDING_2D */, &prev_tex); giv(0x88EF /* GL_PIXEL_UNPACK_BUFFER_BINDING */, &prev_pbo); }
    else {
        static int w = 0; if (!w++) L("SPREAD cannot replay (giv=%d is=%d bb=%d bind=%d sub=%d): queued uploads are dropped\n", giv != nullptr, is_tex != nullptr, bindbuf != nullptr, bindf != nullptr, subf != nullptr);
    }
    bool ok = giv && is_tex && bindbuf && bindf && subf;
    if (ok && prev_pbo) bindbuf(0x88EC /* GL_PIXEL_UNPACK_BUFFER */, 0);
    long long done_b = 0; GLuint cur = (GLuint)prev_tex;
    for (;;) {
        SpItem it;
        {
            std::lock_guard<std::mutex> lk(g_spmu);
            if (g_spq.empty()) break;
            if (!all && done_b >= max_bytes) break;
            it = g_spq.front(); g_spq.pop_front();
            g_sp_qbytes -= it.n;
            if (!it.dead) { auto f = g_sppend.find(it.id); if (f != g_sppend.end() && --f->second <= 0) g_sppend.erase(f); }
        }
        if (!it.dead && ok && is_tex(it.id)) {
            if (cur != it.id) { bindf(GL_TEXTURE_2D, it.id); cur = it.id; }
            subf(GL_TEXTURE_2D, it.l, it.x, it.y, it.w, it.h, it.f, it.n, it.d);
            done_b += it.n; g_sp_nr++;
            long long age = g_sp_frame - it.fr; if (age > g_sp_maxage.load()) g_sp_maxage = age;
        } else if (!it.dead) g_sp_lost++;
        free(it.d);
    }
    if (ok && cur != (GLuint)prev_tex) bindf(GL_TEXTURE_2D, (GLuint)prev_tex);
    if (ok && prev_pbo) bindbuf(0x88EC, (GLuint)prev_pbo);
    g_sp_used += done_b;
}
static void sp_flush_all() { sp_replay(0, true); }

/* ---------- v0.76: live test ----------
   Only active when live.txt = 1 (set by the WebUI; the module never creates it). Three things, all small:
   1. MARK: the WebUI writes mark.txt; this module logs "MARK <label> t=.. cand=.. lvtex=.." itself (so the log order and the time are exact).
      Label A opens the CAPTURE window (a copy of every compressed upload is kept, at most LV_MAX_TEX textures / LV_MAX_BYTES), B closes it, X closes it and frees the copies.
   2. LIVE commands: the WebUI writes livecmd.txt ("h <hash>" hide, "u <hash>" show again, "r <hash>" put the texture parameters back). Done on the render thread
      inside eglSwapBuffers (same save / restore of the GL bindings as the v0.71 replay), only for textures that were captured.
   3. The rule files hidden.txt / orig.txt are read again when they change, so textures loaded from then on follow the new rules.
   mark.txt, livecmd.txt, hidden.txt and orig.txt are looked at once a second (stat). Nothing is read or changed in the game when live mode is off. */
#define LV_MAX_TEX 160
#define LV_MAX_BYTES (64LL << 20)
struct LvLev { int l, x, y, w, h; GLenum f; int n; uint8_t *d; };
struct LvTex { GLuint id; int fmt, w, h; uint64_t hash; bool has0; int state; std::vector<LvLev> lv; };   /* state 0 = original on the GPU, 1 = hidden by a live command */
struct LvCmd { char op; uint64_t hash; };
static std::mutex g_lvmu;
static std::vector<LvTex> g_lvt;
static long long g_lv_bytes = 0;
static std::vector<LvCmd> g_lv_cmd;
static std::atomic<int> g_lv_full{0};
static std::atomic<int64_t> g_lv_last{0};
static void lv_free_entry(LvTex &e) { for (auto &v : e.lv) { g_lv_bytes -= v.n; free(v.d); } e.lv.clear(); }
static void lv_clear_locked() { for (auto &e : g_lvt) lv_free_entry(e); g_lvt.clear(); g_lv_bytes = 0; }
struct LvMeta { int fmt, w, h; uint64_t hash; };
static std::unordered_map<GLuint, LvMeta> g_lvm;      /* v0.78: texture id -> what it is (guarded by g_lvmu). A few bytes per texture. */
static void lv_meta_note(GLuint id, GLenum f, int w, int h, uint64_t hh) {
    std::lock_guard<std::mutex> lk(g_lvmu);
    if (g_lvm.size() > 20000 && !g_lvm.count(id)) return;
    g_lvm[id] = LvMeta{(int)f, w, h, hh};
}
/* v0.79: GPU backup of a texture that is hidden from the menu. The original picture is copied (GPU to GPU, glCopyImageSubData) into a
   second texture before it is blanked, and copied back by Show. No CPU copy, no Mark A needed; costs GPU memory only for textures that are
   hidden right now, limited by LV_BK_CAP and by the free memory of the phone (past that, Hide still works but Show needs a restart). */
struct LvBk { GLuint tex; int levels; long long bytes; int w[14], h[14]; };
static std::unordered_map<GLuint, LvBk> g_lvbk;
static std::vector<GLuint> g_lv_bkdel;            /* backup textures to delete on the render thread */
static long long g_lv_bkbytes = 0;
static const long long LV_BK_CAP = 256LL << 20;
static long long (*g_lv_mem_hook)() = nullptr;    /* host tests only */
static int g_lv_budget_ms = 6;                    /* time one frame may spend on live commands (host tests change it) */
struct LvGl {
    void (*gen)(GLsizei, GLuint *); void (*del)(GLsizei, const GLuint *); void (*stor)(GLenum, GLsizei, GLenum, GLsizei, GLsizei);
    void (*cp)(GLuint, GLenum, GLint, GLint, GLint, GLint, GLuint, GLenum, GLint, GLint, GLint, GLint, GLsizei, GLsizei, GLsizei);
    void (*lvp)(GLenum, GLint, GLenum, GLint *); GLenum (*err)();
};
static LvGl g_lvgl_hook; static bool g_lvgl_hooked = false;   /* host tests only */
static long long lv_memavail_kb() {
    if (g_lv_mem_hook) return g_lv_mem_hook();
    FILE *f = fopen("/proc/meminfo", "r"); if (!f) return -1;
    char ln[128]; long long kb = -1;
    while (fgets(ln, sizeof ln, f)) if (!strncmp(ln, "MemAvailable:", 13)) { kb = atoll(ln + 13); break; }
    fclose(f); return kb;
}
static void lv_drop(GLuint id) {
    std::lock_guard<std::mutex> lk(g_lvmu);
    g_lvm.erase(id);
    { auto b = g_lvbk.find(id); if (b != g_lvbk.end()) { g_lv_bkdel.push_back(b->second.tex); g_lv_bkbytes -= b->second.bytes; g_lvbk.erase(b); } }
    for (size_t i = 0; i < g_lvt.size(); i++) if (g_lvt[i].id == id) { lv_free_entry(g_lvt[i]); g_lvt.erase(g_lvt.begin() + i); return; }
}
static void lv_capture(GLuint id, GLint l, GLint x, GLint y, GLsizei w, GLsizei h, GLenum f, GLsizei n, const void *p) {
    if (id == 0 || id >= MAXTEX || !p || n < 16 || n > (8 << 20) || !is_cmp(f)) return;
    if (unpack_pbo_bound()) return;
    uint64_t hh = (l == 0 && x == 0 && y == 0) ? tex_hash(p, n) : 0;
    std::lock_guard<std::mutex> lk(g_lvmu);
    LvTex *e = nullptr;
    for (auto &t : g_lvt) if (t.id == id) { e = &t; break; }
    if (e && l == 0 && x == 0 && y == 0 && e->has0) { lv_free_entry(*e); e->has0 = false; e->state = 0; }   /* level 0 sent again: a new picture for this texture */
    if (!e) {
        if ((int)g_lvt.size() >= LV_MAX_TEX) { if (++g_lv_full == 1) L("LIVE capture is full (%d textures): later ones are not kept\n", LV_MAX_TEX); return; }
        g_lvt.push_back(LvTex{id, (int)f, (int)w, (int)h, 0, false, 0, {}});
        e = &g_lvt.back();
    }
    if (g_lv_bytes + n > LV_MAX_BYTES) { if (++g_lv_full == 1) L("LIVE capture is full (%lld MB): later data is not kept\n", LV_MAX_BYTES >> 20); return; }
    uint8_t *d = (uint8_t *)malloc((size_t)n);
    if (!d) return;
    memcpy(d, p, (size_t)n);
    e->lv.push_back(LvLev{(int)l, (int)x, (int)y, (int)w, (int)h, f, (int)n, d});
    g_lv_bytes += n;
    if (l == 0 && x == 0 && y == 0) { e->fmt = (int)f; e->w = (int)w; e->h = (int)h; e->hash = hh; e->has0 = true; }
}
static void lv_status() {
    int n = 0, h0 = 0, nm = 0; long long kb;
    { std::lock_guard<std::mutex> lk(g_lvmu); nm = (int)g_lvm.size(); n = (int)g_lvt.size(); for (auto &e : g_lvt) if (e.has0) h0++; kb = g_lv_bytes >> 10; }
    st_seti("lv_tex", n); st_seti("lv_meta", nm); st_seti("lv_hash", h0); { std::lock_guard<std::mutex> lk2(g_lvmu); st_seti("lv_bk", (int)g_lvbk.size()); st_seti("lv_bkmb", (int)(g_lv_bkbytes >> 20)); st_seti("lv_pend", (int)g_lv_cmd.size()); } st_seti("lv_kb", kb); st_seti("lv_cap", g_lv_cap.load());
}
static bool lv_hex(const char *s, uint64_t *out) {
    if (!s || !*s) return false;
    uint64_t v = 0; int n = 0;
    for (; *s && *s != ' ' && *s != '\n' && *s != '\r' && *s != '\t'; s++, n++) {
        int d = (*s >= '0' && *s <= '9') ? *s - '0' : (*s >= 'a' && *s <= 'f') ? *s - 'a' + 10 : (*s >= 'A' && *s <= 'F') ? *s - 'A' + 10 : -1;
        if (d < 0 || n >= 16) return false;
        v = (v << 4) | (uint64_t)d;
    }
    *out = v; return n > 0;
}
static void lv_do_mark(int64_t t) {
    char lab[16] = "?";
    if (FILE *f = fopen(MARKF, "r")) {
        char ln[64] = {0};
        if (fgets(ln, sizeof ln, f)) { int k = 0; for (const char *q = ln; *q && k < 12 && ((*q >= '0' && *q <= '9') || (*q >= 'A' && *q <= 'Z') || (*q >= 'a' && *q <= 'z') || *q == '_'); q++) lab[k++] = *q; lab[k] = 0; if (!k) strcpy(lab, "?"); }
        fclose(f);
    }
    g_lv_last = t;
    if (!strcmp(lab, "A")) { std::lock_guard<std::mutex> lk(g_lvmu); lv_clear_locked(); g_lv_full = 0; g_lv_cap = 1; }
    else if (!strcmp(lab, "B")) g_lv_cap = 0;
    else if (!strcmp(lab, "X")) { g_lv_cap = 0; std::lock_guard<std::mutex> lk(g_lvmu); lv_clear_locked(); }
    int nc, nr; { std::lock_guard<std::mutex> lk(g_cmu); nc = std::min(g_cseen_n, 4096); nr = std::min(g_rseen_n, 4096); }
    L("MARK %s t=%.1f cand=%d rcand=%d\n", lab, (t - g_t0.load()) / 1e9, nc, nr);
    lv_status();
}
static void lv_do_cmd(int64_t t) {
    std::vector<LvCmd> got;
    if (FILE *f = fopen(LIVECF, "r")) {
        char ln[96];
        while (fgets(ln, sizeof ln, f) && got.size() < 8192) {
            if ((ln[0] != 'h' && ln[0] != 'u' && ln[0] != 'r' && ln[0] != 'f') || ln[1] != ' ') continue;
            uint64_t hv; if (!lv_hex(ln + 2, &hv)) continue;
            got.push_back(LvCmd{ln[0], hv});
        }
        fclose(f);
    }
    g_lv_last = t;
    { std::lock_guard<std::mutex> lk(g_lvmu); if (g_lv_cmd.size() + got.size() > 16384) g_lv_cmd.clear(); g_lv_cmd.insert(g_lv_cmd.end(), got.begin(), got.end()); }   /* v0.79: appended, so nothing queued is lost; applied a few per frame */
}
/* the rule files changed: read them again (same parser as the start; no per-line log spam) */
static void rules_read(const char *path, const char *alt, int maxr, std::vector<GrRule> &out) {
    FILE *f = fopen(path, "r");
    if (!f && alt) f = fopen(alt, "r");
    if (!f) return;
    std::set<std::tuple<int, int, int, uint64_t>> have;
    char ln[256];
    while (fgets(ln, sizeof ln, f)) {
        if (!strchr(ln, '\n') && !feof(f)) { int ch; while ((ch = fgetc(f)) != EOF && ch != '\n') {} continue; }
        for (char *q = ln + strlen(ln); q > ln && (q[-1] == '\n' || q[-1] == '\r'); ) *--q = 0;
        GrRule r{0, 0, 0, 0};
        if (grass_parse_line(ln, &r) != GRL_RULE) continue;
        if (!have.insert(std::make_tuple(r.fmt, r.w, r.h, r.hash)).second) continue;
        if ((int)out.size() >= maxr) break;
        out.push_back(r);
    }
    fclose(f);
}
static void rules_reload() {
    std::vector<GrRule> a, b;
    rules_read(GRASSF, GRASSOLDF, GRASS_MAX_RULES, a);
    rules_read(ORIGF, nullptr, ORIG_MAX_RULES, b);
    std::sort(a.begin(), a.end(), grass_rule_less);
    std::sort(b.begin(), b.end(), grass_rule_less);
    { std::lock_guard<std::mutex> lk(g_rmu); g_grass.swap(a); g_orig.swap(b); }
    g_grass_on = g_grass.empty() ? 0 : 1;
    g_orig_on = g_orig.empty() ? 0 : 1;
    L("RULES reloaded while playing: hide=%d restore=%d (textures loaded from now on follow them)\n", (int)g_grass.size(), (int)g_orig.size());
    st_seti("grass_rules", (long long)g_grass.size()); st_seti("orig_rules", (long long)g_orig.size());
}
static int64_t lv_mtime(const char *p) { struct stat sb; if (stat(p, &sb) != 0) return 0; return (int64_t)sb.st_mtim.tv_sec * 1000000000LL + (int64_t)sb.st_mtim.tv_nsec; }
static int64_t g_lvp_next = 0, g_lvp_mark = -1, g_lvp_cmd = -1, g_lvp_hid = -1, g_lvp_org = -1;
static void live_poll(int64_t t) {
    if (t < g_lvp_next) return;
    g_lvp_next = t + 1000000000LL;
    int64_t a = lv_mtime(MARKF), b = lv_mtime(LIVECF), c = lv_mtime(GRASSF), d = lv_mtime(ORIGF);
    if (g_lvp_mark == -1) { g_lvp_mark = a; g_lvp_cmd = b; g_lvp_hid = c; g_lvp_org = d; lv_status(); return; }   /* first look: what is there now is not a change */
    if (a != g_lvp_mark) { g_lvp_mark = a; lv_do_mark(t); }
    if (b != g_lvp_cmd) { g_lvp_cmd = b; lv_do_cmd(t); }
    if (c != g_lvp_hid || d != g_lvp_org) { g_lvp_hid = c; g_lvp_org = d; rules_reload(); }
    if (g_lv_last.load() && t - g_lv_last.load() > 1200LL * 1000000000LL) {       /* 20 minutes without a mark or a command: give the memory back */
        g_lv_cap = 0; { std::lock_guard<std::mutex> lk(g_lvmu); lv_clear_locked(); } g_lv_last = 0; L("LIVE copies freed (20 minutes without use)\n"); lv_status();
    }
}
static void lv_apply() {
    std::vector<LvCmd> cmds;
    std::vector<GLuint> bkdel;
    { std::lock_guard<std::mutex> lk(g_lvmu); bkdel.swap(g_lv_bkdel); if (g_lv_cmd.empty() && bkdel.empty()) return; cmds.swap(g_lv_cmd); }
    typedef void (*giv_t)(GLenum, GLint *);
    typedef GLboolean (*is_t)(GLuint);
    typedef void (*bb_t)(GLenum, GLuint);
    static giv_t giv_r = (giv_t)real_sym("glGetIntegerv");
    static is_t is_r = (is_t)real_sym("glIsTexture");
    static bb_t bb_r = (bb_t)real_sym("glBindBuffer");
    static LvGl real_gl = {(void (*)(GLsizei, GLuint *))real_sym("glGenTextures"), (void (*)(GLsizei, const GLuint *))real_sym("glDeleteTextures"),
        (void (*)(GLenum, GLsizei, GLenum, GLsizei, GLsizei))real_sym("glTexStorage2D"),
        (void (*)(GLuint, GLenum, GLint, GLint, GLint, GLint, GLuint, GLenum, GLint, GLint, GLint, GLint, GLsizei, GLsizei, GLsizei))real_sym("glCopyImageSubData"),
        (void (*)(GLenum, GLint, GLenum, GLint *))real_sym("glGetTexLevelParameteriv"), (GLenum (*)())real_sym("glGetError")};
    const LvGl &gl = g_lvgl_hooked ? g_lvgl_hook : real_gl;
    giv_t giv = g_giv_hook ? g_giv_hook : giv_r;
    is_t is_tex = g_sp_is_hook ? g_sp_is_hook : is_r;
    bb_t bindbuf = g_sp_bb_hook ? g_sp_bb_hook : bb_r;
    auto bindf = orig_or(o_bind, "glBindTexture", h_bind);
    auto subf = orig_or(o_ctsi2, "glCompressedTexSubImage2D", h_ctsi2);
    if (!bkdel.empty() && gl.del) gl.del((GLsizei)bkdel.size(), bkdel.data());
    if (cmds.empty()) return;
    if (!giv || !is_tex || !bindbuf || !bindf || !subf) { L("LIVE cannot apply (giv=%d is=%d bb=%d bind=%d sub=%d)\n", giv != nullptr, is_tex != nullptr, bb_r != nullptr, bindf != nullptr, subf != nullptr); st_set("lv_last", "cannot apply"); return; }
    GLint prev_tex = 0, prev_pbo = 0;
    giv(0x8069 /* GL_TEXTURE_BINDING_2D */, &prev_tex); giv(0x88EF /* GL_PIXEL_UNPACK_BUFFER_BINDING */, &prev_pbo);
    if (prev_pbo) bindbuf(0x88EC /* GL_PIXEL_UNPACK_BUFFER */, 0);
    GLuint cur = (GLuint)prev_tex;
    static int nh = 0, nu = 0, nr = 0, nf = 0, miss = 0, nofmt = 0, nometa = 0, nocopy = 0, nbk = 0, nobk = 0, ncmd = 0, nbad = 0;   /* totals of one burst of commands (many frames) */
    auto restore_params = [&](GLuint id) {
        if (!real_tp || id >= MAXTEX) return;
        uint16_t mn = g_omin[id].load(), mg = g_omag[id].load();
        real_tp(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, mn ? (GLint)mn : 0x2702);
        real_tp(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, mg ? (GLint)mg : 0x2601);
        real_tp(GL_TEXTURE_2D, GL_TEXTURE_BASE_LEVEL, 0);
        real_tp(GL_TEXTURE_2D, TEX_MAX_LEVEL, 1000);
        real_tp(GL_TEXTURE_2D, TEX_MIN_LOD, -1000);
        restore_aniso(id);                         /* v0.81 */
        g_tf[id] = 0; g_tr[id] = 0;
    };
    auto look_on = [&](GLuint id, int fmt, int w, int h, int lvn) {   /* v0.81: Look on = Restore undone; the texture gets the look again (same rules as at load) */
        if (id == 0 || id >= MAXTEX || lvn < 1) return;
        GLuint keep = tl_bound[tl_unit];
        tl_bound[tl_unit] = id;
        if (g_blank[id].load() == 4) g_blank[id] = 2;
        g_tf[id] = 0; g_tr[id] = 0;
        tex_post(GL_TEXTURE_2D, (GLsizei)lvn, (GLenum)fmt, (GLsizei)w, (GLsizei)h, true);
        tl_bound[tl_unit] = keep;
    };
    auto drain = [&]() -> bool { bool bad = false; if (gl.err) for (int q = 0; q < 6; q++) { if (gl.err() != 0) bad = true; else break; } return bad; };
    auto drop_bk = [&](GLuint id) {                                  /* delete the backup of a texture (render thread) */
        auto it = g_lvbk.find(id); if (it == g_lvbk.end()) return;
        if (gl.del) gl.del(1, &it->second.tex);
        g_lv_bkbytes -= it->second.bytes; g_lvbk.erase(it);
    };
    size_t k = 0;
    {
        std::lock_guard<std::mutex> lk(g_lvmu);
        std::unordered_multimap<uint64_t, GLuint> idx;               /* hash -> texture ids, built once per frame */
        idx.reserve(g_lvm.size());
        for (auto &kv : g_lvm) idx.emplace(kv.second.hash, kv.first);
        long long memkb = lv_memavail_kb();
        auto t0 = std::chrono::steady_clock::now();
        for (; k < cmds.size(); k++) {
            if (k > 0 && std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::steady_clock::now() - t0).count() >= g_lv_budget_ms) break;
            LvCmd &c = cmds[k];
            ncmd++;
            bool found = false;
            std::vector<GLuint> done;                                  /* ids handled through a kept copy */
            bool no_copy = false;
            for (auto &e : g_lvt) {
                if (!e.has0 || e.hash != c.hash || !is_tex(e.id)) continue;
                found = true; done.push_back(e.id);
                if (cur != e.id) { bindf(GL_TEXTURE_2D, e.id); cur = e.id; }
                if (c.op == 'r') {
                    restore_params(e.id);
                    nr++;
                } else if (c.op == 'f') {
                    look_on(e.id, e.fmt, e.w, e.h, (int)e.lv.size());
                    nf++;
                } else {
                    for (auto &v : e.lv) {
                        if (c.op == 'h') { const uint8_t *b = blank_fill(v.f, (size_t)v.n); if (b) subf(GL_TEXTURE_2D, v.l, v.x, v.y, v.w, v.h, v.f, v.n, b); else nofmt++; }
                        else subf(GL_TEXTURE_2D, v.l, v.x, v.y, v.w, v.h, v.f, v.n, v.d);
                    }
                    e.state = (c.op == 'h') ? 1 : 0;
                    if (c.op == 'h') nh++; else { nu++; drop_bk(e.id); }
                }
            }
            /* textures that were loaded without a kept copy (v0.78): Hide needs only the format and the size; since v0.79 the original is first
               copied on the GPU into a backup texture, so Show can bring it back. Without a backup (over the limit, low memory, or the texture was
               already blank when it loaded) Show is reported as "nocopy". */
            auto rg = idx.equal_range(c.hash);
            for (auto it = rg.first; it != rg.second; ++it) {
                GLuint id = it->second;
                auto mi = g_lvm.find(id); if (mi == g_lvm.end()) continue;
                const LvMeta m = mi->second;
                if (std::find(done.begin(), done.end(), id) != done.end() || !is_tex(id)) continue;
                if (c.op == 'u') {
                    auto bi = g_lvbk.find(id);
                    if (bi == g_lvbk.end() || !gl.cp) { nocopy++; no_copy = true; continue; }
                    found = true;
                    const LvBk bk = bi->second;
                    for (int l = 0; l < bk.levels; l++) gl.cp(bk.tex, GL_TEXTURE_2D, l, 0, 0, 0, id, GL_TEXTURE_2D, l, 0, 0, 0, bk.w[l], bk.h[l], 1);
                    if (drain()) nbad++;
                    drop_bk(id); nu++;
                    continue;
                }
                found = true;
                if (cur != id) { bindf(GL_TEXTURE_2D, id); cur = id; }
                if (c.op == 'r') { restore_params(id); nr++; continue; }
                if (c.op == 'f') { look_on(id, m.fmt, m.w, m.h, (id < MAXTEX && g_lv[id].load() > 0) ? (int)g_lv[id].load() : 1); nf++; continue; }
                int ws[14], hs[14], n = 0;                              /* the real size of every level the texture has */
                if (gl.lvp) {
                    for (int l = 0; l < 14; l++) { GLint w = 0, h = 0; gl.lvp(GL_TEXTURE_2D, l, 0x1000 /* WIDTH */, &w); gl.lvp(GL_TEXTURE_2D, l, 0x1001 /* HEIGHT */, &h); if (w <= 0 || h <= 0) break; ws[n] = w; hs[n] = h; n++; }
                    drain();
                }
                if (n == 0) { int lvn = (id < MAXTEX && g_lv[id].load() > 0) ? (int)g_lv[id].load() : 1; if (lvn > 14) lvn = 14; for (int l = 0; l < lvn; l++) { ws[l] = std::max(1, m.w >> l); hs[l] = std::max(1, m.h >> l); } n = lvn; }
                if (!g_lvbk.count(id) && gl.gen && gl.stor && gl.cp) {
                    long long bytes = 0; for (int l = 0; l < n; l++) bytes += (long long)tm_level_bytes((GLenum)m.fmt, ws[l], hs[l]);
                    if (g_lv_bkbytes + bytes <= LV_BK_CAP && (memkb < 0 || memkb > 400 * 1024)) {
                        GLuint b = 0; gl.gen(1, &b);
                        if (b) {
                            bindf(GL_TEXTURE_2D, b); cur = b;
                            gl.stor(GL_TEXTURE_2D, n, (GLenum)m.fmt, ws[0], hs[0]);
                            for (int l = 0; l < n; l++) gl.cp(id, GL_TEXTURE_2D, l, 0, 0, 0, b, GL_TEXTURE_2D, l, 0, 0, 0, ws[l], hs[l], 1);
                            if (drain()) { if (gl.del) gl.del(1, &b); nobk++; nbad++; }
                            else { LvBk bk; bk.tex = b; bk.levels = n; bk.bytes = bytes; for (int l = 0; l < n; l++) { bk.w[l] = ws[l]; bk.h[l] = hs[l]; } g_lvbk[id] = bk; g_lv_bkbytes += bytes; nbk++; }
                            bindf(GL_TEXTURE_2D, id); cur = id;
                        } else nobk++;
                    } else nobk++;
                }
                bool ok = true;
                for (int l = 0; l < n && ok; l++) {
                    size_t nb = (size_t)tm_level_bytes((GLenum)m.fmt, ws[l], hs[l]);
                    const uint8_t *b = nb ? blank_fill((GLenum)m.fmt, nb) : nullptr;
                    if (!b) { ok = false; break; }
                    subf(GL_TEXTURE_2D, l, 0, 0, ws[l], hs[l], (GLenum)m.fmt, (GLsizei)nb, b);
                }
                if (ok) { nh++; nometa++; } else nofmt++;
            }
            if (!found && !no_copy) miss++;
        }
        if (k < cmds.size()) g_lv_cmd.insert(g_lv_cmd.begin(), cmds.begin() + k, cmds.end());      /* the rest comes in the next frames */
    }
    if (cur != (GLuint)prev_tex) bindf(GL_TEXTURE_2D, (GLuint)prev_tex);
    if (prev_pbo) bindbuf(0x88EC, (GLuint)prev_pbo);
    int left = (int)(cmds.size() - k);
    char msg[160];
    if (left > 0) { snprintf(msg, sizeof msg, "working: %d left", left); st_set("lv_last", msg); lv_status(); return; }
    L("LIVE applied %d command(s): hidden=%d (without a kept copy=%d, GPU backup made=%d, no backup=%d, GL errors=%d) shown=%d params_restored=%d look_on=%d not_found=%d no_copy_to_show=%d no_blank_format=%d\n", ncmd, nh, nometa, nbk, nobk, nbad, nu, nr, nf, miss, nocopy, nofmt);
    snprintf(msg, sizeof msg, "hidden=%d shown=%d restored=%d lookon=%d missing=%d nocopy=%d backup=%d nobackup=%d", nh, nu, nr, nf, miss, nocopy, nbk, nobk);
    st_set("lv_last", msg);
    nh = nu = nr = nf = miss = nofmt = nometa = nocopy = nbk = nobk = ncmd = nbad = 0;
    lv_status();
}

static void (*o_ts3)(GLenum, GLsizei, GLenum, GLsizei, GLsizei, GLsizei) = nullptr;
static void h_ts3(GLenum t, GLsizei lv, GLenum f, GLsizei w, GLsizei h, GLsizei d) {
    int n3 = ++g_n_ts3; bool c3 = is_cmp(f); if (c3) g_n_ts3_cmp++;
    if (n3 <= 25) L("TS3 target=0x%x lv=%d fmt=0x%x %dx%dx%d cmp=%d (not modified)\n", t, (int)lv, f, (int)w, (int)h, (int)d, c3 ? 1 : 0);
    auto fn_ = orig_or(o_ts3, "glTexStorage3D", h_ts3); if (!fn_) return; TIMED(K_TEX, fn_(t, lv, f, w, h, d));
}

/* ---------- Per-thread CPU usage (shows which threads were busy during a freeze) ---------- */
/* th.txt: 0 = off, 1 = on (default). Runs on the render thread; no extra thread is created. */
static std::atomic<int> g_th{1};
static int g_sched_mode = -1;              /* 1 = /proc schedstat (ns), 0 = /proc stat (ticks) */
struct Thr { pid_t tid; int fd; int64_t prev, cur, wprev, wcur; char name[20]; };
static std::vector<Thr> g_thr;             /* only accessed from the render thread */
static int g_nthr = 0;
static const size_t MAXT = 48;

/* ---------- CPU core logger (diagnostics only) ---------- */
/* core.txt: 0 = off, 1 = on (default). Requires fz.txt = 1 and th.txt = 1. */
static std::atomic<int> g_core{1};
static const int NC = 8;
static std::vector<std::pair<pid_t, int>> g_um;    /* UnityMain threads: tid and an open fd on /proc/self/task/<tid>/stat */
static int g_um_now = -1, g_um_prev = -1;
static int g_h_um[NC], g_h_rt[NC], g_h_fz[NC];
static int g_h_n = 0;

static int read_int_file(const char *path) {
    int fd = open(path, O_RDONLY | O_CLOEXEC);
    if (fd < 0) return -1;
    char b[32];
    ssize_t n = read(fd, b, sizeof(b) - 1);
    close(fd);
    if (n <= 0) return -1;
    b[n] = 0;
    return atoi(b);
}

static int cpu_khz(int c) {
    char p[96];
    snprintf(p, sizeof p, "/sys/devices/system/cpu/cpu%d/cpufreq/scaling_cur_freq", c);
    return read_int_file(p);
}

/* Field 39 ("processor") of /proc/.../stat is the CPU the thread last ran on. */
static int core_of(int fd) {
    char b[640];
    ssize_t n = pread(fd, b, sizeof(b) - 1, 0);
    if (n <= 0) return -1;
    b[n] = 0;
    char *p = strrchr(b, ')');
    if (!p || !p[1]) return -1;
    p += 2;
    for (int i = 0; i < 36; i++) {
        p = strchr(p, ' ');
        if (!p) return -1;
        p++;
    }
    return atoi(p);
}

static void core_info() {
    char buf[480]; int len = snprintf(buf, sizeof buf, "CORES");
    for (int c = 0; c < NC && len < (int)sizeof(buf) - 60; c++) {
        char p[96], a[16], m[16];
        snprintf(p, sizeof p, "/sys/devices/system/cpu/cpu%d/cpu_capacity", c);
        int cap = read_int_file(p);
        snprintf(p, sizeof p, "/sys/devices/system/cpu/cpu%d/cpufreq/cpuinfo_max_freq", c);
        int mx = read_int_file(p);
        if (cap >= 0) snprintf(a, sizeof a, "%d", cap); else strcpy(a, "n/a");
        if (mx >= 0) snprintf(m, sizeof m, "%d", mx); else strcpy(m, "n/a");
        len += snprintf(buf + len, sizeof(buf) - len, " cpu%d=cap:%s/max:%s", c, a, m);
    }
    L("%s\n", buf);
}

/* v0.72: what UnityMain did in the last frame, from /proc/self/task/<tid>/stat: state, user / kernel time, time blocked on block I/O,
   page faults. A freeze where kernel time or I/O wait is large is memory / storage; a large user time is the game's own work. */
struct UmS { char st; unsigned long minf, majf, ut, sy, blk; int cpu; bool ok; };
static bool um_parse(const char *b, UmS &o) {
    o = UmS{'?', 0, 0, 0, 0, 0, -1, false};
    const char *p = strrchr(b, ')');
    if (!p || !p[1] || !p[2]) return false;
    p += 2;                                              /* now at field 3 (state) */
    o.st = *p;
    unsigned long v[43] = {0};
    int f = 3;
    while (f <= 42) {
        const char *q = strchr(p, ' ');
        if (!q) break;
        p = q + 1; f++;
        if (f >= 4 && f <= 42) v[f] = strtoul(p, nullptr, 10);
    }
    o.minf = v[10]; o.majf = v[12]; o.ut = v[14]; o.sy = v[15]; o.cpu = (int)v[39]; o.blk = v[42];
    o.ok = (f >= 42);
    return true;
}
static UmS g_ums_now[2], g_ums_prev[2];
static void um_sample() {
    int i = 0;
    for (auto &u : g_um) {
        if (i >= 2) break;
        g_ums_prev[i] = g_ums_now[i];
        char b[640]; ssize_t n = (u.second >= 0) ? pread(u.second, b, sizeof(b) - 1, 0) : -1;
        if (n > 0) { b[n] = 0; um_parse(b, g_ums_now[i]); } else g_ums_now[i] = UmS{'?', 0, 0, 0, 0, 0, -1, false};
        i++;
    }
}

static void core_sample() {
    um_sample();
    g_um_prev = g_um_now;
    int c = -1;
    for (auto &u : g_um) {
        if (u.second < 0) continue;
        int x = core_of(u.second);
        if (x >= 0) { c = x; break; }
    }
    g_um_now = c;
    int r = sched_getcpu();
    if (c >= 0 && c < NC) g_h_um[c]++;
    if (r >= 0 && r < NC) g_h_rt[r]++;
    g_h_n++;
}

static void core_freeze(long long frame, float ms, double t_s) {
    int c = g_um_now;
    if (c >= 0 && c < NC) g_h_fz[c]++;
    L("CORE t=%.2f f=%lld ms=%.0f um=%d prev=%d um_khz=%d rt=%d\n",
      t_s, frame, ms, c, g_um_prev, c >= 0 ? cpu_khz(c) : -1, sched_getcpu());
    static long tck = sysconf(_SC_CLK_TCK) > 0 ? sysconf(_SC_CLK_TCK) : 100;
    double k = 1000.0 / (double)tck;
    for (int i = 0; i < 2 && i < (int)g_um.size(); i++) {
        const UmS &a = g_ums_now[i], &b = g_ums_prev[i];
        if (!a.ok || !b.ok) continue;
        L("UMS t=%.2f f=%lld ms=%.0f i=%d tid=%d state=%c user=%.0fms kern=%.0fms iowait=%.0fms majf=%ld minf=%ld\n",
          t_s, frame, ms, i, (int)g_um[i].first, a.st, (a.ut - b.ut) * k, (a.sy - b.sy) * k, (a.blk - b.blk) * k,
          (long)(a.majf - b.majf), (long)(a.minf - b.minf));
    }
}

static int put_arr(char *b, size_t cap, const int *a) {
    int len = 0;
    for (int i = 0; i < NC; i++)
        len += snprintf(b + len, cap - len, "%s%d", i ? "," : "", a[i]);
    return len;
}

static void core_hist(double t_s) {
    if (g_h_n <= 0) return;
    char buf[300]; int len = snprintf(buf, sizeof buf, "CH t=%.1f n=%d um=", t_s, g_h_n);
    len += put_arr(buf + len, sizeof(buf) - len, g_h_um);
    len += snprintf(buf + len, sizeof(buf) - len, " rt=");
    len += put_arr(buf + len, sizeof(buf) - len, g_h_rt);
    len += snprintf(buf + len, sizeof(buf) - len, " umfz=");
    put_arr(buf + len, sizeof(buf) - len, g_h_fz);
    L("%s\n", buf);
    memset(g_h_um, 0, sizeof g_h_um);
    memset(g_h_rt, 0, sizeof g_h_rt);
    memset(g_h_fz, 0, sizeof g_h_fz);
    g_h_n = 0;
}

static bool read_cpu(int fd, int64_t &run, int64_t &wait) {
    char b[256];
    ssize_t n = pread(fd, b, sizeof(b) - 1, 0);
    if (n <= 0) return false;
    b[n] = 0;
    if (g_sched_mode == 1) {
        char *e = nullptr;
        run = strtoll(b, &e, 10);
        wait = (e && *e) ? strtoll(e, &e, 10) : 0;
        return true;
    }
    char *p = strrchr(b, ')');
    if (!p) return false;
    unsigned long ut = 0, st = 0;
    if (sscanf(p + 2, "%*c %*d %*d %*d %*d %*d %*u %*u %*u %*u %*u %lu %lu", &ut, &st) != 2) return false;
    run = (int64_t)(ut + st) * 10000000LL;
    wait = 0;
    return true;
}

static void th_init() {
    char path[64];
    snprintf(path, sizeof path, "/proc/self/task/%d/schedstat", (int)getpid());
    g_sched_mode = 0;
    int fd = open(path, O_RDONLY | O_CLOEXEC);
    if (fd >= 0) {
        g_sched_mode = 1;
        int64_t r = 0, w = 0;
        if (!read_cpu(fd, r, w) || r <= 0) g_sched_mode = 0;
        close(fd);
    }
    L("THR mode=%s\n", g_sched_mode == 1 ? "schedstat" : "stat");
    if (g_core.load()) core_info();
}

static void th_rescan() {
    for (auto &t : g_thr) if (t.fd >= 0) close(t.fd);
    g_thr.clear();
    for (auto &u : g_um) if (u.second >= 0) close(u.second);
    g_um.clear();
    auto d = opendir("/proc/self/task");
    if (!d) return;
    std::vector<Thr> all;
    while (dirent *e = readdir(d)) {
        if (e->d_name[0] < '0' || e->d_name[0] > '9') continue;
        pid_t tid = (pid_t)atoi(e->d_name);
        char path[64];
        snprintf(path, sizeof path, "/proc/self/task/%d/%s", (int)tid, g_sched_mode == 1 ? "schedstat" : "stat");
        int fd = open(path, O_RDONLY | O_CLOEXEC);
        if (fd < 0) continue;
        Thr t; memset(&t, 0, sizeof t);
        t.tid = tid; t.fd = fd;
        if (!read_cpu(fd, t.cur, t.wcur)) { close(fd); continue; }
        t.prev = t.cur; t.wprev = t.wcur;
        snprintf(path, sizeof path, "/proc/self/task/%d/comm", (int)tid);
        int cf = open(path, O_RDONLY | O_CLOEXEC);
        ssize_t n = 0;
        if (cf >= 0) { n = read(cf, t.name, 15); close(cf); }
        if (n > 0) {
            t.name[n] = 0;
            for (char *c = t.name; *c; c++) if (*c == '\n' || *c == ' ') *c = (*c == '\n') ? 0 : '_';
        } else strcpy(t.name, "?");
        all.push_back(t);
    }
    closedir(d);
    if (g_core.load()) {
        for (auto &a : all) {
            if (strcmp(a.name, "UnityMain") != 0 || g_um.size() >= 2) continue;
            char sp[64];
            snprintf(sp, sizeof sp, "/proc/self/task/%d/stat", (int)a.tid);
            int sf = open(sp, O_RDONLY | O_CLOEXEC);
            if (sf >= 0) g_um.push_back({a.tid, sf});
        }
    }
    g_nthr = (int)all.size();
    std::sort(all.begin(), all.end(), [](const Thr &a, const Thr &b) { return a.cur > b.cur; });
    pid_t me = getpid(), rt = g_rt.load();
    for (size_t i = 0; i < all.size(); i++) {
        if (i < MAXT || all[i].tid == me || all[i].tid == rt) g_thr.push_back(all[i]);
        else close(all[i].fd);
    }
}

static void th_snapshot() {
    for (auto &x : g_thr) {
        if (x.fd < 0) continue;
        x.prev = x.cur; x.wprev = x.wcur;
        if (!read_cpu(x.fd, x.cur, x.wcur)) { close(x.fd); x.fd = -1; x.cur = x.prev; x.wcur = x.wprev; }
    }
}

static void th_log(long long frame, float ms, double t_s) {
    pid_t me = getpid(), rt = g_rt.load();
    std::vector<std::pair<int64_t, size_t>> v;
    double sum = 0, rwait = 0;
    for (size_t i = 0; i < g_thr.size(); i++) {
        int64_t dl = g_thr[i].cur - g_thr[i].prev;
        if (dl < 0) dl = 0;
        sum += dl / 1e6;
        if (g_thr[i].tid == rt) rwait = (g_thr[i].wcur - g_thr[i].wprev) / 1e6;
        if (dl >= 3000000LL) v.push_back({dl, i});
    }
    std::sort(v.begin(), v.end(), [](const std::pair<int64_t, size_t> &a, const std::pair<int64_t, size_t> &b) { return a.first > b.first; });
    char buf[420]; int len = 0;
    len += snprintf(buf + len, sizeof(buf) - len, "THR t=%.2f f=%lld ms=%.0f sum=%.0f rwait=%.0f nthr=%d |", t_s, frame, ms, sum, rwait, g_nthr);
    for (size_t k = 0; k < v.size() && k < 6 && len < (int)sizeof(buf) - 40; k++) {
        const Thr &x = g_thr[v[k].second];
        len += snprintf(buf + len, sizeof(buf) - len, " %s%s=%.0f", x.name,
                        x.tid == rt ? "*" : (x.tid == me ? "!" : ""), v[k].first / 1e6);
    }
    L("%s\n", buf);
}

static inline double tv_ms(const timeval &a) { return a.tv_sec * 1000.0 + a.tv_usec / 1000.0; }

static void log_gl_info() {
    typedef const GLubyte *(*gs_t)(GLenum);
    gs_t gs = (gs_t)dlsym(RTLD_DEFAULT, "glGetString");
    if (!gs) { void *h = dlopen("libGLESv3.so", RTLD_NOW); if (h) gs = (gs_t)dlsym(h, "glGetString"); }
    if (!gs) { L("GLINFO glGetString n/a\n"); return; }
    const char *r = (const char *)gs(GL_RENDERER), *v = (const char *)gs(GL_VERSION), *e = (const char *)gs(GL_EXTENSIONS);
    L("GLINFO renderer=%s version=%s\n", r ? r : "?", v ? v : "?");
    L("GLINFO ext lod_bias=%d aniso=%d\n", (e && strstr(e, "lod_bias")) ? 1 : 0, (e && strstr(e, "anisotropic")) ? 1 : 0);
}

static void mark_scale_progress(int frames);
/* v0.40 live FPS cap: fps.txt is looked at about once per second on the render thread (a stat() call), and
   a changed file is read again, so the WebUI can change the cap while the game is running. */
static void live_fps_poll(int64_t t) {
    static int64_t next = 0;
    static dev_t last_dev = 0; static ino_t last_ino = 0; static int64_t last_mt = -1; static off_t last_sz = -1;
    if (t < next) return;
    next = t + 1000000000LL;
    struct stat sb;
    if (stat(FPSF, &sb) != 0) return;
    int64_t mt = (int64_t)sb.st_mtim.tv_sec * 1000000000LL + sb.st_mtim.tv_nsec;
    if (last_mt < 0) { last_dev = sb.st_dev; last_ino = sb.st_ino; last_mt = mt; last_sz = sb.st_size; return; }   /* first look: the value was read at launch */
    if (mt == last_mt && sb.st_ino == last_ino && sb.st_dev == last_dev && sb.st_size == last_sz) return;
    last_dev = sb.st_dev; last_ino = sb.st_ino; last_mt = mt; last_sz = sb.st_size;
    int v = -1;
    FILE *f = fopen(FPSF, "r");
    if (!f) return;
    if (fscanf(f, "%d", &v) != 1) v = -1;
    fclose(f);
    if (v < 0) return;                                  /* half-written or garbage: keep the current cap */
    int nv = (v >= 20 && v <= 120) ? v : 0;
    if (nv != g_fps.load()) {
        L("LIVEFPS cap %d -> %d (fps.txt changed while the game runs)\n", g_fps.load(), nv);
        g_fps = nv;
    }
    st_seti("live_fps", nv);
}
/* ---------- v0.71 system snapshot (diagnostics only): free memory, pressure, temperature, own memory ----------
   Logged for every freeze of 250 ms or more and every 30 s. Files the game is not allowed to read show -1. */
static int rd_small(const char *path, char *b, int n) {
    int fd = open(path, O_RDONLY | O_CLOEXEC);
    if (fd < 0) return -1;
    int r = (int)read(fd, b, (size_t)n - 1);
    close(fd);
    if (r < 0) return -1;
    b[r] = 0;
    return r;
}
static long kb_of(const char *buf, const char *key) {
    const char *q = strstr(buf, key);
    if (!q) return -1;
    return strtol(q + strlen(key), nullptr, 10);
}
static double psi10(const char *path) {
    char b[256];
    if (rd_small(path, b, sizeof b) <= 0) return -1.0;
    const char *q = strstr(b, "some avg10=");
    return q ? atof(q + 11) : -1.0;
}
/* v0.72: kernel memory counters (/proc/vmstat). Differences between two readings show swap-in / swap-out, major faults and direct reclaim
   (the game's own thread had to free memory before it could continue = a stall). */
struct VmS { long long swpin, swpout, majf, stall, scan_d, scan_k, steal_d, refault; bool ok; };
static VmS g_vm_last{};
static double g_vm_last_t = 0;
static bool vm_read(VmS &o) {
    static char b[32768];
    o = VmS{0, 0, 0, 0, 0, 0, 0, 0, false};
    int n = rd_small("/proc/vmstat", b, sizeof b);
    if (n <= 0) return false;
    char *p = b;
    while (*p) {
        char *e = strchr(p, '\n'); if (e) *e = 0;
        char *sp = strchr(p, ' ');
        if (sp) {
            long long v = strtoll(sp + 1, nullptr, 10); *sp = 0;
            if (!strcmp(p, "pswpin")) o.swpin = v;
            else if (!strcmp(p, "pswpout")) o.swpout = v;
            else if (!strcmp(p, "pgmajfault")) o.majf = v;
            else if (!strncmp(p, "allocstall", 10)) o.stall += v;
            else if (!strcmp(p, "pgscan_direct")) o.scan_d = v;
            else if (!strcmp(p, "pgscan_kswapd")) o.scan_k = v;
            else if (!strcmp(p, "pgsteal_direct")) o.steal_d = v;
            else if (!strcmp(p, "workingset_refault") || !strcmp(p, "workingset_refault_anon") || !strcmp(p, "workingset_refault_file")) o.refault += v;
        }
        if (!e) break;
        p = e + 1;
    }
    o.ok = true;
    return true;
}
/* called about once a second from the render thread (cheap): remembers the reference reading */
static void vm_tick(double t_s) {
    if (t_s - g_vm_last_t < 1.0 && g_vm_last.ok) return;
    VmS v; if (vm_read(v)) { g_vm_last = v; g_vm_last_t = t_s; }
    else { static int w = 0; if (!w++) L("VMSTAT unreadable (/proc/vmstat is not allowed for the game)\n"); }
}
static void vm_log(const char *tag, double t_s, float ms) {
    VmS v;
    if (!g_vm_last.ok || !vm_read(v)) return;
    L("VMSTAT %s t=%.2f ms=%.0f dt=%.1fs swpin=%lld swpout=%lld majf=%lld allocstall=%lld scan_direct=%lld scan_kswapd=%lld steal_direct=%lld refault=%lld\n",
      tag, t_s, ms, t_s - g_vm_last_t, v.swpin - g_vm_last.swpin, v.swpout - g_vm_last.swpout, v.majf - g_vm_last.majf, v.stall - g_vm_last.stall,
      v.scan_d - g_vm_last.scan_d, v.scan_k - g_vm_last.scan_k, v.steal_d - g_vm_last.steal_d, v.refault - g_vm_last.refault);
}

static void sys_probe(const char *tag, double t_s, float ms) {
    char b[4096];
    long av = -1, sf = -1, st = -1, mt = -1, ca = -1;
    if (rd_small("/proc/meminfo", b, sizeof b) > 0) { av = kb_of(b, "MemAvailable:"); sf = kb_of(b, "SwapFree:"); st = kb_of(b, "SwapTotal:"); mt = kb_of(b, "MemTotal:"); ca = kb_of(b, "Cached:"); }
    long rss = -1, vsw = -1, ran = -1, rfi = -1, rsh = -1;
    if (rd_small("/proc/self/status", b, sizeof b) > 0) { rss = kb_of(b, "VmRSS:"); vsw = kb_of(b, "VmSwap:"); ran = kb_of(b, "RssAnon:"); rfi = kb_of(b, "RssFile:"); rsh = kb_of(b, "RssShmem:"); }
    vm_log(tag, t_s, ms);
    static std::vector<std::string> zones; static bool zinit = false;
    if (!zinit) {
        zinit = true;
        for (int i = 0; i < 40; i++) {
            char p[96]; snprintf(p, sizeof p, "/sys/class/thermal/thermal_zone%d/temp", i);
            if (access(p, R_OK) == 0) zones.push_back(p);
        }
        L("SYS thermal zones readable: %d\n", (int)zones.size());
    }
    int tmax = -1;
    for (const std::string &z : zones) {
        char t[32]; if (rd_small(z.c_str(), t, sizeof t) <= 0) continue;
        long v = strtol(t, nullptr, 10); int c = (int)(v >= 1000 || v <= -1000 ? v / 1000 : v);
        if (c > tmax && c < 200) tmax = c;
    }
    int f0 = -1, f6 = -1;
    if (rd_small("/sys/devices/system/cpu/cpu0/cpufreq/scaling_cur_freq", b, sizeof b) > 0) f0 = (int)(strtol(b, nullptr, 10) / 1000);
    if (rd_small("/sys/devices/system/cpu/cpu6/cpufreq/scaling_cur_freq", b, sizeof b) > 0) f6 = (int)(strtol(b, nullptr, 10) / 1000);
    L("SYS %s t=%.2f ms=%.0f avail=%ldMB swapused=%ldMB rss=%ldMB psi_mem=%.2f psi_io=%.2f temp=%dC f0=%dMHz f6=%dMHz"
      " memtotal=%ldMB cached=%ldMB vmswap=%ldMB anon=%ldMB file=%ldMB shmem=%ldMB texlive=%lldMB\n",
      tag, t_s, ms, av >= 0 ? av / 1024 : -1L, (st >= 0 && sf >= 0) ? (st - sf) / 1024 : -1L, rss >= 0 ? rss / 1024 : -1L,
      psi10("/proc/pressure/memory"), psi10("/proc/pressure/io"), tmax, f0, f6,
      mt >= 0 ? mt / 1024 : -1L, ca >= 0 ? ca / 1024 : -1L, vsw >= 0 ? vsw / 1024 : -1L, ran >= 0 ? ran / 1024 : -1L, rfi >= 0 ? rfi / 1024 : -1L, rsh >= 0 ? rsh / 1024 : -1L,
      (long long)(g_tm_tot.load() / 1024));
}

static EGLBoolean (*o_swap)(EGLDisplay, EGLSurface) = nullptr;
static EGLBoolean h_swap(EGLDisplay d, EGLSurface s) {
    int64_t t_pre = now_ns();
    auto f_swap = orig_or(o_swap, "eglSwapBuffers", h_swap);
    EGLBoolean r = f_swap ? f_swap(d, s) : EGL_FALSE;
    int64_t t_post = now_ns();

    pid_t tid = (pid_t)syscall(SYS_gettid);
    pid_t exp = 0;
    g_rt.compare_exchange_strong(exp, tid);
    if (g_rt.load() != tid) return r;       /* not the render thread: nothing to do */

    static int64_t last = 0;                /* time of previous frame (after cap) */
    static int64_t deadline = 0;            /* when the current frame should finish */
    static int64_t win_start = 0;
    static std::vector<float> ft;           /* frame times (ms) in a 5-second window */
    static int64_t frame_no = 0;
    static int win_fz = 0;                  /* freeze count in the stats window */
    static int fz_logged = 0;               /* cap on FREEZE log lines per session */
    static rusage ru_last;
    static bool ru_ok = false;
    static int64_t next_scan = 0;

    int64_t t = t_post;
    if (g_t0.load() == 0) g_t0 = t;
    frame_no++;
    revisit_pending();
    if (g_live_on.load()) { live_poll(t); lv_apply(); }       /* v0.76: marks, live commands, rule re-read (once a second) */
    if (g_spread_kb.load() > 0) { g_sp_frame = frame_no; g_sp_used = 0; sp_replay((long long)g_spread_kb.load() * 1024, false); }   /* v0.71 (experimental, default OFF) */
    if (frame_no == 1) { L("GFX api=gles (eglSwapBuffers seen)\n"); st_set("gfx", (g_forcegl.load() && g_vk_blocked.load()) ? "gles_forced" : "gles"); st_set("stage", "gfx"); }
    if (frame_no == 20 && g_scale_marked.load()) mark_scale_progress(20);
    if (frame_no == 20 && g_bl_marked.load()) { FILE *bf = fopen(BLRUNF, "w"); if (bf) { fprintf(bf, "20\n"); fclose(bf); } }
    if (frame_no == 120 && g_bl_marked.load()) { unlink(BLRUNF); L("boxloot ok: crash marker cleared after 120 frames\n"); }
    if (frame_no == 120 && g_scale_marked.load()) { unlink(SCRASHF); L("scale ok: crash marker cleared after 120 frames\n"); }
    if (frame_no == 120) maps_report("frame120");
    if (frame_no == 30) log_gl_info();

    /* FPS cap: sleep the remaining time so frame intervals stay even */
    live_fps_poll(t);
    int cap = g_fps.load();
    if (cap > 0) {
        int64_t iv = 1000000000LL / cap;
        if (deadline == 0) deadline = t;
        deadline += iv;
        if (t > deadline + iv) deadline = t;          /* fell far behind: reset deadline */
        else if (t < deadline) {
            timespec ts;
            ts.tv_sec = deadline / 1000000000LL;
            ts.tv_nsec = deadline % 1000000000LL;
            while (clock_nanosleep(CLOCK_MONOTONIC, TIMER_ABSTIME, &ts, nullptr) == EINTR) {}
            t = now_ns();
        }
    }

    float ms = 0.f;
    if (last != 0) {
        ms = (float)((t - last) / 1e6);
        if (ms < 1000.f) ft.push_back(ms);           /* ignore loading pauses in the statistics */
    }
    last = t;
    if (win_start == 0) win_start = t;

    /* Freeze logger: read and reset counters each frame */
    if (g_fz.load()) {
        rusage ru; bool ok = (getrusage(RUSAGE_THREAD, &ru) == 0);
        bool th_on = g_th.load() != 0;
        vm_tick((t - g_t0.load()) / 1e9);                    /* v0.72: reference reading of /proc/vmstat about once a second */
        if (th_on && g_sched_mode < 0) th_init();
        if (th_on && g_thr.empty()) th_rescan();
        if (th_on) th_snapshot();
        if (th_on && g_core.load()) core_sample();
        int cc[2][K_N]; int64_t cn[2][K_N];
        for (int i = 0; i < 2; i++)
            for (int k = 0; k < K_N; k++) { cc[i][k] = c_cnt[i][k].exchange(0); cn[i][k] = c_ns[i][k].exchange(0); }
        long long ub[2] = { c_ubytes[0].exchange(0), c_ubytes[1].exchange(0) };
        int uc[2] = { c_ucnt[0].exchange(0), c_ucnt[1].exchange(0) };
        int umax = c_umax.exchange(0), ufmt = c_ufmt.load(), uw = c_uw.load(), uh = c_uh.load();
        if (last != 0 && ms >= 100.f) {
            win_fz++;
            if (fz_logged < 1500) {                    /* v0.71: was 400; the log cap is 4 MB now */
                fz_logged++;
                double cpu = 0, vcs = 0, ics = 0, minf = 0, majf = 0;
                if (ok && ru_ok) {
                    cpu = tv_ms(ru.ru_utime) + tv_ms(ru.ru_stime) - tv_ms(ru_last.ru_utime) - tv_ms(ru_last.ru_stime);
                    vcs = (double)(ru.ru_nvcsw - ru_last.ru_nvcsw);
                    ics = (double)(ru.ru_nivcsw - ru_last.ru_nivcsw);
                    minf = (double)(ru.ru_minflt - ru_last.ru_minflt);
                    majf = (double)(ru.ru_majflt - ru_last.ru_majflt);
                }
                L("FREEZE t=%.2f f=%lld ms=%.0f swap=%.0f cpu=%.0f vcs=%.0f ics=%.0f minf=%.0f majf=%.0f"
                  " | rt comp=%d/%.0f link=%d/%.0f pbin=%d/%.0f buf=%d/%.0f tex=%d/%.0f"
                  " | bg comp=%d/%.0f link=%d/%.0f pbin=%d/%.0f buf=%d/%.0f tex=%d/%.0f\n",
                  (t - g_t0.load()) / 1e9, (long long)frame_no, ms, (t_post - t_pre) / 1e6, cpu, vcs, ics, minf, majf,
                  cc[0][K_COMP], cn[0][K_COMP] / 1e6, cc[0][K_LINK], cn[0][K_LINK] / 1e6,
                  cc[0][K_PBIN], cn[0][K_PBIN] / 1e6, cc[0][K_BUF], cn[0][K_BUF] / 1e6,
                  cc[0][K_TEX], cn[0][K_TEX] / 1e6,
                  cc[1][K_COMP], cn[1][K_COMP] / 1e6, cc[1][K_LINK], cn[1][K_LINK] / 1e6,
                  cc[1][K_PBIN], cn[1][K_PBIN] / 1e6, cc[1][K_BUF], cn[1][K_BUF] / 1e6,
                  cc[1][K_TEX], cn[1][K_TEX] / 1e6);
                if (th_on) th_log((long long)frame_no, ms, (t - g_t0.load()) / 1e9);
                if (th_on && g_core.load()) core_freeze((long long)frame_no, ms, (t - g_t0.load()) / 1e9);
                if (ms >= 250.f) {                      /* v0.71: what was uploaded and what the system looked like */
                    long long qb; { std::lock_guard<std::mutex> lk(g_spmu); qb = g_sp_qbytes; }
                    L("UPL t=%.2f f=%lld ms=%.0f rt=%lldKB/%d bg=%lldKB/%d max=%dKB fmt=0x%x %dx%d spq=%lldKB\n",
                      (t - g_t0.load()) / 1e9, (long long)frame_no, ms, ub[0] / 1024, uc[0], ub[1] / 1024, uc[1], umax / 1024, ufmt, uw, uh, qb / 1024);
                    sys_probe("freeze", (t - g_t0.load()) / 1e9, ms);
                }
            }
        }
        if (ok) { ru_last = ru; ru_ok = true; }
        if (th_on && t >= next_scan) { th_rescan(); next_scan = t + 5000000000LL; }
    }

    if (t - win_start >= 5000000000LL && ft.size() >= 10) {
        std::sort(ft.begin(), ft.end());
        double sum = 0; for (float v : ft) sum += v;
        size_t n = ft.size();
        float p50 = ft[n / 2], p99 = ft[std::min(n - 1, (size_t)(n * 0.99))], mx = ft[n - 1];
        size_t s33 = 0, s50 = 0;
        for (float v : ft) { if (v > 33.4f) s33++; if (v > 50.f) s50++; }
        L("FT fps=%.1f avg=%.1fms p50=%.1f p99=%.1f max=%.1f >33ms=%zu >50ms=%zu n=%zu cap=%d bias=%d scale=%d t=%.1f fz=%d\n",
          1000.0 * n / sum, sum / n, p50, p99, mx, s33, s50, n, cap, g_bias.load(), g_scale.load(),
          (t - g_t0.load()) / 1e9, win_fz);
        {   /* v0.80 (diagnostic only): when the frame rate jumps (for example 120 -> 30) write one FPSSTEP line and a system snapshot right then
               (temperature, CPU frequency, memory), so a report shows what the phone was doing at that moment. Max 60 lines per game start. */
            static double prev_fps = 0; static int step_n = 0;
            double now_fps = 1000.0 * n / sum;
            if (prev_fps > 0 && step_n < 60 && (now_fps < prev_fps * 0.75 || now_fps > prev_fps * 1.33)) {
                step_n++;
                L("FPSSTEP from=%.1f to=%.1f cap=%d scale=%d t=%.1f\n", prev_fps, now_fps, cap, g_scale.load(), (t - g_t0.load()) / 1e9);
                if (g_fz.load()) sys_probe("fpsstep", (t - g_t0.load()) / 1e9, 0.f);
            }
            prev_fps = now_fps;
        }
        if (g_near.load()) L("NEAR flagged=%d forced=%d smp=%d\n", g_flagged.load(), g_forced.load(), g_smp.load());
        {
            static int sys_n = 0;                       /* v0.71: a system snapshot every 30 s (6 windows) */
            if (g_fz.load() && sys_n++ % 6 == 0) {
                sys_probe("tick", (t - g_t0.load()) / 1e9, 0.f);
                L("TEXMEM t=%.0f live=%lldMB n=%d ge1024=%lldMB 512=%lldMB 256=%lldMB lt256=%lldMB mipskip_save=%lldMB\n", (t - g_t0.load()) / 1e9,
                  g_tm_tot.load() / 1024, g_tm_n.load(), g_tm_cls[1].load() / 1024, g_tm_cls[2].load() / 1024, g_tm_cls[3].load() / 1024, g_tm_cls[4].load() / 1024, g_tm_save.load() / 1024);
            }
            if (g_spread_kb.load() > 0) {
                long long qb; { std::lock_guard<std::mutex> lk(g_spmu); qb = g_sp_qbytes; }
                L("SPREAD kb=%d deferred=%lld (%lldMB) replayed=%lld queue=%lldKB maxq=%lldKB maxage=%lldf flush=%lld pbo=%lld lost=%lld\n",
                  g_spread_kb.load(), g_sp_nd.load(), g_sp_bd.load() >> 20, g_sp_nr.load(), qb / 1024, g_sp_maxq.load() / 1024, g_sp_maxage.load(),
                  g_sp_flush.load(), g_sp_pbo.load(), g_sp_lost.load());
            }
        }
        {
            static int64_t last_gd = 0;
            if (g_gdirty.load() && t - last_gd >= 20000000000LL) { last_gd = t; grp_dump((t - g_t0.load()) / 1e9); }
        }
        if (g_fz.load() && g_th.load() && g_core.load()) core_hist((t - g_t0.load()) / 1e9);
        ft.clear();
        win_fz = 0;
        win_start = t;
    }
    return r;
}

/* ---------- Render scale (shrinks the window buffer) ----------
   v0.29: the native size is learned from the real window (ANativeWindow_getWidth/Height), never guessed.
   Calls with a 0 width/height ("keep native size") and portrait probes are passed through untouched.
   A marker file (scale_crash.txt) is written before scaling and removed after 120 rendered frames;
   if it is still there at the next launch, render scale is switched off so it can never boot-loop. */
static std::atomic<int> g_fullw{0}, g_fullh{0};   /* native landscape size, 0 = not learned yet */
static std::atomic<int> g_ovw{0}, g_ovh{0};       /* the last buffer size WE set: seeing it again must never be shrunk a second time */
static std::atomic<int> g_sbgn{0};
/* Scale a w x h pair together so the aspect ratio is kept. The shorter side never goes below 270 px
   (tiny buffers crash some drivers) unless the original is already smaller; then the longer side follows
   the same factor instead of being clamped on its own (which used to stretch the picture at low percentages).
   Returns false (and leaves the outputs alone) for sizes that make no sense, so the caller passes the
   original request through untouched. */
static bool scaled_pair(int w, int h, int s, int *ow, int *oh) {
    if (w <= 0 || h <= 0 || w > 8192 || h > 8192 || s < 20 || s > 99) return false;
    int64_t m = std::min(w, h);
    int64_t tgt = m * s / 100;
    int64_t floor_ = m < 270 ? m : 270;
    if (tgt < floor_) tgt = floor_;
    int nw = (int)((int64_t)w * tgt / m), nh = (int)((int64_t)h * tgt / m);
    nw &= ~1; nh &= ~1;                                    /* keep both even */
    if (nw < 2) nw = 2;
    if (nh < 2) nh = 2;
    if (nw > w) nw = w & ~1;
    if (nh > h) nh = h & ~1;
    *ow = nw; *oh = nh;
    return true;
}

static void learn_full_wh(int w, int h) {
    if (w <= 0 || h <= 0 || w < h || w > 8192) return;
    if (w == g_ovw.load() && h == g_ovh.load()) return;      /* our own scaled size is never "native" */
    if (w > g_fullw.load()) {
        g_fullw = w; g_fullh = h;
        FILE *f = fopen(FULLF, "w");
        if (f) { fprintf(f, "%d %d\n", w, h); fclose(f); }
    }
}
static void learn_full(ANativeWindow *nwin) {
    if (!nwin) return;
    learn_full_wh(nw_width(nwin), nw_height(nwin));
}
static void mark_scale_progress(int frames) {
    FILE *f = fopen(SCRASHF, "w");
    if (f) { fprintf(f, "%d %d\n", g_scale.load(), frames); fclose(f); }
}

static void mark_scale_in_use() {
    if (g_scale_marked.exchange(1)) return;
    FILE *f = fopen(SCRASHF, "w");
    if (f) { fprintf(f, "%d\n", g_scale.load()); fclose(f); }     /* the scale that was active, for the next launch's message */
}

static EGLSurface (*o_cws)(EGLDisplay, EGLConfig, EGLNativeWindowType, const EGLint *) = nullptr;
static EGLSurface h_cws(EGLDisplay d, EGLConfig c, EGLNativeWindowType win, const EGLint *at) {
    { static std::atomic<int> first{0}; if (!first.exchange(1)) st_set("first_cws", "1"); }
    int s = g_scale.load();
    ANativeWindow *nwin = (ANativeWindow *)win;
    if (s > 0 && nwin) {
        int w = nw_width(nwin), h = nw_height(nwin);
        if (w > 0 && h > 0) {
            if (w < h) {
                L("SURFACE portrait %dx%d: skip\n", w, h);
            } else if (w == g_ovw.load() && h == g_ovh.load()) {
                L("SURFACE cur=%dx%d is already our scaled size: not shrunk again\n", w, h);
            } else {
                learn_full(nwin);
                int fw = g_fullw.load(), fh = g_fullh.load();
                if (fw > 0 && fh > 0) {
                    int nw = 0, nh = 0;
                    if (scaled_pair(fw, fh, s, &nw, &nh) && (nw >= w || nh >= h)) {
                        /* v0.38: the window is already as small as (or smaller than) the target, for example because another
                           module/the system shrank it. Never make it smaller: that was the 1600x720 -> 880x396 -> 600x270 chain. */
                        L("SURFACE cur=%dx%d full=%dx%d target=%dx%d: window already that small, left alone\n", w, h, fw, fh, nw, nh);
                    } else if (scaled_pair(fw, fh, s, &nw, &nh)) {
                        int fmt = nw_format(nwin);
                        if (fmt < 0) fmt = 0;           /* keep the window's current format */
                        mark_scale_in_use();
                        g_ovw = nw; g_ovh = nh;
                        int r = nw_sbg(nwin, nw, nh, fmt);
                        L("SURFACE cur=%dx%d full=%dx%d -> %dx%d fmt=%d r=%d\n", w, h, fw, fh, nw, nh, fmt, r);
                    } else L("SURFACE %dx%d (full %dx%d): scale skipped (size out of range)\n", w, h, fw, fh);
                }
            }
        }
    }
    if (s == 0 && nwin) {
        static std::atomic<int> wn{0};
        if (wn++ < 10) L("WINSIZE cws cur=%dx%d (render scale off, window untouched)\n", nw_width(nwin), nw_height(nwin));
    }
    auto f_cws = orig_or(o_cws, "eglCreateWindowSurface", h_cws);
    return f_cws ? f_cws(d, c, win, at) : EGL_NO_SURFACE;
}

static int32_t (*o_sbg)(ANativeWindow *, int32_t, int32_t, int32_t) = nullptr;
static int32_t h_sbg(ANativeWindow *w, int32_t ww, int32_t hh, int32_t f) {
    int s = g_scale.load();
    int n = ++g_sbgn;
    if (n == 1) st_set("first_sbg", "1");
    if (n <= 20) L("SBG call %dx%d fmt=%d cur=%dx%d\n", ww, hh, f, w ? nw_width(w) : 0, w ? nw_height(w) : 0);
    if (w && ww >= hh && ww >= 640 && hh >= 360) learn_full_wh(ww, hh);   /* what Unity asks for is the real native size */
    if (s > 0 && w) {
        if (ww == 0 || hh == 0) {
            learn_full(w);                          /* "keep native size": never override, just learn it */
        } else if (ww >= hh && ww >= 640 && hh >= 360) {
            /* Scale whatever landscape size Unity asks for (1600x720, 1280x720, ...). Scaling the request keeps
               its aspect ratio and cannot compound, because the request comes from Unity, not from us. */
            int nw = 0, nh = 0;
            if (scaled_pair(ww, hh, s, &nw, &nh)) {
                g_ovw = nw; g_ovh = nh;
                ww = nw; hh = nh;
                mark_scale_in_use();
                if (n <= 20) L("SBG overridden -> %dx%d\n", ww, hh);
            } else if (n <= 20) L("SBG %dx%d: scale skipped (size out of range)\n", ww, hh);
        }
    }
    auto ob = (o_sbg && o_sbg != h_sbg) ? o_sbg : nullptr;
    return ob ? ob(w, ww, hh, f) : nw_sbg(w, ww, hh, f);
}


/* ---------- v0.81: Box loot (device spoof, OFF by default) and the probe (log only) ----------
   The probe writes "PROBE ..." lines: what libunity asks the phone (GL strings, system properties, /proc and /sys files, RAM calls). It changes nothing.
   Box loot answers some of those questions differently (GPU name, RAM) so the game takes its low-end path. It touches ONLY libunity's own import table,
   never another library (the anti-cheat is not touched). Box loot is OFF unless boxloot.txt = 1, and it switches itself OFF when the last launch did not
   reach 20 frames (boxloot_run.txt). Values that look personal (serial, id, mac, address) are logged by name only. */
static std::mutex g_pmu;
static std::set<std::string> g_pseen;
static void probe_note(const char *kind, const char *what, const char *val) {
    if (!g_probe.load() && !g_bl.load()) return;
    std::string key = std::string(kind) + " " + what;
    { std::lock_guard<std::mutex> lk(g_pmu); if (g_pseen.size() >= 200 || !g_pseen.insert(key).second) return; }
    char v[120]; snprintf(v, sizeof v, "%s", val ? val : "");
    for (char *q = v; *q; q++) if (*q == '\n' || *q == '\r') *q = ' ';
    const char *w = what;
    if (!strcmp(kind, "prop") && (strstr(w, "serial") || strstr(w, "imei") || strstr(w, "mac") || strstr(w, "address") || strstr(w, "id") || strstr(w, "fingerprint"))) snprintf(v, sizeof v, "(not logged)");
    L("PROBE %s %s = %s\n", kind, what, v);
}
static std::atomic<int> g_bl_hits{0};
static void bl_hit(const char *what) { int c = ++g_bl_hits; if (c <= 12) L("BOXLOOT answered a different value for %s\n", what); st_seti("bl_hits", c); }

static const GLubyte *(*o_gets)(GLenum) = nullptr;
static const GLubyte *(*o_getsi)(GLenum, GLuint) = nullptr;
static const GLubyte *h_gets(GLenum name) {
    auto f = orig_or(o_gets, "glGetString", h_gets);
    const GLubyte *r = f ? f(name) : nullptr;
    char nm[24]; snprintf(nm, sizeof nm, "glGetString(0x%X)", (unsigned)name);
    if (name == 0x1F00 || name == 0x1F01 || name == 0x1F02) probe_note("gl", nm, r ? (const char *)r : "(null)");
    else if (name == 0x1F03) { char v[60]; snprintf(v, sizeof v, "(%d chars)", r ? (int)strlen((const char *)r) : 0); probe_note("gl", nm, v); }
    if (g_bl.load() && r) {
        if (g_bl_gpu.load()) {
            if (name == 0x1F01) { bl_hit("GL_RENDERER"); return (const GLubyte *)"PowerVR Rogue GE8320"; }
            if (name == 0x1F00) { bl_hit("GL_VENDOR"); return (const GLubyte *)"Imagination Technologies"; }
        }
        if (g_bl_pvr.load() && name == 0x1F03) {
            static std::mutex em; static std::string ext; static const GLubyte *src = nullptr;
            std::lock_guard<std::mutex> lk(em);
            if (src != r) { src = r; ext = (const char *)r; if (ext.find("GL_IMG_texture_compression_pvrtc") == std::string::npos) ext += " GL_IMG_texture_compression_pvrtc"; bl_hit("GL_EXTENSIONS"); }
            return (const GLubyte *)ext.c_str();
        }
    }
    return r;
}
static const GLubyte *h_getsi(GLenum name, GLuint idx) {
    auto f = orig_or(o_getsi, "glGetStringi", h_getsi);
    const GLubyte *r = f ? f(name, idx) : nullptr;
    if (name == 0x1F03 && idx == 0) probe_note("gl", "glGetStringi(GL_EXTENSIONS)", "used (the list is not changed by Box loot)");
    return r;
}

#ifndef SYS_memfd_create
#if defined(__aarch64__)
#define SYS_memfd_create 279
#elif defined(__arm__)
#define SYS_memfd_create 385
#elif defined(__x86_64__)
#define SYS_memfd_create 319
#endif
#endif
/* a /proc/meminfo copy in memory with the RAM numbers of Box loot (MemTotal, and MemFree / MemAvailable cut to fit); the other lines are the real ones */
static int bl_meminfo_fd() {
    std::string real;
    int rf = (int)syscall(SYS_openat, AT_FDCWD, "/proc/meminfo", O_RDONLY, 0);
    if (rf >= 0) { char b[4096]; ssize_t n; while ((n = read(rf, b, sizeof b)) > 0) real.append(b, (size_t)n); close(rf); }
    if (real.empty()) return -1;
    long long tot = (long long)g_bl_ram.load() * 1024;                        /* kB */
    std::string out; size_t pos = 0;
    while (pos < real.size()) {
        size_t e = real.find('\n', pos); if (e == std::string::npos) e = real.size();
        std::string ln = real.substr(pos, e - pos); pos = e + 1;
        long long v = 0; char buf[96];
        if (!ln.compare(0, 9, "MemTotal:")) { snprintf(buf, sizeof buf, "MemTotal:       %lld kB", tot); out += buf; }
        else if (!ln.compare(0, 8, "MemFree:") && sscanf(ln.c_str() + 8, "%lld", &v) == 1) { snprintf(buf, sizeof buf, "MemFree:        %lld kB", std::min(v, tot / 4)); out += buf; }
        else if (!ln.compare(0, 13, "MemAvailable:") && sscanf(ln.c_str() + 13, "%lld", &v) == 1) { snprintf(buf, sizeof buf, "MemAvailable:   %lld kB", std::min(v, tot * 55 / 100)); out += buf; }
        else out += ln;
        out += '\n';
    }
    int fd = (int)syscall(SYS_memfd_create, "meminfo", 0);
    if (fd < 0) return -1;
    size_t off = 0; while (off < out.size()) { ssize_t w = write(fd, out.data() + off, out.size() - off); if (w <= 0) break; off += (size_t)w; }
    lseek(fd, 0, SEEK_SET);
    return fd;
}
static bool bl_want_meminfo(const char *p) { return g_bl.load() && g_bl_ram.load() > 0 && p && !strcmp(p, "/proc/meminfo"); }
static void open_probe(const char *p) {
    if (!p || p[0] != '/' || (!g_probe.load() && !g_bl.load())) return;
    if (!strncmp(p, "/proc/", 6)) { if ((p[6] >= '0' && p[6] <= '9') || strstr(p, "/task/")) return; }
    else if (strncmp(p, "/sys/", 5) && strncmp(p, "/dev/", 5) && strncmp(p, "/vendor/", 8)) return;
    probe_note("open", p, "");
}
static int (*o_open)(const char *, int, ...) = nullptr;
static int (*o_openat)(int, const char *, int, ...) = nullptr;
static FILE *(*o_fopen)(const char *, const char *) = nullptr;
static int h_open(const char *path, int flags, ...) {
    mode_t mode = 0;
    if (flags & O_CREAT) { va_list ap; va_start(ap, flags); mode = (mode_t)va_arg(ap, int); va_end(ap); }
    open_probe(path);
    if (bl_want_meminfo(path) && (flags & O_ACCMODE) == O_RDONLY) { int fd = bl_meminfo_fd(); if (fd >= 0) { bl_hit("/proc/meminfo"); return fd; } }
    auto f = o_open ? o_open : (decltype(o_open))real_sym("open");
    return f ? f(path, flags, mode) : -1;
}
static int h_openat(int dfd, const char *path, int flags, ...) {
    mode_t mode = 0;
    if (flags & O_CREAT) { va_list ap; va_start(ap, flags); mode = (mode_t)va_arg(ap, int); va_end(ap); }
    open_probe(path);
    if (bl_want_meminfo(path) && (flags & O_ACCMODE) == O_RDONLY) { int fd = bl_meminfo_fd(); if (fd >= 0) { bl_hit("/proc/meminfo"); return fd; } }
    auto f = o_openat ? o_openat : (decltype(o_openat))real_sym("openat");
    return f ? f(dfd, path, flags, mode) : -1;
}
static FILE *h_fopen(const char *path, const char *mode) {
    open_probe(path);
    if (bl_want_meminfo(path) && mode && mode[0] == 'r') { int fd = bl_meminfo_fd(); if (fd >= 0) { FILE *fp = fdopen(fd, "r"); if (fp) { bl_hit("/proc/meminfo"); return fp; } close(fd); } }
    auto f = o_fopen ? o_fopen : (decltype(o_fopen))real_sym("fopen");
    return f ? f(path, mode) : nullptr;
}
static int (*o_sysinfo)(struct sysinfo *) = nullptr;
static int h_sysinfo(struct sysinfo *si) {
    auto f = o_sysinfo ? o_sysinfo : (decltype(o_sysinfo))real_sym("sysinfo");
    int r = f ? f(si) : -1;
    if (r == 0 && si) {
        uint64_t unit = si->mem_unit ? si->mem_unit : 1;
        char v[64]; snprintf(v, sizeof v, "totalram=%lluMB", (unsigned long long)(((uint64_t)si->totalram * unit) >> 20));
        probe_note("ram", "sysinfo", v);
        if (g_bl.load() && g_bl_ram.load() > 0) {
            uint64_t tot = (uint64_t)g_bl_ram.load() * 1048576ull / unit;
            if (si->totalram > tot) { si->totalram = (decltype(si->totalram))tot; if (si->freeram > tot / 4) si->freeram = (decltype(si->freeram))(tot / 4); bl_hit("sysinfo"); }
        }
    }
    return r;
}
static long (*o_sysconf)(int) = nullptr;
static long h_sysconf(int name) {
    auto f = o_sysconf ? o_sysconf : (decltype(o_sysconf))real_sym("sysconf");
    long r = f ? f(name) : -1;
    if (name == _SC_PHYS_PAGES || name == _SC_AVPHYS_PAGES) {
        long ps = f ? f(_SC_PAGESIZE) : 4096; if (ps <= 0) ps = 4096;
        char v[64]; snprintf(v, sizeof v, "%ldMB", (long)(((long long)r * ps) >> 20));
        probe_note("ram", name == _SC_PHYS_PAGES ? "sysconf(_SC_PHYS_PAGES)" : "sysconf(_SC_AVPHYS_PAGES)", v);
        if (g_bl.load() && g_bl_ram.load() > 0) {
            long long tot = (long long)g_bl_ram.load() * 1048576ll / ps;
            long long cap = name == _SC_PHYS_PAGES ? tot : tot * 55 / 100;
            if (r > cap) { r = (long)cap; bl_hit("sysconf"); }
        }
    }
    return r;
}
static int (*o_spg)(const char *, char *) = nullptr;
static int h_spg(const char *name, char *value) {
    auto f = o_spg ? o_spg : (decltype(o_spg))real_sym("__system_property_get");
    int r = f ? f(name, value) : 0;
    if (name && (g_probe.load() || g_bl.load())) probe_note("prop", name, (r > 0 && value) ? value : "");
    return r;
}

static void *wrap(const char *n, void *r) {
    if (!n || !r) return r;
    if (n[0] == 'v' && n[1] == 'k' && n[2] >= 'A' && n[2] <= 'Z' && g_forcegl.load()) {
        /* v0.41 Force OpenGL ES: libunity must not find any Vulkan entry point, so Unity cannot create a
           Vulkan device and falls back to its next graphics API (GLES). Idea and method: the contributors' v0.39.1. */
        int c = ++g_vk_blocked;
        if (c == 1) { st_set("gfx", "gles_forced"); L("FORCEGL blocked Vulkan symbol %s (Unity should fall back to OpenGL ES)\n", n); }
        st_seti("vk_blocked", c);
        return nullptr;
    }
    if (n[0] == 'v' && n[1] == 'k') {          /* Vulkan entry point requested by libunity */
        static std::atomic<int> vk_once{0};
        if (!vk_once.exchange(1)) {
            st_set("gfx", "vulkan");
            L("GFX vk-symbol %s requested\n", n);
            L("GFX api=vulkan (detected) - texture effects, fps cap and render scale are NOT supported on Vulkan in %s; use GLES (disable modules that force Vulkan, e.g. core-vulkan)\n", VERSION);
        }
        return r;
    }
    /* v0.37: never keep our own hook as the "original" (another injector may hand our pointer back to us),
       and hand an already-wrapped pointer back untouched, so the chain can never loop. */
#define WRAP_ONE(NAME, O, H) if (!strcmp(n, NAME)) { if (r == (void *)(H)) return r; if (!(O)) (O) = (decltype(O))r; return (void *)(H); }
    if (!strcmp(n, "glTexParameteri")) { if (r == (void *)h_tp) return r; if (!real_tp) real_tp = (decltype(real_tp))r; return (g_near.load() || g_style.load() || g_flat.load() || g_testtex.load()) ? (void *)h_tp : r; }
    if (!strcmp(n, "glTexParameterf")) { if (r == (void *)h_tpf) return r; if (!o_tpf) o_tpf = (decltype(o_tpf))r; return (g_style.load() || g_flat.load() || g_testtex.load()) ? (void *)h_tpf : r; }
    if (tex_track()) {
        WRAP_ONE("glActiveTexture", o_act, h_act)
        WRAP_ONE("glBindTexture", o_bind, h_bind)
        WRAP_ONE("glDeleteTextures", o_del, h_del)
        WRAP_ONE("glSamplerParameteri", o_smp, h_smp)
    }
    WRAP_ONE("glTexStorage2D", o_st, h_st)
    if (g_bl.load() || g_probe.load()) { WRAP_ONE("glGetString", o_gets, h_gets) WRAP_ONE("glGetStringi", o_getsi, h_getsi) }
    WRAP_ONE("eglSwapBuffers", o_swap, h_swap)
    WRAP_ONE("eglCreateWindowSurface", o_cws, h_cws)
    WRAP_ONE("ANativeWindow_setBuffersGeometry", o_sbg, h_sbg)
    if (g_fz.load()) {
        WRAP_ONE("glCompileShader", o_comp, h_comp)
        WRAP_ONE("glLinkProgram", o_link, h_link)
        WRAP_ONE("glProgramBinary", o_pbin, h_pbin)
        WRAP_ONE("glBufferData", o_buf, h_buf)
        WRAP_ONE("glTexImage2D", o_ti2, h_ti2)
        WRAP_ONE("glCompressedTexImage2D", o_cti2, h_cti2)
        WRAP_ONE("glTexSubImage2D", o_tsi2, h_tsi2)
        WRAP_ONE("glCompressedTexSubImage2D", o_ctsi2, h_ctsi2)
        WRAP_ONE("glTexStorage3D", o_ts3, h_ts3)
    } else {                                 /* v0.45: the finder log and Remove grass need the two compressed upload calls even when the freeze logger is off */
        WRAP_ONE("glCompressedTexImage2D", o_cti2, h_cti2)
        WRAP_ONE("glCompressedTexSubImage2D", o_ctsi2, h_ctsi2)
    }
#undef WRAP_ONE
    return r;
}

static void *(*o_dlsym)(void *, const char *) = nullptr;
static void *h_dlsym(void *h, const char *n) {
    void *r = (o_dlsym && o_dlsym != h_dlsym) ? o_dlsym(h, n) : dlsym(h, n);   /* v0.37: was an unguarded call through o_dlsym */
    return wrap(n, r);
}
static void *(*o_egl)(const char *) = nullptr;
static void *h_egl(const char *n) {
    auto f = orig_or(o_egl, "eglGetProcAddress", h_egl);   /* v0.37: was an unguarded call through o_egl */
    void *r = f ? f(n) : nullptr;
    return wrap(n, r);
}

/* ---------- Force OpenGL ES (v0.41) ----------
   Unity tries Vulkan first when the game lists it, and only falls back to GLES when the Vulkan loader or
   device creation fails. With forcegl.txt=1, libunity is told that libvulkan does not exist: dlopen of it
   fails here, and every vk* symbol lookup (dlsym / eglGetProcAddress, see wrap()) returns null. Only
   libunity's own imports are changed; the rest of the system keeps using Vulkan normally.
   This is NOT Vulkan support: no texture hooks are installed for Vulkan. */
static bool is_vulkan_lib(const char *path) {
    if (!path) return false;
    const char *b = strrchr(path, '/');
    b = b ? b + 1 : path;
    return strncmp(b, "libvulkan", 9) == 0;      /* libvulkan.so, libvulkan_*.so, libvulkan.adreno.so ... */
}
static void forcegl_note(const char *path) {
    int c = ++g_vk_blocked;
    st_seti("vk_blocked", c);
    static std::atomic<int> once{0};
    if (!once.exchange(1)) { st_set("gfx", "gles_forced"); L("FORCEGL refused to load %s for libunity (Unity should fall back to OpenGL ES)\n", path); }
}
static void *(*o_dlopen_u)(const char *, int) = nullptr;
static void *h_dlopen_u(const char *path, int flags) {
    if (g_forcegl.load() && is_vulkan_lib(path)) { forcegl_note(path); return nullptr; }
    return (o_dlopen_u && o_dlopen_u != h_dlopen_u) ? o_dlopen_u(path, flags) : dlopen(path, flags);
}
static void *(*o_adle_u)(const char *, int, const android_dlextinfo *) = nullptr;
static void *h_adle_u(const char *path, int flags, const android_dlextinfo *info) {
    if (g_forcegl.load() && is_vulkan_lib(path)) { forcegl_note(path); return nullptr; }
    return (o_adle_u && o_adle_u != h_adle_u) ? o_adle_u(path, flags, info) : android_dlopen_ext(path, flags, info);
}

/* New module version -> start a fresh log, so the top of codm_tex.log is always the installed version
   and nobody has to press "Clear log" after an update. Runs once per game launch, before the first L(). */
static void log_rotate_if_new_version() {
    FILE *f = fopen(LOGF, "r");
    if (!f) return;
    char line[512];
    bool old = false;
    const char *pre = "=== start ";
    size_t pl = strlen(pre), vl = strlen(VERSION);
    while (fgets(line, sizeof line, f)) {
        if (strncmp(line, pre, pl) != 0) continue;
        /* version token ends at the next space: "=== start v0.33 build=..." */
        if (strncmp(line + pl, VERSION, vl) != 0 || line[pl + vl] != ' ') { old = true; break; }
    }
    fclose(f);
    if (!old) return;
    std::lock_guard<std::mutex> g(mu);
    if (lf) { fclose(lf); lf = nullptr; }
    FILE *w = fopen(LOGF, "w");                    /* truncate */
    if (w) fclose(w);
    lf_bytes = 0;
}

/* ---------- Settings audit ----------
   A missing, zero-length or non-numeric settings file used to leave some values at an
   undefined "whatever the variable started as" (for example delay stayed 20 while the file
   said 0). Now every key has an explicit default; a broken file is reported (log + status)
   and rewritten atomically with that default. Missing files are only reported; load_cfg()
   creates them as before. */
struct CfgKey { const char *name; const char *path; int def; bool optional; };
static const CfgKey CFG_KEYS[] = {
    {"bias", "bias.txt", 0, false}, {"fps", "fps.txt", 0, false}, {"scale", "scale.txt", 0, false}, {"fz", "fz.txt", 1, false},
    {"th", "th.txt", 1, false}, {"core", "core.txt", 1, false}, {"near", "near.txt", 1, false}, {"blk", "blk.txt", 0, false},
    {"minsz", "minsz.txt", 64, false}, {"delay", "delay.txt", 0, false}, {"style", "style.txt", 0, false}, {"sedge", "sedge.txt", 1, false},
    {"flat", "flat.txt", 0, false}, {"testtex", "testtex.txt", 1, false}, {"ttsize", "ttsize.txt", 0, false}, {"ttsm", "ttsm.txt", 0, false},
    {"hookdelay", "hookdelay.txt", 0, true}, {"forcegl", "forcegl.txt", 1, false}, {"alpha", "alpha.txt", 1, false},
};
static int g_scale_safety = 0;   /* >0 = render scale was switched off at this launch; value = the percent that was active */
static std::string g_cfg_note;   /* "" = no broken settings file; else e.g. "delay=empty,scale=invalid" */
static int g_cfg_missing = 0;    /* settings files that did not exist yet (reported, not an error) */

static void write_int_atomic(const char *path, int v) {
    std::string tmp = std::string(path) + ".tmp";
    FILE *f = fopen(tmp.c_str(), "w");
    if (!f) { unlink(tmp.c_str()); f = fopen(tmp.c_str(), "w"); }   /* root-owned leftover .tmp */
    if (!f) return;
    fprintf(f, "%d\n", v);
    fclose(f);
    chmod(tmp.c_str(), 0666);
    rename(tmp.c_str(), path);        /* also replaces a root-owned file: the folder belongs to the game */
}

static void cfg_audit() {
    g_cfg_note.clear(); g_cfg_missing = 0;
    for (const CfgKey &k : CFG_KEYS) {
        const char *kp = P(k.path);
        FILE *f = fopen(kp, "r");
        if (!f) {
            if (!k.optional && access(kp, F_OK) != 0) g_cfg_missing++;   /* normal on a fresh install; load_cfg() creates it */
            continue;
        }
        char buf[32]; size_t n = fread(buf, 1, sizeof buf - 1, f); fclose(f);
        buf[n] = 0;
        const char *why = nullptr;
        char *e = nullptr; (void)strtol(buf, &e, 10);
        bool blank = true; for (size_t i = 0; i < n; i++) if (buf[i] != ' ' && buf[i] != '\n' && buf[i] != '\r' && buf[i] != '\t') { blank = false; break; }
        if (blank) why = "empty"; else if (e == buf) why = "invalid";
        if (why) {
            if (!g_cfg_note.empty()) g_cfg_note += ",";
            g_cfg_note += std::string(k.name) + "=" + why;
            write_int_atomic(kp, k.def);
        }
    }
}

static void load_cfg() {
    log_rotate_if_new_version();
    g_scale_safety = 0;
    g_delay = 0;                                    /* explicit defaults for values whose file is missing or unreadable */
    g_scale = 0;
    cfg_audit();
    FILE *f = fopen(CFGF, "r");
    if (f) {
        int v = 2;
        if (fscanf(f, "%d", &v) == 1) g_bias = std::max(0, std::min(v, 6));
        fclose(f);
    } else {
        f = fopen(CFGF, "w");
        if (f) { fprintf(f, "0\n"); fclose(f); }
    }
    f = fopen(FPSF, "r");
    if (f) {
        int v = 0;
        if (fscanf(f, "%d", &v) == 1) g_fps = (v >= 20 && v <= 120) ? v : 0;
        fclose(f);
    } else {
        f = fopen(FPSF, "w");
        if (f) { fprintf(f, "0\n"); fclose(f); }
    }
    f = fopen(SCLF, "r");
    if (f) {
        int v = 65;
        if (fscanf(f, "%d", &v) == 1) g_scale = (v >= 20 && v <= 99) ? v : 0;
        fclose(f);
    } else {
        f = fopen(SCLF, "w");
        if (f) { fprintf(f, "0\n"); fclose(f); }
    }
    f = fopen(FZF, "r");
    if (f) {
        int v = 1;
        if (fscanf(f, "%d", &v) == 1) g_fz = v ? 1 : 0;
        fclose(f);
    } else {
        f = fopen(FZF, "w");
        if (f) { fprintf(f, "1\n"); fclose(f); }
    }
    g_live_on = 0;                                  /* v0.76: optional, never created here */
    f = fopen(LIVEF, "r");
    if (f) { int v = 0; if (fscanf(f, "%d", &v) == 1) g_live_on = v ? 1 : 0; fclose(f); }
    g_lv_cap = 0;                                   /* v0.78: optional, never created here; capture window open from the start (live mode must be on) */
    f = fopen(LIVECAPF, "r");
    if (f) { int v = 0; if (fscanf(f, "%d", &v) == 1 && v && g_live_on.load()) g_lv_cap = 1; fclose(f); }
    g_spread_kb = 0;                                /* v0.71: optional, never created here; only a value of 256..32768 turns it on */
    f = fopen(SPREADF, "r");
    if (f) {
        int v = 0;
        if (fscanf(f, "%d", &v) == 1) g_spread_kb = (v >= 256 && v <= 32768) ? v : 0;
        fclose(f);
    }
    f = fopen(THF, "r");
    if (f) {
        int v = 1;
        if (fscanf(f, "%d", &v) == 1) g_th = v ? 1 : 0;
        fclose(f);
    } else {
        f = fopen(THF, "w");
        if (f) { fprintf(f, "1\n"); fclose(f); }
    }
    f = fopen(NEARF, "r");
    if (f) {
        int v = 1;
        if (fscanf(f, "%d", &v) == 1) g_near = v ? 1 : 0;
        fclose(f);
    } else {
        f = fopen(NEARF, "w");
        if (f) { fprintf(f, "1\n"); fclose(f); }
    }
    f = fopen(BLKF, "r");
    if (f) {
        int v = 16;
        if (fscanf(f, "%d", &v) == 1) g_blk = (v >= 4 && v <= 256) ? v : 0;
        fclose(f);
    } else {
        f = fopen(BLKF, "w");
        if (f) { fprintf(f, "0\n"); fclose(f); }
    }
    f = fopen(MINF, "r");
    if (f) {
        int v = 64;
        if (fscanf(f, "%d", &v) == 1) g_minsz = std::max(64, std::min(v, 2048));
        fclose(f);
    } else {
        f = fopen(MINF, "w");
        if (f) { fprintf(f, "64\n"); fclose(f); }
    }
    f = fopen(DLYF, "r");
    if (f) {
        int v = 0;
        if (fscanf(f, "%d", &v) == 1) g_delay = std::max(0, std::min(v, 120));
        fclose(f);
    } else {
        f = fopen(DLYF, "w");
        if (f) { fprintf(f, "0\n"); fclose(f); }
    }
    g_skip.clear();
    f = fopen(SKIPF, "r");
    if (f) {
        char ln[96];
        while (g_skip.size() < 128 && fgets(ln, sizeof ln, f)) {
            int a = 0, b = 0, c = 0;
            /* v0.38: %i also reads 0x9279 (hex); before, a hex format was read as 0 and the whole line was silently ignored */
            int n = sscanf(ln, "%i %i %i", &a, &b, &c);
            if (n == 2) g_skip.push_back({a, b, 0});
            else if (n == 3) g_skip.push_back({a, b, c});
            else if (ln[0] != '\n' && ln[0] != '#') L("SKIPRULE ignored (cannot read it): %.40s", ln);
        }
        for (auto &r : g_skip) L("SKIPRULE loaded fmt=%d a=%d b=%d (%s)\n", r.fmt, r.a, r.b, r.b ? "exact WxH" : (r.a ? "longest side" : "any size"));
        fclose(f);
    }
    g_bloff.clear();
    f = fopen(BLOFFF, "r");
    if (f) {
        char ln[96];
        while (g_bloff.size() < 16 && fgets(ln, sizeof ln, f)) {
            int a = 0, b = 0, c = 0;
            if (sscanf(ln, "%d %d %d", &a, &b, &c) == 3) g_bloff.push_back({a, b, c});
        }
        fclose(f);
    }
    f = fopen(STYF, "r");
    if (f) {
        int v = 0;
        if (fscanf(f, "%d", &v) == 1) g_style = std::max(0, std::min(v, 4));
        fclose(f);
    } else {
        f = fopen(STYF, "w");
        if (f) { fprintf(f, "0\n"); fclose(f); }
    }
    f = fopen(SEDF, "r");
    if (f) {
        int v = 1;
        if (fscanf(f, "%d", &v) == 1) g_sedge = v ? 1 : 0;
        fclose(f);
    } else {
        f = fopen(SEDF, "w");
        if (f) { fprintf(f, "1\n"); fclose(f); }
    }
    f = fopen(FLATF, "r");
    if (f) {
        int v = 0;
        if (fscanf(f, "%d", &v) == 1) g_flat = std::max(0, std::min(v, 8));
        fclose(f);
    } else {
        f = fopen(FLATF, "w");
        if (f) { fprintf(f, "0\n"); fclose(f); }
    }
    f = fopen(TTEXF, "r");
    if (f) {
        int v = 0;
        if (fscanf(f, "%d", &v) == 1) g_testtex = v ? 1 : 0;
        fclose(f);
    } else {
        f = fopen(TTEXF, "w");
        if (f) { fprintf(f, "1\n"); fclose(f); }
    }
    f = fopen(TTSZF, "r");
    if (f) {
        int v = 0;
        if (fscanf(f, "%d", &v) == 1) g_ttsize = std::max(-2, std::min(v, 3));
        fclose(f);
    } else {
        f = fopen(TTSZF, "w");
        if (f) { fprintf(f, "0\n"); fclose(f); }
    }
    f = fopen(TTSMF, "r");
    if (f) {
        int v = 0;
        if (fscanf(f, "%d", &v) == 1) g_ttsm = std::max(0, std::min(v, 1));
        fclose(f);
    } else {
        f = fopen(TTSMF, "w");
        if (f) { fprintf(f, "0\n"); fclose(f); }
    }
    f = fopen(ALPHAF, "r");                        /* v0.44: Keep alpha soft, default ON */
    if (f) {
        int v = 1;
        if (fscanf(f, "%d", &v) == 1) g_alpha = v ? 1 : 0;
        fclose(f);
    } else {
        g_alpha = 1;
        f = fopen(ALPHAF, "w");
        if (f) { fprintf(f, "1\n"); fclose(f); }
    }
    {   /* v0.81: Keep ASTC soft, the probe (log only) and Box loot (device spoof, OFF by default) */
        auto rdi = [](const char *path, int def) -> int { int v = def; FILE *q = fopen(path, "r"); if (q) { if (fscanf(q, "%d", &v) != 1) v = def; fclose(q); } return v; };
        g_astc = rdi(ASTCF, 0) ? 1 : 0;
        g_probe = rdi(PROBEF, 1) ? 1 : 0;
        int bl = rdi(BLF, 0) ? 1 : 0;
        int ram = rdi(BLRAMF, 0);
        g_bl_ram = ram <= 0 ? 0 : std::max(512, std::min(ram, 16384));
        g_bl_gpu = rdi(BLGPUF, 1) ? 1 : 0;
        g_bl_pvr = rdi(BLPVRF, 1) ? 1 : 0;
        if (access(BLRUNF, F_OK) == 0) {                     /* the last launch with Box loot ON did not reach 20 frames (crash or closed at once) */
            int fr = 0; FILE *mf = fopen(BLRUNF, "r"); if (mf) { if (fscanf(mf, "%d", &fr) != 1) fr = 0; fclose(mf); }
            unlink(BLRUNF);
            if (bl && fr < 20) { bl = 0; write_int_atomic(BLF, 0); st_set("bl_safety", "1"); L("SAFETY: the last launch with Box loot ON did not reach 20 frames -> Box loot switched OFF (boxloot.txt=0). Other settings unchanged.\n"); }
        }
        g_bl = bl;
        if (bl) { FILE *mf = fopen(BLRUNF, "w"); if (mf) { fprintf(mf, "0\n"); fclose(mf); } g_bl_marked = 1; }
        st_seti("bl", bl); st_seti("probe", g_probe.load()); st_seti("astc", g_astc.load());
        if (bl) L("BOXLOOT ON: gpu=%d ram=%dMB pvrtc=%d (a different answer is given only to libunity)\n", g_bl_gpu.load(), g_bl_ram.load(), g_bl_pvr.load());
        if (g_astc.load()) L("ASTC soft ON: ASTC textures stay untouched\n");
    }
    g_grass.clear(); g_grass_range_old = g_grass_over = g_grass_dups = g_grass_bad = 0;
    f = fopen(GRASSF, "r");
    if (!f) f = fopen(GRASSOLDF, "r");             /* v0.70: hidden.txt missing = old install. An existing but EMPTY hidden.txt is a real "all off" and never falls back */
    /* v0.57: exact "format width height hash" per line (max 4096); missing or empty = off */
    if (f) {
        std::vector<GrRule> got;                   /* accepted rules, file order */
        std::set<std::tuple<int, int, int, uint64_t>> have;
        char ln[256];
        while (fgets(ln, sizeof ln, f)) {
            if (!strchr(ln, '\n') && !feof(f)) {   /* longer than the buffer: it is not a rule; skip the rest of this line */
                int ch; while ((ch = fgetc(f)) != EOF && ch != '\n') {}
                g_grass_bad++; L("GRASSRULE ignored (line too long): %.40s\n", ln); continue;
            }
            for (char *q = ln + strlen(ln); q > ln && (q[-1] == '\n' || q[-1] == '\r'); ) *--q = 0;
            GrRule r{0, 0, 0, 0};
            int kind = grass_parse_line(ln, &r);
            if (kind == GRL_SKIP) continue;
            if (kind == GRL_RANGE) { if (++g_grass_range_old == 1) L("GRASSRULE obsolete range rule ignored (v0.57 supports exact textures only): %.60s\n", ln); continue; }
            if (kind == GRL_LEGACY) { g_grass_bad++; L("GRASSRULE old v0.44 line ignored (it matched too many textures): %.40s\n", ln); continue; }
            if (kind != GRL_RULE) { g_grass_bad++; L("GRASSRULE ignored (cannot read it): %.40s\n", ln); continue; }
            if (!have.insert(std::make_tuple(r.fmt, r.w, r.h, r.hash)).second) { g_grass_dups++; continue; }
            if ((int)got.size() >= GRASS_MAX_RULES) { g_grass_over++; continue; }
            got.push_back(r);
        }
        fclose(f);
        if (g_grass_range_old > 1) L("GRASSRULE %d obsolete range rules ignored in total\n", g_grass_range_old);
        if (g_grass_over > 0) L("GRASSRULE limit: only the first %d unique rules are used, %d more ignored\n", GRASS_MAX_RULES, g_grass_over);
        if (g_grass_dups > 0) L("GRASSRULE %d duplicate rules ignored\n", g_grass_dups);
        std::sort(got.begin(), got.end(), grass_rule_less);
        g_grass.swap(got);
        if (g_grass.size() <= 64) for (auto &r : g_grass) L("GRASSRULE loaded fmt=%d %dx%d h=%016llx\n", r.fmt, r.w, r.h, (unsigned long long)r.hash);
        else L("GRASSRULE loaded %d exact rules\n", (int)g_grass.size());
    }
    g_grass_on = g_grass.empty() ? 0 : 1;
    g_orig.clear(); g_orig_range_old = g_orig_over = g_orig_dups = g_orig_bad = 0;
    f = fopen(ORIGF, "r");                         /* v0.61: Restore original, exact "format width height hash" per line (max 4096); missing or empty = off */
    if (f) {
        std::vector<GrRule> got;
        std::set<std::tuple<int, int, int, uint64_t>> have;
        char ln[256];
        while (fgets(ln, sizeof ln, f)) {
            if (!strchr(ln, '\n') && !feof(f)) {
                int ch; while ((ch = fgetc(f)) != EOF && ch != '\n') {}
                g_orig_bad++; L("ORIGRULE ignored (line too long): %.40s\n", ln); continue;
            }
            for (char *q = ln + strlen(ln); q > ln && (q[-1] == '\n' || q[-1] == '\r'); ) *--q = 0;
            GrRule r{0, 0, 0, 0};
            int kind = grass_parse_line(ln, &r);
            if (kind == GRL_SKIP) continue;
            if (kind == GRL_RANGE) { g_orig_range_old++; continue; }
            if (kind != GRL_RULE) { g_orig_bad++; L("ORIGRULE ignored (cannot read it): %.40s\n", ln); continue; }
            if (!have.insert(std::make_tuple(r.fmt, r.w, r.h, r.hash)).second) { g_orig_dups++; continue; }
            if ((int)got.size() >= ORIG_MAX_RULES) { g_orig_over++; continue; }
            got.push_back(r);
        }
        fclose(f);
        if (g_orig_over > 0) L("ORIGRULE limit: only the first %d unique rules are used, %d more ignored\n", ORIG_MAX_RULES, g_orig_over);
        if (g_orig_dups > 0) L("ORIGRULE %d duplicate rules ignored\n", g_orig_dups);
        std::sort(got.begin(), got.end(), grass_rule_less);
        g_orig.swap(got);
        if (g_orig.size() <= 64) for (auto &r : g_orig) L("ORIGRULE loaded fmt=%d %dx%d h=%016llx\n", r.fmt, r.w, r.h, (unsigned long long)r.hash);
        else L("ORIGRULE loaded %d exact rules\n", (int)g_orig.size());
    }
    g_orig_on = g_orig.empty() ? 0 : 1;
    if (FILE *ff = fopen(FULLF, "r")) {
        int fw = 0, fh = 0;
        if (fscanf(ff, "%d %d", &fw, &fh) == 2 && fw >= 640 && fw <= 8192 && fh >= 360 && fw >= fh) { g_fullw = fw; g_fullh = fh; }
        fclose(ff);
    }
    if (access(SCRASHF, F_OK) == 0) {           /* previous launch did not reach 120 frames with render scale active (crash OR closed early) */
        int prev = 0, fr = 0;
        FILE *mf = fopen(SCRASHF, "r");
        if (mf) { if (fscanf(mf, "%d %d", &prev, &fr) < 1) prev = 0; fclose(mf); }
        unlink(SCRASHF);
        /* v0.38: a launch that rendered 20+ frames was not a boot loop (the game was just closed): keep the user's scale. */
        if (fr >= 20) L("SAFETY: last launch rendered %d frames with render scale %d%% then ended: not treated as a crash, scale kept\n", fr, prev);
        else if (g_scale.load() > 0) {
            g_scale = 0;
            write_int_atomic(SCLF, 0);                 /* only scale.txt changes; no other setting is touched */
            L("SAFETY: last launch did not reach 120 frames with render scale %d%% on (crash or closed early) -> render scale forced OFF (scale.txt=0). Other settings unchanged.\n", prev);
            g_scale_safety = prev > 0 ? prev : 1;
        }
    }
    g_tstart = now_ns();
    f = fopen(FGLF, "r");                          /* v0.41: force OpenGL ES, default ON (a missing file counts as 1) */
    if (f) {
        int v = 1;
        if (fscanf(f, "%d", &v) == 1) g_forcegl = v ? 1 : 0;
        fclose(f);
    } else {
        g_forcegl = 1;
        f = fopen(FGLF, "w");
        if (f) { fprintf(f, "1\n"); fclose(f); }
    }
    f = fopen(COREF, "r");
    if (f) {
        int v = 1;
        if (fscanf(f, "%d", &v) == 1) g_core = v ? 1 : 0;
        fclose(f);
    } else {
        f = fopen(COREF, "w");
        if (f) { fprintf(f, "1\n"); fclose(f); }
    }
}

/* mode.txt:
     0 = idle
     1 = background thread only
     2 = thread + locate libunity (no hooks)
     3 = full hooks, installed by polling
     4 = hook libunity as soon as it loads (no polling thread) */
static int read_mode() {
    /* v26: the module always runs in mode 4. mode.txt is no longer a switch; it is only kept
       (and repaired here) so the WebUI shows the right value. A missing, empty or wrong file
       can no longer turn the module off. */
    int v = -1;
    FILE *f = fopen(MODEF, "r");
    if (f) {
        if (fscanf(f, "%d", &v) != 1) v = -1;
        fclose(f);
    }
    if (v != 4) {
        f = fopen(MODEF, "w");
        if (f) { fprintf(f, "4\n"); fclose(f); }
    }
    return 4;
}

/* hookdelay.txt: 0 = hook the moment libunity loads (default).
   N > 0 = wait N seconds after libunity appears, then hook. Slower, but can avoid
   clashes with other loaders / injectors that touch the same library at startup. */
static int read_hookdelay() {
    int v = 0;
    FILE *f = fopen(HDLYF, "r");
    if (f) {
        if (fscanf(f, "%d", &v) != 1) v = 0;
        fclose(f);
    }
    return std::max(0, std::min(v, 30));
}

/* Register every hook on a single libunity mapping */
static void reg_hooks(dev_t dv, ino_t in) {
    if (g_forcegl.load()) {
        lsplt::RegisterHook(dv, in, "dlopen", (void *)h_dlopen_u, (void **)&o_dlopen_u);
        lsplt::RegisterHook(dv, in, "android_dlopen_ext", (void *)h_adle_u, (void **)&o_adle_u);
    }
    lsplt::RegisterHook(dv, in, "dlsym", (void *)h_dlsym, (void **)&o_dlsym);
    lsplt::RegisterHook(dv, in, "eglGetProcAddress", (void *)h_egl, (void **)&o_egl);
    lsplt::RegisterHook(dv, in, "glTexStorage2D", (void *)h_st, (void **)&o_st);
    if (g_bl.load() || g_probe.load()) {                    /* v0.81: probe (log only) and Box loot: libunity's own table only */
        lsplt::RegisterHook(dv, in, "glGetString", (void *)h_gets, (void **)&o_gets);
        lsplt::RegisterHook(dv, in, "glGetStringi", (void *)h_getsi, (void **)&o_getsi);
        lsplt::RegisterHook(dv, in, "open", (void *)h_open, (void **)&o_open);
        lsplt::RegisterHook(dv, in, "openat", (void *)h_openat, (void **)&o_openat);
        lsplt::RegisterHook(dv, in, "fopen", (void *)h_fopen, (void **)&o_fopen);
        lsplt::RegisterHook(dv, in, "sysinfo", (void *)h_sysinfo, (void **)&o_sysinfo);
        lsplt::RegisterHook(dv, in, "sysconf", (void *)h_sysconf, (void **)&o_sysconf);
        lsplt::RegisterHook(dv, in, "__system_property_get", (void *)h_spg, (void **)&o_spg);
    }
    if (g_style.load() || g_flat.load() || g_testtex.load()) lsplt::RegisterHook(dv, in, "glTexParameterf", (void *)h_tpf, (void **)&o_tpf);
    if (g_near.load() || g_style.load() || g_flat.load() || g_testtex.load())
        lsplt::RegisterHook(dv, in, "glTexParameteri", (void *)h_tp, (void **)&real_tp);
    if (tex_track()) {
        lsplt::RegisterHook(dv, in, "glActiveTexture", (void *)h_act, (void **)&o_act);
        lsplt::RegisterHook(dv, in, "glBindTexture", (void *)h_bind, (void **)&o_bind);
        lsplt::RegisterHook(dv, in, "glDeleteTextures", (void *)h_del, (void **)&o_del);
        lsplt::RegisterHook(dv, in, "glSamplerParameteri", (void *)h_smp, (void **)&o_smp);
    }
    lsplt::RegisterHook(dv, in, "eglSwapBuffers", (void *)h_swap, (void **)&o_swap);
    lsplt::RegisterHook(dv, in, "eglCreateWindowSurface", (void *)h_cws, (void **)&o_cws);
    lsplt::RegisterHook(dv, in, "ANativeWindow_setBuffersGeometry", (void *)h_sbg, (void **)&o_sbg);
    if (g_fz.load()) {
        lsplt::RegisterHook(dv, in, "glCompileShader", (void *)h_comp, (void **)&o_comp);
        lsplt::RegisterHook(dv, in, "glLinkProgram", (void *)h_link, (void **)&o_link);
        lsplt::RegisterHook(dv, in, "glProgramBinary", (void *)h_pbin, (void **)&o_pbin);
        lsplt::RegisterHook(dv, in, "glBufferData", (void *)h_buf, (void **)&o_buf);
        lsplt::RegisterHook(dv, in, "glTexImage2D", (void *)h_ti2, (void **)&o_ti2);
        lsplt::RegisterHook(dv, in, "glCompressedTexImage2D", (void *)h_cti2, (void **)&o_cti2);
        lsplt::RegisterHook(dv, in, "glTexSubImage2D", (void *)h_tsi2, (void **)&o_tsi2);
        lsplt::RegisterHook(dv, in, "glCompressedTexSubImage2D", (void *)h_ctsi2, (void **)&o_ctsi2);
        lsplt::RegisterHook(dv, in, "glTexStorage3D", (void *)h_ts3, (void **)&o_ts3);
    } else {
        lsplt::RegisterHook(dv, in, "glCompressedTexImage2D", (void *)h_cti2, (void **)&o_cti2);
        lsplt::RegisterHook(dv, in, "glCompressedTexSubImage2D", (void *)h_ctsi2, (void **)&o_ctsi2);
    }
}

/* ---------- Mode 4: hook libunity right after it is loaded ---------- */
static std::atomic<bool> g_hooked{false};
static void *(*o_adle)(const char *, int, const android_dlextinfo *) = nullptr;
static void *h_adle(const char *path, int flags, const android_dlextinfo *info);

/* ---------- Coexistence diagnostics (v0.37, log only, no behaviour change) ----------
   chain_report: after CommitHook, say which library owns the function our hook will call as "original".
   A system library (libEGL, libandroid, libdl...) = clean. An app/anonymous mapping = another injector hooked that slot first.
   maps_report: executable mappings that are neither system libraries nor the game's own libs. */
static bool is_system_path(const std::string &p) {
    static const char *pre[] = {"/system/", "/system_ext/", "/apex/", "/vendor/", "/product/", "/odm/", "/linkerconfig/"};
    for (const char *x : pre) if (p.compare(0, strlen(x), x) == 0) return true;
    return false;
}
struct MapOwner { bool found = false; char perms[8] = {0}; std::string path; };
static MapOwner owner_of(const void *ptr) {
    MapOwner o;
    FILE *f = fopen("/proc/self/maps", "r");
    if (!f) return o;
    char line[768];
    unsigned long long a = (unsigned long long)(uintptr_t)ptr;
    while (fgets(line, sizeof line, f)) {
        unsigned long long s0 = 0, e0 = 0; char pm[8] = {0}; int off = 0;
        if (sscanf(line, "%llx-%llx %7s %*s %*s %*s %n", &s0, &e0, pm, &off) < 3) continue;
        if (a < s0 || a >= e0) continue;
        o.found = true; memcpy(o.perms, pm, sizeof pm);
        o.path = off > 0 ? line + off : "";
        while (!o.path.empty() && (o.path.back() == '\n' || o.path.back() == ' ')) o.path.pop_back();
        break;
    }
    fclose(f);
    return o;
}
static void chain_report(const char *tag) {
    struct C { const char *name; void *ptr; };
    C c[] = {
        {"android_dlopen_ext", (void *)o_adle}, {"dlsym", (void *)o_dlsym}, {"eglGetProcAddress", (void *)o_egl},
        {"glTexStorage2D", (void *)o_st}, {"eglSwapBuffers", (void *)o_swap},
        {"eglCreateWindowSurface", (void *)o_cws}, {"ANativeWindow_setBuffersGeometry", (void *)o_sbg},
    };
    std::string foreign;
    for (auto &x : c) {
        if (!x.ptr) { L("CHAIN %s %s orig=null (not imported by the hooked library)\n", tag, x.name); continue; }
        MapOwner o = owner_of(x.ptr);
        bool fr = !o.found || o.path.empty() || !is_system_path(o.path);
        L("CHAIN %s %s orig=%p in=%s perms=%s foreign=%d\n", tag, x.name, x.ptr,
          o.found ? (o.path.empty() ? "[anon]" : o.path.c_str()) : "[unmapped]", o.perms, fr ? 1 : 0);
        if (fr) { if (!foreign.empty()) foreign += ","; foreign += x.name; }
    }
    st_set("chain_foreign", foreign.empty() ? "none" : foreign);
}
static void maps_report(const char *tag) {
    FILE *f = fopen("/proc/self/maps", "r");
    if (!f) return;
    char line[768];
    std::set<std::string> seen;
    int anon_x = 0, shown = 0, total = 0;
    while (fgets(line, sizeof line, f)) {
        char pm[8] = {0}; int off = 0;
        if (sscanf(line, "%*[0-9a-fA-F]-%*[0-9a-fA-F] %7s %*s %*s %*s %n", pm, &off) < 1) continue;
        if (pm[2] != 'x') continue;                           /* executable mappings only */
        std::string p = off > 0 ? line + off : "";
        while (!p.empty() && (p.back() == '\n' || p.back() == ' ')) p.pop_back();
        if (p.empty()) { anon_x++; continue; }
        if (p[0] != '/' || is_system_path(p) || p.find(PKG) != std::string::npos) continue;
        if (!seen.insert(p).second) continue;
        total++;
        if (shown < 24) { shown++; L("MAPS %s non-system exec: %s\n", tag, p.c_str()); }
    }
    fclose(f);
    L("MAPS %s non_system_exec=%d anon_exec_no_path=%d\n", tag, total, anon_x);
    st_seti("maps_nonsys", total); st_seti("maps_anon_exec", anon_x);
}

static void install_unity_hooks() {
    if (g_hooked.exchange(true)) return;
    for (auto &m : lsplt::MapInfo::Scan()) {
        const std::string &p = m.path;
        if (p.size() < 12 || p.compare(p.size() - 12, 12, "/libunity.so") != 0) continue;
        st_set("stage", "hooking");              /* if the game dies inside CommitHook, codm_tex.status stops at "hooking" */
        maps_report("pre-commit");
        reg_hooks(m.dev, m.inode);
        L("pre-commit (unity)\n");
        bool ok = lsplt::CommitHook();
        g_hook_state = ok ? 1 : 2;
        st_set("hook", ok ? "committed" : "commit_failed"); st_set("stage", "hooked");
        L("commit=%d (unity)\n", (int)ok);
        chain_report("unity");
        return;
    }
    st_set("lib", "not_in_maps");
    L("libunity not found in maps\n");
    g_hooked = false;
}

static void *h_adle(const char *path, int flags, const android_dlextinfo *info) {
    { static std::atomic<int> first{0}; if (!first.exchange(1)) { st_set("adle_first", "1"); L("adle first call: %s\n", path ? path : "(null)"); } }
    auto oa = (o_adle && o_adle != h_adle) ? o_adle : nullptr;
    void *r = oa ? oa(path, flags, info) : android_dlopen_ext(path, flags, info);
    if (r && path) {
        size_t n = strlen(path);
        if (n >= 11 && !strcmp(path + n - 11, "libunity.so")) {
            st_set("lib", "loaded"); st_set("stage", "lib_loaded");
            L("dlopen libunity done: %s\n", path);
            install_unity_hooks();
        }
    }
    return r;
}

static void hook_nativeloader() {
    for (auto &m : lsplt::MapInfo::Scan()) {
        const std::string &p = m.path;
        if (p.size() < 19 || p.compare(p.size() - 19, 19, "/libnativeloader.so") != 0) continue;
        lsplt::RegisterHook(m.dev, m.inode, "android_dlopen_ext", (void *)h_adle, (void **)&o_adle);
        st_set("stage", "nl_hooking");
        bool ok = lsplt::CommitHook();
        L("nativeloader hook commit=%d\n", (int)ok);
        st_set("nl_hook", ok ? "committed" : "commit_failed"); st_set("stage", "nl_hooked");
        return;
    }
    L("libnativeloader not found\n");
    st_set("nl_hook", "not_found");
}

static void log_start(int mode) {
#if defined(__aarch64__)
    const char *abi = "arm64-v8a";
#elif defined(__arm__)
    const char *abi = "armeabi-v7a";
#else
    const char *abi = "other";
#endif
    L("=== start %s build=%s %s abi=%s mode=%d bias=%d fpscap=%d scale=%d fz=%d th=%d core=%d near=%d blk=%d min=%d delay=%d skip=%d style=%d sedge=%d flat=%d testtex=%d ttsize=%d ttsm=%d forcegl=%d builtin=%d alpha=%d grass=%d orig=%d ===\n",
      VERSION, __DATE__, __TIME__, abi, mode, g_bias.load(), g_fps.load(), g_scale.load(), g_fz.load(), g_th.load(), g_core.load(), g_near.load(), g_blk.load(), g_minsz.load(), g_delay.load(), (int)g_skip.size(), g_style.load(), g_sedge.load(), g_flat.load(), g_testtex.load(), g_ttsize.load(), g_ttsm.load(), g_forcegl.load(), (int)(sizeof g_builtin / sizeof g_builtin[0]), g_alpha.load(), (int)g_grass.size(), (int)g_orig.size());
    st_set("ver", VERSION); st_seti("pid", (long long)getpid()); st_set("abi", abi); st_set("stage", "started");
    st_set("forcegl", g_forcegl.load() ? "on" : "off");
    st_seti("spread_kb", g_spread_kb.load());
    if (g_spread_kb.load() > 0) L("NOTE spread=%d KB per frame: EXPERIMENTAL upload spreading is ON (delete spread.txt to turn it off)\n", g_spread_kb.load());
    st_set("alpha", g_alpha.load() ? "keep" : "off"); st_seti("grass_rules", (long long)g_grass.size()); st_seti("grass_range_old", g_grass_range_old); st_seti("grass_over", g_grass_over); st_seti("grass_max", GRASS_MAX_RULES);
    st_seti("orig_rules", (long long)g_orig.size()); st_seti("orig_over", g_orig_over); st_seti("orig_max", ORIG_MAX_RULES); st_seti("orig_n", 0); st_seti("orig_fix", 0);
    st_seti("started", (long long)time(nullptr));
    st_seti("live_fps", g_fps.load()); st_set("dir", g_dir); st_set("live", "1");
    st_set("scale_safety", g_scale_safety > 0 ? "forced_off_prev_" + std::to_string(g_scale_safety) : "no");
    st_set("cfg_bad", g_cfg_note.empty() ? "none" : g_cfg_note); st_seti("cfg_missing", g_cfg_missing);
    if (!g_cfg_note.empty()) L("CFG invalid or missing settings were replaced by defaults: %s\n", g_cfg_note.c_str());
    if (g_delay.load() > 0) L("NOTE delay=%d: textures created in the first %d s are modified once the delay is over (v0.38 revisits them)\n", g_delay.load(), g_delay.load());
}

/* ---------- Crash-in-hook breaker (v0.40) ----------
   The status file is rewritten at every stage. If the previous launch left "hooking" / "nl_hooking" behind, the game
   died inside CommitHook. Hooks are then skipped (hooksafe.txt=1) so the game starts clean; the WebUI shows a banner
   and a "Retry hooks" button that writes hooksafe.txt=0. */
static int g_safe = 0;
static std::string g_safe_why = "no";
static std::string read_status_key(const char *key) {
    FILE *f = fopen(STATF, "r");
    if (!f) return "";
    char line[256]; std::string out; size_t kl = strlen(key);
    while (fgets(line, sizeof line, f)) {
        if (strncmp(line, key, kl) == 0 && line[kl] == '=') { out = line + kl + 1; while (!out.empty() && (out.back() == '\n' || out.back() == '\r')) out.pop_back(); break; }
    }
    fclose(f);
    return out;
}
static void decide_safe(const std::string &prev_stage) {
    g_safe = 0; g_safe_why = "no";
    int v = 0;
    if (FILE *f = fopen(HSAFEF, "r")) { if (fscanf(f, "%d", &v) != 1) v = 0; fclose(f); }
    if (v == 1) { g_safe = 1; g_safe_why = "hooksafe_file"; }
    else if (prev_stage == "hooking" || prev_stage == "nl_hooking") {
        g_safe = 1; g_safe_why = "crash_in_" + prev_stage;
        write_int_atomic(HSAFEF, 1);
    }
    st_seti("hooksafe", g_safe); st_set("safe_why", g_safe_why);
    if (g_safe) { st_set("stage", "safe_mode"); __android_log_print(ANDROID_LOG_WARN, "codm_tex", "%s safe mode: hooks skipped (%s)", VERSION, g_safe_why.c_str()); }
}

static void run(int mode) {
    load_cfg();
    std::set<std::pair<dev_t, ino_t>> done;
    std::map<std::pair<dev_t, ino_t>, int64_t> first;   /* when libunity was first seen */
    log_start(mode);
    if (g_safe) { L("SAFE MODE: hooks skipped (%s). Press Retry hooks in the WebUI to try again.\n", g_safe_why.c_str()); st_set("stage", "safe_mode"); return; }
    int hd = read_hookdelay();
    int64_t settle_ns = (int64_t)std::max(3, hd) * 1000000000LL;   /* wait this long after libunity appears */
    if (mode >= 3) L("HOOK late: %d s after libunity appears\n", std::max(3, hd));
    int total = (mode == 1) ? 60 : 1200;
    for (int i = 0; i < total; i++) {
        if (mode >= 2) {
            bool added = false;
            for (auto &m : lsplt::MapInfo::Scan()) {
                const std::string &p = m.path;
                if (p.size() < 12 || p.compare(p.size() - 12, 12, "/libunity.so") != 0) continue;
                std::pair<dev_t, ino_t> key{m.dev, m.inode};
                if (done.count(key)) continue;
                auto it = first.find(key);
                if (it == first.end()) { first[key] = now_ns(); st_set("lib", "seen"); st_set("stage", "lib_loaded"); L("SEEN libunity i=%d\n", i); continue; }
                if (now_ns() - it->second < settle_ns) continue;   /* give libunity time to finish loading */
                done.insert(key);
                if (mode == 2) { L("mode2: stable, no hooks\n"); continue; }
                reg_hooks(m.dev, m.inode);
                added = true;
            }
            if (added) {
                L("pre-commit\n");
                st_set("stage", "hooking");
                maps_report("pre-commit-late");
                bool ok = lsplt::CommitHook();
                g_hook_state = ok ? 1 : 2;
                st_set("hook", ok ? "committed" : "commit_failed"); st_set("stage", "hooked");
                L("commit=%d\n", (int)ok);
                chain_report("late");
            }
        }
        sleep(1);
    }
}

#include "menu.inc"          /* v0.77: in-game menu loader (Java part: menu/q9/Menu.java) */

class M : public zygisk::ModuleBase {
    zygisk::Api *api; JNIEnv *env; bool target = false;
public:
    void onLoad(zygisk::Api *a, JNIEnv *e) override { api = a; env = e; menu_set_vm(e); }
    void preAppSpecialize(zygisk::AppSpecializeArgs *args) override {
        const char *n = env->GetStringUTFChars(args->nice_name, nullptr);
        target = n && strcmp(n, PKG) == 0;
        g_app_dir[0] = 0;
        if (!target && args->app_data_dir) {          /* clones / secondary users may use another process name */
            const char *d = env->GetStringUTFChars(args->app_data_dir, nullptr);
            if (d && strstr(d, PKG)) target = true;
            if (d) env->ReleaseStringUTFChars(args->app_data_dir, d);
        }
        if (target && args->app_data_dir) {               /* v0.40: remember where this copy of the game keeps its data */
            const char *d = env->GetStringUTFChars(args->app_data_dir, nullptr);
            if (d && strlen(d) < sizeof g_app_dir) snprintf(g_app_dir, sizeof g_app_dir, "%s", d);
            if (d) env->ReleaseStringUTFChars(args->app_data_dir, d);
        }
        /* Breadcrumb in logcat (tag codm_tex) for the game and anything that looks like it, so a
           "module never loaded" report can be told apart from "process name did not match". */
        if (n && (target || strstr(n, "garena") || strstr(n, "codm")))
            __android_log_print(ANDROID_LOG_INFO, "codm_tex", "%s preAppSpecialize nice_name=%s uid=%d target=%d", VERSION, n, (int)args->uid, (int)target);
        if (n) env->ReleaseStringUTFChars(args->nice_name, n);
        if (!target) api->setOption(zygisk::DLCLOSE_MODULE_LIBRARY);
    }
    void postAppSpecialize(const zygisk::AppSpecializeArgs *) override {
        if (!target) return;
        /* First thing the game process does: leave proof in logcat and in the status file, before any
           other settings / log work, so "module never loaded" can be told apart from "loaded, no log". */
        set_dir(g_app_dir[0] ? g_app_dir : nullptr);
        std::string prev_stage = read_status_key("stage");      /* BEFORE the first st_set below overwrites the file */
        int dir_ok = access(g_dir, W_OK) == 0;
        __android_log_print(ANDROID_LOG_INFO, "codm_tex", "%s postAppSpecialize target pid=%d dir_writable=%d", VERSION, (int)getpid(), dir_ok);
        st_set("ver", VERSION); st_seti("pid", (long long)getpid()); st_set("stage", "injected");
        st_seti("injected", (long long)time(nullptr)); st_set("dir_writable", dir_ok ? "yes" : "no"); st_set("dir", g_dir);
        st_set("live", "1");
        decide_safe(prev_stage);
        menu_launch();                                  /* v0.77: only when menu.txt = 1 (WebUI); never in safe mode */
        int mode = read_mode();
        if (mode == 4) {
            if (g_safe) { load_cfg(); log_start(4); L("SAFE MODE: hooks skipped (%s). Press Retry hooks in the WebUI to try again.\n", g_safe_why.c_str()); st_set("stage", "safe_mode"); return; }
            if (read_hookdelay() > 0) { std::thread(run, 3).detach(); return; }   /* late hooking: run() logs its own start line */
            load_cfg();
            log_start(4);
            L("HOOK early (at libunity load)\n");
            hook_nativeloader();
            return;
        }
        if (mode >= 1) std::thread(run, mode).detach();
    }
};
REGISTER_ZYGISK_MODULE(M)
