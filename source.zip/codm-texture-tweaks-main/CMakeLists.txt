cmake_minimum_required(VERSION 3.18)
project(codm_tex)

set(CMAKE_CXX_STANDARD 20)
set(CMAKE_LIBRARY_OUTPUT_DIRECTORY ${CMAKE_BINARY_DIR}/libs)
set(DEBUG_SYMBOLS_PATH ${CMAKE_BINARY_DIR}/symbols)

# LSPlt (PLT hook library) is cloned next to this file by the CI workflow.
add_subdirectory(LSPlt/lsplt/src/main/jni lsplt)

# v0.77: in-game menu. menu/build_dex.sh builds menu/q9/*.java into a dex and writes it as menu_dex.h. It never fails the build:
# without android.jar / d8 / javac (or when the Java does not compile) it writes an empty dex and the module just has no menu.
add_custom_command(OUTPUT ${CMAKE_BINARY_DIR}/menu_dex.h
    COMMAND sh ${CMAKE_SOURCE_DIR}/menu/build_dex.sh ${CMAKE_SOURCE_DIR}/menu ${CMAKE_BINARY_DIR}/menu_dex.h
    DEPENDS ${CMAKE_SOURCE_DIR}/menu/q9/Menu.java ${CMAKE_SOURCE_DIR}/menu/build_dex.sh
    VERBATIM)
add_custom_target(menu_dex DEPENDS ${CMAKE_BINARY_DIR}/menu_dex.h)

# v0.86: build mark. SHA-256 of the protected files that end up in the module zip, written into the .so as one string
# ("CODMSUM1 index=.. notice=.. license=.. customize=.. tag=.."). customize.sh reads it back (grep -a) and compares, so a changed WebUI /
# script / notice shows as MODIFIED at install time without anybody having to regenerate a manifest. The optional hidden tester tag (-DCODM_TESTER_ID=..
# from the workflow's tester_id input) is only inside this string, never printed.
set(CODM_TESTER_ID "" CACHE STRING "optional hidden tester tag (letters, digits, _ and -, at most 24)")
string(REGEX REPLACE "[^A-Za-z0-9_-]" "" CODM_TAG_CLEAN "${CODM_TESTER_ID}")
string(SUBSTRING "${CODM_TAG_CLEAN}" 0 24 CODM_TAG)
set(CODM_MARK "CODMSUM1")
foreach(pair index:webroot/index.html notice:webroot/NOTICE.txt license:webroot/LICENSE.txt customize:customize.sh)
    string(REPLACE ":" ";" pair_l "${pair}")
    list(GET pair_l 0 pk)
    list(GET pair_l 1 pf)
    file(SHA256 "${CMAKE_SOURCE_DIR}/${pf}" ph)
    string(APPEND CODM_MARK " ${pk}=${ph}")
    set_property(DIRECTORY APPEND PROPERTY CMAKE_CONFIGURE_DEPENDS "${CMAKE_SOURCE_DIR}/${pf}")
endforeach()
# v0.90: the display name / description fields of module.prop were not checked before (only id= and author=, by an exact-text
# grep in customize.sh). Their SHA-256 at build time is added to the SAME mark string, right after customize=, so a changed
# name/description shows the same way as a changed file above (MODIFIED) - no new kind of result.
set(CODM_MP_NAME "")
set(CODM_MP_DESC "")
file(STRINGS "${CMAKE_SOURCE_DIR}/module.prop" CODM_MP_LINES)
foreach(mpl ${CODM_MP_LINES})
    if(mpl MATCHES "^name=(.*)$")
        set(CODM_MP_NAME "${CMAKE_MATCH_1}")
    elseif(mpl MATCHES "^description=(.*)$")
        set(CODM_MP_DESC "${CMAKE_MATCH_1}")
    endif()
endforeach()
string(SHA256 CODM_MP_NAME_H "${CODM_MP_NAME}")
string(SHA256 CODM_MP_DESC_H "${CODM_MP_DESC}")
string(APPEND CODM_MARK " name=${CODM_MP_NAME_H} desc=${CODM_MP_DESC_H}")
set_property(DIRECTORY APPEND PROPERTY CMAKE_CONFIGURE_DEPENDS "${CMAKE_SOURCE_DIR}/module.prop")
if(NOT CODM_TAG STREQUAL "")
    string(APPEND CODM_MARK " tag=${CODM_TAG}")
endif()
file(WRITE ${CMAKE_BINARY_DIR}/build_mark.h "#define CODM_BUILD_MARK \"${CODM_MARK}\"\n")

# Zygisk module library; packaged as zygisk/<abi>.so.
add_library(codm_tex SHARED main.cpp)
add_dependencies(codm_tex menu_dex)
target_include_directories(codm_tex PRIVATE
    ${CMAKE_SOURCE_DIR}
    ${CMAKE_BINARY_DIR}
    ${CMAKE_SOURCE_DIR}/LSPlt/lsplt/src/main/jni/include)
target_link_libraries(codm_tex lsplt_static log android)

# v0.40: 16 KB page-size phones (Android 15+) need segments aligned to 16 KB. NDK r28+ does this by default; older
# NDKs on the runner need the flag. Harmless on r28+.
target_link_options(codm_tex PRIVATE -Wl,-z,max-page-size=16384)

# v0.90: release hardening - applies only to the finished zygisk/<abi>.so (the same CMake build the GitHub workflow runs for a real
# release), never to the host tests (tests/run_host_tests.sh compiles a separate copy of main.cpp with g++ directly, without CMake
# or Android.toolchain.cmake at all, so none of this can affect it). The compiler's optimization level is NOT changed here; it stays
# whatever CMAKE_BUILD_TYPE=Release already sets.
if(CMAKE_BUILD_TYPE STREQUAL "Release")
    # Hide every symbol by default (function/variable names do not end up in the .so's dynamic symbol table), except the two entries
    # Zygisk itself needs: zygisk.hpp declares zygisk_module_entry / zygisk_companion_entry with explicit default visibility, so those
    # two stay exported regardless of this setting.
    set_target_properties(codm_tex PROPERTIES CXX_VISIBILITY_PRESET hidden VISIBILITY_INLINES_HIDDEN ON)
    if(CMAKE_STRIP)
        add_custom_command(TARGET codm_tex POST_BUILD
            COMMAND ${CMAKE_STRIP} --strip-unneeded "$<TARGET_FILE:codm_tex>"
            COMMENT "v0.90: strip local symbol names from the finished .so (release build only; keeps the dynamic symbols the loader needs)")
    endif()
endif()
