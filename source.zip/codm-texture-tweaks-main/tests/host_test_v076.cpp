/* v0.76: live test mode (live.txt): MARK, capture window, live hide / show / restore on the render thread, rules re-read while playing. */
#include "main_test_copy.cpp"
extern "C" int __android_log_print(int,const char*,const char*,...){return 0;}
extern "C" int __android_log_vprint(int,const char*,const char*,va_list){return 0;}
static int fails=0;
#define CHECK(c) do{if(!(c)){printf("FAIL line %d: %s\n",__LINE__,#c);fails++;}}while(0)
static void wr(const char *p,const char *s){FILE*f=fopen(p,"w");if(f){fputs(s,f);fclose(f);}}
static std::string rd(const char *p){FILE*f=fopen(p,"r");if(!f)return "";std::string s;char b[4096];while(size_t n=fread(b,1,sizeof b,f))s.append(b,n);fclose(f);return s;}
static int g_tex_bound=7, g_real_pbo=0;
static std::set<GLuint> g_alive;
struct Call{GLuint id; GLint l; GLsizei n; uint8_t first;};
static std::vector<Call> g_calls;
static std::vector<std::pair<int,int>> g_tp;
static void fake_giv(GLenum e,GLint *v){ if(e==0x88EF)*v=g_real_pbo; else if(e==0x8069)*v=g_tex_bound; else *v=0; }
static GLboolean fake_is(GLuint id){return g_alive.count(id)?1:0;}
static void fake_bb(GLenum,GLuint b){g_real_pbo=(int)b;}
static void fake_bind(GLenum,GLuint id){g_tex_bound=(int)id;}
static void fake_ctsi2(GLenum,GLint l,GLint,GLint,GLsizei,GLsizei,GLenum,GLsizei n,const void*p){ g_calls.push_back({(GLuint)g_tex_bound,l,n,(p && !g_real_pbo)?*(const uint8_t*)p:(uint8_t)0}); }
static void fake_del(GLsizei,const GLuint*){}
static void fake_tp(GLenum,GLenum pn,GLint v){ g_tp.push_back({(int)pn,(int)v}); }
static std::vector<uint8_t> mk(int n,uint8_t v){return std::vector<uint8_t>(n,v);}
static int64_t T=0;
static void poll(){ T+=2000000000LL; live_poll(T); lv_apply(); }
static int ntex(){ std::lock_guard<std::mutex> lk(g_lvmu); return (int)g_lvt.size(); }
int main(){
  unlink(LIVEF); unlink(MARKF); unlink(LIVECF); wr(GRASSF,""); wr(ORIGF,""); load_cfg(); log_start(4);
  g_giv_hook=fake_giv; g_sp_is_hook=fake_is; g_sp_bb_hook=fake_bb; o_bind=fake_bind; o_ctsi2=fake_ctsi2; o_del=fake_del; real_tp=fake_tp; tl_unit=0;
  g_near=0; g_testtex=0; g_style=0; g_flat=0; g_blk=0; g_alpha=0; g_grass_on=0; g_orig_on=0; g_minsz=64; g_delay=0;
  g_rt=(pid_t)syscall(SYS_gettid); g_t0=1;
  for(GLuint i=1;i<=12;i++)g_alive.insert(i);

  /* OFF by default: nothing is captured, tracking is not forced */
  CHECK(g_live_on.load()==0 && g_lv_cap.load()==0);
  auto A=mk(262144,11), B=mk(262144,22);
  tl_bound[0]=2; g_tex_bound=2; h_ctsi2(GL_TEXTURE_2D,0,0,0,512,512,0x9279,(GLsizei)A.size(),A.data());
  CHECK(ntex()==0);
  wr(LIVEF,"1\n"); load_cfg(); CHECK(g_live_on.load()==1); CHECK(tex_track());
  wr(LIVEF,"7\n"); load_cfg(); CHECK(g_live_on.load()==1);
  wr(LIVEF,"0\n"); load_cfg(); CHECK(g_live_on.load()==0);
  wr(LIVEF,"1\n"); load_cfg();

  /* first poll only takes a baseline */
  poll(); CHECK(g_lv_cap.load()==0);
  /* uploads while the window is closed are not kept */
  g_calls.clear(); h_ctsi2(GL_TEXTURE_2D,0,0,0,512,512,0x9279,(GLsizei)A.size(),A.data()); CHECK(ntex()==0 && g_calls.size()==1);

  /* MARK A opens the window */
  wr(MARKF,"A\n"); poll(); CHECK(g_lv_cap.load()==1);
  CHECK(rd(P("codm_tex.log")).find("MARK A t=")!=std::string::npos);
  /* a copy of the ORIGINAL data of every compressed upload; level 0 gives the fingerprint */
  tl_bound[0]=2; g_tex_bound=2; h_ctsi2(GL_TEXTURE_2D,0,0,0,512,512,0x9279,(GLsizei)A.size(),A.data());
  tl_bound[0]=2; h_ctsi2(GL_TEXTURE_2D,1,0,0,256,256,0x9279,(GLsizei)65536,A.data());
  tl_bound[0]=3; g_tex_bound=3; h_ctsi2(GL_TEXTURE_2D,0,0,0,512,512,0x9279,(GLsizei)B.size(),B.data());
  CHECK(ntex()==2);
  uint64_t hA=tex_hash(A.data(),(int)A.size()), hB=tex_hash(B.data(),(int)B.size());
  { std::lock_guard<std::mutex> lk(g_lvmu); CHECK(g_lvt[0].has0 && g_lvt[0].hash==hA && g_lvt[0].lv.size()==2 && g_lvt[1].hash==hB); }
  std::fill(A.begin(),A.end(),0);                                      /* the game reuses its buffer: the copy must not change */
  { std::lock_guard<std::mutex> lk(g_lvmu); CHECK(g_lvt[0].lv[0].d[0]==11); }
  /* a pixel buffer upload is never copied */
  g_real_pbo=9; tl_bound[0]=4; g_tex_bound=4; h_ctsi2(GL_TEXTURE_2D,0,0,0,512,512,0x9279,(GLsizei)B.size(),(const void*)0x10); g_real_pbo=0; CHECK(ntex()==2);
  /* a new picture for the same level 0 replaces the old copy */
  auto A2=mk(262144,33); tl_bound[0]=2; g_tex_bound=2; h_ctsi2(GL_TEXTURE_2D,0,0,0,512,512,0x9279,(GLsizei)A2.size(),A2.data());
  { std::lock_guard<std::mutex> lk(g_lvmu); CHECK(g_lvt[0].lv.size()==1 && g_lvt[0].hash==tex_hash(A2.data(),(int)A2.size())); }
  auto A1=mk(262144,11); tl_bound[0]=2; h_ctsi2(GL_TEXTURE_2D,0,0,0,512,512,0x9279,(GLsizei)A1.size(),A1.data());  /* back to the first picture */
  { std::lock_guard<std::mutex> lk(g_lvmu); CHECK(g_lvt[0].hash==hA); }

  /* MARK B closes the window: copies stay, no new ones */
  wr(MARKF,"B\n"); poll(); CHECK(g_lv_cap.load()==0 && ntex()==2);
  tl_bound[0]=5; g_tex_bound=5; h_ctsi2(GL_TEXTURE_2D,0,0,0,512,512,0x9279,(GLsizei)B.size(),B.data()); CHECK(ntex()==2);

  /* LIVE hide: blank data, same size, uploaded on the render thread; the game's binding comes back */
  uint8_t blk[16]; int bs=blank_block(0x9279,blk); CHECK(bs>0);
  char buf[64]; snprintf(buf,sizeof buf,"h %016llx\n",(unsigned long long)hA); wr(LIVECF,buf);
  g_calls.clear(); g_tex_bound=7; poll();
  CHECK(g_calls.size()==1 && g_calls[0].id==2 && g_calls[0].first==blk[0] && g_calls[0].n==262144 && g_calls[0].l==0);   /* level 1 was dropped when level 0 came again */
  CHECK(g_tex_bound==7);
  { std::lock_guard<std::mutex> lk(g_lvmu); CHECK(g_lvt[0].state==1 && g_lvt[1].state==0); }
  /* LIVE show: the original data again */
  snprintf(buf,sizeof buf,"u %016llx\n",(unsigned long long)hA); wr(LIVECF,buf);
  g_calls.clear(); poll(); CHECK(g_calls.size()==1 && g_calls[0].first==11 && g_tex_bound==7);
  { std::lock_guard<std::mutex> lk(g_lvmu); CHECK(g_lvt[0].state==0); }
  /* LIVE restore: the texture parameters are put back (filters, base level, max level, min lod) */
  snprintf(buf,sizeof buf,"r %016llx\n",(unsigned long long)hB); wr(LIVECF,buf);
  g_calls.clear(); g_tp.clear(); poll(); CHECK(g_calls.empty() && g_tp.size()==5 && g_tex_bound==7);
  /* unknown hash / bad lines: nothing happens */
  wr(LIVECF,"h 00000000000000ff\nx 1234\nh zz\nh 12345678901234567\n"); g_calls.clear(); poll(); CHECK(g_calls.empty());
  CHECK(rd(P("codm_tex.log")).find("not_captured=1")!=std::string::npos);
  /* a pixel buffer bound at that moment is put back */
  snprintf(buf,sizeof buf,"u %016llx\n",(unsigned long long)hB); wr(LIVECF,buf); g_real_pbo=9; g_calls.clear(); poll(); CHECK(g_real_pbo==9 && g_calls.size()==1); g_real_pbo=0;
  /* a deleted texture is forgotten */
  GLuint d3=3; h_del(1,&d3); g_alive.erase(3); CHECK(ntex()==1);
  snprintf(buf,sizeof buf,"h %016llx\n",(unsigned long long)hB); wr(LIVECF,buf); g_calls.clear(); poll(); CHECK(g_calls.empty());
  /* a texture that no longer exists in GL when its turn comes is skipped */
  g_alive.erase(2); snprintf(buf,sizeof buf,"h %016llx\n",(unsigned long long)hA); wr(LIVECF,buf); g_calls.clear(); poll(); CHECK(g_calls.empty()); g_alive.insert(2);

  /* MARK X frees everything */
  wr(MARKF,"X\n"); poll(); CHECK(ntex()==0); { std::lock_guard<std::mutex> lk(g_lvmu); CHECK(g_lv_bytes==0); }
  /* capture limits: 64 MB */
  wr(MARKF,"A\n"); poll(); auto big=mk(8<<20,5);
  for(GLuint i=1;i<=12;i++){ tl_bound[0]=i; g_tex_bound=i; h_ctsi2(GL_TEXTURE_2D,0,0,0,2048,2048,0x9279,(GLsizei)big.size(),big.data()); }
  { std::lock_guard<std::mutex> lk(g_lvmu); CHECK(g_lv_bytes<=LV_MAX_BYTES); } CHECK(g_lv_full.load()>=1);
  wr(MARKF,"X\n"); poll(); { std::lock_guard<std::mutex> lk(g_lvmu); CHECK(g_lv_bytes==0 && g_lvt.empty()); }
  /* 20 minutes without use gives the memory back */
  wr(MARKF,"A\n"); poll(); tl_bound[0]=2; g_tex_bound=2; h_ctsi2(GL_TEXTURE_2D,0,0,0,512,512,0x9279,(GLsizei)B.size(),B.data()); CHECK(ntex()==1);
  T+=1300LL*1000000000LL; live_poll(T); CHECK(ntex()==0 && g_lv_cap.load()==0);

  /* rules re-read while playing */
  CHECK(g_grass.empty() && g_grass_on.load()==0);
  wr(GRASSF,"37497 512 512 14d49f3bf0a7aecb\n"); poll();
  CHECK(g_grass.size()==1 && g_grass_on.load()==1 && grass_rule_match(37497,512,512,0x14d49f3bf0a7aecbULL));
  wr(ORIGF,"37497 256 256 39e797c518477967\n"); poll(); CHECK(g_orig.size()==1 && g_orig_on.load()==1);
  wr(GRASSF,""); poll(); CHECK(g_grass.empty() && g_grass_on.load()==0 && g_orig_on.load()==1);
  CHECK(rd(P("codm_tex.log")).find("RULES reloaded")!=std::string::npos);
  printf(fails?"v076: %d FAILED\n":"v076 ok\n",fails);
  return fails?1:0;
}
