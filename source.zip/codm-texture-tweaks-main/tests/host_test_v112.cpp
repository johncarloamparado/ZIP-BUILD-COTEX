/* v1.12: B5 native signature check (sigcheck.h) + companion verdict in decide_safe + HMIN line (hitches per minute) + BUILD line (B7). */
#include "main_test_copy.cpp"
#include <sys/socket.h>
extern "C" int __android_log_print(int,const char*,const char*,...){return 0;}
extern "C" int __android_log_vprint(int,const char*,const char*,va_list){return 0;}
static int fails=0;
#define CHECK(c) do{if(!(c)){printf("FAIL line %d: %s\n",__LINE__,#c);fails++;}}while(0)
static void wr(const char *p,const char *s){FILE*f=fopen(p,"w");if(f){fputs(s,f);fclose(f);}}
static std::string rd(const char *p){FILE*f=fopen(p,"r");if(!f)return "";std::string s;char b[4096];while(size_t n=fread(b,1,sizeof b,f))s.append(b,n);fclose(f);return s;}
static int count(const std::string &h,const char *n){int c=0;size_t p=0;while((p=h.find(n,p))!=std::string::npos){c++;p+=strlen(n);}return c;}
static std::vector<sigc::u8> unhex(const char *h){std::vector<sigc::u8> o;for(size_t i=0;h[i]&&h[i+1];i+=2){unsigned v;sscanf(h+i,"%2x",&v);o.push_back((sigc::u8)v);}return o;}
static std::string sh(const std::string &c){std::string o;FILE*p=popen((c+" 2>/dev/null").c_str(),"r");if(!p)return o;char b[512];while(size_t n=fread(b,1,sizeof b,p))o.append(b,n);pclose(p);while(!o.empty()&&(o.back()=='\n'))o.pop_back();return o;}
static bool have(const char *tool){return sh(std::string("command -v ")+tool).size()>0;}

int main(){
  using namespace sigc;
  /* ---- hashes (standard vectors) ---- */
  { Sha256 s; u8 d[32]; s.update("abc",3); s.final(d); CHECK(hex(d,32)=="ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad"); }
  { Sha256 s; u8 d[32]; s.final(d); CHECK(hex(d,32)=="e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"); }
  { Sha256 s; u8 d[32]; const char *m="abcdbcdecdefdefgefghfghighijhijkijkljklmklmnlmnomnopnopq"; s.update(m,strlen(m)); s.final(d); CHECK(hex(d,32)=="248d6a61d20638b8e5c026930c3e6039a33ce45964ff2167f6ecedd419db06c1"); }
  { Sha256 s; u8 d[32]; std::string a(1000000,'a'); for(size_t i=0;i<a.size();i+=777) s.update(a.data()+i,std::min<size_t>(777,a.size()-i)); s.final(d); CHECK(hex(d,32)=="cdc76e5c9914fb9281a1c7e284d73e67f1809a48a497200e046d39ccc7112cd0"); }
  { Sha512 s; u8 d[64]; s.update("abc",3); s.final(d); CHECK(hex(d,64)=="ddaf35a193617abacc417349ae20413112e6fa4e89a97ea20a9eeee64b55d39a2192992a274fc1a836ba3c23a3feebbd454d4423643ce80e2a9ac94fa54ca49f"); }
  /* ---- Ed25519 (RFC 8032 test 1 key; signatures made with an independent library) ---- */
  { auto pk=unhex("d75a980182b10ab7d54bfed3c964073a0ee172f3daa62325af021a68f707511a");
    auto s0=unhex("e5564300c360ac729086e2cc806e828a84877f1eb8e5d974d873e065224901555fb8821590a33bacc61e39701cf9b46bd25bf5f0595bbe24655141438e7a100b");
    auto s1=unhex("80d724b01e7ca260f4cc7f8de7c95f73cfac615bab1f762b6435b6ec26c8cf6d2c758dae2f87399a8eeda1cbcd2835ac5ba66d6ecaa3aba5e567a751053dc207");
    CHECK(ed25519_verify(s0.data(),(const u8*)"",0,pk.data()));
    CHECK(ed25519_verify(s1.data(),(const u8*)"abc",3,pk.data()));
    CHECK(!ed25519_verify(s1.data(),(const u8*)"abd",3,pk.data()));          /* other message */
    CHECK(!ed25519_verify(s0.data(),(const u8*)"abc",3,pk.data()));          /* other signature */
    auto bad=s1; bad[40]^=1; CHECK(!ed25519_verify(bad.data(),(const u8*)"abc",3,pk.data()));
    bad=s1; bad[3]^=0x80; CHECK(!ed25519_verify(bad.data(),(const u8*)"abc",3,pk.data()));
    auto pk2=pk; pk2[5]^=1; CHECK(!ed25519_verify(s1.data(),(const u8*)"abc",3,pk2.data()));
    bad=s1; for(int i=0;i<32;i++) bad[32+i]=0xff; CHECK(!ed25519_verify(bad.data(),(const u8*)"abc",3,pk.data()));   /* S >= L */
  }
  /* ---- verdict line ---- */
  { Verdict v; v.status="tampered"; v.reason="signature_invalid"; v.key8="71b05e3e"; Verdict w; CHECK(parse_verdict_line(verdict_line(v).c_str(),w)); CHECK(w.status=="tampered"&&w.reason=="signature_invalid"&&w.key8=="71b05e3e"&&w.rel12.empty());
    Verdict e; CHECK(!parse_verdict_line("garbage",e)); CHECK(!parse_verdict_line("V1 hacked x y z\n",e)); CHECK(!parse_verdict_line("V1 verified x\n",e));
    Verdict z; CHECK(parse_verdict_line("V1 unknown ../../etc - -\n",z)); CHECK(z.reason=="etc"); }
  /* ---- the pinned key in main.cpp is the one in webroot/check.sh ---- */
  { std::string chk=rd("../webroot/check.sh"); if(chk.empty()) chk=rd("webroot/check.sh"); if(chk.empty()) chk=rd(CODM_TEST_ROOT "/webroot/check.sh");
    CHECK(chk.find(std::string("CODM_PUBKEY_FP=\"")+CODM_PUBKEY_FP+"\"")!=std::string::npos); }
  /* ---- a signed folder made with openssl exactly like tools/sign_release.sh ---- */
  if(have("openssl")&&have("sha256sum")){
    char tpl[]="/tmp/codm_sig_XXXXXX"; std::string T=mkdtemp(tpl); std::string M=T+"/mod";
    sh("mkdir -p "+M+"/webroot "+M+"/zygisk "+M+"/META-INF/com/google/android; printf 'hello' > "+M+"/module.prop; printf 'page' > "+M+"/webroot/index.html; head -c 300000 /dev/urandom > "+M+"/zygisk/arm64-v8a.so; printf 'x' > "+M+"/customize.sh; printf 'u' > "+M+"/META-INF/com/google/android/update-binary");
    std::string K=T+"/key.pem", K2=T+"/key2.pem";
    sh("openssl genpkey -algorithm ED25519 -out "+K); sh("openssl genpkey -algorithm ED25519 -out "+K2);
    auto sign=[&](const std::string &key,const std::string &dir){ sh("cd "+dir+" && rm -f RELEASE.sha256 RELEASE.sig RELEASE.pub && openssl pkey -in "+key+" -pubout -out RELEASE.pub && find . -type f ! -name 'RELEASE.*' -print0 | sort -z | xargs -0 sha256sum > RELEASE.sha256 && openssl pkeyutl -sign -rawin -inkey "+key+" -in RELEASE.sha256 -out RELEASE.sig"); };
    auto fp=[&](const std::string &key){ return sh("openssl pkey -in "+key+" -pubout -outform DER | sha256sum | cut -d' ' -f1"); };
    sign(K,M); std::string FP=fp(K);
    Verdict v=sig_check_dir(M,FP.c_str());
    CHECK(v.status=="verified"); CHECK(v.reason.empty()); CHECK(v.key8==FP.substr(0,8)); CHECK(v.rel12.size()==12);
    CHECK(v.rel12==sh("sha256sum "+M+"/RELEASE.sha256 | cut -c1-12"));
    /* extra file that is not in the list: fine (same as check.sh) */
    sh("printf z > "+M+"/extra.txt"); CHECK(sig_check_dir(M,FP.c_str()).status=="verified");
    /* customize.sh deleted after the install and META-INF never extracted: fine */
    sh("rm -rf "+M+"/customize.sh "+M+"/META-INF"); CHECK(sig_check_dir(M,FP.c_str()).status=="verified");
    /* a signed file changed */
    sh("printf 'page2' > "+M+"/webroot/index.html"); v=sig_check_dir(M,FP.c_str()); CHECK(v.status=="tampered"&&v.reason=="signed_file_mismatch"); sh("printf 'page' > "+M+"/webroot/index.html");
    CHECK(sig_check_dir(M,FP.c_str()).status=="verified");
    /* a signed file is missing */
    sh("mv "+M+"/webroot/index.html "+T+"/idx"); v=sig_check_dir(M,FP.c_str()); CHECK(v.status=="tampered"&&v.reason=="signed_file_mismatch"); sh("mv "+T+"/idx "+M+"/webroot/index.html");
    /* the signed list was edited */
    sh("cp "+M+"/RELEASE.sha256 "+T+"/lst; sed -i '1d' "+M+"/RELEASE.sha256"); v=sig_check_dir(M,FP.c_str()); CHECK(v.status=="tampered"&&v.reason=="signature_invalid"); sh("cp "+T+"/lst "+M+"/RELEASE.sha256");
    /* signature bytes changed */
    sh("cp "+M+"/RELEASE.sig "+T+"/sig; printf 'Z' | dd of="+M+"/RELEASE.sig bs=1 seek=10 conv=notrunc"); v=sig_check_dir(M,FP.c_str()); CHECK(v.status=="tampered"&&v.reason=="signature_invalid"); sh("cp "+T+"/sig "+M+"/RELEASE.sig");
    CHECK(sig_check_dir(M,FP.c_str()).status=="verified");
    /* everything re-signed with ANOTHER key (internally consistent): refused because the pinned key differs */
    sign(K2,M); v=sig_check_dir(M,FP.c_str()); CHECK(v.status=="tampered"&&v.reason=="pubkey_mismatch");
    CHECK(sig_check_dir(M,fp(K2).c_str()).status=="verified");                 /* ... and it is fine for its own key, so the failure above is the pin */
    sign(K,M);
    /* RELEASE.pub is garbage */
    sh("printf 'not a key' > "+M+"/RELEASE.pub"); v=sig_check_dir(M,FP.c_str()); CHECK(v.status=="tampered"&&v.reason=="pubkey_mismatch"); sign(K,M);
    /* NOT a failure: files missing (unsigned), folder missing / unreadable, list odd -> never "tampered" */
    sh("rm -f "+M+"/RELEASE.sig"); v=sig_check_dir(M,FP.c_str()); CHECK(v.status=="unsigned"); sign(K,M);
    sh("rm -f "+M+"/RELEASE.sig "+M+"/RELEASE.sha256 "+M+"/RELEASE.pub"); v=sig_check_dir(M,FP.c_str()); CHECK(v.status=="unsigned"&&v.reason=="no_release_files"); sign(K,M);
    v=sig_check_dir(T+"/nothing",FP.c_str()); CHECK(v.status=="unknown"&&v.reason=="nodir");
    sh("chmod 000 "+M+"/RELEASE.sig"); if(getuid()!=0){ v=sig_check_dir(M,FP.c_str()); CHECK(v.status=="unknown"&&v.reason=="read_failed"); } sh("chmod 644 "+M+"/RELEASE.sig");
    CHECK(sig_check_dir(M,FP.c_str()).status=="verified");
    /* a list line with ".." is never followed */
    { std::string l=rd((M+"/RELEASE.sha256").c_str()); l+="0000000000000000000000000000000000000000000000000000000000000000  ./../x\n"; wr((M+"/RELEASE.sha256").c_str(),l.c_str());
      sh("openssl pkeyutl -sign -rawin -inkey "+K+" -in "+M+"/RELEASE.sha256 -out "+M+"/RELEASE.sig"); v=sig_check_dir(M,FP.c_str()); CHECK(v.status!="tampered"&&v.status!="verified"&&v.reason=="list_unparsable"); }
    sh("rm -rf "+T);
  } else printf("v1.12: openssl / sha256sum not found - signed-folder cases SKIPPED\n");
  /* ---- the companion handler over a real socket pair (no module folder here: must say unknown / nodir, never tampered) ---- */
  { int sp[2]; CHECK(socketpair(AF_UNIX,SOCK_STREAM,0,sp)==0); codm_companion(sp[1]); close(sp[1]);
    char b[200]={0}; ssize_t n=read(sp[0],b,sizeof b-1); CHECK(n>0); Verdict v; CHECK(parse_verdict_line(b,v)); CHECK(v.status=="unknown"||v.status=="unsigned"||v.status=="verified"); CHECK(v.status!="tampered"); close(sp[0]); }
  /* ---- game side: comp_collect + decide_safe ---- */
  { g_comp_fd=-1; comp_collect(50); CHECK(g_sig.status=="unknown"&&g_sig.reason=="no_companion");
    int sp[2]; socketpair(AF_UNIX,SOCK_STREAM,0,sp); g_comp_fd=sp[0]; comp_collect(100); CHECK(g_sig.status=="unknown"&&g_sig.reason=="no_answer"); close(sp[1]);     /* nothing is sent: fail open after the wait */
    socketpair(AF_UNIX,SOCK_STREAM,0,sp); const char *l="V1 verified - 71b05e3e 0123456789ab\n"; CHECK(write(sp[1],l,strlen(l))>0); close(sp[1]); g_comp_fd=sp[0]; comp_collect(500);
    CHECK(g_sig.status=="verified"&&g_sig.key8=="71b05e3e"&&g_sig.rel12=="0123456789ab");
    wr(HSAFEF,"0"); unlink(INTEGF); decide_safe("started"); CHECK(g_safe==0);                                      /* verified: no safe mode */
    socketpair(AF_UNIX,SOCK_STREAM,0,sp); l="V1 unknown read_failed - -\n"; CHECK(write(sp[1],l,strlen(l))>0); close(sp[1]); g_comp_fd=sp[0]; comp_collect(500); decide_safe("started"); CHECK(g_safe==0);
    socketpair(AF_UNIX,SOCK_STREAM,0,sp); l="V1 unsigned no_release_files - -\n"; CHECK(write(sp[1],l,strlen(l))>0); close(sp[1]); g_comp_fd=sp[0]; comp_collect(500); decide_safe("started"); CHECK(g_safe==0);
    socketpair(AF_UNIX,SOCK_STREAM,0,sp); l="garbage without newline"; CHECK(write(sp[1],l,strlen(l))>0); close(sp[1]); g_comp_fd=sp[0]; comp_collect(500); CHECK(g_sig.status=="unknown"); decide_safe("started"); CHECK(g_safe==0);
    socketpair(AF_UNIX,SOCK_STREAM,0,sp); l="V1 tampered signature_invalid 71b05e3e -\n"; CHECK(write(sp[1],l,strlen(l))>0); close(sp[1]); g_comp_fd=sp[0]; comp_collect(500);
    decide_safe("started"); CHECK(g_safe==1&&g_safe_why=="tampered_sig_signature_invalid");
    unlink(HSAFEF); g_sig=sigc::Verdict(); decide_safe("started"); CHECK(g_safe==0);
  }
  /* ---- HMIN: one line per minute, kept when the log is cut ---- */
  { wr(GRASSF,""); wr(ORIGF,""); load_cfg(); log_start(4); g_t0=1; const int64_t S=1000000000LL;
    g_hm=HitchMin(); hm_flush(10*S);                                                    /* first call only starts the minute */
    for(int i=0;i<3000;i++) hm_note(i%100==0?120.f:(i%500==0?300.f:16.7f)); hm_note(1500.f);
    hm_flush(40*S); CHECK(count(rd(LOGF),"HMIN")==0);
    hm_flush(71*S); std::string lg=rd(LOGF); CHECK(count(lg,"HMIN")==1); CHECK(lg.find("frames=3000")!=std::string::npos); CHECK(lg.find("stalls1s=1")!=std::string::npos);
    CHECK(lg.find(">100ms=30")!=std::string::npos); CHECK(lg.find(">250ms=")!=std::string::npos);
    hm_flush(100*S); CHECK(count(rd(LOGF),"HMIN")==1);                                  /* counters reset, still inside the minute */
    hm_flush(140*S); CHECK(count(rd(LOGF),"HMIN")==1);                                  /* a quiet minute (no frames) writes nothing */
    CHECK(log_is_event("HMIN t=71: x")&&log_is_event("BUILD owner=Q9 Papyrus"));
    lg=rd(LOGF); CHECK(lg.find("BUILD owner=Q9 Papyrus ver=" VERSION " sig=")!=std::string::npos); }
  printf("%s\n",fails?"v1.12 host test: FAILED":"v1.12 host test: OK");
  return fails?1:0;
}
