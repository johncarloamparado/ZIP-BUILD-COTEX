// v0.77: compile check of menu.inc against the real jni.h (syntax only; never run).
#include <jni.h>
#include <string>
#include <atomic>
#include <thread>
#include <cstdio>
#include <cstring>
#include <cstdlib>
#include <ctime>
#include <unistd.h>
static char g_dir[320] = "/tmp/";
static int g_safe = 0;
static std::atomic<long long> g_t0{0};
static const char *P(const char *n) { return n; }
static void L(const char *, ...) {}
static void st_set(const char *, const std::string &) {}
#include "menu.inc"
