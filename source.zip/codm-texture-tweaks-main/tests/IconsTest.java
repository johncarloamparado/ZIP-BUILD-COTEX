package q9;

/** v1.10: the icon data and the label -> icon map of the live menu (plain JDK + the stubs; the drawing itself is checked on the phone). */
public class IconsTest {
    static int fails = 0;
    static void check(boolean c, String m) { if (!c) { fails++; System.out.println("FAIL " + m); } }
    public static void main(String[] a) {
        check(IconData.NAMES.length == 160 && IconData.PATHS.length == 160, "160 icons");
        java.util.HashSet<String> names = new java.util.HashSet<String>();
        for (String n : IconData.NAMES) check(names.add(n), "duplicate name " + n);
        int bad = 0;
        for (int i = 0; i < IconData.NAMES.length; i++) {
            android.graphics.Path.ops = 0;
            try { Icons.parse(IconData.PATHS[i]); } catch (Throwable t) { bad++; System.out.println("parse " + IconData.NAMES[i] + ": " + t); }
            check(android.graphics.Path.ops >= 2, IconData.NAMES[i] + " has drawing commands");
            check(Icons.path(IconData.NAMES[i]) != null, IconData.NAMES[i] + " path()");
        }
        check(bad == 0, "every icon parses");
        check(Icons.path("no-such-icon") == null && Icons.path(null) == null, "unknown name = null");
        String[][] lab = {{"Hide (3)", "hide"}, {"Hide all", "hide"}, {"Show", "show"}, {"Show hidden", "show-hidden"}, {"Restore (9)", "restore"}, {"Look on", "look-on"},
            {"Save as skip", "skip"}, {"Save texture", "save"}, {"Save as set (3)", "save-set"}, {"Save hidden", "save-hidden"}, {"Group\u2026", "group"}, {"Ungroup", "ungroup"},
            {"Singles (4)", "single"}, {"Folders (2)", "folder"}, {"Skipped (1)", "skipped-list"}, {"Make group (2)", "make-group"}, {"Cancel finder", "cancel-search"},
            {"Cancel", "close"}, {"Click again!", "delete-armed"}, {"Delete", "delete"}, {"Del", "delete"}, {"Rename", "rename"}, {"Yes", "check"}, {"No", "cross"},
            {"\u2190 Back to Test", "back"}, {"\u2190", "back"}, {"\u2715", "close"}, {"1st half", "half-first"}, {"2nd half", "half-second"}, {"Q9 icon: ON  (always visible)", "icon-on"},
            {"Q9 icon: OFF  (hides when this closes)", "icon-off"}, {"Window size: M \u25BE", "window-size"}, {"Order: Newest first \u25BE", "sort"}, {"Reload list", "refresh"}, {"NARROW DOWN  \u25BE", "narrow-down"}};
        for (String[] l : lab) {
            check(l[1].equals(Icons.forLabel(l[0])), "label '" + l[0] + "' -> " + l[1] + " (got " + Icons.forLabel(l[0]) + ")");
            check(names.contains(l[1]), "icon exists: " + l[1]);
        }
        check(Icons.forLabel("Normal") == null && Icons.forLabel("Delay") == null && Icons.forLabel("Skip  (close the question)") == null && Icons.forLabel("Nothing") == null && Icons.forLabel("") == null && Icons.forLabel(null) == null, "no icon for other words");
        System.out.println(fails == 0 ? "IconsTest ok" : "IconsTest FAILED " + fails);
        System.exit(fails == 0 ? 0 : 1);
    }
}
