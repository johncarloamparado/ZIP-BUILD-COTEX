/* v0.89: crash guards that no longer trip on one early close (Box loot 2 strikes, menu marker states), the log keeps the start of the run when it is
   started over, GL_VERSION is answered together with the GPU name. */
#include "main_test_copy.cpp"
extern "C" int __android_log_print(int,const char*,const char*,...){return 0;}
extern "C" int __android_log_vprint(int,const char*,const char*,va_list){return 0;}
static int fails=0;
#define CHECK(c) do{if(!(c)){printf("FAIL line %d: %s\n",__LINE__,#c);fails++;}}while(0)
static void wr(const char *p,const char *s){unlink(p);FILE*f=fopen(p,"w");if(f){fputs(s,f);fclose(f);}}
static std::string rd(const char *p){FILE*f=fopen(p,"r");if(!f)return "";std::string s;char b[4096];while(size_t n=fread(b,1,sizeof b,f))s.append(b,n);fclose(f);return s;}
static const GLubyte *fake_gets(GLenum n){ return (const GLubyte *)(n==0x1F02 ? "OpenGL ES 3.2.0 (ANGLE)" : "real"); }
int main(){
  /* ---- 1. guard_strikes ---- */
  int out=-1;
  CHECK(guard_strikes("20 0\n",20,&out)==0 && out==0);
  CHECK(guard_strikes("0\n",20,&out)==0 && out==1);        /* old marker: one strike */
  CHECK(guard_strikes("0 1\n",20,&out)==1 && out==2);      /* second in a row: OFF */
  CHECK(guard_strikes("20 1\n",20,&out)==0 && out==0);     /* a long launch clears the strikes */
  CHECK(guard_strikes("",20,&out)==0 && out==1);
  CHECK(guard_strikes(nullptr,20,&out)==0 && out==1);
  /* ---- 2. menu marker states ---- */
  int nn=-1;
  CHECK(menu_guard_skip("",&nn)==0 && nn==0);
  CHECK(menu_guard_skip("1794678152\n",&nn)==0 && nn==1);  /* the old marker of the report: tried again */
  CHECK(menu_guard_skip("loaded 1\n",&nn)==0 && nn==1);
  CHECK(menu_guard_skip("loaded 2\n",&nn)==0 && nn==2);
  CHECK(menu_guard_skip("loaded 3\n",&nn)==1);
  CHECK(menu_guard_skip("try 0\n",&nn)==1);                /* died while the dex was loading: skipped at once */
  CHECK(menu_guard_skip("try 2\n",&nn)==1);
  /* ---- 3. GL_VERSION is answered with the GPU name (Box loot ON, GPU on) ---- */
  o_gets=fake_gets;
  g_probe=0; g_bl=1; g_bl_gpu=1; g_bl_pvr=0;
  CHECK(std::string((const char*)h_gets(0x1F02)).find("build 1.10@5130912")!=std::string::npos);
  CHECK(std::string((const char*)h_gets(0x1F01))=="PowerVR Rogue GE8320");
  g_bl_gpu=0;
  CHECK(std::string((const char*)h_gets(0x1F02))=="OpenGL ES 3.2.0 (ANGLE)");   /* GPU switch OFF: the real version */
  g_bl=0;
  /* ---- 3b. who_calls names the library and offset of the caller; ours counter exists ---- */
  { std::string w = who_calls((void *)&guard_strikes); CHECK(w.find("+0x") != std::string::npos); CHECK(who_calls(nullptr) == "?"); g_ours = 0; CHECK(g_ours.load() == 0); }
  /* ---- 4. the log keeps the start of the run and the last events when it is started over ---- */
  unlink(LOGF);
  if(lf){fclose(lf);lf=nullptr;} lf_bytes=0; g_log_head.clear(); g_log_events.clear();
  L("=== start v0.89 test\n"); L("SBG call 0x0 fmt=4 cur=880x396\n"); L("SURFACE cur=880x396 first\n");
  for(int i=0;i<700;i++) L("TEXG t=1 fmt=1 hex=0x1 sz=64 n=%d ap=1 padpadpadpadpadpadpadpadpadpadpadpadpadpadpadpadpadpadpadpadpad\n",i);
  L("SURFACE cur=1600x720 later event\n");
  lf_bytes = LOG_CAP_BYTES + 10;                            /* pretend 4 MB were written */
  L("FT fps=60 after the cut\n");
  std::string lg=rd(LOGF);
  CHECK(lg.find("log truncated")!=std::string::npos);
  CHECK(lg.find("SBG call 0x0 fmt=4 cur=880x396")!=std::string::npos);        /* start of the run kept */
  CHECK(lg.find("=== start v0.89 test")!=std::string::npos);
  CHECK(lg.find("FT fps=60 after the cut")!=std::string::npos);
  CHECK(lg.size() < 200000);
  /* events after the head is full are kept too */
  for(int i=0;i<2000;i++) L("TEXG t=2 fmt=1 hex=0x1 sz=64 n=%d ap=1 padpadpadpadpadpadpadpadpadpadpadpadpadpadpadpadpadpadpadpadpadpadpadpadpad\n",i);
  L("SBG call 0x0 fmt=4 cur=1600x720 LATE\n");
  lf_bytes = LOG_CAP_BYTES + 10; L("FT fps=61 second cut\n");
  lg=rd(LOGF);
  CHECK(lg.find("cur=1600x720 LATE")!=std::string::npos);
  CHECK(lg.find("last window / menu / Box loot events")!=std::string::npos);
  if(fails){printf("TESTS FAILED %d\n",fails);return 1;}
  printf("v089 ok\n"); return 0;
}
