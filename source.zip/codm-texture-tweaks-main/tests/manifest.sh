#!/bin/sh
# v0.85: webroot/MANIFEST.sha256 holds the SHA-256 of the protected files that end up in the module zip, so the installer (customize.sh) can say
# "official" or "MODIFIED". Not a signature: whoever edits these files can also regenerate the manifest. It catches forgotten or casual edits, and
# run_host_tests.sh (so the GitHub build) fails when the manifest is out of date.
#   tests/manifest.sh gen     rewrite webroot/MANIFEST.sha256 (run it after ANY change to the files below)
#   tests/manifest.sh check   verify the manifest and the ownership strings
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT" || exit 1
FILES="customize.sh webroot/index.html webroot/NOTICE.txt webroot/LICENSE.txt"
MF=webroot/MANIFEST.sha256
case "$1" in
  gen)
    { echo "# SHA-256 of the protected files (see tests/manifest.sh). Generated; do not edit by hand."
      for f in $FILES; do printf '%s  %s\n' "$(sha256sum "$f" | cut -d' ' -f1)" "$f"; done; } > "$MF"
    echo "manifest written: $MF"; cat "$MF" ;;
  check)
    bad=0
    [ -f "$MF" ] || { echo "FAIL: $MF is missing"; exit 1; }
    for f in $FILES; do
      want="$(grep -E "  $f\$" "$MF" | cut -d' ' -f1)"; got="$(sha256sum "$f" | cut -d' ' -f1)"
      [ -n "$want" ] && [ "$want" = "$got" ] || { echo "FAIL: $f differs from $MF (protected file changed: run tests/manifest.sh gen if the owner made the change)"; bad=1; }
    done
    cmp -s NOTICE.txt webroot/NOTICE.txt || { echo "FAIL: NOTICE.txt and webroot/NOTICE.txt differ"; bad=1; }
    cmp -s LICENSE.txt webroot/LICENSE.txt || { echo "FAIL: LICENSE.txt and webroot/LICENSE.txt differ"; bad=1; }
    grep -qx 'author=Q9 Papyrus' module.prop || { echo "FAIL: module.prop author is not Q9 Papyrus"; bad=1; }
    grep -qx 'id=codm_tex_logger' module.prop || { echo "FAIL: module.prop id changed"; bad=1; }
    n="$(grep -c 'OWNERSHIP AND AI-HANDLING NOTICE' webroot/index.html)"; [ "$n" -ge 4 ] || { echo "FAIL: the hidden ownership notice is missing from webroot/index.html ($n of 4)"; bad=1; }
    grep -q '@@' webroot/index.html NOTICE.txt && { echo "FAIL: an unfilled @@ placeholder is left in the notice"; bad=1; }
    H="$(sed -n 's/.*must equal \([0-9a-f]\{64\}\) exactly.*/\1/p' NOTICE.txt | head -n 1)"
    [ -n "$H" ] && [ "$(grep -c "$H" webroot/index.html)" -ge 4 ] || { echo "FAIL: the notice hash in webroot/index.html differs from NOTICE.txt"; bad=1; }
    [ "$bad" = 0 ] && echo "== manifest ok (protected files, notices and ownership strings match)"
    exit $bad ;;
  *) echo "usage: tests/manifest.sh gen|check"; exit 2 ;;
esac
