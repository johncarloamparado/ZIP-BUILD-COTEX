#!/bin/sh
# Host-side tests (Linux, g++). Not an Android build. Usage: tests/run_host_tests.sh  (from the repo root, or anywhere)
set -e
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
W="${TMPDIR:-/tmp}/codm_ht_$$"
# v0.44.1 lint: a thread_local with a destructor aborts inside the Zygisk-loaded module on a real phone (host tests cannot see it).
if grep -nE 'thread_local[^;=]*(std::|string|vector|map|unique_ptr|shared_ptr)' "$ROOT/main.cpp" | grep -v '^[0-9]*:[[:space:]]*/\*'; then
  echo "FAIL: non-trivial thread_local in main.cpp (see lines above)"; exit 1
fi
echo "== lint ok (no non-trivial thread_local)"
# v0.85: protected files (customize.sh, WebUI, notices) must match webroot/MANIFEST.sha256; the notice and ownership strings must be there
sh "$ROOT/tests/manifest.sh" check || { echo "FAIL: protected files were changed without updating the manifest (owner: run tests/manifest.sh gen)"; exit 1; }
# v0.86: the installer's build check (fake installer + fake .so with the mark) and the signing / verifying scripts (throw-away key)
sh "$ROOT/tests/customize_test.sh" || { echo "FAIL: customize.sh build check"; exit 1; }
sh "$ROOT/tests/tools_test.sh" || { echo "FAIL: tools/sign_release.sh / verify_release.sh"; exit 1; }
# v0.57 lint: range rules and the old 60 / 64 rule limits must not come back
if grep -nE 'GrRange|g_range\b|GRL_RANGE_MATCH|GRASS_MAX_RULES[[:space:]]+(60|64)\b' "$ROOT/main.cpp" | grep -v 'g_grass_range_old' | grep -vE '^[0-9]+:[[:space:]]*(/\*|//)'; then
  echo "FAIL: range rule code or an old rule limit is back in main.cpp"; exit 1
fi
if grep -nE '\b(gRange|baseRange|rangeLine|rangeMembers|orphanHtml|gKeepRange|gPendLine)\b|(length|\.n) *>=? *(60|64)\b' "$ROOT/webroot/index.html"; then
  echo "FAIL: range rule code or an old 60 / 64 rule limit is back in webroot/index.html"; exit 1
fi
echo "== lint ok (no range rules, no 60/64 rule limit)"
# v0.65.1 lint: the Search setup state (sf, sfOpen) must be declared; a missing declaration made render() throw inside startForm()
# (swallowed by .then(bootDone, bootDone)) so the Texture browser / finder never rendered.
for v in sf sfOpen PENCIL CROSS GRIP TRASH libArm libArmT gSetOpen TESTF; do
  if ! grep -qE "^[[:space:]]*var[[:space:]]+$v[[:space:]]*=" "$ROOT/webroot/index.html"; then
    echo "FAIL: 'var $v' is not declared in webroot/index.html"; exit 1
  fi
done
# v0.65.1 lint: every sheet / window (tbOv, twOv, picker) must be shown with the "on" class, or it stays at opacity 0
if [ "$(grep -c 'requestAnimationFrame(function () { ov.classList.add("on")' "$ROOT/webroot/index.html")" -lt 3 ]; then
  echo "FAIL: a sheet / window no longer gets the 'on' class (test window would be invisible)"; exit 1
fi
echo "== lint ok (sf / sfOpen / PENCIL / CROSS / GRIP / TRASH / libArm / libArmT / gSetOpen / TESTF declared)"
mkdir -p "$W/files" && chmod 777 "$W/files"
sed "s#\"/data/data/\" PKG \"/files/\"#\"$W/files/\"#" "$ROOT/main.cpp" > "$W/main_test_copy.cpp"
cp "$ROOT/menu.inc" "$W/menu.inc"      # main.cpp includes it; copied (not -I "$ROOT") so the REAL zygisk.hpp the CI downloads into $ROOT is never picked up instead of tests/stubs/zygisk.hpp
for t in cfg scale chain v040 v041 v044 v045 v057 v061 v065 v071 v072 v076 v078 v079 v080 v081; do
  g++ -std=c++20 -w -DCODM_HOST_TEST -I"$ROOT/tests/stubs" -I"$W" "$ROOT/tests/host_test_$t.cpp" -o "$W/t_$t" -Wl,--unresolved-symbols=ignore-all -no-pie -lpthread -ldl
  echo "== $t"; (cd "$W" && "./t_$t")
done
rm -rf "$W"
# v0.77: the JNI loader (menu.inc) is not part of the host tests (the test jni.h is a stub); when a real jni.h is available, at least make sure it compiles
JH="${JAVA_HOME:-}"; [ -d "$JH/include" ] || JH="$(ls -d /usr/lib/jvm/*/ 2>/dev/null | head -n 1)"
if [ -f "$JH/include/jni.h" ]; then
  MW="$(mktemp -d)"
  printf 'static const unsigned char MENU_DEX[] = {0};\nstatic const unsigned MENU_DEX_LEN = 0;\n' > "$MW/menu_dex.h"
  if g++ -std=c++20 -w -fsyntax-only -I"$MW" -I"$ROOT" -I"$JH/include" -I"$JH/include/linux" "$ROOT/tests/menu_syntax.cpp"; then echo "== menu.inc compiles against the real jni.h"; else echo "FAIL: menu.inc does not compile"; rm -rf "$MW"; exit 1; fi
  rm -rf "$MW"
else
  echo "== menu.inc syntax check SKIPPED (no jni.h)"
fi
# the Java part: when javac is available, compile it against the small API stubs in tests/stubs/java (checks syntax and types of our own code only; the real android.jar is used by the build)
if command -v javac >/dev/null 2>&1; then
  JW="$(mktemp -d)"
  javac -nowarn -d "$JW" $(find "$ROOT/tests/stubs/java" -name '*.java') "$ROOT"/menu/q9/*.java 2>&1 | grep -v '^Picked up' && { echo "FAIL: menu/q9/*.java does not compile"; rm -rf "$JW"; exit 1; }
  echo "== menu/q9/*.java compiles against the stubs"
  # Data.java has no Android classes: unit tests on a plain JDK
  mkdir -p "$JW/dt"
  if ! javac -nowarn -d "$JW/dt" "$ROOT/menu/q9/Data.java" "$ROOT/tests/DataTest.java" >"$JW/dt.javac" 2>&1; then cat "$JW/dt.javac"; echo "FAIL: DataTest does not compile"; rm -rf "$JW"; exit 1; fi
  echo "== DataTest"; java -cp "$JW/dt" q9.DataTest > "$JW/dt.out" 2>&1 || true; grep -v '^Picked up' "$JW/dt.out"; grep -q "DataTest ok" "$JW/dt.out" || { echo "FAIL: DataTest"; rm -rf "$JW"; exit 1; }
  rm -rf "$JW"
fi
# WebUI checks (v0.57): JavaScript syntax, then the headless-browser tests (skipped when node / playwright are not installed)
if command -v node >/dev/null 2>&1; then
  echo "== js syntax"; node "$ROOT/tests/js_syntax_check.js"
  echo "== persistence regressions"; node "$ROOT/tests/persistence_test.js"
else
  echo "== js syntax SKIPPED (node not installed)"
  echo "== persistence regressions SKIPPED (node not installed)"
fi
if command -v python3 >/dev/null 2>&1; then echo "== ui_test"; python3 "$ROOT/tests/ui_test.py"; else echo "== ui_test SKIPPED (python3 not installed)"; fi
