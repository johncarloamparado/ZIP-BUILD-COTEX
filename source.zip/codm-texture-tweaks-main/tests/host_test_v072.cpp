/* v0.72: UnityMain stat parsing, /proc/vmstat deltas, live texture memory estimate, extended SYS line. */
#include "main_test_copy.cpp"
extern "C" int __android_log_print(int,const char*,const char*,...){return 0;}
extern "C" int __android_log_vprint(int,const char*,const char*,va_list){return 0;}
static int fails=0;
#define CHECK(c) do{if(!(c)){printf("FAIL line %d: %s\n",__LINE__,#c);fails++;}}while(0)
static std::string rd(const char *p){FILE*f=fopen(p,"r");if(!f)return "";std::string s;char b[2048];while(size_t n=fread(b,1,sizeof b,f))s.append(b,n);fclose(f);return s;}
static void fake_st(GLenum,GLsizei,GLenum,GLsizei,GLsizei){}
int main(){
  unlink(SPREADF); load_cfg(); log_start(4);
  /* stat line of a real kernel: state S, minflt 1111, majflt 22, utime 300, stime 40, processor 6, blkio 7 */
  const char *line = "1234 (UnityMain) S 1 2 3 0 -1 4194560 1111 0 22 0 300 40 0 0 20 0 130 0 5555 100 200 18446744073709551615 1 1 0 0 0 0 0 0 0 0 0 0 17 6 0 0 7 0 0\n";
  UmS u; CHECK(um_parse(line,u)); CHECK(u.ok && u.st=='S' && u.minf==1111 && u.majf==22 && u.ut==300 && u.sy==40 && u.cpu==6 && u.blk==7);
  CHECK(!um_parse("garbage",u) || !u.ok);
  const char *short_line = "1 (UnityMain) R 1 2 3\n"; UmS u2; um_parse(short_line,u2); CHECK(!u2.ok);

  /* /proc/vmstat: readable on this host, deltas are never negative between two readings */
  VmS a,b; bool ok=vm_read(a); CHECK(ok && a.ok);
  if(ok){ std::vector<int> junk(1<<20,1); (void)junk; vm_read(b); CHECK(b.majf>=a.majf && b.swpin>=a.swpin); }
  g_vm_last_t=0; g_vm_last.ok=false; vm_tick(5.0); CHECK(g_vm_last.ok==ok);
  vm_log("test",6.0,300.f); if(lf)fflush(lf);
  if(ok) CHECK(rd(LOGF).find("VMSTAT test t=6.00 ms=300 dt=1.0s")!=std::string::npos);

  /* live texture memory: ETC2 RGBA 1024x1024 with 11 levels = 1 MB (level 0) * 4/3 ~ 1.33 MB; ASTC 6x6 and an uncompressed estimate */
  g_tm_tot=0; for(int i=0;i<5;i++) g_tm_cls[i]=0; g_tm_save=0; g_tm_n=0;
  tm_add(10,11,0x9279,1024,1024);                 /* 1024*1024 = 1 MB for level 0 (8 bpp) */
  CHECK(g_tm_n.load()==1 && g_tm_l0[10].load()==1024 && g_tm_kb[10].load()>1300 && g_tm_kb[10].load()<1400);
  CHECK(g_tm_cls[1].load()==g_tm_kb[10].load() && g_tm_save.load()==1024);
  tm_add(11,10,0x9274,512,512);                    /* 4 bpp: 128 KB level 0 */
  CHECK(g_tm_l0[11].load()==128 && g_tm_cls[2].load()>0 && g_tm_save.load()==1024+128);
  tm_add(12,1,0x9274,128,128);                     /* single level, small: not counted for the mip skip */
  CHECK(g_tm_cls[4].load()>0 && g_tm_save.load()==1024+128 && g_tm_n.load()==3);
  tm_add(13,9,0x93d4,512,512);                     /* ASTC 6x6: 16 bytes per 36 px */
  CHECK(g_tm_l0[13].load()==((512+5)/6)*((512+5)/6)*16/1024+ (((((512+5)/6)*((512+5)/6)*16)%1024)?1:0));
  long long before=g_tm_tot.load(); tm_add(10,11,0x9279,1024,1024);   /* the same id again replaces the old size, no double count */
  CHECK(g_tm_tot.load()==before && g_tm_n.load()==4);
  GLuint d[2]={10,11}; h_del(2,d);
  CHECK(g_tm_n.load()==2 && g_tm_kb[10].load()==0 && g_tm_cls[1].load()==0 && g_tm_save.load()==g_tm_l0[13].load());
  tm_del(10);                                       /* deleting twice must not go negative */
  CHECK(g_tm_n.load()==2);
  tm_del(0); tm_del(MAXTEX+5);
  /* h_st really calls it, with the bound texture */
  o_st=fake_st; tl_unit=0; tl_bound[0]=20; h_st(GL_TEXTURE_2D,9,0x9279,512,512); CHECK(g_tm_kb[20].load()>0 && g_tm_n.load()==3);

  /* SYS line has the new fields */
  sys_probe("test",1.0,300.f); if(lf)fflush(lf); std::string lg=rd(LOGF);
  size_t p=lg.find("SYS test t=1.00 ms=300"); CHECK(p!=std::string::npos);
  CHECK(lg.find("memtotal=",p)!=std::string::npos && lg.find("vmswap=",p)!=std::string::npos && lg.find("anon=",p)!=std::string::npos && lg.find("texlive=",p)!=std::string::npos);
  if(lf){fclose(lf);lf=nullptr;}
  printf(fails?"FAILED %d\n":"ALL TESTS PASSED\n",fails); return fails?1:0;
}
