/* v0.99: the menu can ask which textures of the finder list are alive in the game now ("a 0" in livecmd.txt -> codm_tex.alive: "A <seq> <n>", then one 16-digit hex fingerprint per line). */
#include "main_test_copy.cpp"
extern "C" int __android_log_print(int,const char*,const char*,...){return 0;}
extern "C" int __android_log_vprint(int,const char*,const char*,va_list){return 0;}
static int fails=0;
#define CHECK(c) do{if(!(c)){printf("FAIL line %d: %s\n",__LINE__,#c);fails++;}}while(0)
static void wr(const char *p,const char *s){FILE*f=fopen(p,"w");if(f){fputs(s,f);fclose(f);}}
static std::string rd(const char *p){FILE*f=fopen(p,"r");if(!f)return "";std::string s;char b[2048];while(size_t n=fread(b,1,sizeof b,f))s.append(b,n);fclose(f);return s;}
static int count(const std::string&s,const std::string&nd){int n=0;size_t p=0;while((p=s.find(nd,p))!=std::string::npos){++n;p+=nd.size();}return n;}
int main(){
  wr(GRASSF,""); wr(ORIGF,""); load_cfg(); log_start(4);
  unlink(ALIVEF);
  lv_meta_note(10,37492,256,256,0x00000000000000aaULL);
  lv_meta_note(11,37492,256,256,0x00000000000000bbULL);
  lv_meta_note(12,37496,512,512,0x00000000000000aaULL);     /* same fingerprint twice: listed once */
  lv_meta_note(13,37497,512,512,0xfedcba9876543210ULL);
  /* nothing is written until the menu asks */
  wr(LIVECF,"h 00000000000000aa\n"); lv_do_cmd(1); CHECK(rd(ALIVEF).empty());
  /* "a 0" -> the list, first line has a seq and the count */
  wr(LIVECF,"a 0\n"); lv_do_cmd(2);
  std::string s=rd(ALIVEF);
  CHECK(s.compare(0,2,"A ")==0);
  int sq1=0,n1=0; sscanf(s.c_str(),"A %d %d",&sq1,&n1); CHECK(sq1>0 && n1==3);
  CHECK(count(s,"00000000000000aa\n")==1); CHECK(count(s,"00000000000000bb\n")==1); CHECK(count(s,"fedcba9876543210\n")==1);
  CHECK(count(s,"\n")==4);
  CHECK(rd((std::string(ALIVEF)+".tmp").c_str()).empty());           /* the temp file was renamed away */
  /* the game deletes texture 11: a new answer has a new seq and does not list it */
  lv_drop(11);
  wr(LIVECF,"a 0\nx 5\n"); lv_do_cmd(3);
  s=rd(ALIVEF); int sq2=0,n2=0; sscanf(s.c_str(),"A %d %d",&sq2,&n2);
  CHECK(sq2==sq1+1 && n2==2); CHECK(count(s,"00000000000000bb\n")==0);
  /* "a" together with hide commands: both are handled, the alive list does not eat the hide */
  wr(LIVECF,"a 0\nh 00000000000000aa\n"); lv_do_cmd(4);
  { std::lock_guard<std::mutex> lk(g_lvmu); CHECK(g_lv_cmd.size()>=1); }
  s=rd(ALIVEF); int sq3=0,n3=0; sscanf(s.c_str(),"A %d %d",&sq3,&n3); CHECK(sq3==sq2+1);
  /* an empty table gives an empty list, still with a new seq */
  lv_drop(10); lv_drop(12); lv_drop(13);
  wr(LIVECF,"a 0\n"); lv_do_cmd(5);
  s=rd(ALIVEF); int sq4=0,n4=-1; sscanf(s.c_str(),"A %d %d",&sq4,&n4); CHECK(sq4==sq3+1 && n4==0 && count(s,"\n")==1);
  unlink(ALIVEF);
  if(lf){fclose(lf);lf=nullptr;}
  printf(fails?"FAILED %d\n":"ALL TESTS PASSED\n",fails); return fails?1:0;
}
