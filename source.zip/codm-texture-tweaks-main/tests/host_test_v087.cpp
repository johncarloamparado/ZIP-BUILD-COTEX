/* v0.87: a live Restore (op r) is remembered for this game session: a texture the game loads AGAIN with the same fingerprint is restored too (before, it got the look again).
   The filter the game asked for is recorded in live mode even without orig.txt rules, so a live Restore puts THAT back and not the GL default. Look on (f) and Hide (h) forget it. */
#include <array>
#include "main_test_copy.cpp"
extern "C" int __android_log_print(int,const char*,const char*,...){return 0;}
extern "C" int __android_log_vprint(int,const char*,const char*,va_list){return 0;}
static int fails=0;
#define CHECK(c) do{if(!(c)){printf("FAIL line %d: %s\n",__LINE__,#c);fails++;}}while(0)
static void wr(const char *p,const char *s){FILE*f=fopen(p,"w");if(f){fputs(s,f);fclose(f);}}
static std::string rd(const char *p){FILE*f=fopen(p,"r");if(!f)return "";std::string s;char b[4096];while(size_t n=fread(b,1,sizeof b,f))s.append(b,n);fclose(f);return s;}
static std::vector<std::pair<GLenum,GLint>> g_tp;
static void fake_tp(GLenum,GLenum p,GLint v){ g_tp.push_back({p,v}); }
static void fake_tpf(GLenum,GLenum,GLfloat){}
static int last_of(GLenum pname){ int b=-1; for(auto &c:g_tp) if(c.first==pname) b=c.second; return b; }
static int g_tex_bound=7, g_real_pbo=0; static std::set<GLuint> g_alive;
static void fake_giv(GLenum e,GLint *v){ if(e==0x88EF)*v=g_real_pbo; else if(e==0x8069)*v=g_tex_bound; else *v=0; }
static GLboolean fake_is(GLuint id){return g_alive.count(id)?1:0;}
static void fake_bb(GLenum,GLuint b){g_real_pbo=(int)b;}
static void fake_bind(GLenum,GLuint id){g_tex_bound=(int)id;}
static void fake_ctsi2(GLenum,GLint,GLint,GLint,GLsizei,GLsizei,GLenum,GLsizei,const void*){}
static void fake_del(GLsizei,const GLuint*){}
static void gl_gen(GLsizei n,GLuint*o){ for(GLsizei i=0;i<n;i++)o[i]=900+i; }
static void gl_del(GLsizei,const GLuint*){}
static void gl_stor(GLenum,GLsizei,GLenum,GLsizei,GLsizei){}
static void gl_cp(GLuint,GLenum,GLint,GLint,GLint,GLint,GLuint,GLenum,GLint,GLint,GLint,GLint,GLsizei,GLsizei,GLsizei){}
static void gl_lvp(GLenum,GLint,GLenum,GLint*v){ *v=0; }
static GLenum gl_err(){ return 0; }
static long long mem_hook(){return 2000000;}
static int64_t T=0; static void poll(){ T+=2000000000LL; live_poll(T); lv_apply(); }
static std::string hex16(uint64_t h){ char b[24]; snprintf(b,sizeof b,"%016llx",(unsigned long long)h); return b; }
/* the game makes a texture: filters first, then storage (look applied), then the level 0 picture */
static void game_loads(GLuint id, const std::vector<uint8_t> &data){
  tl_bound[0]=id; g_tex_bound=(int)id;
  h_tp(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,0x2703);          /* LINEAR_MIPMAP_LINEAR: what the game wants */
  h_tp(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,0x2601);
  h_st(GL_TEXTURE_2D,9,0x9279,256,256);
  h_ctsi2(GL_TEXTURE_2D,0,0,0,256,256,0x9279,(GLsizei)data.size(),data.data());
}
int main(){
  unlink(LIVECF); unlink(MARKF); wr(GRASSF,""); wr(ORIGF,""); wr(LIVEF,"1\n"); load_cfg(); log_start(4);
  g_giv_hook=fake_giv; g_sp_is_hook=fake_is; g_sp_bb_hook=fake_bb; o_bind=fake_bind; o_ctsi2=fake_ctsi2; o_del=fake_del; real_tp=fake_tp; o_tpf=fake_tpf;
  g_lvgl_hook={gl_gen,gl_del,gl_stor,gl_cp,gl_lvp,gl_err}; g_lvgl_hooked=true; g_lv_mem_hook=mem_hook;
  g_near=0; g_testtex=0; g_style=0; g_flat=4; g_blk=0; g_alpha=0; g_astc=0; g_grass_on=0; g_orig_on=0; g_minsz=64; g_delay=0; g_skip.clear();   /* NO orig.txt rules: only the live Restore */
  g_rt=(pid_t)syscall(SYS_gettid); g_t0=1; for(GLuint i=1;i<=3000;i++)g_alive.insert(i);
  CHECK(g_live_on.load()==1 && g_orig_on.load()==0 && g_lv_rest_n.load()==0);
  std::vector<uint8_t> A(65536,11); uint64_t hA=tex_hash(A.data(),(int)A.size());
  std::vector<uint8_t> B(65536,22); uint64_t hB=tex_hash(B.data(),(int)B.size());
  /* ---- 1. texture 2 loads with the look; the game's filters are recorded although orig.txt is empty ---- */
  game_loads(2,A);
  CHECK(g_omin[2].load()==0x2703 && g_omag[2].load()==0x2601 && g_tr[2].load()==1 && g_tf[2].load()==1);
  wr(MARKF,""); poll();
  /* ---- 2. live Restore: the GAME's filter goes back (before: the GL default 0x2702), the fingerprint is remembered ---- */
  g_tp.clear(); wr(LIVECF,("r "+hex16(hA)+"\n").c_str()); usleep(1100000); poll(); poll();
  CHECK(last_of(GL_TEXTURE_BASE_LEVEL)==0 && last_of(GL_TEXTURE_MIN_FILTER)==0x2703 && last_of(GL_TEXTURE_MAG_FILTER)==0x2601);
  CHECK(g_tr[2].load()==0 && g_tf[2].load()==0);
  CHECK(g_lv_rest_n.load()==1 && lv_rest_match(hA) && !lv_rest_match(hB));
  /* ---- 3. the game unloads texture 2 and loads the same picture again as texture 5: it must NOT get the look (before: it did) ---- */
  { GLuint ids[1]={2}; h_del(1,ids); }
  g_tp.clear(); game_loads(5,A);
  CHECK(last_of(GL_TEXTURE_BASE_LEVEL)==0);                   /* the look set base 8, the restore at level 0 put 0 back */
  CHECK(last_of(GL_TEXTURE_MIN_FILTER)==0x2703 && g_blank[5].load()==4 && g_tr[5].load()==0 && g_tf[5].load()==0);
  /* another picture still gets the look */
  g_tp.clear(); game_loads(6,B);
  CHECK(last_of(GL_TEXTURE_BASE_LEVEL)==8 && g_tr[6].load()==1 && g_blank[6].load()==2);
  /* ---- 4. Look on (f) forgets it: the next load of that picture has the look again, and texture 5 gets it now ---- */
  g_tp.clear(); wr(LIVECF,("f "+hex16(hA)+"\n").c_str()); usleep(1100000); poll(); poll();
  CHECK(last_of(GL_TEXTURE_BASE_LEVEL)==8 && g_lv_rest_n.load()==0 && !lv_rest_match(hA));
  { GLuint ids[1]={5}; h_del(1,ids); }
  g_tp.clear(); game_loads(7,A);
  CHECK(last_of(GL_TEXTURE_BASE_LEVEL)==8 && g_tr[7].load()==1);
  /* ---- 5. Restore again, then Hide takes it back (a hidden texture is not also restored) ---- */
  wr(LIVECF,("r "+hex16(hB)+"\n").c_str()); usleep(1100000); poll(); poll();
  CHECK(g_lv_rest_n.load()==1 && lv_rest_match(hB));
  wr(LIVECF,("h "+hex16(hB)+"\n").c_str()); usleep(1100000); poll(); poll();
  CHECK(g_lv_rest_n.load()==0 && !lv_rest_match(hB));
  /* ---- 6. a file rule in orig.txt still works exactly as before ---- */
  g_lv_rest.clear(); g_lv_rest_n=0;
  g_orig_on=0; { std::lock_guard<std::mutex> lk(g_rmu); g_orig.clear(); g_orig.push_back(GrRule{0x9279,256,256,hA}); } g_orig_on=1;
  g_tp.clear(); game_loads(8,A);
  CHECK(last_of(GL_TEXTURE_BASE_LEVEL)==0 && g_blank[8].load()==4);
  unlink(LIVEF); unlink(LIVECF); unlink(MARKF);
  if(fails){printf("TESTS FAILED %d\n",fails);return 1;}
  printf("v087 ok\n"); return 0;
}
