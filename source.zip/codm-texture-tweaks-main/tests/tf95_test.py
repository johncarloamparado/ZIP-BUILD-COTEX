#!/usr/bin/env python3
"""v0.95/v0.96: Texture shortcuts has two containers (Restore / Hide); v0.96: the same texture can be in both (one entry per action), only one of them ON at a time."""
import os,sys
try:
    from playwright.sync_api import sync_playwright
except Exception as e:
    print('SKIP tf95_test: playwright not available'); sys.exit(0)
PAGE="file://"+os.path.join(os.path.dirname(os.path.abspath(__file__)),"..","webroot","index.html")
fails=[]
def ck(n,c,x=""):
    print("PASS" if c else "FAIL",n,x if not c else "")
    if not c: fails.append(n)
K1="37497|64|64|00000000000000aa"; K2="37497|32|32|00000000000000bb"; K3="37496|16|16|00000000000000cc"
with sync_playwright() as p:
    b=p.chromium.launch(); pg=b.new_page(); errs=[]; pg.on("pageerror",lambda e:errs.append(str(e)))
    pg.goto(PAGE+"?demo=20"); pg.wait_for_timeout(900)
    pg.click("#dock [data-v=home]"); pg.wait_for_timeout(300); pg.evaluate("document.querySelector('#tfCard details').open=true")
    pg.evaluate("window.__ct.saveAs(['%s'],'Smoke','effects','hide',false)"%K1); pg.wait_for_timeout(300)
    pg.evaluate("window.__ct.saveAs(['%s'],'Other','other','hide',false)"%K3); pg.wait_for_timeout(300)
    lib=pg.evaluate("window.__ct.lib()")
    ck("two Hide entries saved", len(lib)==2 and all(e["act"]=="hide" for e in lib), lib)
    ck("container is Hide", pg.evaluate("window.__ct.tfAct()")=="hide")
    ck("Hide container lists both, Restore none", pg.evaluate("document.querySelectorAll('#tfList .item.lib [data-tfu]').length")==2 and "0 saved" in pg.inner_text("#tfList [data-tfv=restore]"), pg.inner_text("#tfList"))
    # v0.96: the same texture saved as Restore is a SECOND entry (it no longer replaces the Hide one)
    pg.evaluate("window.__ct.saveAs(['%s'],'Smoke soft','effects','restore',false)"%K1); pg.wait_for_timeout(400)
    lib=pg.evaluate("window.__ct.lib()"); es=[x for x in lib if x["key"]==K1]
    ck("same texture saved under both actions: two entries, 3 in all", len(es)==2 and sorted(x["act"] for x in es)==["hide","restore"] and len(lib)==3, lib)
    ck("Texture shortcuts opened on the Restore container", pg.evaluate("window.__ct.tfAct()")=="restore")
    ck("Restore container lists only the restore one", pg.evaluate("document.querySelectorAll('#tfList .item.lib [data-tfu]').length")==1 and "Smoke soft" in pg.inner_text("#tfList .gf-conf") and "Smoke" not in pg.inner_text("#tfList .gf-conf").replace("Smoke soft",""), pg.inner_text("#tfList"))
    ck("Restore is ON (orig.txt), Hide is not", any(K1 in r or K1.replace("|"," ") in r for r in pg.evaluate("window.__ct.orig()")) or K1 in pg.evaluate("window.__ct.orig()"), pg.evaluate("window.__ct.orig()"))
    ck("not in the Hide rules", not any(K1.split("|")[3] in r for r in pg.evaluate("window.__ct.rules()")), pg.evaluate("window.__ct.rules()"))
    pg.click("#tfList [data-tfv=hide]"); pg.wait_for_timeout(200)
    ck("Hide container still has both Hide textures", pg.evaluate("document.querySelectorAll('#tfList .item.lib [data-tfu]').length")==2 and "Smoke" in pg.inner_text("#tfList .gf-conf") and "Other" in pg.inner_text("#tfList .gf-conf"), pg.inner_text("#tfList"))
    # turning Hide ON turns the Restore of the same texture OFF
    pg.click("#tfList [data-tfu='%s']"%K1); pg.wait_for_timeout(500)
    ck("Hide ON: in the Hide rules, Restore is OFF", any(K1.split("|")[3] in r for r in pg.evaluate("window.__ct.rules()")) and not any(K1.split("|")[3] in r for r in pg.evaluate("window.__ct.orig()")), (pg.evaluate("window.__ct.rules()"), pg.evaluate("window.__ct.orig()")))
    pg.click("#tfList [data-tfv=restore]"); pg.wait_for_timeout(200)
    pg.click("#tfList [data-tfu]"); pg.wait_for_timeout(500)
    ck("Restore ON again: Hide goes OFF", not any(K1.split("|")[3] in r for r in pg.evaluate("window.__ct.rules()")) and any(K1.split("|")[3] in r for r in pg.evaluate("window.__ct.orig()")), (pg.evaluate("window.__ct.rules()"), pg.evaluate("window.__ct.orig()")))
    pg.click("#tfList [data-tfu]"); pg.wait_for_timeout(500)
    ck("both can be OFF", not any(K1.split("|")[3] in r for r in pg.evaluate("window.__ct.rules()")) and not any(K1.split("|")[3] in r for r in pg.evaluate("window.__ct.orig()")))
    # the same action again is "already"
    n0=len(pg.evaluate("window.__ct.lib()")); pg.evaluate("window.__ct.saveAs(['%s'],'again','effects','restore',false)"%K1); pg.wait_for_timeout(200)
    ck("same action again: nothing duplicated", len(pg.evaluate("window.__ct.lib()"))==n0)
    # delete the Restore one: the Hide one stays
    pg.click("#tfList [data-tfv=restore]"); pg.wait_for_timeout(200)
    ids=pg.evaluate("Array.prototype.map.call(document.querySelectorAll('[data-forget]'), function (e) { return e.getAttribute('data-forget'); })")
    ck("My textures list gives the Restore entry its own id (key~r), the Hide one keeps the key", (K1+"~r") in ids and K1 in ids, ids)
    pg.evaluate("document.querySelector('[data-forget=\"%s~r\"]').click()"%K1); pg.wait_for_timeout(500)
    lib=pg.evaluate("window.__ct.lib()"); es=[x for x in lib if x["key"]==K1]
    ck("deleting the Restore entry leaves the Hide entry", len(es)==1 and es[0]["act"]=="hide" and len(lib)==2, lib)
    # v0.97: slim Restore / Hide switch (no dot, no heavy edge) and Share / Import folded away
    r=pg.evaluate("(function(){var o=[];document.querySelectorAll('#tfActSeg .mode').forEach(function(m){var c=getComputedStyle(m),b=m.getBoundingClientRect(),a=getComputedStyle(m,'::after');o.push({h:b.height,bw:c.borderRightWidth+'/'+c.borderLeftWidth,after:a.display,shadow:c.boxShadow})});return o})()")
    ck("Restore and Hide buttons are slim (<= 46 px), same border on both sides, no dot", len(r)==2 and all(x["h"]<=46 and x["bw"].split("/")[0]==x["bw"].split("/")[1] and x["after"]=="none" and x["shadow"]=="none" for x in r), r)
    ck("Share / Import is folded away at first", pg.evaluate("!!document.getElementById('tfXfer') && !document.getElementById('tfXfer').open") and not pg.is_visible("#tfShare") and pg.is_visible("#tfXfer > summary"))
    pg.evaluate("document.querySelector('#tfXfer > summary').click()"); pg.wait_for_timeout(200)
    ck("tapping 'Share or import' opens both buttons", pg.evaluate("(function(){var d=document.getElementById('tfXfer');return d.open})()") and pg.is_visible("#tfShare") and pg.is_visible("#tfImp"))
    # v1.02: a group shows its textures: small arrow (closed at first), the textures indented, read only
    K4="37497|128|128|00000000000000dd"; K5="37497|128|64|00000000000000ee"
    pg.click("#tfList [data-tfv=hide]"); pg.wait_for_timeout(200)
    pg.evaluate("window.__ct.saveAs(['%s','%s'],'Pack','effects','hide',true)"%(K4,K5)); pg.wait_for_timeout(500)
    pg.click("#tfList [data-tfv=hide]"); pg.wait_for_timeout(200)
    ck("v1.02 only the group has an arrow, closed at first (no textures listed)", pg.evaluate("document.querySelectorAll('#tfList .tf-arrow').length")==1 and pg.get_attribute("#tfList .tf-arrow","aria-expanded")=="false" and pg.evaluate("document.querySelectorAll('#tfList .tf-mem').length")==0)
    pg.click("#tfList .tf-arrow"); pg.wait_for_timeout(200)
    r=pg.evaluate("(function(){var m=document.querySelector('#tfList .tf-mem'),s=document.querySelector('#tfList .item.tf-set .sw'),a=document.querySelector('#tfList .tf-arrow');return {n:m?m.querySelectorAll('li').length:-1,ml:m?m.getBoundingClientRect().left:0,sl:s?s.getBoundingClientRect().left:0,ex:a.getAttribute('aria-expanded'),inside:!!(m&&m.closest('.item.tf-set'))}})()")
    ck("v1.02 the arrow opens the list of the 2 textures, indented under the group", r["n"]==2 and r["ex"]=="true" and r["inside"] and r["ml"]>r["sl"]+20, r)
    pg.click("#tfList .tf-arrow"); pg.wait_for_timeout(200)
    ck("v1.02 the arrow closes it again", pg.evaluate("document.querySelectorAll('#tfList .tf-mem').length")==0 and pg.get_attribute("#tfList .tf-arrow","aria-expanded")=="false")
    ck("no page errors", not errs, errs)
    b.close()
print("FAILS",fails); sys.exit(1 if fails else 0)
