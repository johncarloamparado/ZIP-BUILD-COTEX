/* v1.05: skip.txt is read as "fmt size" lines only (Texture groups switches). Old Skip Manager forms ("fmt w h", size 0, fmt 0) are ignored. */
#include "main_test_copy.cpp"
extern "C" int __android_log_print(int,const char*,const char*,...){return 0;}
extern "C" int __android_log_vprint(int,const char*,const char*,va_list){return 0;}
static int fails=0;
#define CHECK(c) do{if(!(c)){printf("FAIL line %d: %s\n",__LINE__,#c);fails++;}}while(0)
static void wr(const char *p,const char *s){FILE*f=fopen(p,"w");if(f){fputs(s,f);fclose(f);}}
static std::string rd(const char *p){FILE*f=fopen(p,"r");if(!f)return "";std::string s;char b[2048];while(size_t n=fread(b,1,sizeof b,f))s.append(b,n);fclose(f);return s;}
int main(){
  wr(GRASSF,""); wr(ORIGF,"");
  wr(SKIPF,"37492 256\n37497 512 512\n37497 0\n0 128\n# 37496 64\n0x93b0 64\n\n");
  load_cfg(); log_start(4);
  CHECK(g_skip.size()==2);                       /* "37492 256" and the hex "0x93b0 64" */
  CHECK(in_skip(37492,256,128));                 /* longest side 256 */
  CHECK(in_skip(37492,128,256));
  CHECK(!in_skip(37492,128,128));
  CHECK(!in_skip(37497,512,512));                /* old "fmt w h" line: ignored */
  CHECK(!in_skip(37497,256,256));                /* old "size 0 = any size" line: ignored */
  CHECK(!in_skip(37492,64,64) || false);
  CHECK(!in_skip(1234,128,128));                 /* old "fmt 0 = any format" line: ignored */
  CHECK(in_skip(0x93b0,64,64));
  CHECK(!in_skip(37496,64,64));                  /* commented line */
  std::string lg=rd(LOGF);
  CHECK(lg.find("SKIPRULE ignored")!=std::string::npos);
  CHECK(lg.find("SKIPRULE loaded fmt=37492 size=256")!=std::string::npos);
  unlink(SKIPF);
  printf("%s\n",fails?"v1.05 host test: FAILED":"v1.05 host test: OK");
  return fails?1:0;
}
