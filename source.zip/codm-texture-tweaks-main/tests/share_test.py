#!/usr/bin/env python3
"""v0.93: share codes CTX1 (My textures) and CTS1 (Texture shortcuts): export, import, validation, round trip. Demo mode, headless Chromium."""
import os,sys
try:
    from playwright.sync_api import sync_playwright
except Exception as e:
    print('SKIP share_test: playwright not available'); sys.exit(0)
PAGE="file://"+os.path.join(os.path.dirname(os.path.abspath(__file__)),"..","webroot","index.html")
def csum(t):
    h=2166136261
    for c in t: h^=ord(c); h=(h*16777619)&0xffffffff
    n=h; d="0123456789abcdefghijklmnopqrstuvwxyz"; o=""
    while n: o=d[n%36]+o; n//=36
    return o or "0"
def mk(pfx,rows):
    b=pfx+";"+"/".join(rows); return b+";"+csum(b)
rows=["37497,64,64,00000000000000aa,effects,1,h,Smoke+A","37497,32,32,00000000000000bb,effects,1,h,Smoke+A","37496,16,16,00000000000000cc,plants,,r,Lobby+x","37496,8,8,00000000000000dd,other,,h,Solo"]
code=mk("CTX1",rows)
fails=[]
def ck(n,c,x=""):
    print("PASS" if c else "FAIL",n,x if not c else "")
    if not c: fails.append(n)
with sync_playwright() as p:
    b=p.chromium.launch(); pg=b.new_page(); errs=[]; pg.on("pageerror",lambda e:errs.append(str(e)))
    pg.goto(PAGE+"?demo=20"); pg.wait_for_timeout(900)
    pg.click("#dock [data-v=adv]"); pg.wait_for_timeout(300)
    ck("share empty lib toasts", (pg.evaluate("document.getElementById('libShare').click(), 0") or 1) and not pg.evaluate("document.getElementById('codew').classList.contains('open')"))
    pg.evaluate("document.getElementById('libImp').click()"); pg.wait_for_timeout(200)
    ck("import dialog title", pg.inner_text("#codet2")=="Import My textures", pg.inner_text("#codet2"))
    pg.fill("#codet", "CTX1;"+"x"); pg.evaluate("document.getElementById('codeGo').click()")
    ck("bad code rejected", "not a CTX1" in pg.inner_text("#codemsg"), pg.inner_text("#codemsg"))
    pg.fill("#codet", code[:30]+"\n"+code[30:]); pg.evaluate("document.getElementById('codeGo').click()"); pg.wait_for_timeout(400)
    lib=pg.evaluate("window.__ct.lib()")
    ck("4 imported", len(lib)==4, lib)
    ck("set remapped to one new id", lib[0]["set"] and lib[0]["set"]==lib[1]["set"] and lib[0]["set"]!="1", lib)
    ck("restore + names", lib[2]["act"]=="restore" and lib[0]["name"]=="Smoke A", lib)
    ck("all OFF", pg.evaluate("window.__ct.rules().length")==0 and pg.evaluate("window.__ct.orig().length")==0)
    tx=pg.evaluate("window.__ct.fakeTexlib()"); ck("texlib file written", len([l for l in tx.split('\n') if l.strip()])==4, tx)
    # shortcuts: wrong type
    pg.evaluate("document.getElementById('tfImp').click()"); pg.wait_for_timeout(200)
    pg.fill("#codet", code); pg.evaluate("document.getElementById('codeGo').click()")
    ck("CTX1 into shortcuts refused", "CTX1" in pg.inner_text("#codemsg"), pg.inner_text("#codemsg"))
    sc=mk("CTS1",rows[1:3]+[rows[3]])
    pg.fill("#codet", sc); pg.evaluate("document.getElementById('codeGo').click()"); pg.wait_for_timeout(500)
    ck("hide ON for 2 keys", len(pg.evaluate("window.__ct.rules()"))==2, pg.evaluate("window.__ct.rules()"))
    ck("restore ON for 1 key", len(pg.evaluate("window.__ct.orig()"))==1, pg.evaluate("window.__ct.orig()"))
    ck("lib still 4 (no dupes)", len(pg.evaluate("window.__ct.lib()"))==4)
    # copy codes
    pg.evaluate("document.getElementById('tfShare').click()"); pg.wait_for_timeout(200)
    t=pg.input_value("#codet"); ck("CTS1 has ON entries only", t.startswith("CTS1;") and t.count("/")==2, t)
    pg.evaluate("document.getElementById('codex').click()")
    pg.evaluate("document.getElementById('libShare').click()"); pg.wait_for_timeout(200)
    t=pg.input_value("#codet"); ck("CTX1 round trip has 4", t.startswith("CTX1;") and t.count("/")==3 and "Smoke+A" in t, t)
    pg.evaluate("document.getElementById('codex').click()")
    # add-only: importing never removes or changes what is already here
    before=pg.evaluate("window.__ct.lib()"); on_h=pg.evaluate("window.__ct.rules()"); on_r=pg.evaluate("window.__ct.orig()")
    more=["37497,64,64,00000000000000aa,effects,1,h,RENAMED+Smoke","37497,128,128,00000000000000ee,effects,,h,New+one","37496,4,4,00000000000000ff,plants,,r,New+restore"]
    pg.evaluate("document.getElementById('libImp').click()"); pg.wait_for_timeout(200)
    pg.fill("#codet", mk("CTX1",more)); pg.evaluate("document.getElementById('codeGo').click()"); pg.wait_for_timeout(500)
    lib2=pg.evaluate("window.__ct.lib()")
    ck("CTX1 add: old 4 kept unchanged, 2 added", len(lib2)==6 and [ (e["key"],e["name"],e["grp"],e["set"],e["act"]) for e in lib2[:4]]==[(e["key"],e["name"],e["grp"],e["set"],e["act"]) for e in before], lib2)
    ck("CTX1 add: shortcuts that were ON stay ON", pg.evaluate("window.__ct.rules()")==on_h and pg.evaluate("window.__ct.orig()")==on_r)
    pg.evaluate("document.getElementById('tfImp').click()"); pg.wait_for_timeout(200)
    pg.fill("#codet", mk("CTS1",more[1:])); pg.evaluate("document.getElementById('codeGo').click()"); pg.wait_for_timeout(500)
    ck("CTS1 add: old ON stay ON and the new ones are added ON", set(on_h)<=set(pg.evaluate("window.__ct.rules()")) and set(on_r)<=set(pg.evaluate("window.__ct.orig()")) and len(pg.evaluate("window.__ct.rules()"))==len(on_h)+1 and len(pg.evaluate("window.__ct.orig()"))==len(on_r)+1, (pg.evaluate("window.__ct.rules()"),pg.evaluate("window.__ct.orig()")))
    ck("library never shrank", len(pg.evaluate("window.__ct.lib()"))==6)
    # tamper
    pg.evaluate("document.getElementById('libImp').click()"); pg.wait_for_timeout(200)
    pg.fill("#codet", t.replace("Solo","Sol0")); pg.evaluate("document.getElementById('codeGo').click()")
    ck("tampered rejected", "checksum" in pg.inner_text("#codemsg"), pg.inner_text("#codemsg"))
    ck("no page errors", not errs, errs)
    b.close()
print("FAILS",fails); sys.exit(1 if fails else 0)
