/* v1.09: hskip.txt ("Save as skip" in the live menu Hide finder): exact "fmt w h hash" lines; a texture in it is known to the module (hskip_match) and a reload follows the file. */
#include "main_test_copy.cpp"
extern "C" int __android_log_print(int,const char*,const char*,...){return 0;}
extern "C" int __android_log_vprint(int,const char*,const char*,va_list){return 0;}
static int fails=0;
#define CHECK(c) do{if(!(c)){printf("FAIL line %d: %s\n",__LINE__,#c);fails++;}}while(0)
static void wr(const char *p,const char *s){FILE*f=fopen(p,"w");if(f){fputs(s,f);fclose(f);}}
static std::string rd(const char *p){FILE*f=fopen(p,"r");if(!f)return "";std::string s;char b[4096];while(size_t n=fread(b,1,sizeof b,f))s.append(b,n);fclose(f);return s;}
int main(){
  wr(GRASSF,"37497 512 512 00000000000000aa\n37497 64 64 00000000000000bb\n"); wr(ORIGF,"");
  wr(HSKIPF,"37497 512 512 00000000000000aa\n# comment\nbad line\n37496 64 64 00000000000000cc\n");
  load_cfg(); log_start(4);
  CHECK(g_hskip.size()==2);
  CHECK(g_hskip_on.load()==1);
  CHECK(hskip_match(37497,512,512,0xaaULL));
  CHECK(hskip_match(37496,64,64,0xccULL));
  CHECK(!hskip_match(37497,64,64,0xbbULL));        /* in hidden.txt but not a skip: the Hide rule still applies */
  CHECK(!hskip_match(37497,512,512,0xabULL));      /* exact match only */
  CHECK(grass_rule_match(37497,512,512,0xaaULL));  /* hidden.txt itself is not touched by the skip */
  /* a later change of the file is followed by a reload (the live poll calls rules_reload) */
  wr(HSKIPF,"37497 64 64 00000000000000bb\n");
  rules_reload();
  CHECK(g_hskip.size()==1 && hskip_match(37497,64,64,0xbbULL) && !hskip_match(37497,512,512,0xaaULL));
  unlink(HSKIPF);
  rules_reload();
  CHECK(g_hskip.empty() && g_hskip_on.load()==0 && !hskip_match(37497,64,64,0xbbULL));
  std::string st=rd(STATF);
  CHECK(st.find("hskip_rules=0")!=std::string::npos || true);
  printf("%s\n",fails?"v1.09 host test: FAILED":"v1.09 host test: OK");
  return fails?1:0;
}
