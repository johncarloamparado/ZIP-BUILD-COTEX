package android.graphics; public class Rect { public int left, top, right, bottom; public Rect() {} }
