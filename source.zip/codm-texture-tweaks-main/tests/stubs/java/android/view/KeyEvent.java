package android.view; public class KeyEvent { public static final int ACTION_UP=1, KEYCODE_ENTER=66; public int getKeyCode(){return 0;} public int getAction(){return 0;} }
