package android.text; public class InputType { public static final int TYPE_CLASS_TEXT=1; }
