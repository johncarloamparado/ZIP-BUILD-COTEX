/* v0.81: eight Flat levels, Look on after Restore (op f) + anisotropy put back, ASTC keep-soft switch, Box loot spoof (GPU / RAM / PVRTC), probe (log only), Box loot crash safety. */
#include <array>
#include "main_test_copy.cpp"
extern "C" int __android_log_print(int,const char*,const char*,...){return 0;}
extern "C" int __android_log_vprint(int,const char*,const char*,va_list){return 0;}
static int fails=0;
#define CHECK(c) do{if(!(c)){printf("FAIL line %d: %s\n",__LINE__,#c);fails++;}}while(0)
static void wr(const char *p,const char *s){FILE*f=fopen(p,"w");if(f){fputs(s,f);fclose(f);}}
static std::string rd(const char *p){FILE*f=fopen(p,"r");if(!f)return "";std::string s;char b[4096];while(size_t n=fread(b,1,sizeof b,f))s.append(b,n);fclose(f);return s;}
static std::vector<std::pair<GLenum,GLint>> g_tp; static std::vector<std::pair<GLenum,float>> g_tpf;
static void fake_tp(GLenum,GLenum p,GLint v){ g_tp.push_back({p,v}); }
static void fake_tpf(GLenum,GLenum p,GLfloat v){ g_tpf.push_back({p,v}); }
static int base_of(){ int b=-1; for(auto &c:g_tp) if(c.first==GL_TEXTURE_BASE_LEVEL) b=c.second; return b; }
static int g_tex_bound=7, g_real_pbo=0; static std::set<GLuint> g_alive;
static void fake_giv(GLenum e,GLint *v){ if(e==0x88EF)*v=g_real_pbo; else if(e==0x8069)*v=g_tex_bound; else *v=0; }
static GLboolean fake_is(GLuint id){return g_alive.count(id)?1:0;}
static void fake_bb(GLenum,GLuint b){g_real_pbo=(int)b;}
static void fake_bind(GLenum,GLuint id){g_tex_bound=(int)id;}
static void fake_ctsi2(GLenum,GLint,GLint,GLint,GLsizei,GLsizei,GLenum,GLsizei,const void*){}
static void fake_del(GLsizei,const GLuint*){}
static void gl_gen(GLsizei n,GLuint*o){ for(GLsizei i=0;i<n;i++)o[i]=900+i; }
static void gl_del(GLsizei,const GLuint*){}
static void gl_stor(GLenum,GLsizei,GLenum,GLsizei,GLsizei){}
static void gl_cp(GLuint,GLenum,GLint,GLint,GLint,GLint,GLuint,GLenum,GLint,GLint,GLint,GLint,GLsizei,GLsizei,GLsizei){}
static void gl_lvp(GLenum,GLint,GLenum,GLint*v){ *v=0; }
static GLenum gl_err(){ return 0; }
static long long mem_hook(){return 2000000;}
static int64_t T=0; static void poll(){ T+=2000000000LL; live_poll(T); lv_apply(); }
static std::string hex16(uint64_t h){ char b[24]; snprintf(b,sizeof b,"%016llx",(unsigned long long)h); return b; }
static const GLubyte *fake_gets(GLenum n){ if(n==0x1F01) return (const GLubyte*)"Mali-G57 MC2"; if(n==0x1F00) return (const GLubyte*)"ARM"; if(n==0x1F03) return (const GLubyte*)"GL_OES_texture_float GL_EXT_texture_filter_anisotropic"; return (const GLubyte*)"x"; }
static std::string g_open_seen;
static FILE *fake_fopen(const char *p,const char *m){ g_open_seen=p; return fopen("/dev/null",m); }
static int fake_sysinfo(struct sysinfo *s){ memset(s,0,sizeof *s); s->totalram=8ull*1024*1024*1024; s->freeram=3ull*1024*1024*1024; s->mem_unit=1; return 0; }
static int fake_spg(const char *n,char *v){ strcpy(v, strstr(n,"serial")?"SECRET123":"value1"); return (int)strlen(v); }
int main(){
  /* ---- 1. eight Flat levels (code -> target pixels 8,4,2,1,32,16,12,6) ---- */
  wr(LIVEF,"0\n"); load_cfg(); log_start(4);
  real_tp=fake_tp; o_tpf=fake_tpf; tl_unit=0; tl_bound[0]=31;
  g_near=0; g_testtex=0; g_style=0; g_blk=0; g_alpha=0; g_astc=0; g_grass_on=0; g_orig_on=0; g_minsz=64; g_delay=0; g_skip.clear();
  const int want[9]={0,5,6,7,8,3,4,4,5};          /* 256x256, 9 levels */
  for(int code=1;code<=8;code++){ g_flat=code; g_tp.clear(); tex_post(GL_TEXTURE_2D,9,0x9274,256,256,true); CHECK(base_of()==want[code]); }
  g_flat=8; { FILE*f=fopen(FLATF,"w"); fputs("8\n",f); fclose(f); } load_cfg(); CHECK(g_flat.load()==8);
  { FILE*f=fopen(FLATF,"w"); fputs("9\n",f); fclose(f); } load_cfg(); CHECK(g_flat.load()==8);
  g_near=0; g_testtex=0; g_style=0; g_blk=0; g_alpha=0; g_astc=0; g_grass_on=0; g_orig_on=0; g_minsz=64; g_delay=0; g_skip.clear();   /* load_cfg put the defaults back */
  /* ---- 2. Keep ASTC soft: ASTC stays untouched only while the switch is on; ETC2 RGB is not affected ---- */
  g_flat=4; g_astc=0; g_tp.clear(); tex_post(GL_TEXTURE_2D,9,0x93B0,256,256,true); CHECK(base_of()==8);
  g_astc=1; g_tp.clear(); tex_post(GL_TEXTURE_2D,9,0x93B0,256,256,true); CHECK(base_of()==-1);
  g_tp.clear(); tex_post(GL_TEXTURE_2D,9,0x93D0,256,256,true); CHECK(base_of()==-1);
  g_tp.clear(); tex_post(GL_TEXTURE_2D,9,0x9274,256,256,true); CHECK(base_of()==8);
  g_astc=0;
  /* ---- 3. anisotropy the game asked for is remembered and put back ---- */
  g_orig_on=1; g_style=1; tl_bound[0]=21; g_tpf.clear();
  h_tpf(GL_TEXTURE_2D,TEX_ANISO,8.0f);
  CHECK(g_tpf.size()==1 && g_tpf[0].second==1.0f && g_oan[21].load()==8);
  g_tpf.clear(); restore_aniso(21); CHECK(g_tpf.size()==1 && g_tpf[0].first==TEX_ANISO && g_tpf[0].second==8.0f);
  g_tpf.clear(); restore_aniso(22); CHECK(g_tpf.empty());
  { GLuint ids[1]={21}; h_del(1,ids); } CHECK(g_oan[21].load()==0);
  g_orig_on=0; g_style=0;
  /* ---- 4. Look on (op f) after Restore (op r): the look comes back, the anisotropy goes back with Restore ---- */
  unlink(LIVECF); unlink(MARKF); wr(GRASSF,""); wr(ORIGF,""); wr(LIVEF,"1\n"); load_cfg();
  g_giv_hook=fake_giv; g_sp_is_hook=fake_is; g_sp_bb_hook=fake_bb; o_bind=fake_bind; o_ctsi2=fake_ctsi2; o_del=fake_del; real_tp=fake_tp; o_tpf=fake_tpf;
  g_lvgl_hook={gl_gen,gl_del,gl_stor,gl_cp,gl_lvp,gl_err}; g_lvgl_hooked=true; g_lv_mem_hook=mem_hook;
  g_near=0; g_testtex=0; g_style=0; g_flat=4; g_blk=0; g_alpha=0; g_grass_on=0; g_orig_on=1; g_minsz=64; g_delay=0; g_skip.clear();   /* no built-in skip rule may hide the test texture */
  g_rt=(pid_t)syscall(SYS_gettid); g_t0=1; for(GLuint i=1;i<=3000;i++)g_alive.insert(i);
  std::vector<uint8_t> A(65536,11); uint64_t hA=tex_hash(A.data(),(int)A.size());
  tl_bound[0]=2; g_tex_bound=2; h_st(GL_TEXTURE_2D,9,0x9279,256,256);
  h_tpf(GL_TEXTURE_2D,TEX_ANISO,8.0f);
  h_ctsi2(GL_TEXTURE_2D,0,0,0,256,256,0x9279,(GLsizei)A.size(),A.data());
  CHECK(g_oan[2].load()==8);
  wr(MARKF,""); poll();
  g_tp.clear(); g_tpf.clear(); wr(LIVECF,("r "+hex16(hA)+"\n").c_str()); usleep(1100000); poll(); poll();
  CHECK(base_of()==0); CHECK(g_tpf.size()==1 && g_tpf[0].second==8.0f);
  g_tp.clear(); wr(LIVECF,("f "+hex16(hA)+"\n").c_str()); usleep(1100000); poll(); poll();
  CHECK(base_of()==8);                              /* flat code 4 = 1 px: base level 8 of 9 */
  CHECK(rd(P("codm_tex.status")).find("lookon=1")!=std::string::npos);
  CHECK(rd(P("codm_tex.log")).find("look_on=1")!=std::string::npos);
  unlink(LIVEF); unlink(LIVECF); unlink(MARKF); g_orig_on=0; g_flat=0;
  /* ---- 5. Box loot: GPU / vendor / extensions / RAM answered differently only while ON ---- */
  o_gets=fake_gets; o_fopen=fake_fopen; o_sysinfo=fake_sysinfo; o_spg=fake_spg;
  g_bl=0; g_bl_gpu=1; g_bl_pvr=1; g_bl_ram=2048; g_probe=1;
  CHECK(!strcmp((const char*)h_gets(0x1F01),"Mali-G57 MC2") && !strcmp((const char*)h_gets(0x1F00),"ARM"));
  { FILE*q=h_fopen("/proc/meminfo","r"); CHECK(q!=nullptr); if(q) fclose(q); CHECK(g_open_seen=="/proc/meminfo"); }
  { struct sysinfo si; h_sysinfo(&si); CHECK(si.totalram==8ull*1024*1024*1024); }
  g_bl=1;
  CHECK(!strcmp((const char*)h_gets(0x1F01),"PowerVR Rogue GE8320") && !strcmp((const char*)h_gets(0x1F00),"Imagination Technologies"));
  { std::string e=(const char*)h_gets(0x1F03); CHECK(e.find("GL_IMG_texture_compression_pvrtc")!=std::string::npos && e.find("GL_OES_texture_float")!=std::string::npos); }
  g_bl_gpu=0; CHECK(!strcmp((const char*)h_gets(0x1F01),"Mali-G57 MC2")); g_bl_gpu=1;
  g_bl_pvr=0; { std::string e=(const char*)h_gets(0x1F03); CHECK(e.find("pvrtc")==std::string::npos); } g_bl_pvr=1;
  { FILE*q=h_fopen("/proc/meminfo","r"); CHECK(q!=nullptr); long long tot=0,fr=-1,av=-1; if(q){ char ln[160]; while(fgets(ln,sizeof ln,q)){ long long v; if(sscanf(ln,"MemTotal: %lld",&v)==1)tot=v; else if(sscanf(ln,"MemFree: %lld",&v)==1)fr=v; else if(sscanf(ln,"MemAvailable: %lld",&v)==1)av=v; } fclose(q); }
    CHECK(tot==2048LL*1024); CHECK(fr>=0 && fr<=2048LL*1024/4); CHECK(av>=0 && av<=2048LL*1024*55/100); }
  { struct sysinfo si; h_sysinfo(&si); CHECK(si.totalram==2048ull*1024*1024 && si.freeram<=2048ull*1024*1024/4); }
  g_bl_ram=0; { struct sysinfo si; h_sysinfo(&si); CHECK(si.totalram==8ull*1024*1024*1024); } g_open_seen.clear(); { FILE*q=h_fopen("/proc/meminfo","r"); if(q)fclose(q); CHECK(g_open_seen=="/proc/meminfo"); }
  g_bl=0;
  /* ---- 6. probe lines (log only); personal property values are never written ---- */
  char v[92]; h_spg("ro.product.model",v); h_spg("ro.serialno",v);
  std::string lg=rd(P("codm_tex.log"));
  CHECK(lg.find("PROBE gl glGetString(0x1F01) = Mali-G57 MC2")!=std::string::npos);
  CHECK(lg.find("PROBE open /proc/meminfo")!=std::string::npos);
  CHECK(lg.find("PROBE ram sysinfo = totalram=8192MB")!=std::string::npos);
  CHECK(lg.find("PROBE prop ro.product.model = value1")!=std::string::npos);
  CHECK(lg.find("PROBE prop ro.serialno = (not logged)")!=std::string::npos && lg.find("SECRET123")==std::string::npos);
  CHECK(lg.find("BOXLOOT answered a different value for GL_RENDERER")!=std::string::npos);
  /* probe OFF and Box loot OFF: nothing new is written */
  g_probe=0; size_t before=rd(P("codm_tex.log")).size(); h_spg("ro.build.type",v); h_gets(0x1F02); CHECK(rd(P("codm_tex.log")).size()==before); g_probe=1;
  /* ---- 7. Box loot safety: a launch that did not reach 20 frames switches it OFF; one that did keeps it ---- */
  wr(BLF,"1\n"); wr(BLRUNF,"0\n"); load_cfg(); CHECK(g_bl.load()==0); CHECK(rd(BLF)=="0\n");
  wr(BLF,"1\n"); wr(BLRUNF,"20\n"); load_cfg(); CHECK(g_bl.load()==1); CHECK(access(BLRUNF,F_OK)==0);   /* marker written again for this launch */
  unlink(BLRUNF); wr(BLF,"1\n"); wr(BLRAMF,"100\n"); load_cfg(); CHECK(g_bl_ram.load()==512); unlink(BLRUNF);
  wr(BLRAMF,"99999\n"); load_cfg(); CHECK(g_bl_ram.load()==16384); unlink(BLRUNF);
  wr(BLF,"0\n"); wr(BLRAMF,"0\n"); load_cfg(); CHECK(g_bl.load()==0 && access(BLRUNF,F_OK)!=0);
  if(fails){printf("TESTS FAILED %d\n",fails);return 1;}
  printf("v081 ok\n"); return 0;
}
