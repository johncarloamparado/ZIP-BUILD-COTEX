/* v1.10: one "RULE HITS" line per minute in the log while the hit counters change (A2); it is kept when the 4 MB log is cut. */
#include "main_test_copy.cpp"
extern "C" int __android_log_print(int,const char*,const char*,...){return 0;}
extern "C" int __android_log_vprint(int,const char*,const char*,va_list){return 0;}
static int fails=0;
#define CHECK(c) do{if(!(c)){printf("FAIL line %d: %s\n",__LINE__,#c);fails++;}}while(0)
static void wr(const char *p,const char *s){FILE*f=fopen(p,"w");if(f){fputs(s,f);fclose(f);}}
static std::string rd(const char *p){FILE*f=fopen(p,"r");if(!f)return "";std::string s;char b[4096];while(size_t n=fread(b,1,sizeof b,f))s.append(b,n);fclose(f);return s;}
static int count(const std::string &h,const char *n){int c=0;size_t p=0;while((p=h.find(n,p))!=std::string::npos){c++;p+=strlen(n);}return c;}
int main(){
  wr(GRASSF,"37497 512 512 00000000000000aa\n"); wr(ORIGF,""); unlink(HSKIPF);
  load_cfg(); log_start(4);
  const int64_t S=1000000000LL;
  g_t0=1;
  rules_summary(100*S);                                    /* no hits yet: counters 0 differ from -1 -> one line */
  CHECK(count(rd(LOGF),"RULE HITS")==1);
  rules_summary(110*S);                                    /* inside the minute: nothing */
  CHECK(count(rd(LOGF),"RULE HITS")==1);
  rules_summary(170*S);                                    /* a minute later, nothing changed: nothing */
  CHECK(count(rd(LOGF),"RULE HITS")==1);
  g_grass_n=7; g_hskip_n=2;
  rules_summary(240*S);
  std::string lg=rd(LOGF);
  CHECK(count(lg,"RULE HITS")==2);
  CHECK(lg.find("hidden 7, restored 0, kept by skip 2")!=std::string::npos);
  CHECK(lg.find("hide 1, restore 0, skip 0")!=std::string::npos);
  CHECK(log_is_event("RULE HITS t=240: x") && log_is_event("RULES reloaded while playing"));
  wr(GRASSF,""); rules_reload();                           /* no rule loaded at all: silent */
  g_grass_n=9; rules_summary(400*S);
  CHECK(count(rd(LOGF),"RULE HITS")==2);
  printf("%s\n",fails?"v1.10 host test: FAILED":"v1.10 host test: OK");
  return fails?1:0;
}
