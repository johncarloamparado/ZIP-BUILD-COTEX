#!/bin/sh
# v0.91 host test for service.sh: runs the REAL file (not a reimplementation of it), pointed at a fake module
# folder and a fake /data (CODM_DATA_ROOT - only this test ever sets it; unset on a real device, so service.sh
# still defaults to the real /data there) with its two passes sped up (CODM_SVC_DELAYS - same deal). Checks
# that it writes codm_tex.integrity into the main app folder AND every clone folder with the right verdict,
# that a folder which does not exist yet (a brand-new install) is simply skipped with no error, and that the
# delayed second pass still finds a data folder created after the first pass already ran. Run by
# tests/run_host_tests.sh.
set -u
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
SVC="$ROOT/webroot/service.sh"    # v0.92: ships from webroot/; customize.sh copies it to the module root (build_mod does the same)
CHK="$ROOT/webroot/check.sh"
fails=0
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
PKG="com.garena.game.codm"

build_mod() { # build_mod <tag> <official 1|0> [real] -> sets $MOD   ("real" = check.sh exactly as shipped; default = signing switched off)
  MOD="$TMP/mod_$1"; rm -rf "$MOD"; mkdir -p "$MOD/webroot" "$MOD/zygisk"
  echo "<html>index</html>" > "$MOD/webroot/index.html"
  echo "notice" > "$MOD/webroot/NOTICE.txt"
  echo "license" > "$MOD/webroot/LICENSE.txt"
  echo "#!/system/bin/sh" > "$MOD/customize.sh"
  if [ "${3:-}" = real ]; then cp "$CHK" "$MOD/webroot/check.sh"
  else sed 's/^CODM_REQUIRE_SIGNED=.*/CODM_REQUIRE_SIGNED=0/' "$CHK" > "$MOD/webroot/check.sh"; fi
  cp "$SVC" "$MOD/webroot/service.sh"
  cp "$SVC" "$MOD/service.sh"
  if [ "$2" = 1 ]; then NAME="CODM Blocky Textures"; else NAME="Ghost Textures"; fi
  { echo "id=codm_tex_logger"; echo "name=$NAME"; echo "author=Q9 Papyrus"; echo "description=d"; } > "$MOD/module.prop"
  h() { sha256sum "$1" | cut -d' ' -f1; }
  NAMEH="$(printf '%s' "CODM Blocky Textures" | sha256sum | cut -d' ' -f1)"   # the mark always expects THIS name, regardless of $2
  DESCH="$(printf '%s' "d" | sha256sum | cut -d' ' -f1)"
  echo "CODMSUM1 index=$(h "$MOD/webroot/index.html") notice=$(h "$MOD/webroot/NOTICE.txt") license=$(h "$MOD/webroot/LICENSE.txt") customize=$(h "$MOD/customize.sh") chk=$(h "$MOD/webroot/check.sh") svc=$(h "$MOD/webroot/service.sh") name=$NAMEH desc=$DESCH" > "$MOD/zygisk/arm64-v8a.so"
}

run_service() { # run_service <mod dir> <data root>
  CODM_DATA_ROOT="$2" CODM_CFG_DIR="$TMP/cfg" CODM_SVC_DELAYS="0 1" sh "$1/service.sh"
}

wait_for() { # wait_for <file> -> polls up to ~3s
  i=0
  while [ ! -f "$1" ] && [ "$i" -lt 30 ]; do sleep 0.1; i=$((i + 1)); done
}

expect() { # expect <label> <file> <status>
  wait_for "$2"
  if [ ! -f "$2" ]; then echo "FAIL [$1]: $2 was never written"; fails=$((fails + 1)); return; fi
  got="$(sed -n 's/^status=//p' "$2" | head -n 1)"
  [ "$got" = "$3" ] || { echo "FAIL [$1]: $2 has status=$got, wanted $3"; fails=$((fails + 1)); }
}

# 1: official module, main data dir + two clones all exist before the service runs
build_mod 1 1
DATA1="$TMP/data1"
mkdir -p "$DATA1/data/$PKG/files" "$DATA1/user/0/$PKG/files" "$DATA1/user/10/$PKG/files"
run_service "$MOD" "$DATA1"
expect "main dir"   "$DATA1/data/$PKG/files/codm_tex.integrity"       official
expect "clone u0"   "$DATA1/user/0/$PKG/files/codm_tex.integrity"     official
expect "clone u10"  "$DATA1/user/10/$PKG/files/codm_tex.integrity"    official

# 2: tampered module (renamed) -> every dir gets status=tampered
build_mod 2 0
DATA2="$TMP/data2"
mkdir -p "$DATA2/data/$PKG/files"
run_service "$MOD" "$DATA2"
expect "renamed -> tampered" "$DATA2/data/$PKG/files/codm_tex.integrity" tampered

# 3: no data dir at all yet (brand-new install, game never opened) -> no crash, no file, nothing to clean up
build_mod 3 1
DATA3="$TMP/data3"   # deliberately never created
if out="$(run_service "$MOD" "$DATA3" 2>&1)"; then :; fi
sleep 1.3   # let both backgrounded passes finish
if [ -n "${out:-}" ]; then echo "FAIL [no data dir yet]: service.sh printed something: $out"; fails=$((fails + 1)); fi
[ -e "$DATA3" ] && { echo "FAIL [no data dir yet]: $DATA3 should still not exist"; fails=$((fails + 1)); }

# 4: data dir appears only AFTER the service script has already started - the delayed second pass must still
# catch it (expect()'s own polling comfortably outlasts pass 2's 1s delay either way)
build_mod 4 1
DATA4="$TMP/data4"
run_service "$MOD" "$DATA4"
mkdir -p "$DATA4/data/$PKG/files"
expect "late-created dir caught by pass 2" "$DATA4/data/$PKG/files/codm_tex.integrity" official

# 5 (v0.92): check.sh exactly as shipped needs a signed release; an unsigned module is tampered, reason unsigned
build_mod 5 1 real
DATA5="$TMP/data5"
mkdir -p "$DATA5/data/$PKG/files"
run_service "$MOD" "$DATA5"
expect "unsigned module (shipped check.sh) -> tampered" "$DATA5/data/$PKG/files/codm_tex.integrity" tampered
[ "$(sed -n 's/^reason=//p' "$DATA5/data/$PKG/files/codm_tex.integrity" | head -n 1)" = unsigned ] || { echo "FAIL [unsigned]: reason is not unsigned"; fails=$((fails + 1)); }

# 6 (v1.08, audit F1/F3): a symlink planted by the game uid at the verdict name (or as the folder itself) is never written through
build_mod 6 1
DATA6="$TMP/data6"
mkdir -p "$DATA6/data/$PKG/files" "$DATA6/user/0/$PKG" "$TMP/victimdir/files"
echo "ROOT SECRET" > "$TMP/victim"; chmod 600 "$TMP/victim"
ln -s "$TMP/victim" "$DATA6/data/$PKG/files/codm_tex.integrity"            # file symlink
ln -s "$TMP/victimdir/files" "$DATA6/user/0/$PKG/files"                    # the clone "files" folder itself is a symlink to a directory the game does not own
ln -s "$TMP/victim" "$TMP/victimdir/files/codm_tex.integrity"
run_service "$MOD" "$DATA6"
i=0; while [ -L "$DATA6/data/$PKG/files/codm_tex.integrity" ] && [ "$i" -lt 30 ]; do sleep 0.1; i=$((i + 1)); done
expect "symlink at the verdict name is replaced by a real file" "$DATA6/data/$PKG/files/codm_tex.integrity" official
[ -L "$DATA6/data/$PKG/files/codm_tex.integrity" ] && { echo "FAIL [symlink]: the verdict is still a symlink"; fails=$((fails + 1)); }
[ "$(cat "$TMP/victim")" = "ROOT SECRET" ] || { echo "FAIL [symlink]: the file the link pointed to was overwritten"; fails=$((fails + 1)); }
[ "$(stat -c %a "$TMP/victim")" = 600 ] || { echo "FAIL [symlink]: the mode of the link target changed"; fails=$((fails + 1)); }
sleep 1.4
[ "$(stat -c %a "$DATA6/data/$PKG/files/codm_tex.integrity")" = 644 ] || { echo "FAIL [mode]: the verdict is not 644"; fails=$((fails + 1)); }
[ "$(stat -c %u "$DATA6/data/$PKG/files/codm_tex.integrity")" = "$(id -u)" ] || { echo "FAIL [owner]: the verdict is not owned by the writer (root on a phone)"; fails=$((fails + 1)); }
[ "$(cat "$TMP/victim")" = "ROOT SECRET" ] || { echo "FAIL [symlinked folder]: the link target was written through"; fails=$((fails + 1)); }
[ -L "$TMP/victimdir/files/codm_tex.integrity" ] || { echo "FAIL [symlinked folder]: the link inside a symlinked game folder was touched"; fails=$((fails + 1)); }
[ -z "$(ls "$TMP/cfg/tmp" 2>/dev/null)" ] || { echo "FAIL [temp]: a temp file is left in the root-only folder"; fails=$((fails + 1)); }
[ "$(stat -c %a "$TMP/cfg")" = 700 ] || { echo "FAIL [cfg]: the root-only folder is not 700"; fails=$((fails + 1)); }
# nothing predictable is left inside the game folder
ls "$DATA6/data/$PKG/files" | grep -q 'tmp' && { echo "FAIL [temp]: a temp file name was left in the game folder"; fails=$((fails + 1)); }

if [ "$fails" = 0 ]; then echo "ALL TESTS PASSED (service.sh)"; else echo "TESTS FAILED $fails (service.sh)"; fi
exit $([ "$fails" = 0 ] && echo 0 || echo 1)
