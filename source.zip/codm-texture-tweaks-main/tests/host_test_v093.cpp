/* v0.93: MARK A starts a new finder window: the candidate lists forget what they logged, so a texture the game freed and uploaded again
   shows up again in the A..B window (before it was logged once per game session and could never appear in a later window). */
#include <array>
#include "main_test_copy.cpp"
extern "C" int __android_log_print(int,const char*,const char*,...){return 0;}
extern "C" int __android_log_vprint(int,const char*,const char*,va_list){return 0;}
static int fails=0;
#define CHECK(c) do{if(!(c)){printf("FAIL line %d: %s\n",__LINE__,#c);fails++;}}while(0)
static void wr(const char *p,const char *s){FILE*f=fopen(p,"w");if(f){fputs(s,f);fclose(f);}}
static std::string rd(const char *p){FILE*f=fopen(p,"r");if(!f)return "";std::string s;char b[4096];while(size_t n=fread(b,1,sizeof b,f))s.append(b,n);fclose(f);return s;}
static std::vector<std::pair<GLenum,GLint>> g_tp;
static void fake_tp(GLenum,GLenum p,GLint v){ g_tp.push_back({p,v}); }
static void fake_tpf(GLenum,GLenum,GLfloat){}
static int last_of(GLenum pname){ int b=-1; for(auto &c:g_tp) if(c.first==pname) b=c.second; return b; }
static int g_tex_bound=7, g_real_pbo=0; static std::set<GLuint> g_alive;
static void fake_giv(GLenum e,GLint *v){ if(e==0x88EF)*v=g_real_pbo; else if(e==0x8069)*v=g_tex_bound; else *v=0; }
static GLboolean fake_is(GLuint id){return g_alive.count(id)?1:0;}
static void fake_bb(GLenum,GLuint b){g_real_pbo=(int)b;}
static void fake_bind(GLenum,GLuint id){g_tex_bound=(int)id;}
static void fake_ctsi2(GLenum,GLint,GLint,GLint,GLsizei,GLsizei,GLenum,GLsizei,const void*){}
static void fake_del(GLsizei,const GLuint*){}
static void gl_gen(GLsizei n,GLuint*o){ for(GLsizei i=0;i<n;i++)o[i]=900+i; }
static void gl_del(GLsizei,const GLuint*){}
static void gl_stor(GLenum,GLsizei,GLenum,GLsizei,GLsizei){}
static void gl_cp(GLuint,GLenum,GLint,GLint,GLint,GLint,GLuint,GLenum,GLint,GLint,GLint,GLint,GLsizei,GLsizei,GLsizei){}
static void gl_lvp(GLenum,GLint,GLenum,GLint*v){ *v=0; }
static GLenum gl_err(){ return 0; }
static long long mem_hook(){return 2000000;}
static int64_t T=0; static void poll(){ T+=2000000000LL; live_poll(T); lv_apply(); }
static std::string hex16(uint64_t h){ char b[24]; snprintf(b,sizeof b,"%016llx",(unsigned long long)h); return b; }
/* the game makes a texture: filters first, then storage (look applied), then the level 0 picture */
static void game_loads(GLuint id, const std::vector<uint8_t> &data){
  tl_bound[0]=id; g_tex_bound=(int)id;
  h_tp(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,0x2703);          /* LINEAR_MIPMAP_LINEAR: what the game wants */
  h_tp(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,0x2601);
  h_st(GL_TEXTURE_2D,9,0x9279,256,256);
  h_ctsi2(GL_TEXTURE_2D,0,0,0,256,256,0x9279,(GLsizei)data.size(),data.data());
}
static int cnt(const std::string &s, const std::string &needle){ int c=0; size_t p=0; while((p=s.find(needle,p))!=std::string::npos){c++;p++;} return c; }
int main(){
  unlink(LIVECF); unlink(MARKF); wr(GRASSF,""); wr(ORIGF,""); wr(LIVEF,"1\n"); load_cfg(); unlink(LOGF); log_start(4);
  g_giv_hook=fake_giv; g_sp_is_hook=fake_is; g_sp_bb_hook=fake_bb; o_bind=fake_bind; o_ctsi2=fake_ctsi2; o_del=fake_del; real_tp=fake_tp; o_tpf=fake_tpf;
  g_lvgl_hook={gl_gen,gl_del,gl_stor,gl_cp,gl_lvp,gl_err}; g_lvgl_hooked=true; g_lv_mem_hook=mem_hook;
  g_near=0; g_testtex=0; g_style=0; g_flat=4; g_blk=0; g_astc=0; g_grass_on=0; g_orig_on=0; g_minsz=64; g_delay=0; g_skip.clear();
  g_rt=(pid_t)syscall(SYS_gettid); g_t0=1; for(GLuint i=1;i<=3000;i++)g_alive.insert(i);
  std::vector<uint8_t> A(65536,11); uint64_t hA=tex_hash(A.data(),(int)A.size());
  std::string key="h="+hex16(hA);
  poll();                                                          /* first look = baseline (no mark yet) */
  game_loads(2,A);                                                 /* first upload: listed once */
  { GLuint ids[1]={2}; h_del(1,ids); }
  game_loads(3,A);                                                 /* uploaded again (next match): same session, NOT listed again */
  std::string lg=rd(LOGF);
  CHECK(cnt(lg,"RESTORECAND")==1 && cnt(lg,"GRASSCAND")==1 && cnt(lg,key)==2);
  wr(MARKF,"A\n"); usleep(1100000); poll(); poll();                                         /* the finder starts a window */
  { GLuint ids[1]={3}; h_del(1,ids); }
  game_loads(4,A);                                                 /* uploaded again inside the window: listed again */
  lg=rd(LOGF);
  CHECK(cnt(lg,"RESTORECAND")==2 && cnt(lg,"GRASSCAND")==2);
  CHECK(lg.find("MARK A ")!=std::string::npos && lg.find("MARK A ")<lg.rfind("RESTORECAND"));
  game_loads(5,A);                                                 /* a second copy in the same window is still listed only once */
  lg=rd(LOGF);
  CHECK(cnt(lg,"RESTORECAND")==2);
  unlink(LIVEF); unlink(LIVECF); unlink(MARKF);
  if(fails){printf("TESTS FAILED %d\n",fails);return 1;}
  printf("v093 ok\n"); return 0;
}
