/* v0.80: FPSSTEP diagnostic. A frame-rate jump (about 125 fps -> about 30 fps) must write one FPSSTEP line (log only, nothing else changes).
   Real time: about 12 seconds (the frame-time window is 5 seconds). */
#include "main_test_copy.cpp"
extern "C" int __android_log_print(int,const char*,const char*,...){return 0;}
extern "C" int __android_log_vprint(int,const char*,const char*,va_list){return 0;}
static int fails=0;
#define CHECK(c) do{if(!(c)){printf("FAIL line %d: %s\n",__LINE__,#c);fails++;}}while(0)
static std::string rd(const char *p){FILE*f=fopen(p,"r");if(!f)return "";std::string s;char b[4096];while(size_t n=fread(b,1,sizeof b,f))s.append(b,n);fclose(f);return s;}
static EGLBoolean fake_swap(EGLDisplay, EGLSurface){ return EGL_TRUE; }
static void run_for(double sec, int sleep_us){
  int64_t t0 = now_ns();
  while ((now_ns() - t0) < (int64_t)(sec * 1e9)) { h_swap(nullptr, nullptr); usleep(sleep_us); }
}
int main(){
  load_cfg(); log_start(4);
  g_fps = 0; g_live_on = 0; g_near = 0;
  o_swap = fake_swap;
  g_rt = (pid_t)syscall(SYS_gettid);
  run_for(5.6, 8000);          /* about 125 fps */
  run_for(5.8, 33000);         /* about 30 fps  */
  std::string log = rd(LOGF);
  size_t ft = 0, n = 0; while ((ft = log.find("FT fps=", ft)) != std::string::npos) { n++; ft += 7; }
  CHECK(n >= 2);
  size_t p = log.find("FPSSTEP from=");
  CHECK(p != std::string::npos);
  if (p != std::string::npos) {
    double from = 0, to = 0; sscanf(log.c_str() + p, "FPSSTEP from=%lf to=%lf", &from, &to);
    printf("FPSSTEP from=%.1f to=%.1f\n", from, to);
    CHECK(from > 90 && to < 45 && to > 15);
  }
  if (!fails) printf("v080 ok\n");
  return fails ? 1 : 0;
}
