#!/usr/bin/env python3
"""v0.97 live menu: source checks (the menu is compiled only against stubs here, so these pin the intended behaviour; the phone is the real test)."""
import os,re,sys
H=os.path.dirname(os.path.abspath(__file__))
J=open(os.path.join(H,"..","menu","q9","Menu.java"),encoding="utf-8").read()
W=open(os.path.join(H,"..","webroot","index.html"),encoding="utf-8").read()
fails=[]
def ck(n,c):
    print("PASS" if c else "FAIL",n)
    if not c: fails.append(n)
ck("content scales with the window size (dp / ts use KS[size]; window geometry uses dpx)", "KS[size]" in J and "private static int dpx(" in J and "private static float ts(" in J and "dpx(BASE_W * SCALE[size])" in J)
ck("buttons keep a minimum touch height per size (MINH / MINS)", "MINH[size]" in J and "MINS[size]" in J)
ck("Saved rows are one line (name+info column, buttons on the same line, Ungroup only in a group)", "h.l2.setVisibility(!grpMode && u.size() > 1" in J and "setEllipsize(TextUtils.TruncateAt.END)" in J)
ck("Saved header is one row (Restore | Hide | Group...) at 35 : 35 : 30 and the help lines only on M / L", 'wbtn(a, "Group\\u2026"' in J and '35f' in J and '30f' in J and "size >= 2 ? shown.size()" in J)
ck("Size, List limit and the search type are picked from a small list window", J.count("showPicker(")>=4 and "private static void pickLimit()" in J and '"Window size"' in J and '"Way to search"' in J)
ck("the search type list has only Narrow down for now", 'new String[]{"Narrow down"}' in J)
ck("picker is closed when the window closes or is rebuilt", "dismissPicker();" in J and J.count("dismissPicker()")>=4)
ck("v1.03 Restore has 'Restore all' again, like Hide (a lone texture = 'Restore')", "boolean showAll = true;" in J and "boolean showAll = mode == 0 ||" not in J)
ck("Cancel finder turns solid amber while it waits for the second tap", "AMBFILL" in J and '"Click again!"' in J and "renderControl();" in J)
ck("a save from the Test tab cancels the finder by itself", "fromFinder = formBack == 0" in J and 'toast("Saved. Finder cancelled.")' in J and "private static boolean saveRows(" in J)
ck("name box: window goes short and to the top above the keyboard, and comes back", "private static void applyTyping()" in J and "private static void typingOff()" in J and "setOnFocusChangeListener" in J and "getWindowVisibleDisplayFrame" in J)
ck("Live test mode switch writes live.txt AND menu.txt (WebUI)", 'liveW("menu.txt", on ? "1" : "0")' in W and 'id="menuOn"' not in W)
# ---- v0.98
M=open(os.path.join(H,"..","main.cpp"),encoding="utf-8").read()
D=open(os.path.join(H,"..","menu","q9","Data.java"),encoding="utf-8").read()
ck("v0.98 Hide: no 'Show all' button in the finder; one texture left says 'Hide' (not 'Hide all')", 'good(a, "Show all"' not in J and 'set.size() == 1 ? verb : verb + " all"' in J)
ck("v0.98 the word 'using' is an arrow now (under the button and in the path)", 'on ? "using"' not in J and 'u25B2 using' not in J and J.count('"\\u25B2"')>=2)
ck("v0.98 'Back to ...' button goes back one step and is only there when the test is not on its first part", 'if (path.size() > 1) {' in J and '"\\u2190 Back to "' in J and "up(path.size() - 2)" in J)
ck("v0.98 the answers are named 1st-N / 2nd-N (not yes N / other N)", 'path.add(new Node(name + "-" + part.size(), part))' in J and 'qFirstIdx == 0 ? "1st" : "2nd"' in J and 'into(qFirst, "yes")' not in J and 'into(now, "other")' not in J)
ck("v0.98 loading: busyStart on every Hide / Restore, finder buttons gated and dimmed, label with animation, stops at the module's lv_seq (or lv_last change, or time)", "private static void busyStart()" in J and J.count("gate(new Runnable()")>=8 and "BUSY_FR" in J and 'kvI(st, "lv_seq")' in J and "BUSY_MAX" in J and "if (!ls.isEmpty()) busyStart();" in J)
ck("v0.98 module counts finished live batches (lv_seq in the status file)", 'st_set_nw("lv_seq", std::to_string(++g_lv_seq));' in M)
# ---- v1.00
ck("v1.00 two lists: allRoot = what the List shows, root = what the test uses (alive only); no toggle", "allRoot = f.rows;" in J and "private static ArrayList<Data.Row> shownBase()" in J and "path.size() <= 1 ? allRoot : cur()" in J and "private static boolean isGone(Data.Row r)" in J)
ck("v1.00 the test (halves, Yes / No, Save of the result) still works on cur() = alive only", "final ArrayList<Data.Row> set = cur();" in J and "new Node(\"All \" + root.size(), root)" in J)
ck("v1.00 gone rows: dim, 'gone' text, button 'Gone' (Hide / Restore off), Save unchanged", "final boolean gone = isGone(r);" in J and 'h.b1.setText("Gone");' in J and "v.setAlpha(gone ? 0.5f : 1f);" in J and 'h.b2.setText(saved ? "Saved" : "Save");' in J)
ck("v1.00 List header counts gone ones and the rail count uses the shown list", '" gone" : ""' in J and "String.valueOf(shownBase().size())" in J)
ck("v1.00 Texture shortcuts has no 'Own risk' label (card text and the search index)", "OWN RISK" not in W and "Own risk" not in W)


# ---- v0.99
ck("v0.99 module answers 'a 0' with codm_tex.alive (seq, count, hashes, temp + rename)", "static void lv_write_alive()" in M and "ln[0] == 'a' && ln[1] == ' '" in M and 'ALIVEF P("codm_tex.alive")' in M and "rename(tmp.c_str(), ALIVEF)" in M)
ck("v0.99 menu asks, waits for a new seq (askAlive); v1.00: no toggle, the List keeps every texture and only the test is cut", "private static void askAlive(" in J and "Data.onlyAlive(f.rows, aliveSet)" in J and "askAlive(loud);" in J and "aliveOnly" not in J and "Loaded now only" not in J)
ck("v0.99 Data.readAlive / onlyAlive", "static Alive readAlive(File dir)" in D and "static ArrayList<Row> onlyAlive(" in D)
# ---- v1.01
ck("v1.01 'Wait after apply' setting: picker Off / 250 / 450 / 700 / 1000 / 1500 / 2000 ms, saved in menu_settle.txt, read at start, used instead of the fixed 450", "SETTLES = {0, 250, 450, 700, 1000, 1500, 2000}" in J and "private static void pickSettle()" in J and 'put("menu_settle.txt"' in J and "loadSettle();" in J and "now - busyAckAt >= busySettle" in J and "now - busyAckAt >= BUSY_SETTLE" not in J and '"Wait after apply: "' in J)
ck("v1.01 group mode: tick box (checklist) at the left of the row, whole row ticks / unticks, no 'Pick' / 'Picked' text", 'h.sel.setText(picked ? "\\u2713" : "");' in J and "v.setOnClickListener(grpMode ? tap(flip) : null);" in J and '"Picked"' not in J and '"Pick"' not in J and "Tick the textures to put together" in J)

# ---- v1.02
ck("v1.02 Cancel finder: 'Click again!' lasts CANCEL_ARM_MS = 2000 and the button goes back by itself (no 4 s any more)", "CANCEL_ARM_MS = 2000" in J and "<= CANCEL_ARM_MS" in J and "CANCEL_ARM_MS + 100" in J and "<= 4000" not in J and "}, 4100);" not in J)
ck("v1.02 (changed in v1.03) the group arrow now opens the group as its own page (grpPage), not a list under the row", "grpPage" in J and "grpOpen" not in J and "renderGroupPage(" in J and "h.ar.setText(\"Open \"" in J)
ck("v1.02 Keep ASTC soft is gone from the page (switch, key lists, backup list); the page deletes astc.txt; the module no longer reads it", 'id="astc"' not in W and "Keep ASTC soft</span>" not in W and "$D/astc.txt" in W and "g_astc = 0;" in open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "main.cpp"), encoding="utf-8").read())

# ---- v1.03
ck("v1.03 group page: back arrow, member rows with ON / OFF and Delete, 'not loaded now' label from the alive list (v1.10 wording)", "private static View memberView(" in J and '" \\u00B7 not loaded now"' in J and '" not loaded now"' in J and "memberGone(" in J and 'sm(a, "\\u2190"' in J and "askAliveOnce()" in J and "path.size() > 1" in J)
ck("v1.03 Delete = Click again that goes back by itself (DEL_ARM_MS), amber like Cancel finder", "DEL_ARM_MS = 2000" in J and "armDelete(id)" in J and '"Click again!"' in J)
ck("v1.03 Undo chip after Save and Delete (UNDO_MS), puts back texlib / hidden / orig and sends the reverse commands", "UNDO_MS = 3500" in J and "pushUndo(before, \"delete\")" in J and "pushUndo(before, \"save\")" in J and "private static void doUndo()" in J)
ck("v1.03 Settings tab (Wait after apply, List limit moved there); the word 'drag' is gone", 'TABN = {"Test", "List", "Saved", "Settings"}' in J and "private static void renderSettings()" in J and 'txt(a, "drag"' not in J and 'neut(a, "Wait after apply: "' in J[J.index("renderSettings() {"):])
ck("v1.03 compact spacing (tighter wt / fullW / button padding)", "m / 2 + dp(1)" in J and "top / 2 + dp(1)" in J)
print("FAILS",fails); sys.exit(1 if fails else 0)
