#!/bin/sh
# v0.86: runs customize.sh in a fake installer with a fake .so that carries the build mark, and checks the "Build check" result in nine situations.
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
T="$(mktemp -d)"; trap 'rm -rf "$T"' EXIT
fail=0
h() { sha256sum "$ROOT/$1" | cut -d' ' -f1; }
mk() { head -c 3000 /dev/urandom > "$1"; printf '\0%s\0more\0' "$2" >> "$1"; head -c 400 /dev/urandom >> "$1"; }
cat > "$T/run.sh" <<'EOS'
ui_print() { echo "$1"; }
abort() { echo "ABORT: $1"; exit 1; }
getprop() { case "$1" in ro.product.cpu.abi|ro.product.cpu.abilist64) echo arm64-v8a;; ro.zygote) echo zygote64;; esac; }
ARCH=arm64; IS64BIT=true; MODPATH="$1"
. "$MODPATH/customize.sh"
echo "(install continued)"
EOS
fresh() { rm -rf "$T/mod"; mkdir -p "$T/mod/zygisk"; cp "$ROOT/module.prop" "$ROOT/customize.sh" "$T/mod/"; cp -r "$ROOT/webroot" "$T/mod/"; MARK="CODMSUM1 index=$(h webroot/index.html) notice=$(h webroot/NOTICE.txt) license=$(h webroot/LICENSE.txt) customize=$(h customize.sh) tag=Test"; mk "$T/mod/zygisk/arm64-v8a.so" "$MARK"; mk "$T/mod/zygisk/armeabi-v7a.so" "$MARK"; }
run() { sh "$T/run.sh" "$T/mod" 2>&1; }
expect() { # name, output, must-contain, must-not-contain
  if echo "$2" | grep -q -- "$3" && { [ -z "$4" ] || ! echo "$2" | grep -q -- "$4"; }; then echo "ok   $1"; else echo "FAIL $1"; echo "$2" | sed 's/^/     | /'; fail=1; fi; }
fresh; expect "official zip" "$(run)" "Build check: official" "MODIFIED"
fresh; echo "<!-- x -->" >> "$T/mod/webroot/index.html"; o="$(run)"; expect "WebUI edited -> MODIFIED, install goes on" "$o" "MODIFIED" "ABORT"; expect "  ... and says which file" "$o" "changed or missing: webroot/index.html" ""; expect "  ... and continues" "$o" "install continued" ""
fresh; echo "# x" >> "$T/mod/customize.sh"; expect "customize.sh edited -> MODIFIED" "$(run)" "changed or missing: customize.sh" ""
fresh; rm "$T/mod/webroot/NOTICE.txt"; expect "NOTICE removed -> MODIFIED" "$(run)" "changed or missing: webroot/NOTICE.txt" ""
fresh; mk "$T/mod/zygisk/arm64-v8a.so" "nothing here"; expect "mark wiped from a .so -> MODIFIED" "$(run)" "no build mark" ""
fresh; mk "$T/mod/zygisk/armeabi-v7a.so" "$(echo "$MARK" | sed 's/index=./index=0/')"; expect "the two .so carry different marks -> MODIFIED" "$(run)" "do not match each other" ""
fresh; sed -i 's/^author=.*/author=Someone/' "$T/mod/module.prop"; expect "author changed -> MODIFIED" "$(run)" "Build check: MODIFIED" ""
fresh; sed -i 's/^STRICT_BUILD_CHECK=0/STRICT_BUILD_CHECK=1/' "$T/mod/customize.sh"; echo "<!-- x -->" >> "$T/mod/webroot/index.html"; o="$(run)"; expect "STRICT=1 and modified -> install stopped" "$o" "ABORT" "install continued"
fresh; sed -i 's/^STRICT_BUILD_CHECK=0/STRICT_BUILD_CHECK=1/' "$T/mod/customize.sh"; MARK="CODMSUM1 index=$(h webroot/index.html) notice=$(h webroot/NOTICE.txt) license=$(h webroot/LICENSE.txt) customize=$(sha256sum "$T/mod/customize.sh" | cut -d' ' -f1)"; mk "$T/mod/zygisk/arm64-v8a.so" "$MARK"; mk "$T/mod/zygisk/armeabi-v7a.so" "$MARK"; expect "STRICT=1 and official -> installs" "$(run)" "install continued" "ABORT"
grep -q '^STRICT_BUILD_CHECK=0$' "$ROOT/customize.sh" && echo "ok   shipped default is STRICT_BUILD_CHECK=0 (report only)" || { echo "FAIL shipped customize.sh is not STRICT_BUILD_CHECK=0"; fail=1; }
[ "$fail" = 0 ] && echo "== customize.sh build check ok" || exit 1
