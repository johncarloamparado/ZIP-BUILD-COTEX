#!/bin/sh
# v0.86: runs customize.sh in a fake installer with a fake .so that carries the build mark, and checks the "Build check" result.
# v0.90: the mark also carries name=/desc= (SHA-256 of module.prop's name= / description= VALUES), checked here too.
# v0.91: the actual checking logic moved into webroot/check.sh (its own tests are in tests/check_test.sh); this file now only
# checks that customize.sh correctly runs it, reports its result, and - since STRICT_BUILD_CHECK is now 1 by default - stops
# the install on a MODIFIED zip unless that is turned off.
# v0.92: check.sh now REQUIRES a signed release. The fixtures below use a copy of check.sh with that switched off (so each case still
# tests one thing); two cases at the end use the check.sh exactly as shipped. service.sh ships as webroot/service.sh and customize.sh
# copies it to the module root, which is checked here too.
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
T="$(mktemp -d)"; trap 'rm -rf "$T"' EXIT
fail=0
h() { sha256sum "$1" | cut -d' ' -f1; }
hv() { sed -n "s/^$1=//p" "$T/mod/module.prop" | head -n 1 | tr -d '\n' | { v="$(cat)"; printf '%s' "$v" | sha256sum | cut -d' ' -f1; }; }
cat > "$T/run.sh" <<'EOS'
ui_print() { echo "$1"; }
abort() { echo "ABORT: $1"; exit 1; }
getprop() { case "$1" in ro.product.cpu.abi|ro.product.cpu.abilist64) echo arm64-v8a;; ro.zygote) echo zygote64;; esac; }
ARCH=arm64; IS64BIT=true; MODPATH="$1"
. "$MODPATH/customize.sh"
echo "(install continued)"
EOS
fresh() { # fresh [real]: "real" = the check.sh exactly as shipped (signed release required); default = signing switched off
  rm -rf "$T/mod"; mkdir -p "$T/mod/zygisk" "$T/mod/webroot"
  cp "$ROOT/module.prop" "$ROOT/customize.sh" "$T/mod/"
  cp "$ROOT/webroot/index.html" "$ROOT/webroot/NOTICE.txt" "$ROOT/webroot/LICENSE.txt" "$ROOT/webroot/service.sh" "$T/mod/webroot/"
  if [ "${1:-}" = real ]; then cp "$ROOT/webroot/check.sh" "$T/mod/webroot/check.sh"
  else sed 's/^CODM_REQUIRE_SIGNED=.*/CODM_REQUIRE_SIGNED=0/' "$ROOT/webroot/check.sh" > "$T/mod/webroot/check.sh"; fi
  MARK="CODMSUM1 index=$(h "$T/mod/webroot/index.html") notice=$(h "$T/mod/webroot/NOTICE.txt") license=$(h "$T/mod/webroot/LICENSE.txt") customize=$(h "$T/mod/customize.sh") chk=$(h "$T/mod/webroot/check.sh") svc=$(h "$T/mod/webroot/service.sh") name=$(hv name) desc=$(hv description)"
  echo "$MARK" > "$T/mod/zygisk/arm64-v8a.so"
  echo "$MARK" > "$T/mod/zygisk/armeabi-v7a.so"
}
run() { sh "$T/run.sh" "$T/mod" 2>&1; }
expect() { # name, output, must-contain, must-not-contain
  if echo "$2" | grep -q -- "$3" && { [ -z "$4" ] || ! echo "$2" | grep -q -- "$4"; }; then echo "ok   $1"; else echo "FAIL $1"; echo "$2" | sed 's/^/     | /'; fail=1; fi; }

fresh; expect "official zip" "$(run)" "Build check: official" "MODIFIED"
# v0.92: the boot-time script is copied from webroot/ to the module root (the build workflows never ship a root-level one)
fresh; run >/dev/null
if [ -f "$T/mod/service.sh" ] && cmp -s "$T/mod/service.sh" "$T/mod/webroot/service.sh"; then echo "ok   service.sh is copied from webroot/ to the module root"; else echo "FAIL service.sh was not copied to the module root"; fail=1; fi
fresh; echo "# x" >> "$T/mod/webroot/service.sh"; expect "webroot/service.sh edited -> MODIFIED" "$(run)" "changed_svc" ""

fresh; echo "<!-- x -->" >> "$T/mod/webroot/index.html"
o="$(run)"; expect "WebUI edited -> MODIFIED, install stops (strict is now the default)" "$o" "ABORT" "install continued"
expect "  ... and says why" "$o" "changed_index" ""

fresh; echo "# x" >> "$T/mod/customize.sh"; expect "customize.sh edited -> MODIFIED" "$(run)" "changed_customize" ""
fresh; rm "$T/mod/webroot/NOTICE.txt"; expect "NOTICE removed -> MODIFIED" "$(run)" "changed_notice" ""
fresh; echo "x" > "$T/mod/zygisk/arm64-v8a.so"; expect "mark wiped from a .so -> MODIFIED" "$(run)" "no_mark" ""
fresh; ZERO64="$(printf '0%.0s' $(seq 1 64))"; sed -E "s/index=[0-9a-f]{64}/index=$ZERO64/" "$T/mod/zygisk/arm64-v8a.so" > "$T/mod/zygisk/armeabi-v7a.so"
expect "the two .so carry different marks -> MODIFIED" "$(run)" "so_mismatch" ""
fresh; sed -i 's/^author=.*/author=Someone/' "$T/mod/module.prop"; expect "author changed -> MODIFIED" "$(run)" "author_changed" ""
fresh; sed -i 's/^name=.*/name=Something Else/' "$T/mod/module.prop"; expect "display name changed in module.prop -> MODIFIED" "$(run)" "changed_name" ""
fresh; sed -i 's/^description=.*/description=Something else entirely/' "$T/mod/module.prop"; expect "description changed in module.prop -> MODIFIED" "$(run)" "changed_description" ""

fresh; echo "<!-- x -->" >> "$T/mod/webroot/index.html"
sed -i 's/^STRICT_BUILD_CHECK=1/STRICT_BUILD_CHECK=0/' "$T/mod/customize.sh"
o="$(run)"; expect "STRICT=0 (own test install) and modified -> install still goes on" "$o" "install continued" "ABORT"

fresh; expect "check.sh missing entirely -> reported, not silently official" "$(rm -f "$T/mod/webroot/check.sh"; run)" "could not be completed" "Build check: official"

# check.sh exactly as shipped: an unsigned zip does not install, and says why
fresh real; o="$(run)"; expect "unsigned zip (shipped check.sh) -> install stops" "$o" "ABORT" "install continued"
expect "  ... reason unsigned" "$o" "unsigned" ""
expect "  ... and says only signed builds install" "$o" "Only signed builds install" ""

grep -q '^STRICT_BUILD_CHECK=1$' "$ROOT/customize.sh" && echo "ok   shipped default is STRICT_BUILD_CHECK=1 (a MODIFIED zip cannot be installed)" || { echo "FAIL shipped customize.sh is not STRICT_BUILD_CHECK=1"; fail=1; }

[ "$fail" = 0 ] && echo "== customize.sh build check ok" || exit 1
