/* v0.88: base screen size typed in (natw.txt / nath.txt), "Leave render scale to another module" (rsoff.txt) and the small-texture floor of Detail Cut.
   The window functions are faked here (exported, found by dlsym like the real libandroid ones). */
#include "main_test_copy.cpp"
extern "C" int __android_log_print(int,const char*,const char*,...){return 0;}
extern "C" int __android_log_vprint(int,const char*,const char*,va_list){return 0;}
static int fails=0;
#define CHECK(c) do{if(!(c)){printf("FAIL line %d: %s\n",__LINE__,#c);fails++;}}while(0)
static void wr(const char *p,const char *s){unlink(p);FILE*f=fopen(p,"w");if(f){fputs(s,f);fclose(f);}}
static std::string rd(const char *p){FILE*f=fopen(p,"r");if(!f)return "";std::string s;char b[4096];while(size_t n=fread(b,1,sizeof b,f))s.append(b,n);fclose(f);return s;}
static int fw_w=0, fw_h=0, sbg_n=0, sbg_w=0, sbg_h=0;
extern "C" int32_t ANativeWindow_getWidth(ANativeWindow*){return fw_w;}
extern "C" int32_t ANativeWindow_getHeight(ANativeWindow*){return fw_h;}
extern "C" int32_t ANativeWindow_getFormat(ANativeWindow*){return 1;}
extern "C" int32_t ANativeWindow_setBuffersGeometry(ANativeWindow*,int32_t w,int32_t h,int32_t){sbg_n++;sbg_w=w;sbg_h=h;return 0;}
static ANativeWindow *WIN=(ANativeWindow*)0x1000;
static EGLSurface fake_cws(EGLDisplay,EGLConfig,EGLNativeWindowType,const EGLint*){return (EGLSurface)0x1;}
static void reset_win(){ sbg_n=0; sbg_w=sbg_h=0; g_ovw=0; g_ovh=0; }
static void cws(int w,int h){ fw_w=w; fw_h=h; reset_win(); h_cws(nullptr,nullptr,(EGLNativeWindowType)WIN,nullptr); }
static void cfg(const char*nw,const char*nh,const char*dg,int scale){
  unlink(FULLF); if(nw)wr(P("natw.txt"),nw); else unlink(P("natw.txt")); if(nh)wr(P("nath.txt"),nh); else unlink(P("nath.txt"));
  if(dg)wr(RSOFFF,dg); else unlink(RSOFFF);
  char b[16]; snprintf(b,sizeof b,"%d\n",scale); wr(SCLF,b); unlink(SCRASHF);
  g_fullw=0; g_fullh=0; load_cfg();
}
static std::vector<std::pair<GLenum,GLint>> g_tp;
static void fake_tp(GLenum,GLenum p,GLint v){ g_tp.push_back({p,v}); }
static int last_of(GLenum pname){ int b=-999; for(auto &c:g_tp) if(c.first==pname) b=c.second; return b; }
int main(){
  o_cws=fake_cws;
  /* ---- 1. native.txt files: typed size is read, any order, bad values ignored ---- */
  cfg("1600\n","720\n",nullptr,65);
  CHECK(g_natw.load()==1600 && g_nath.load()==720 && g_fullw.load()==1600 && g_fullh.load()==720 && g_scale.load()==65);
  cfg("720\n","1600\n",nullptr,65);
  CHECK(g_natw.load()==1600 && g_nath.load()==720);
  cfg("100\n","50\n",nullptr,65);
  CHECK(g_natw.load()==0 && g_nath.load()==0 && g_fullw.load()==0);
  cfg("1600\n",nullptr,nullptr,65);
  CHECK(g_natw.load()==0);
  cfg("0\n","0\n",nullptr,65);
  CHECK(g_natw.load()==0 && g_nath.load()==0);
  CHECK(same_shape(1600,720,1600,720) && same_shape(1040,468,1600,720) && !same_shape(800,720,1600,720) && !same_shape(1920,1080,1600,720));
  /* ---- 2. a window shrunk by something else (880x396) is set to native x percent when the native size is typed in ---- */
  cfg("1600\n","720\n",nullptr,65);
  cws(880,396);
  CHECK(sbg_n==1 && sbg_w==1040 && sbg_h==468);
  cws(1600,720);                                  /* the normal case still works */
  CHECK(sbg_n==1 && sbg_w==1040 && sbg_h==468);
  cws(1040,468);                                  /* the right size already: no second call */
  CHECK(sbg_n==0);
  cfg("1600\n","720\n",nullptr,65); g_ovw=1040; g_ovh=468;
  fw_w=1040; fw_h=468; sbg_n=0; h_cws(nullptr,nullptr,(EGLNativeWindowType)WIN,nullptr); CHECK(sbg_n==0);
  /* ---- 3. without a typed size nothing changed: a window smaller than the target is left alone (the old chain protection) ---- */
  cfg(nullptr,nullptr,nullptr,65);
  g_fullw=1600; g_fullh=720;
  cws(880,396);
  CHECK(sbg_n==0);
  cws(1600,720);
  CHECK(sbg_n==1 && sbg_w==1040 && sbg_h==468);
  /* ---- 4. rsoff: this module leaves render scale to another module: the window is never touched, scale.txt keeps its value ---- */
  cfg("1600\n","720\n","1\n",65);
  CHECK(g_scale.load()==0 && rd(SCLF)=="65\n");
  cws(880,396); CHECK(sbg_n==0);
  cws(1600,720); CHECK(sbg_n==0);
  sbg_n=0; reset_win(); h_sbg(WIN,1600,720,1); CHECK(sbg_n==1 && sbg_w==1600 && sbg_h==720);      /* passed through unchanged */
  cfg("1600\n","720\n","0\n",65);
  CHECK(g_scale.load()==65);
  cws(1600,720); CHECK(sbg_n==1 && sbg_w==1040);
  /* SBG path (what Unity asks for) */
  sbg_n=0; g_sbgn=0; reset_win(); fw_w=1600; fw_h=720;
  h_sbg(WIN,1600,720,1); CHECK(sbg_n==1 && sbg_w==1040 && sbg_h==468);
  sbg_n=0; reset_win(); h_sbg(WIN,880,396,1); CHECK(sbg_n==1 && sbg_w==1040 && sbg_h==468);   /* asked small, native typed in */
  cfg(nullptr,nullptr,nullptr,65);
  sbg_n=0; reset_win(); h_sbg(WIN,1600,720,1); CHECK(sbg_n==1 && sbg_w==1040 && sbg_h==468);   /* no typed size: as before */
  sbg_n=0; reset_win(); h_sbg(WIN,880,396,1); CHECK(sbg_w==600 && sbg_h==270);                 /* as before (scales the request) */
  /* scale off: the window is never touched */
  cfg("1600\n","720\n","1\n",0);
  cws(880,396); CHECK(sbg_n==0);
  { std::string lg=rd(LOGF); (void)lg; }
  /* ---- 5. Detail Cut: a small texture is never cut below 16 px (violet / tint guess), larger ones unchanged ---- */
  unlink(LIVECF); wr(GRASSF,""); wr(ORIGF,""); unlink(LIVEF); load_cfg(); log_start(4);
  real_tp=fake_tp; o_tpf=nullptr;
  g_near=0; g_testtex=0; g_flat=0; g_blk=0; g_alpha=0; g_astc=0; g_grass_on=0; g_orig_on=0; g_minsz=64; g_delay=0; g_skip.clear(); g_sedge=0;
  g_rt=(pid_t)syscall(SYS_gettid); g_t0=1;
  auto lodof=[&](int s,int w,int h,int lv){ g_style=s; g_tp.clear(); tl_bound[0]=3; tex_post(GL_TEXTURE_2D,lv,0x9279,w,h,false); return last_of(TEX_MIN_LOD); };
  CHECK(lodof(8,64,64,7)==2);      /* before: 5 (8 px) */
  CHECK(lodof(3,64,64,7)==2);
  CHECK(lodof(2,64,64,7)==2);
  CHECK(lodof(1,64,64,7)==1);
  CHECK(lodof(8,128,128,8)==3);
  CHECK(lodof(8,64,32,6)==2);      /* the long side counts */
  CHECK(lodof(8,256,256,7)==5);    /* unchanged: lv - 2 */
  CHECK(lodof(4,256,256,9)==4);
  CHECK(lodof(8,1024,1024,9)==7);
  unlink(SCLF); unlink(RSOFFF); unlink(P("natw.txt")); unlink(P("nath.txt"));
  if(fails){printf("TESTS FAILED %d\n",fails);return 1;}
  printf("v088 ok\n"); return 0;
}
