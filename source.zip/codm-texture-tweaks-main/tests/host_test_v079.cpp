/* v0.79: GPU backup on Hide (so Show works without Mark A), commands applied a few per frame, many commands at once. */
#include <array>
#include "main_test_copy.cpp"
extern "C" int __android_log_print(int,const char*,const char*,...){return 0;}
extern "C" int __android_log_vprint(int,const char*,const char*,va_list){return 0;}
static int fails=0;
#define CHECK(c) do{if(!(c)){printf("FAIL line %d: %s\n",__LINE__,#c);fails++;}}while(0)
static void wr(const char *p,const char *s){FILE*f=fopen(p,"w");if(f){fputs(s,f);fclose(f);}}
static std::string rd(const char *p){FILE*f=fopen(p,"r");if(!f)return "";std::string s;char b[4096];while(size_t n=fread(b,1,sizeof b,f))s.append(b,n);fclose(f);return s;}
static int g_tex_bound=7, g_real_pbo=0;
static std::set<GLuint> g_alive;
struct Call{GLuint id; GLint l; GLsizei n;};
static std::vector<Call> g_calls;
struct Cp{GLuint src,dst; GLint l; GLsizei w,h;};
static std::vector<Cp> g_cps;
static std::vector<GLuint> g_deleted, g_gens;
static std::vector<std::array<int,5>> g_stor;
static GLuint g_next=100;
static int g_err=0; static int g_cp_err=0;
static void fake_giv(GLenum e,GLint *v){ if(e==0x88EF)*v=g_real_pbo; else if(e==0x8069)*v=g_tex_bound; else *v=0; }
static GLboolean fake_is(GLuint id){return g_alive.count(id)?1:0;}
static void fake_bb(GLenum,GLuint b){g_real_pbo=(int)b;}
static void fake_bind(GLenum,GLuint id){g_tex_bound=(int)id;}
static void fake_ctsi2(GLenum,GLint l,GLint,GLint,GLsizei,GLsizei,GLenum,GLsizei n,const void*){ g_calls.push_back({(GLuint)g_tex_bound,l,n}); }
static void fake_del(GLsizei,const GLuint*){}
static void fake_tp(GLenum,GLenum,GLint){}
static void gl_gen(GLsizei n,GLuint*o){ for(GLsizei i=0;i<n;i++){o[i]=g_next++; g_gens.push_back(o[i]); g_alive.insert(o[i]);} }
static void gl_del(GLsizei n,const GLuint*t){ for(GLsizei i=0;i<n;i++){g_deleted.push_back(t[i]); g_alive.erase(t[i]);} }
static void gl_stor(GLenum,GLsizei lv,GLenum f,GLsizei w,GLsizei h){ g_stor.push_back(std::array<int,5>{{g_tex_bound,(int)lv,(int)f,(int)w,(int)h}}); }
static void gl_cp(GLuint s,GLenum,GLint l,GLint,GLint,GLint,GLuint d,GLenum,GLint,GLint,GLint,GLint,GLsizei w,GLsizei h,GLsizei){ g_cps.push_back({s,d,l,w,h}); if(g_cp_err) g_err=1; }
static void gl_lvp(GLenum,GLint l,GLenum pn,GLint*v){ int ws[3]={512,256,128}; *v = (l<3)? ((pn==0x1000)?ws[l]:ws[l]) : 0; }
static GLenum gl_err(){ if(g_err>0){g_err--; return 0x502;} return 0; }
static long long g_mem=2000000;
static long long mem_hook(){return g_mem;}
static int64_t T=0;
static void poll(){ T+=2000000000LL; live_poll(T); lv_apply(); }
static std::string hex16(uint64_t h){ char b[24]; snprintf(b,sizeof b,"%016llx",(unsigned long long)h); return b; }
static void upload(GLuint id,const std::vector<uint8_t>&d,int w,int h){ tl_bound[0]=id; g_tex_bound=id; g_alive.insert(id); h_ctsi2(GL_TEXTURE_2D,0,0,0,w,h,0x9279,(GLsizei)d.size(),d.data()); }
int main(){
  unlink(LIVEF); unlink(LIVECAPF); unlink(MARKF); unlink(LIVECF); wr(GRASSF,""); wr(ORIGF,""); wr(LIVEF,"1\n"); load_cfg(); log_start(4);
  g_giv_hook=fake_giv; g_sp_is_hook=fake_is; g_sp_bb_hook=fake_bb; o_bind=fake_bind; o_ctsi2=fake_ctsi2; o_del=fake_del; real_tp=fake_tp; tl_unit=0;
  g_lvgl_hook={gl_gen,gl_del,gl_stor,gl_cp,gl_lvp,gl_err}; g_lvgl_hooked=true; g_lv_mem_hook=mem_hook;
  g_near=0; g_testtex=0; g_style=0; g_flat=0; g_blk=0; g_alpha=0; g_grass_on=0; g_orig_on=0; g_minsz=64; g_delay=0;
  g_rt=(pid_t)syscall(SYS_gettid); g_t0=1;
  for(GLuint i=1;i<=3000;i++)g_alive.insert(i);
  std::vector<uint8_t> A(262144,11); uint64_t hA=tex_hash(A.data(),(int)A.size());
  upload(2,A,512,512);
  wr(MARKF,""); poll();
  /* Hide without a kept copy: a GPU backup is made first (all 3 levels), then every level is blanked */
  g_calls.clear(); g_cps.clear(); g_gens.clear(); g_stor.clear();
  g_tex_bound=7; wr(LIVECF,("h "+hex16(hA)+"\n").c_str()); poll();
  CHECK(g_gens.size()==1 && g_stor.size()==1 && g_stor[0][1]==3 && g_stor[0][3]==512 && g_stor[0][4]==512);
  CHECK(g_cps.size()==3 && g_cps[0].src==2 && g_cps[0].dst==g_gens[0] && g_cps[2].w==128);
  CHECK(g_calls.size()==3 && g_calls[0].id==2 && g_calls[1].n==65536 && g_calls[2].n==16384);
  CHECK(g_tex_bound==7);
  { std::lock_guard<std::mutex> lk(g_lvmu); CHECK(g_lvbk.count(2)==1 && g_lv_bkbytes==262144+65536+16384); }
  /* hiding it again does not make a second backup (the first one holds the original) */
  g_gens.clear(); g_cps.clear(); wr(LIVECF,("h "+hex16(hA)+"\n").c_str()); usleep(1100000); poll(); poll();
  CHECK(g_gens.empty() && g_cps.empty());
  /* Show: the backup is copied back and deleted */
  GLuint bk=0; { std::lock_guard<std::mutex> lk(g_lvmu); bk=g_lvbk[2].tex; }
  g_cps.clear(); g_deleted.clear(); g_calls.clear();
  wr(LIVECF,("u "+hex16(hA)+"\n").c_str()); usleep(1100000); poll(); poll();
  CHECK(g_cps.size()==3 && g_cps[0].src==bk && g_cps[0].dst==2 && g_calls.empty());
  CHECK(g_deleted.size()==1 && g_deleted[0]==bk);
  { std::lock_guard<std::mutex> lk(g_lvmu); CHECK(g_lvbk.empty() && g_lv_bkbytes==0); }
  /* Show again: nothing to bring back (reported) */
  g_cps.clear(); wr(LIVECF,("u "+hex16(hA)+"\n").c_str()); usleep(1100000); poll(); poll(); CHECK(g_cps.empty());
  CHECK(rd(P("codm_tex.status")).find("nocopy=1")!=std::string::npos);
  /* a GL error while backing up: no backup is kept, the texture is still hidden, the backup texture is deleted */
  g_cp_err=1; g_gens.clear(); g_deleted.clear(); g_calls.clear();
  wr(LIVECF,("h "+hex16(hA)+"\n").c_str()); usleep(1100000); poll(); poll();
  CHECK(g_calls.size()==3 && g_deleted.size()==1 && g_deleted[0]==g_gens[0]);
  { std::lock_guard<std::mutex> lk(g_lvmu); CHECK(g_lvbk.empty()); }
  g_cp_err=0; g_err=0;
  /* low free memory: Hide still works, no backup */
  g_mem=100000; g_gens.clear(); g_calls.clear(); g_cps.clear();
  { GLuint ids[1]={2}; h_del(1,ids); } upload(2,A,512,512); g_calls.clear();
  wr(LIVECF,("h "+hex16(hA)+"\n").c_str()); usleep(1100000); poll(); poll();
  CHECK(g_gens.empty() && g_calls.size()==3);
  g_mem=2000000;
  /* a deleted texture drops its backup (deleted on the render thread at the next apply) */
  g_gens.clear(); { GLuint ids[1]={2}; h_del(1,ids); } upload(2,A,512,512); g_alive.insert(2);
  wr(LIVECF,("h "+hex16(hA)+"\n").c_str()); usleep(1100000); poll(); poll();
  CHECK(g_gens.size()==1);
  g_deleted.clear(); { GLuint ids[1]={2}; h_del(1,ids); }
  { std::lock_guard<std::mutex> lk(g_lvmu); CHECK(g_lvbk.empty() && g_lv_bkbytes==0 && g_lv_bkdel.size()==1); }
  wr(LIVECF,"u 00000000000000aa\n"); usleep(1100000); poll(); poll();
  CHECK(g_deleted.size()==1);
  /* many commands: all are read, applied a few per frame, none is lost */
  g_lv_budget_ms=0; g_calls.clear(); g_gens.clear(); g_cps.clear();
  std::string cmds; for(int i=0;i<300;i++){ std::vector<uint8_t> d(262144,(uint8_t)(50+(i%200))); d[0]=(uint8_t)i; d[1]=(uint8_t)(i>>8); upload(500+i,d,512,512); cmds+="h "+hex16(tex_hash(d.data(),(int)d.size()))+"\n"; }
  g_calls.clear(); wr(LIVECF,cmds.c_str()); usleep(1100000);
  poll(); size_t after1=g_calls.size(); CHECK(after1>=3 && after1<=3*3);               /* budget 0 ms: one command per frame */
  for(int i=0;i<400;i++) poll();
  CHECK(g_calls.size()==300*3);
  CHECK(rd(P("codm_tex.log")).find("LIVE applied 300 command(s)")!=std::string::npos);
  { std::lock_guard<std::mutex> lk(g_lvmu); CHECK(g_lv_cmd.empty()); CHECK(g_lvbk.size()<=300); }
  unlink(LIVEF); unlink(LIVECF); unlink(MARKF);
  if(fails){printf("TESTS FAILED %d\n",fails);return 1;}
  printf("v079 ok\n"); return 0;
}
