package q9;

import java.io.File;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashSet;

/** v0.78: plain-JDK unit tests for menu/q9/Data.java. Run: javac -d out menu/q9/Data.java tests/DataTest.java && java -cp out q9.DataTest */
public class DataTest {
    static int fails = 0;
    static void check(boolean c, String m) { if (!c) { fails++; System.out.println("FAIL " + m); } }

    public static void main(String[] a) throws Exception {
        File dir = Files.createTempDirectory("q9t").toFile();
        String log = "old line\n=== start v0.77 build=x ===\nGRASSCAND fmt=37497 w=512 h=512 n=262144 h=0a1b2c3d4e5f6071 a=1 z=2 lv=10\nRESTORECAND fmt=37497 w=512 h=512 n=262144 h=0a1b2c3d4e5f6071 a=1 z=2 lv=10\n"
            + "MARK A t=10.0 cand=1 rcand=1\nGRASSCAND fmt=37496 w=256 h=256 n=65536 h=99887766554433ff a=1 z=2 lv=9\nRESTORECAND fmt=37808 w=256 h=256 n=32768 h=dd04000000000004 a=-1 z=-1 lv=8\nMARK B t=20.0 cand=2 rcand=2\nGRASSCAND fmt=37497 w=64 h=64 n=4096 h=aaaaaaaaaaaaaaaa a=1 z=2\n";
        ArrayList<Data.Row> all = Data.parseLog(log, false), mk = Data.parseLog(log, true);
        check(all.size() == 4, "all rows " + all.size());
        check(mk.size() == 2 && mk.get(0).hash.equals("99887766554433ff") && mk.get(0).canHide && !mk.get(1).canHide, "marks rows");
        check(all.get(0).canHide && all.get(0).lv == 10, "merged hide flag");
        check(Data.hasMarks(log) && !Data.hasMarks("=== start x\nGRASSCAND fmt=1 w=1 h=1 n=1 h=0000000000000000 a=0 z=0\n"), "hasMarks");
        {   // v0.95: the Marks card state
            String g = "=== start v\nGRASSCAND fmt=37497 w=512 h=512 n=262144 h=0a1b2c3d4e5f6071 a=1 z=2 lv=10\n";
            check(Data.markState(g)[0] == 0, "no mark -> 0");
            int[] open = Data.markState(g + "MARK A t=1.0 cand=1 rcand=1\nGRASSCAND fmt=37496 w=256 h=256 n=65536 h=99887766554433ff a=1 z=2 lv=9\n");
            check(open[0] == 1 && open[1] == 1, "A without B -> open, 1 texture: " + open[0] + "," + open[1]);
            int[] done = Data.markState(log);
            check(done[0] == 2 && done[1] == 2, "A and B -> done, 2 textures: " + done[0] + "," + done[1]);
            check(Data.markState(g + "MARK A t=1.0\nMARK X t=2.0\n")[0] == 0, "A then X -> cleared");
            check(Data.markState(g + "MARK A t=1.0\nMARK B t=2.0\nMARK A t=3.0\n")[0] == 1, "a new A after B opens a new window");
            check(Data.markState("=== start a\nMARK A t=1.0\n=== start b\n")[0] == 0, "an older session does not count");
        }
        check(Data.parseLog("=== start a\nGRASSCAND fmt=37497 w=512 h=512 n=262144 h=0a1b2c3d4e5f6071 a=1 z=2\n=== start b\n", false).isEmpty(), "only the last session");
        check(Data.parseLog("junk", true).isEmpty(), "no marks -> empty");
        ArrayList<Data.Row> l7 = new ArrayList<Data.Row>();
        for (int i = 0; i < 7; i++) { Data.Row r = new Data.Row(); r.hash = "000000000000000" + i; l7.add(r); }
        check(Data.half(l7, 0).size() == 4 && Data.half(l7, 1).size() == 3 && Data.minus(l7, Data.half(l7, 0)).size() == 3, "halves");
        check(Data.cleanName("  Green  grass!!<b>1 ").equals("Green grassb1") && Data.cleanName("a".repeat(40)).length() == 24, "cleanName");
        check(Data.keyOfLine("37497 512 512 0A1B2C3D4E5F6071 extra").equals("37497|512|512|0a1b2c3d4e5f6071") && Data.keyOfLine("# note") == null, "keyOfLine");

        // rules: add, keep unknown lines, remove, old grass.txt fallback
        Files.write(new File(dir, "grass.txt").toPath(), "37497 512 512 aaaaaaaaaaaaaaaa\n# keep me\n".getBytes());
        check(Data.readRuleKeys(dir, "hidden.txt").contains("37497|512|512|aaaaaaaaaaaaaaaa"), "old grass.txt fallback");
        check(Data.setRules(dir, "hidden.txt", Arrays.asList("37496|256|256|bbbbbbbbbbbbbbbb"), true), "add rule");
        String h = new String(Files.readAllBytes(new File(dir, "hidden.txt").toPath()));
        check(h.contains("37497 512 512 aaaaaaaaaaaaaaaa\n") && h.contains("# keep me") && h.contains("37496 256 256 bbbbbbbbbbbbbbbb\n"), "rules content " + h);
        check(Data.setRules(dir, "hidden.txt", Arrays.asList("37497|512|512|aaaaaaaaaaaaaaaa"), false), "remove rule");
        h = new String(Files.readAllBytes(new File(dir, "hidden.txt").toPath()));
        check(!h.contains("aaaaaaaaaaaaaaaa") && h.contains("# keep me") && h.contains("bbbbbbbbbbbbbbbb"), "after remove " + h);
        check(Data.setRules(dir, "hidden.txt", Arrays.asList("37496|256|256|bbbbbbbbbbbbbbbb"), true) && new String(Files.readAllBytes(new File(dir, "hidden.txt").toPath())).split("bbbbbbbbbbbbbbbb", -1).length == 2, "no duplicate on add");
        check(!new File(dir, "hidden.txt.new").exists(), "no leftover .new");

        // texlib: WebUI format round trip, sets, restore entries, names
        String lib = "37497 512 512 0a1b2c3d4e5f6071 plants|Green grass\n37496 256 256 99887766554433ff effects~s1abc|Smoke fx\n37497 512 1024 cc03000000000003 effects~s1abc|Smoke fx\n37808 256 256 dd04000000000004 other~~r|Rest one\nbad line\n37497 512 512 0a1b2c3d4e5f6071 other|dup\n";
        Files.write(new File(dir, "texlib.txt").toPath(), lib.getBytes());
        ArrayList<Data.Saved> sl = Data.readLib(dir);
        check(sl.size() == 4 && sl.get(0).grp.equals("plants") && sl.get(1).set.equals("s1abc") && sl.get(3).restore && sl.get(3).set.equals(""), "readLib " + sl.size());
        check(Data.units(sl).size() == 3 && Data.units(sl).get(1).size() == 2, "units");
        check(Data.writeLib(dir, sl), "writeLib");
        String back = new String(Files.readAllBytes(new File(dir, "texlib.txt").toPath()));
        check(back.equals("37497 512 512 0a1b2c3d4e5f6071 plants|Green grass\n37496 256 256 99887766554433ff effects~s1abc|Smoke fx\n37497 512 1024 cc03000000000003 effects~s1abc|Smoke fx\n37808 256 256 dd04000000000004 other~~r|Rest one\n"), "round trip " + back);
        Data.Saved n = new Data.Saved(); n.key = "37497|64|64|1111111111111111"; n.name = Data.cleanName("My tex #1"); n.grp = Data.grpOk("weird");
        sl.add(n); Data.writeLib(dir, sl);
        check(new String(Files.readAllBytes(new File(dir, "texlib.txt").toPath())).endsWith("37497 64 64 1111111111111111 other|My tex 1\n"), "new entry line");
        check(Data.sizeText(262144).equals("256 KB") && Data.sizeText(1572864).equals("1.5 MB") && Data.fmtName(0x93b4).equals("ASTC 6x6"), "texts");
        // v0.79: states, filters, friendly text
        java.util.LinkedHashMap<String, String> chip = new java.util.LinkedHashMap<String, String>();
        java.util.LinkedHashSet<String> eh = new java.util.LinkedHashSet<String>(), eo = new java.util.LinkedHashSet<String>(), el = new java.util.LinkedHashSet<String>();
        check(Data.stateOf(null, false, false) == Data.ST_NONE && Data.stateOf(null, true, false) == Data.ST_HID && Data.stateOf("S", true, false) == Data.ST_SHOWN
                && Data.stateOf("H", false, false) == Data.ST_HID && Data.stateOf(null, false, true) == Data.ST_REST && Data.stateOf("R", true, false) == Data.ST_REST
                && Data.stateOf("O", false, true) == Data.ST_NONE && Data.stateOf("O", true, false) == Data.ST_NONE, "stateOf (chip O = Look on overrides a saved Restore rule)");
        ArrayList<Data.Row> rr = new ArrayList<Data.Row>();
        String[] ks = {"37497|512|512|aaaaaaaaaaaaaaaa", "37497|256|512|bbbbbbbbbbbbbbbb", "37496|64|64|cccccccccccccccc", "37808|32|32|dddddddddddddddd"};
        for (int i = 0; i < 4; i++) { Data.Row r = Data.rowOfKey(ks[i]); r.canHide = i != 3; rr.add(r); }
        check(Data.rowOfKey(ks[1]).fmt == 37497 && Data.rowOfKey(ks[1]).w == 256 && Data.rowOfKey(ks[1]).h == 512 && Data.rowOfKey(ks[1]).key().equals(ks[1]), "rowOfKey");
        Data.Filtered f1 = Data.rootRows(rr, true), f3 = Data.rootRows(rr, false);
        check(f1.rows.size() == 3 && f3.rows.size() == 4, "rootRows (v0.93: scope / lobby sizes are listed too) " + f1.rows.size());
        chip.put(ks[0], "H"); chip.put(ks[2], "H"); chip.put(ks[3], "S");
        el.add(ks[2]); eh.add(ks[1]);
        check(Data.filterRows(rr, 1, chip, eh, eo, el).size() == 3 && Data.filterRows(rr, 2, chip, eh, eo, el).size() == 1 && Data.filterRows(rr, 3, chip, eh, eo, el).size() == 2
                && Data.filterRows(rr, 4, chip, eh, eo, el).size() == 2 && Data.filterRows(rr, 0, chip, eh, eo, el).size() == 4, "filterRows");
        ArrayList<Data.Row> uh = Data.unsavedHidden(chip, el, eh, eo);
        check(uh.size() == 1 && uh.get(0).key().equals(ks[0]), "unsavedHidden " + uh.size());
        check(Data.keysWith(chip, "H").size() == 2 && Data.keysWith(chip, "S").size() == 1, "keysWith");
        check(Data.kvInt("hidden=3 shown=0 nocopy=15", "nocopy") == 15 && Data.kvInt("x=1", "nocopy") == -1 && Data.kvInt("hidden=3", "hidden") == 3 && Data.kvInt(null, "a") == -1, "kvInt");
        check(Data.friendlyLast("hidden=1 shown=0 restored=0 missing=63 nocopy=15 backup=2 nobackup=0").equals("hidden 1 · shown 0 · restored 0 · not loaded now 63 · can't show 15 · GPU backups 2")
                && Data.friendlyLast("working: 40 left").equals("working: 40 left") && Data.friendlyLast(null).equals(""), "friendlyLast " + Data.friendlyLast("hidden=1 shown=0 restored=0 missing=63 nocopy=15 backup=2 nobackup=0"));
        // v0.87: Cancel finder puts every touched texture back to how it was BEFORE the test (saved rules are the "before")
        {
            String kH = "37497|512|512|aaaaaaaaaaaaaaaa", kS = "37497|256|512|bbbbbbbbbbbbbbbb", kR = "37496|64|64|cccccccccccccccc", kO = "37808|32|32|dddddddddddddddd", kX = "37497|128|128|eeeeeeeeeeeeeeee";
            java.util.LinkedHashMap<String, String> c2 = new java.util.LinkedHashMap<String, String>();
            java.util.LinkedHashSet<String> hid2 = new java.util.LinkedHashSet<String>(), ori2 = new java.util.LinkedHashSet<String>(), keys2 = new java.util.LinkedHashSet<String>();
            c2.put(kH, "H"); c2.put(kS, "S"); c2.put(kR, "R"); c2.put(kO, "O");               // the finder hid kH, showed kS, restored kR, looked kO on again
            keys2.add(kH); keys2.add(kS); keys2.add(kR); keys2.add(kO); keys2.add(kX);       // kX was touched but has no chip: nothing to send
            ArrayList<String> o1 = Data.cancelOps(keys2, c2, hid2, ori2);
            check(o1.size() == 2 && o1.get(0).equals("u aaaaaaaaaaaaaaaa") && o1.get(1).equals("f cccccccccccccccc"), "cancelOps plain (hide -> show, restore -> look on): " + o1);
            hid2.add(kS); ori2.add(kO); ori2.add(kR); hid2.add(kH);                              // saved: kS and kH hide, kO and kR restore
            ArrayList<String> o2 = Data.cancelOps(keys2, c2, hid2, ori2);
            check(o2.size() == 2 && o2.contains("h bbbbbbbbbbbbbbbb") && o2.contains("r dddddddddddddddd"), "cancelOps with saved rules (re-hide / re-restore, nothing else): " + o2);
            check(Data.cancelOps(new java.util.LinkedHashSet<String>(), c2, hid2, ori2).isEmpty() && Data.cancelOps(keys2, new java.util.LinkedHashMap<String, String>(), hid2, ori2).isEmpty(), "cancelOps empty");
        }
        // v0.89: groups (a group = a set in texlib.txt)
        {
            java.io.File gd = new java.io.File(System.getProperty("java.io.tmpdir"), "dt_grp_" + System.nanoTime()); gd.mkdirs();
            ArrayList<Data.Saved> glib = new ArrayList<Data.Saved>();
            String[] nm = {"Grass A", "Grass B", "Smoke", "Misc", "Rest R"};
            for (int i = 0; i < 5; i++) { Data.Saved x = new Data.Saved(); x.key = "37497|64|64|" + String.format("%016x", i + 1); x.name = nm[i]; x.grp = i == 2 ? "effects" : "plants"; x.restore = i == 4; glib.add(x); }
            // two singles -> a new group with the given name, first one's category, one set id
            String why = Data.groupUnits(glib, java.util.Arrays.asList(glib.get(0).key, glib.get(1).key), "My pack");
            check(why.length() == 0 && glib.get(0).set.length() > 0 && glib.get(0).set.equals(glib.get(1).set) && glib.get(0).name.equals("My pack") && glib.get(1).name.equals("My pack") && glib.get(2).set.length() == 0, "groupUnits two singles: " + why);
            String gid = glib.get(0).set;
            // a single joins the existing group: its name, its category, its set id; a given name is not used
            why = Data.groupUnits(glib, java.util.Arrays.asList(glib.get(2).key, glib.get(0).key), "Other name");
            check(why.length() == 0 && glib.get(2).set.equals(gid) && glib.get(2).name.equals("My pack") && glib.get(2).grp.equals("plants") && Data.units(glib).size() == 3, "groupUnits join: " + why + " units=" + Data.units(glib).size());
            // Hide and Restore are never mixed; fewer than 2 is refused; nothing changes
            why = Data.groupUnits(glib, java.util.Arrays.asList(glib.get(3).key, glib.get(4).key), "x");
            check(why.length() > 0 && glib.get(3).set.length() == 0 && glib.get(4).set.length() == 0, "groupUnits mixed action refused: " + why);
            check(Data.groupUnits(glib, java.util.Arrays.asList(glib.get(3).key), "x").length() > 0 && Data.groupUnits(glib, new ArrayList<String>(), "x").length() > 0, "groupUnits needs 2");
            // empty name = "Group N" (N not used by any saved name)
            why = Data.groupUnits(glib, java.util.Arrays.asList(glib.get(3).key, glib.get(0).key), "");
            check(why.length() == 0 && glib.get(3).set.equals(gid), "join group with empty name keeps group name");
            ArrayList<Data.Saved> l2 = new ArrayList<Data.Saved>();
            for (int i = 0; i < 2; i++) { Data.Saved x = new Data.Saved(); x.key = "37497|32|32|" + String.format("%016x", 50 + i); x.name = "T" + i; l2.add(x); }
            Data.Saved g1 = new Data.Saved(); g1.key = "37497|32|32|" + String.format("%016x", 99); g1.name = "Group 1"; l2.add(g1);
            why = Data.groupUnits(l2, java.util.Arrays.asList(l2.get(0).key, l2.get(1).key), "");
            check(why.length() == 0 && l2.get(0).name.equals("Group 2") && l2.get(0).set.equals(l2.get(1).set) && !l2.get(0).set.equals(g1.set) , "groupUnits default name skips used 'Group 1': " + l2.get(0).name);
            // two groups: the first group in the list wins, all members move
            ArrayList<Data.Saved> l3 = new ArrayList<Data.Saved>();
            for (int i = 0; i < 4; i++) { Data.Saved x = new Data.Saved(); x.key = "37497|16|16|" + String.format("%016x", 70 + i); x.name = i < 2 ? "A" : "B"; x.set = i < 2 ? "sa" : "sb"; l3.add(x); }
            why = Data.groupUnits(l3, java.util.Arrays.asList(l3.get(2).key, l3.get(0).key), "");
            check(why.length() == 0 && Data.units(l3).size() == 1 && l3.get(3).set.equals("sa") && l3.get(3).name.equals("A"), "two groups joined: " + why);
            // it survives a write / read of texlib.txt (the WebUI reads the same file)
            check(Data.writeLib(gd, glib), "writeLib");
            ArrayList<Data.Saved> gback = Data.readLib(gd);
            check(gback.size() == 5 && gback.get(0).set.equals(gid) && gback.get(2).set.equals(gid) && gback.get(0).name.equals("My pack") && Data.units(gback).size() == 2, "group round trip units=" + Data.units(gback).size());
            // ungroup: every member alone again with numbered names; a single is not a group
            check(Data.ungroup(glib, gid) && Data.units(glib).size() == 5 && glib.get(0).set.length() == 0 && glib.get(0).name.equals("My pack 1") && glib.get(1).name.equals("My pack 2"), "ungroup");
            check(!Data.ungroup(glib, glib.get(4).key) && !Data.ungroup(glib, "nope"), "ungroup refuses a single / unknown");
            for (java.io.File f : gd.listFiles()) f.delete(); gd.delete();
        }
        {   // v0.95: the module's own list file (not cut by the log cap) is read first; Row.key() is built once
            java.io.File cd = java.nio.file.Files.createTempDirectory("dt95").toFile();
            check(Data.readCands(cd) == null, "no cands file = null (older module: the log is used)");
            StringBuilder cb = new StringBuilder();
            for (int i = 0; i < 6000; i++) cb.append(String.format("RESTORECAND fmt=37492 w=256 h=256 n=32768 h=%016x a=120 z=3 lv=9\n", (long) i + 1));
            Data.writeAtomic(new java.io.File(cd, "codm_tex.cands"), cb.toString());
            String cs = Data.readCands(cd);
            ArrayList<Data.Row> crows = Data.parseLog(cs, false);
            check(crows.size() == 6000, "all 6000 listed (more than the old 4096), got " + crows.size());
            check(crows.get(0).key() == crows.get(0).key() && crows.get(5999).hash.equals(String.format("%016x", 6000L)), "key built once / last row present");
            for (java.io.File f : cd.listFiles()) f.delete(); cd.delete();
        }
        {   // v0.96: one entry per texture AND action
            java.io.File dd = java.nio.file.Files.createTempDirectory("dt96").toFile();
            Data.writeAtomic(new java.io.File(dd, "texlib.txt"),
                "37497 64 64 00000000000000aa effects|Smoke\n37497 64 64 00000000000000aa effects~~r|Smoke soft\n37497 64 64 00000000000000aa effects|Smoke dup\n37496 16 16 00000000000000cc other|Other\n");
            ArrayList<Data.Saved> lb = Data.readLib(dd);
            check(lb.size() == 3, "same texture under Hide and Restore = 2 entries, same action twice = 1, got " + lb.size());
            check(lb.get(0).uid().equals("37497|64|64|00000000000000aa") && lb.get(1).uid().equals("37497|64|64|00000000000000aa~r") && lb.get(1).restore, "uids differ by action");
            check(Data.writeLib(dd, lb) && Data.readLib(dd).size() == 3, "written and read back: still 3");
            ArrayList<String> ids = new ArrayList<String>(); ids.add(lb.get(1).uid()); ids.add(lb.get(2).uid());
            String why = Data.groupUnits(lb, ids, "G");
            check(why.length() > 0, "a Restore and a Hide entry are never put in one group");
            for (java.io.File f : dd.listFiles()) f.delete(); dd.delete();
        }
        System.out.println(fails == 0 ? "DataTest ok" : "DataTest FAILED " + fails);
        System.exit(fails == 0 ? 0 : 1);
    }
}
