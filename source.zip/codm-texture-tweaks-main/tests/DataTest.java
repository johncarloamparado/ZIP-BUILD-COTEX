package q9;

import java.io.File;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashSet;

/** v0.78: plain-JDK unit tests for menu/q9/Data.java. Run: javac -d out menu/q9/Data.java tests/DataTest.java && java -cp out q9.DataTest */
public class DataTest {
    static int fails = 0;
    static void check(boolean c, String m) { if (!c) { fails++; System.out.println("FAIL " + m); } }

    public static void main(String[] a) throws Exception {
        File dir = Files.createTempDirectory("q9t").toFile();
        String log = "old line\n=== start v0.77 build=x ===\nGRASSCAND fmt=37497 w=512 h=512 n=262144 h=0a1b2c3d4e5f6071 a=1 z=2 lv=10\nRESTORECAND fmt=37497 w=512 h=512 n=262144 h=0a1b2c3d4e5f6071 a=1 z=2 lv=10\n"
            + "MARK A t=10.0 cand=1 rcand=1\nGRASSCAND fmt=37496 w=256 h=256 n=65536 h=99887766554433ff a=1 z=2 lv=9\nRESTORECAND fmt=37808 w=256 h=256 n=32768 h=dd04000000000004 a=-1 z=-1 lv=8\nMARK B t=20.0 cand=2 rcand=2\nGRASSCAND fmt=37497 w=64 h=64 n=4096 h=aaaaaaaaaaaaaaaa a=1 z=2\n";
        ArrayList<Data.Row> all = Data.parseLog(log, false), mk = Data.parseLog(log, true);
        check(all.size() == 4, "all rows " + all.size());
        check(mk.size() == 2 && mk.get(0).hash.equals("99887766554433ff") && mk.get(0).canHide && !mk.get(1).canHide, "marks rows");
        check(all.get(0).canHide && all.get(0).lv == 10, "merged hide flag");
        check(Data.hasMarks(log) && !Data.hasMarks("=== start x\nGRASSCAND fmt=1 w=1 h=1 n=1 h=0000000000000000 a=0 z=0\n"), "hasMarks");
        check(Data.parseLog("=== start a\nGRASSCAND fmt=37497 w=512 h=512 n=262144 h=0a1b2c3d4e5f6071 a=1 z=2\n=== start b\n", false).isEmpty(), "only the last session");
        check(Data.parseLog("junk", true).isEmpty(), "no marks -> empty");
        ArrayList<Data.Row> l7 = new ArrayList<Data.Row>();
        for (int i = 0; i < 7; i++) { Data.Row r = new Data.Row(); r.hash = "000000000000000" + i; l7.add(r); }
        check(Data.half(l7, 0).size() == 4 && Data.half(l7, 1).size() == 3 && Data.minus(l7, Data.half(l7, 0)).size() == 3, "halves");
        check(Data.cleanName("  Green  grass!!<b>1 ").equals("Green grassb1") && Data.cleanName("a".repeat(40)).length() == 24, "cleanName");
        check(Data.keyOfLine("37497 512 512 0A1B2C3D4E5F6071 extra").equals("37497|512|512|0a1b2c3d4e5f6071") && Data.keyOfLine("# note") == null, "keyOfLine");

        // rules: add, keep unknown lines, remove, old grass.txt fallback
        Files.write(new File(dir, "grass.txt").toPath(), "37497 512 512 aaaaaaaaaaaaaaaa\n# keep me\n".getBytes());
        check(Data.readRuleKeys(dir, "hidden.txt").contains("37497|512|512|aaaaaaaaaaaaaaaa"), "old grass.txt fallback");
        check(Data.setRules(dir, "hidden.txt", Arrays.asList("37496|256|256|bbbbbbbbbbbbbbbb"), true), "add rule");
        String h = new String(Files.readAllBytes(new File(dir, "hidden.txt").toPath()));
        check(h.contains("37497 512 512 aaaaaaaaaaaaaaaa\n") && h.contains("# keep me") && h.contains("37496 256 256 bbbbbbbbbbbbbbbb\n"), "rules content " + h);
        check(Data.setRules(dir, "hidden.txt", Arrays.asList("37497|512|512|aaaaaaaaaaaaaaaa"), false), "remove rule");
        h = new String(Files.readAllBytes(new File(dir, "hidden.txt").toPath()));
        check(!h.contains("aaaaaaaaaaaaaaaa") && h.contains("# keep me") && h.contains("bbbbbbbbbbbbbbbb"), "after remove " + h);
        check(Data.setRules(dir, "hidden.txt", Arrays.asList("37496|256|256|bbbbbbbbbbbbbbbb"), true) && new String(Files.readAllBytes(new File(dir, "hidden.txt").toPath())).split("bbbbbbbbbbbbbbbb", -1).length == 2, "no duplicate on add");
        check(!new File(dir, "hidden.txt.new").exists(), "no leftover .new");

        // texlib: WebUI format round trip, sets, restore entries, names
        String lib = "37497 512 512 0a1b2c3d4e5f6071 plants|Green grass\n37496 256 256 99887766554433ff effects~s1abc|Smoke fx\n37497 512 1024 cc03000000000003 effects~s1abc|Smoke fx\n37808 256 256 dd04000000000004 other~~r|Rest one\nbad line\n37497 512 512 0a1b2c3d4e5f6071 other|dup\n";
        Files.write(new File(dir, "texlib.txt").toPath(), lib.getBytes());
        ArrayList<Data.Saved> sl = Data.readLib(dir);
        check(sl.size() == 4 && sl.get(0).grp.equals("plants") && sl.get(1).set.equals("s1abc") && sl.get(3).restore && sl.get(3).set.equals(""), "readLib " + sl.size());
        check(Data.units(sl).size() == 3 && Data.units(sl).get(1).size() == 2, "units");
        check(Data.writeLib(dir, sl), "writeLib");
        String back = new String(Files.readAllBytes(new File(dir, "texlib.txt").toPath()));
        check(back.equals("37497 512 512 0a1b2c3d4e5f6071 plants|Green grass\n37496 256 256 99887766554433ff effects~s1abc|Smoke fx\n37497 512 1024 cc03000000000003 effects~s1abc|Smoke fx\n37808 256 256 dd04000000000004 other~~r|Rest one\n"), "round trip " + back);
        Data.Saved n = new Data.Saved(); n.key = "37497|64|64|1111111111111111"; n.name = Data.cleanName("My tex #1"); n.grp = Data.grpOk("weird");
        sl.add(n); Data.writeLib(dir, sl);
        check(new String(Files.readAllBytes(new File(dir, "texlib.txt").toPath())).endsWith("37497 64 64 1111111111111111 other|My tex 1\n"), "new entry line");
        check(Data.sizeText(262144).equals("256 KB") && Data.sizeText(1572864).equals("1.5 MB") && Data.fmtName(0x93b4).equals("ASTC 6x6"), "texts");
        System.out.println(fails == 0 ? "DataTest ok" : "DataTest FAILED " + fails);
        System.exit(fails == 0 ? 0 : 1);
    }
}
