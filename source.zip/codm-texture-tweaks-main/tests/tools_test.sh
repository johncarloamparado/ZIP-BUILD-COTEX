#!/bin/sh
# v0.86: signing and verifying with a throw-away key (skipped when openssl 3 is not installed).
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
command -v openssl >/dev/null 2>&1 || { echo "== tools test SKIPPED (no openssl)"; exit 0; }
T="$(mktemp -d)"; trap 'rm -rf "$T"' EXIT; fail=0
openssl genpkey -algorithm ED25519 -out "$T/k.pem" 2>/dev/null || { echo "== tools test SKIPPED (openssl cannot make Ed25519 keys)"; exit 0; }
openssl pkey -in "$T/k.pem" -pubout -out "$T/pub.pem"; openssl genpkey -algorithm ED25519 -out "$T/k2.pem" 2>/dev/null; openssl pkey -in "$T/k2.pem" -pubout -out "$T/pub2.pem"
mkdir -p "$T/out/zygisk" "$T/out/webroot"; echo m > "$T/out/module.prop"; echo i > "$T/out/webroot/index.html"; echo a > "$T/out/zygisk/arm64-v8a.so"
ok() { if [ "$2" = "0" ]; then echo "ok   $1"; else echo "FAIL $1"; fail=1; fi; }
env -u SIGNING_KEY sh "$ROOT/tools/sign_release.sh" "$T/out" >/dev/null 2>&1; ok "no secret: exit 0 and NOT signed" "$([ $? = 0 ] && [ ! -f "$T/out/RELEASE.sig" ]; echo $?)"
SIGNING_KEY="not a key" sh "$ROOT/tools/sign_release.sh" "$T/out" >/dev/null 2>&1; ok "bad key: the build fails" "$([ $? != 0 ]; echo $?)"
SIGNING_KEY="$(cat "$T/k.pem")" sh "$ROOT/tools/sign_release.sh" "$T/out" >"$T/sign.log" 2>&1; ok "signing works" "$?"
ok "the private key is not printed or shipped" "$(! grep -rq 'PRIVATE KEY' "$T/sign.log" "$T/out"; echo $?)"
sh "$T/out/RELEASE.verify.sh" "$T/out" "$T/pub.pem" >/dev/null 2>&1; ok "verify: official" "$?"
echo x >> "$T/out/webroot/index.html"; sh "$T/out/RELEASE.verify.sh" "$T/out" "$T/pub.pem" >/dev/null 2>&1; ok "verify: a changed file is caught" "$([ $? != 0 ]; echo $?)"
echo i > "$T/out/webroot/index.html"
echo y > "$T/out/webroot/new.js"; sh "$T/out/RELEASE.verify.sh" "$T/out" "$T/pub.pem" >/dev/null 2>&1; ok "verify: an extra file is caught" "$([ $? != 0 ]; echo $?)"; rm -f "$T/out/webroot/new.js"
sh "$T/out/RELEASE.verify.sh" "$T/out" "$T/pub2.pem" >/dev/null 2>&1; ok "verify: the wrong public key is refused" "$([ $? != 0 ]; echo $?)"
echo x >> "$T/out/webroot/index.html"; (cd "$T/out" && find . -type f ! -name 'RELEASE.*' -print0 | sort -z | xargs -0 sha256sum > RELEASE.sha256); sh "$T/out/RELEASE.verify.sh" "$T/out" "$T/pub.pem" >/dev/null 2>&1; ok "verify: an edited hash list is caught by the signature" "$([ $? != 0 ]; echo $?)"
[ "$fail" = 0 ] && echo "== tools (sign / verify) ok" || exit 1
