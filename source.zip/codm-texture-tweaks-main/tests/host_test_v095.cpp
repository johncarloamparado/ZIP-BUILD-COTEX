/* v0.95: the finder list is not limited to 4096 any more: a user limit (listcap.txt, 1000..16000), a list file of its own (codm_tex.cands) that the 4 MB log cap cannot cut,
   distinct textures that do not fit are counted and are listed when the limit is raised, and lv_status() writes the status file once. */
#include "main_test_copy.cpp"
extern "C" int __android_log_print(int,const char*,const char*,...){return 0;}
extern "C" int __android_log_vprint(int,const char*,const char*,va_list){return 0;}
static int fails=0;
#define CHECK(c) do{if(!(c)){printf("FAIL line %d: %s\n",__LINE__,#c);fails++;}}while(0)
static void wr(const char *p,const char *s){FILE*f=fopen(p,"w");if(f){fputs(s,f);fclose(f);}}
static std::vector<uint8_t> mk(int n,int seed){std::vector<uint8_t> v(n);uint32_t x=(uint32_t)seed*2654435761u+1;for(auto&b:v){x=x*1664525u+1013904223u;b=(uint8_t)(x>>24);}return v;}
static int g_pbo=0;
static void fake_giv(GLenum,GLint *v){*v=g_pbo;}
static void fake_st(GLenum,GLsizei,GLenum,GLsizei,GLsizei){}
static void fake_ctsi2(GLenum,GLint,GLint,GLint,GLsizei,GLsizei,GLenum,GLsizei,const void*){}
static std::string rd(const char *p){FILE*f=fopen(p,"r");if(!f)return "";std::string s;char b[2048];while(size_t n=fread(b,1,sizeof b,f))s.append(b,n);fclose(f);return s;}
static int count(const std::string&s,const std::string&needle){int n=0;size_t p=0;while((p=s.find(needle,p))!=std::string::npos){++n;p+=needle.size();}return n;}
int main(){
  wr(GRASSF,""); wr(ORIGF,""); load_cfg(); log_start(4); cand_start();
  g_giv_hook=fake_giv; o_st=fake_st; o_ctsi2=fake_ctsi2; tl_unit=0;
  g_near=0; g_testtex=0; g_style=0; g_flat=0; g_blk=0; g_grass_on=0; g_orig_on=0; g_minsz=64; g_delay=0;
  CHECK(g_cand_cap.load()==CAND_CAP_DEF);
  wr(LISTCAPF,"999\n"); cand_cap_read(); CHECK(g_cand_cap.load()==CAND_CAP_DEF);
  wr(LISTCAPF,"abc\n"); cand_cap_read(); CHECK(g_cand_cap.load()==CAND_CAP_DEF);
  wr(LISTCAPF,"1000\n"); cand_cap_read(); CHECK(g_cand_cap.load()==1000);
  std::vector<std::vector<uint8_t>> T; for(int i=0;i<1005;i++) T.push_back(mk(32768,1000+i));
  for(int i=0;i<1005;i++){ tl_bound[0]=100+i; h_st(GL_TEXTURE_2D,8,0x9274,256,256); h_ctsi2(GL_TEXTURE_2D,0,0,0,256,256,0x9274,(GLsizei)T[i].size(),T[i].data()); }
  for(int i=0;i<1005;i+=7){ tl_bound[0]=3000+i; h_st(GL_TEXTURE_2D,8,0x9274,256,256); h_ctsi2(GL_TEXTURE_2D,0,0,0,256,256,0x9274,(GLsizei)T[i].size(),T[i].data()); }
  if(lf)fflush(lf);
  std::string cands=rd(CANDF), lg=rd(LOGF);
  CHECK(count(cands,"RESTORECAND fmt=37492")==1000);
  CHECK(g_rseen_n==1000); CHECK(g_rskip==5);
  CHECK(count(lg,"RESTORECAND list is full")==1);
  CHECK(count(lg,"RESTORECAND fmt=37492")==1000);
  wr(LISTCAPF,"2000\n"); cand_cap_read(); CHECK(g_cand_cap.load()==2000);
  tl_bound[0]=5000; h_st(GL_TEXTURE_2D,8,0x9274,256,256); h_ctsi2(GL_TEXTURE_2D,0,0,0,256,256,0x9274,(GLsizei)T[1001].size(),T[1001].data());
  CHECK(g_rseen_n==1001); CHECK(g_rskip==4);
  tl_bound[0]=5001; h_st(GL_TEXTURE_2D,8,0x9274,256,256); h_ctsi2(GL_TEXTURE_2D,0,0,0,256,256,0x9274,(GLsizei)T[1001].size(),T[1001].data());
  CHECK(g_rseen_n==1001);
  cands=rd(CANDF); CHECK(count(cands,"RESTORECAND fmt=37492")==1001);
  { std::lock_guard<std::mutex> lk(g_cmu); cand_reset_locked(); } CHECK(g_rseen_n==0 && g_rskip==0);
  lv_status(); std::string st=rd(STATF);
  CHECK(st.find("cand_cap=2000")!=std::string::npos); CHECK(st.find("cand_n=")!=std::string::npos); CHECK(st.find("cand_over=0")!=std::string::npos);
  unlink(LISTCAPF);
  if(lf){fclose(lf);lf=nullptr;}
  printf(fails?"FAILED %d\n":"ALL TESTS PASSED\n",fails); return fails?1:0;
}
