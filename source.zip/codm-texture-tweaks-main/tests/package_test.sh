#!/bin/sh
# v0.92 host test: the module as it really reaches a phone, not as a hand-built fixture.
#
# Why this exists: in v0.91 every other test used a fake module folder that was assembled BY THE TEST, and that folder happened to contain
# service.sh. The real packaging step (build.yml / zip-build.yml "Assemble module package") only copies module.prop, customize.sh, webroot/,
# META-INF/ and the two .so, so service.sh was never in the zip, check.sh found no service.sh and called every genuine install MODIFIED.
# Nothing caught it, because nothing ran the real packaging. This test does:
#   1. it takes the "Assemble module package" commands out of .github/workflows/build.yml and runs them (zip-build.yml uses the same lines),
#   2. it writes the build mark exactly the way CMakeLists.txt composes it (it reads CMake's own pair list, so the two cannot drift apart),
#   3. it signs the result with the REAL tools/sign_release.sh (throw-away key, swapped into a copy of check.sh as the pinned key),
#   4. it plays the installer: extracts everything except META-INF/, runs the REAL customize.sh, then deletes customize.sh like Magisk /
#      KernelSU do at the end of an install, and runs the REAL check.sh and service.sh in that state (what the WebUI and every boot see).
set -u
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
unset GITHUB_STEP_SUMMARY    # the real sign_release.sh appends a "Signed release" block there; a test with a throw-away key must not
T="$(mktemp -d)"; trap 'rm -rf "$T"' EXIT
fails=0
h() { sha256sum "$1" | cut -d' ' -f1; }
hs() { printf '%s' "$1" | sha256sum | cut -d' ' -f1; }
ok() { echo "ok   $1"; }
bad() { echo "FAIL $1"; if [ $# -gt 1 ]; then shift; printf '%s\n' "$*" | sed 's/^/     | /'; fi; fails=$((fails + 1)); }
expect() { # <name> <output> <must contain> <must NOT contain, or "">
  if printf '%s\n' "$2" | grep -q -- "$3" && { [ -z "$4" ] || ! printf '%s\n' "$2" | grep -q -- "$4"; }; then ok "$1"; else bad "$1" "$2"; fi; }

# --- what the project's own workflow does to assemble the package ---------------------------------------------------
ASSEMBLE="$(awk '/- name: Assemble module package/{f=1;next} f&&/run: \|/{r=1;next} f&&r&&/^      - name:/{exit} f&&r{sub(/^          /,"");print}' "$ROOT/.github/workflows/build.yml")"
case "$ASSEMBLE" in *"cp -r webroot META-INF out/"*) ;; *) bad "could not read the Assemble module package step from .github/workflows/build.yml" "$ASSEMBLE"; echo "TESTS FAILED (package)"; exit 1 ;; esac

# --- the pair list CMakeLists.txt writes into the mark, and the one webroot/check.sh reads back ---------------------------
PAIRS="$(sed -n 's/^foreach(pair \(.*\))$/\1/p' "$ROOT/CMakeLists.txt")"
[ -n "$PAIRS" ] || { bad "no foreach(pair ...) line found in CMakeLists.txt"; echo "TESTS FAILED (package)"; exit 1; }
CHKPAIRS="$(sed -n 's/^  for PAIR in \(.*\); do$/\1/p' "$ROOT/webroot/check.sh")"
if [ "$(printf '%s\n' $PAIRS | sort)" = "$(printf '%s\n' $CHKPAIRS | sort)" ]; then ok "CMake's mark pair list and check.sh's pair list are the same"; else bad "CMake's pair list differs from check.sh's" "cmake: $PAIRS
check.sh: $CHKPAIRS"; fi

# --- build one package: a copy of the source, a fake build with the mark, then the real assemble commands ----------------
build_pkg() { # build_pkg <dir> <CODM_REQUIRE_SIGNED 0|1> [pinned fingerprint to use instead of the owner's]
  D="$1"; rm -rf "$D"; mkdir -p "$D"; cp -r "$ROOT"/. "$D"/
  sed -i "s/^CODM_REQUIRE_SIGNED=.*/CODM_REQUIRE_SIGNED=$2/" "$D/webroot/check.sh"
  [ -z "${3:-}" ] || sed -i "s/^CODM_PUBKEY_FP=.*/CODM_PUBKEY_FP=\"$3\"/" "$D/webroot/check.sh"
  MARK="CODMSUM1"
  for p in $PAIRS; do MARK="$MARK ${p%%:*}=$(h "$D/${p#*:}")"; done
  NV="$(sed -n 's/^name=//p' "$D/module.prop" | head -n 1)"; DV="$(sed -n 's/^description=//p' "$D/module.prop" | head -n 1)"
  MARK="$MARK name=$(hs "$NV") desc=$(hs "$DV")"
  mkdir -p "$D/build-arm64/libs" "$D/build-arm32/libs"
  echo "$MARK" > "$D/build-arm64/libs/libcodm_tex.so"; echo "$MARK" > "$D/build-arm32/libs/libcodm_tex.so"
  (cd "$D" && sh -c "$ASSEMBLE") >/dev/null 2>&1 || bad "the assemble commands from build.yml failed"
  for p in $PAIRS; do [ -f "$D/out/${p#*:}" ] || bad "the package does not contain ${p#*:} (the mark covers it, check.sh will look for it on the phone)"; done
}

# --- play the installer -------------------------------------------------------------------------------------------------
cat > "$T/run.sh" <<'EOS'
ui_print() { echo "$1"; }
abort() { echo "ABORT: $1"; exit 1; }
getprop() { case "$1" in ro.product.cpu.abi|ro.product.cpu.abilist64) echo arm64-v8a;; ro.zygote) echo zygote64;; esac; }
ARCH=arm64; IS64BIT=true; MODPATH="$1"
. "$MODPATH/customize.sh"
echo "(install continued)"
EOS
extract() { # <out dir> <phone dir>: what the installer puts in the module folder before customize.sh runs (everything but META-INF/)
  rm -rf "$2"; cp -r "$1" "$2"; rm -rf "$2/META-INF"; }
flash() { sh "$T/run.sh" "$1" 2>&1; }
status_of() { sh "$1/webroot/check.sh" "$1" 2>&1 | tr '\n' ' '; }
svc_status() { # <phone dir>: run the REAL service.sh from the module root against its own fake /data, print the status it wrote
  # (own directory per call via mktemp: this runs inside $( ), so a counter would not advance, and service.sh's second pass, one
  # second later, would then overwrite the verdict of the next call that shared the directory)
  DR="$(mktemp -d "$T/data.XXXXXX")"; mkdir -p "$DR/data/com.garena.game.codm/files"
  CODM_DATA_ROOT="$DR" CODM_SVC_DELAYS="0 1" sh "$1/service.sh"
  F="$DR/data/com.garena.game.codm/files/codm_tex.integrity"; i=0
  while [ ! -f "$F" ] && [ "$i" -lt 40 ]; do sleep 0.1; i=$((i + 1)); done
  sed -n 's/^status=//p' "$F" 2>/dev/null | head -n 1; }

# === A: signed with a throw-away key (pinned into this package's own copy of check.sh) =============================
if command -v openssl >/dev/null 2>&1 && openssl genpkey -algorithm ED25519 -out "$T/k.pem" 2>/dev/null; then
  FP="$(openssl pkey -in "$T/k.pem" -pubout 2>/dev/null | openssl pkey -pubin -outform DER 2>/dev/null | sha256sum | cut -d' ' -f1)"
  build_pkg "$T/pkgA" 1 "$FP"
  (cd "$T/pkgA" && SIGNING_KEY="$(cat "$T/k.pem")" sh tools/sign_release.sh out >/dev/null 2>&1) || bad "tools/sign_release.sh failed on the assembled package"
  [ -f "$T/pkgA/out/RELEASE.sig" ] && ok "the real sign_release.sh signed the assembled package" || bad "no RELEASE.sig after signing"
  grep -q 'META-INF/com/google/android/update-binary' "$T/pkgA/out/RELEASE.sha256" && ok "(the signed list does name META-INF/ files, as in the real build)" || bad "expected META-INF in the signed list"

  extract "$T/pkgA/out" "$T/phoneA"
  o="$(flash "$T/phoneA")"
  expect "A signed: flash -> official and the install continues" "$o" "Build check: official" "ABORT"
  [ "$(printf '%s\n' "$o" | grep -c 'install continued')" = 1 ] || bad "A signed: install did not continue" "$o"
  [ -f "$T/phoneA/service.sh" ] && ok "A signed: customize.sh put service.sh in the module root" || bad "A signed: no service.sh in the module root after the install"
  rm -f "$T/phoneA/customize.sh"    # Magisk / KernelSU delete it when the install ends
  s="$(status_of "$T/phoneA")"; expect "A signed: afterwards (customize.sh deleted) the WebUI / boot check says official" "$s" "status=official" "tampered"
  [ "$(svc_status "$T/phoneA")" = official ] && ok "A signed: the real service.sh writes status=official" || bad "A signed: service.sh did not write official"

  cp -r "$T/phoneA" "$T/phoneA2"; echo "<!-- x -->" >> "$T/phoneA2/webroot/index.html"
  expect "A signed: WebUI edited after install -> tampered" "$(status_of "$T/phoneA2")" "changed_index" ""
  cp -r "$T/phoneA" "$T/phoneA3"; rm -f "$T/phoneA3/RELEASE.sig"
  expect "A signed: RELEASE.sig deleted -> tampered (unsigned)" "$(status_of "$T/phoneA3")" "reason=unsigned" ""
  cp -r "$T/phoneA" "$T/phoneA4"; printf 'xx' >> "$T/phoneA4/RELEASE.sig"
  expect "A signed: corrupted signature -> tampered" "$(status_of "$T/phoneA4")" "signature_invalid" ""
  cp -r "$T/phoneA" "$T/phoneA5"; echo "versionCode=999" >> "$T/phoneA5/module.prop"
  expect "A signed: any signed file changed (module.prop) -> tampered" "$(status_of "$T/phoneA5")" "signed_file_mismatch" ""
else
  echo "(openssl with Ed25519 not available on this host - skipping the signed-package cases)"
fi

# === B: the shipped check.sh, built on a repository without the SIGNING_KEY secret (no RELEASE.* files) ==============
build_pkg "$T/pkgB" 1
extract "$T/pkgB/out" "$T/phoneB"
o="$(flash "$T/phoneB")"
expect "B unsigned build, shipped check.sh: the install stops" "$o" "ABORT" "install continued"
expect "  ... reason unsigned" "$o" "unsigned" ""

# === C: the same unsigned build with CODM_REQUIRE_SIGNED=0 (the owner's own test build) =============================
build_pkg "$T/pkgC" 0
extract "$T/pkgC/out" "$T/phoneC"
o="$(flash "$T/phoneC")"
expect "C unsigned build with CODM_REQUIRE_SIGNED=0: official, install continues" "$o" "Build check: official" "ABORT"
rm -f "$T/phoneC/customize.sh"
expect "C afterwards (customize.sh deleted): official" "$(status_of "$T/phoneC")" "status=official" "tampered"
[ "$(svc_status "$T/phoneC")" = official ] && ok "C: the real service.sh writes status=official" || bad "C: service.sh did not write official"

if [ "$fails" = 0 ]; then echo "ALL TESTS PASSED (package)"; else echo "TESTS FAILED $fails (package)"; fi
exit $([ "$fails" = 0 ] && echo 0 || echo 1)
