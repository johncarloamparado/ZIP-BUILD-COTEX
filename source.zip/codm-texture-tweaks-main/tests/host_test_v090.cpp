/* v0.90: owner identification (XOR-decoded in the binary, not a plain string) is the first line of a fresh log file; module.prop's
   name=/description= are now part of the build mark (checked separately by tests/customize_test.sh, not here). */
#include "main_test_copy.cpp"
extern "C" int __android_log_print(int,const char*,const char*,...){return 0;}
extern "C" int __android_log_vprint(int,const char*,const char*,va_list){return 0;}
static int fails=0;
#define CHECK(c) do{if(!(c)){printf("FAIL line %d: %s\n",__LINE__,#c);fails++;}}while(0)
static std::string rd(const char *p){FILE*f=fopen(p,"r");if(!f)return "";std::string s;char b[4096];while(size_t n=fread(b,1,sizeof b,f))s.append(b,n);fclose(f);return s;}
int main(){
  /* ---- owner_name() decodes to the right text ---- */
  CHECK(std::string(owner_name()) == "Q9 Papyrus");
  CHECK(owner_name() == owner_name());                 /* stable across calls (cached) */
  /* the encoded bytes themselves must not spell the name out (that is the whole point) */
  CHECK(memcmp(OWNER_ENC, "Q9 Papyrus", sizeof OWNER_ENC) != 0);
  /* ---- the owner line is the very first line of a FRESH log file, and only written once ---- */
  unlink(LOGF);
  if (lf) { fclose(lf); lf = nullptr; } lf_bytes = 0; g_log_head.clear(); g_log_events.clear();
  L("second line, not the first\n");
  std::string lg = rd(LOGF);
  CHECK(lg.find("CODM Blocky Textures - owner: Q9 Papyrus. Contributors: zynn, Shari.\n") == 0);   /* at position 0: truly the first line */
  CHECK(lg.find("second line, not the first") != std::string::npos);
  size_t n1 = lg.size();
  L("third line\n");
  lg = rd(LOGF);
  CHECK(lg.substr(0, n1) == lg.substr(0, n1));          /* unchanged prefix */
  CHECK(std::count(lg.begin(), lg.end(), '\n') >= 3);
  /* exactly one owner line even after more writes */
  { size_t c = 0, pos = 0; while ((pos = lg.find("CODM Blocky Textures - owner:", pos)) != std::string::npos) { c++; pos++; } CHECK(c == 1); }
  if(fails){printf("TESTS FAILED %d\n",fails);return 1;}
  printf("v090 ok\n"); return 0;
}
