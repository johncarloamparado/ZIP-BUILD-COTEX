/* v0.91 host test: the integrity gate (INTEGF / integrity_tampered() / decide_safe()). Build like the others (run_host_tests.sh). */
#include "main_test_copy.cpp"
extern "C" int __android_log_print(int,const char*,const char*,...){return 0;}
extern "C" int __android_log_vprint(int,const char*,const char*,va_list){return 0;}
static int fails=0;
#define CHECK(c) do{ if(!(c)){printf("FAIL line %d: %s\n",__LINE__,#c);fails++;} }while(0)
static void wr(const char*p,const char*t){unlink(p);FILE*f=fopen(p,"w");fputs(t,f);fclose(f);}
int main(){
  set_dir(nullptr);                                            /* back to the default test folder (writable) */
  unlink(INTEGF); unlink(HSAFEF);
  /* 1: no verdict file at all (never checked yet, or an old root solution with no service.sh) -> fail OPEN */
  CHECK(!integrity_tampered(nullptr));
  decide_safe(""); CHECK(g_safe==0); CHECK(g_safe_why=="no");
  /* 2: service.sh wrote "official" -> still not tampered */
  wr(INTEGF,"status=official\nreason=\nchecked=123\n");
  CHECK(!integrity_tampered(nullptr));
  decide_safe(""); CHECK(g_safe==0);
  /* 3: "status=tampered" with a reason -> tampered, reason comes back, safe mode kicks in */
  wr(INTEGF,"status=tampered\nreason=changed_index\nchecked=456\n");
  std::string reason; CHECK(integrity_tampered(&reason)); CHECK(reason=="changed_index");
  decide_safe(""); CHECK(g_safe==1); CHECK(g_safe_why=="tampered_changed_index");
  CHECK(read_status_key("stage")=="safe_mode");
  CHECK(read_status_key("safe_why")=="tampered_changed_index");
  /* 4: reason with characters outside [A-Za-z0-9_] -> stripped, never lands raw in the status file / log */
  wr(INTEGF,"status=tampered\nreason=weird=ch ar;s\n");
  reason.clear(); CHECK(integrity_tampered(&reason)); CHECK(reason=="weirdchars");
  /* 5: empty reason line -> still tampered, g_safe_why falls back to the plain "tampered" token */
  wr(INTEGF,"status=tampered\n");
  reason="x"; CHECK(integrity_tampered(&reason)); CHECK(reason=="");
  unlink(HSAFEF); decide_safe(""); CHECK(g_safe==1); CHECK(g_safe_why=="tampered");
  /* 6: garbage / no recognised "status=" line at all -> not tampered (only a literal "status=tampered" blocks) */
  wr(INTEGF,"not a status file\njust some text\n");
  CHECK(!integrity_tampered(nullptr));
  unlink(HSAFEF); decide_safe(""); CHECK(g_safe==0);
  /* 7: an existing hooksafe_file / crash reason takes priority - its own reason is kept, not overwritten by "tampered" */
  wr(INTEGF,"status=tampered\nreason=changed_index\n");
  wr(HSAFEF,"1\n"); decide_safe(""); CHECK(g_safe==1); CHECK(g_safe_why=="hooksafe_file");
  unlink(HSAFEF); decide_safe("hooking"); CHECK(g_safe==1); CHECK(g_safe_why=="crash_in_hooking");
  /* 8: tampered copy is cleared (e.g. the owner re-flashed an official build) -> safe mode lifts again */
  unlink(HSAFEF); wr(INTEGF,"status=official\nreason=\n");
  decide_safe(""); CHECK(g_safe==0); CHECK(read_status_key("hooksafe")=="0");
  unlink(INTEGF); unlink(HSAFEF);
  printf(fails?"TESTS FAILED %d\n":"ALL TESTS PASSED\n",fails); return fails!=0;
}
