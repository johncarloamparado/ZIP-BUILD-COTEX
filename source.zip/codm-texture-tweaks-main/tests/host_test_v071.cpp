/* v0.71: upload spreading (queue, order, budget, PBO, delete, replay state restore) and upload accounting. */
#include "main_test_copy.cpp"
extern "C" int __android_log_print(int,const char*,const char*,...){return 0;}
extern "C" int __android_log_vprint(int,const char*,const char*,va_list){return 0;}
static int fails=0;
#define CHECK(c) do{if(!(c)){printf("FAIL line %d: %s\n",__LINE__,#c);fails++;}}while(0)
static void wr(const char *p,const char *s){FILE*f=fopen(p,"w");if(f){fputs(s,f);fclose(f);}}
static std::string rd(const char *p){FILE*f=fopen(p,"r");if(!f)return "";std::string s;char b[2048];while(size_t n=fread(b,1,sizeof b,f))s.append(b,n);fclose(f);return s;}
static int g_pbo=0, g_tex_bound=7, g_real_pbo=0;
static std::set<GLuint> g_alive;
struct Call{GLuint id; GLint l; GLsizei n; uint8_t first;};
static std::vector<Call> g_calls;      /* uploads that reached the "driver" */
static std::vector<int> g_binds;
static void fake_giv(GLenum e,GLint *v){ if(e==0x88EF)*v=g_real_pbo; else if(e==0x8069)*v=g_tex_bound; else *v=0; }
static GLboolean fake_is(GLuint id){return g_alive.count(id)?1:0;}
static void fake_bb(GLenum,GLuint b){g_real_pbo=(int)b;}
static void fake_bind(GLenum,GLuint id){g_tex_bound=(int)id; g_binds.push_back((int)id);}
static void fake_ctsi2(GLenum,GLint l,GLint,GLint,GLsizei,GLsizei,GLenum,GLsizei n,const void*p){ g_calls.push_back({(GLuint)g_tex_bound,l,n,(p && !g_real_pbo)?*(const uint8_t*)p:(uint8_t)0}); }
static void fake_del(GLsizei,const GLuint*){}
static std::vector<uint8_t> mk(int n,uint8_t v){return std::vector<uint8_t>(n,v);}
static void frame(int n){ g_sp_frame=n; g_sp_used=0; sp_replay((long long)g_spread_kb.load()*1024,false); }
int main(){
  unlink(SPREADF); wr(GRASSF,""); wr(ORIGF,""); load_cfg(); log_start(4);
  g_giv_hook=fake_giv; g_sp_is_hook=fake_is; g_sp_bb_hook=fake_bb; o_bind=fake_bind; o_ctsi2=fake_ctsi2; o_del=fake_del; tl_unit=0;
  g_near=0; g_testtex=0; g_style=0; g_flat=0; g_blk=0; g_alpha=0; g_grass_on=0; g_orig_on=0; g_minsz=64; g_delay=0;
  g_rt=(pid_t)syscall(SYS_gettid);                 /* this thread plays the render thread */
  for(GLuint i=1;i<=9;i++)g_alive.insert(i);

  /* OFF by default: spread.txt missing -> 0, uploads pass straight through */
  CHECK(g_spread_kb.load()==0);
  auto A=mk(300*1024,11); tl_bound[0]=1; g_tex_bound=1; h_ctsi2(GL_TEXTURE_2D,0,0,0,512,512,0x9279,(GLsizei)A.size(),A.data());
  CHECK(g_calls.size()==1 && g_sp_nd.load()==0);
  /* spread.txt value range */
  wr(SPREADF,"100\n"); load_cfg(); CHECK(g_spread_kb.load()==0);
  wr(SPREADF,"99999\n"); load_cfg(); CHECK(g_spread_kb.load()==0);
  wr(SPREADF,"1024\n"); load_cfg(); CHECK(g_spread_kb.load()==1024);
  CHECK(access(SPREADF,F_OK)==0);

  /* budget 1 MB: first big upload passes, the next ones in the same frame are queued, small ones pass if their texture has nothing queued */
  g_calls.clear(); g_sp_nd=0; g_sp_nr=0; frame(1);
  auto B=mk(700*1024,22), C=mk(700*1024,33), D=mk(700*1024,44), S=mk(16*1024,55);
  tl_bound[0]=2; g_tex_bound=2; h_ctsi2(GL_TEXTURE_2D,0,0,0,512,512,0x9279,(GLsizei)B.size(),B.data());       /* passes (used was 0) */
  tl_bound[0]=3; g_tex_bound=3; h_ctsi2(GL_TEXTURE_2D,0,0,0,512,512,0x9279,(GLsizei)C.size(),C.data());       /* 700+700 > 1024 -> queued */
  tl_bound[0]=4; g_tex_bound=4; h_ctsi2(GL_TEXTURE_2D,0,0,0,512,512,0x9279,(GLsizei)D.size(),D.data());       /* queued */
  tl_bound[0]=5; g_tex_bound=5; h_ctsi2(GL_TEXTURE_2D,0,0,0,64,64,0x9279,(GLsizei)S.size(),S.data());         /* small, texture 5 clean -> passes */
  CHECK(g_calls.size()==2 && g_calls[0].id==2 && g_calls[1].id==5);
  CHECK(g_sp_nd.load()==2);
  /* the source buffer may be reused by the game right away: replay must use the copy */
  std::fill(C.begin(),C.end(),0); std::fill(D.begin(),D.end(),0);
  /* order per texture: a SMALL later upload to a texture with queued data must queue too (even below the size limit) */
  tl_bound[0]=3; g_tex_bound=3; auto S3=mk(8*1024,66); h_ctsi2(GL_TEXTURE_2D,1,0,0,128,128,0x9279,(GLsizei)S3.size(),S3.data());
  CHECK(g_calls.size()==2 && g_sp_nd.load()==3);
  /* next frame: replay until the 1 MB budget is reached: 3/l0 (700 KB) then 4 (700 KB); the small level-1 upload of texture 3 waits one more frame */
  g_calls.clear(); g_binds.clear(); g_tex_bound=7; g_real_pbo=0; frame(2);
  CHECK(g_calls.size()==2);
  CHECK(g_calls[0].id==3 && g_calls[0].l==0 && g_calls[0].first==33);  /* original data, not the zeroed source */
  CHECK(g_calls[1].id==4 && g_calls[1].first==44);
  CHECK(g_tex_bound==7);                                               /* the game's binding is put back */
  g_calls.clear(); frame(3);
  CHECK(g_calls.size()==1 && g_calls[0].id==3 && g_calls[0].l==1);    /* FIFO: level 1 of texture 3 comes after its level 0 */
  { std::lock_guard<std::mutex> lk(g_spmu); CHECK(g_spq.empty() && g_sppend.empty() && g_sp_qbytes==0); }
  CHECK(g_sp_nr.load()==3);

  /* pixel buffer: never copied; queued uploads of that texture are flushed first so the order holds */
  g_calls.clear(); frame(4);
  tl_bound[0]=2; g_tex_bound=2; h_ctsi2(GL_TEXTURE_2D,0,0,0,512,512,0x9279,(GLsizei)B.size(),B.data());       /* passes */
  tl_bound[0]=3; g_tex_bound=3; h_ctsi2(GL_TEXTURE_2D,0,0,0,512,512,0x9279,(GLsizei)C.size(),C.data());       /* queued (C is zero filled now) */
  g_pbo=1; /* g_giv_hook reports the unpack buffer through g_real_pbo */ g_real_pbo=9;
  size_t before=g_calls.size();
  tl_bound[0]=3; g_tex_bound=3; h_ctsi2(GL_TEXTURE_2D,2,0,0,64,64,0x9279,(GLsizei)S3.size(),(const void*)0x10);  /* PBO offset: must pass through uncopied, after the flush of texture 3 */
  CHECK(g_calls.size()==before+2 && g_calls[before].id==3 && g_calls[before].l==0 && g_calls[before+1].l==2);
  CHECK(g_sp_pbo.load()>=1);
  CHECK(g_real_pbo==9);                                                /* the PBO binding was restored after the flush */
  g_real_pbo=0; g_pbo=0;

  /* a deleted texture drops its queued uploads (no upload into a recycled id) */
  g_calls.clear(); frame(5);
  tl_bound[0]=2; g_tex_bound=2; h_ctsi2(GL_TEXTURE_2D,0,0,0,512,512,0x9279,(GLsizei)B.size(),B.data());
  tl_bound[0]=6; g_tex_bound=6; h_ctsi2(GL_TEXTURE_2D,0,0,0,512,512,0x9279,(GLsizei)C.size(),C.data());      /* queued */
  GLuint del6=6; h_del(1,&del6); g_alive.erase(6);
  frame(6);
  bool up6=false; for(auto&c:g_calls) if(c.id==6) up6=true;
  CHECK(!up6);
  { std::lock_guard<std::mutex> lk(g_spmu); CHECK(g_spq.empty() && g_sppend.empty() && g_sp_qbytes==0); }

  /* a texture that no longer exists when its turn comes is counted, not uploaded */
  g_calls.clear(); frame(7);
  tl_bound[0]=2; g_tex_bound=2; h_ctsi2(GL_TEXTURE_2D,0,0,0,512,512,0x9279,(GLsizei)B.size(),B.data());
  tl_bound[0]=8; g_tex_bound=8; h_ctsi2(GL_TEXTURE_2D,0,0,0,512,512,0x9279,(GLsizei)C.size(),C.data());
  g_alive.erase(8); long long lost0=g_sp_lost.load(); frame(8);
  CHECK(g_sp_lost.load()==lost0+1);

  /* queue cap: more than 96 MB queued forces a full flush instead of growing */
  g_calls.clear(); g_sp_flush=0; frame(9);
  auto big=mk(8<<20,77); for(GLuint i=1;i<=7;i++) g_alive.insert(i);
  tl_bound[0]=2; g_tex_bound=2; h_ctsi2(GL_TEXTURE_2D,0,0,0,2048,2048,0x9279,(GLsizei)big.size(),big.data());
  for(int k=0;k<14;k++){ tl_bound[0]=1; g_tex_bound=1; h_ctsi2(GL_TEXTURE_2D,k%10,0,0,2048,2048,0x9279,(GLsizei)big.size(),big.data()); }
  { std::lock_guard<std::mutex> lk(g_spmu); CHECK(g_sp_qbytes<=SP_QCAP); }
  CHECK(g_sp_flush.load()>=1);
  sp_flush_all(); { std::lock_guard<std::mutex> lk(g_spmu); CHECK(g_spq.empty() && g_sp_qbytes==0); }

  /* accounting: bytes and the biggest upload are counted on the render thread */
  c_ubytes[0]=0; c_ucnt[0]=0; c_umax=0; g_spread_kb=0;
  auto E=mk(40*1024,1); tl_bound[0]=1; g_tex_bound=1; h_ctsi2(GL_TEXTURE_2D,0,0,0,256,256,0x9276,(GLsizei)E.size(),E.data());
  CHECK(c_ubytes[0].load()==40*1024 && c_ucnt[0].load()==1 && c_umax.load()==40*1024 && c_ufmt.load()==0x9276 && c_uw.load()==256);
  /* the system snapshot never crashes and logs one line */
  sys_probe("test",1.0,300.f); if(lf)fflush(lf);
  CHECK(rd(LOGF).find("SYS test t=1.00 ms=300")!=std::string::npos);
  if(lf){fclose(lf);lf=nullptr;}
  printf(fails?"FAILED %d\n":"ALL TESTS PASSED\n",fails); return fails?1:0;
}
