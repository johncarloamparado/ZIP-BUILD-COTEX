/* v0.78: live Hide / Restore-parameters without a kept copy (metadata only), capture from the start (livecap.txt). */
#include "main_test_copy.cpp"
extern "C" int __android_log_print(int,const char*,const char*,...){return 0;}
extern "C" int __android_log_vprint(int,const char*,const char*,va_list){return 0;}
static int fails=0;
#define CHECK(c) do{if(!(c)){printf("FAIL line %d: %s\n",__LINE__,#c);fails++;}}while(0)
static void wr(const char *p,const char *s){FILE*f=fopen(p,"w");if(f){fputs(s,f);fclose(f);}}
static std::string rd(const char *p){FILE*f=fopen(p,"r");if(!f)return "";std::string s;char b[4096];while(size_t n=fread(b,1,sizeof b,f))s.append(b,n);fclose(f);return s;}
static int g_tex_bound=7, g_real_pbo=0;
static std::set<GLuint> g_alive;
struct Call{GLuint id; GLint l; GLsizei n; GLsizei w; uint8_t first;};
static std::vector<Call> g_calls;
static std::vector<std::pair<int,int>> g_tp;
static void fake_giv(GLenum e,GLint *v){ if(e==0x88EF)*v=g_real_pbo; else if(e==0x8069)*v=g_tex_bound; else *v=0; }
static GLboolean fake_is(GLuint id){return g_alive.count(id)?1:0;}
static void fake_bb(GLenum,GLuint b){g_real_pbo=(int)b;}
static void fake_bind(GLenum,GLuint id){g_tex_bound=(int)id;}
static void fake_ctsi2(GLenum,GLint l,GLint,GLint,GLsizei w,GLsizei,GLenum,GLsizei n,const void*p){ g_calls.push_back({(GLuint)g_tex_bound,l,n,w,(p && !g_real_pbo)?*(const uint8_t*)p:(uint8_t)0}); }
static void fake_del(GLsizei,const GLuint*){}
static void fake_tp(GLenum,GLenum pn,GLint v){ g_tp.push_back({(int)pn,(int)v}); }
static std::vector<uint8_t> mk(int n,uint8_t v){return std::vector<uint8_t>(n,v);}
static int64_t T=0;
static void poll(){ T+=2000000000LL; live_poll(T); lv_apply(); }
static std::string hex16(uint64_t h){ char b[24]; snprintf(b,sizeof b,"%016llx",(unsigned long long)h); return b; }
int main(){
  unlink(LIVEF); unlink(LIVECAPF); unlink(MARKF); unlink(LIVECF); wr(GRASSF,""); wr(ORIGF,""); load_cfg(); log_start(4);
  g_giv_hook=fake_giv; g_sp_is_hook=fake_is; g_sp_bb_hook=fake_bb; o_bind=fake_bind; o_ctsi2=fake_ctsi2; o_del=fake_del; real_tp=fake_tp; tl_unit=0;
  g_near=0; g_testtex=0; g_style=0; g_flat=0; g_blk=0; g_alpha=0; g_grass_on=0; g_orig_on=0; g_minsz=64; g_delay=0;
  g_rt=(pid_t)syscall(SYS_gettid); g_t0=1;
  for(GLuint i=1;i<=12;i++)g_alive.insert(i);

  /* livecap.txt: only with live mode; capture window open from the start */
  wr(LIVECAPF,"1\n"); load_cfg(); CHECK(g_lv_cap.load()==0);
  wr(LIVEF,"1\n"); load_cfg(); CHECK(g_live_on.load()==1 && g_lv_cap.load()==1);
  wr(LIVECAPF,"0\n"); load_cfg(); CHECK(g_lv_cap.load()==0);
  unlink(LIVECAPF); load_cfg(); CHECK(g_lv_cap.load()==0);

  /* a texture is loaded while NO capture window is open: only metadata is noted */
  auto A=mk(262144,11);                                   /* ETC2 RGBA 512x512 = 128*128*16 bytes */
  uint64_t hA=tex_hash(A.data(),(int)A.size());
  g_lv[2]=3;                                              /* made with 3 levels */
  tl_bound[0]=2; g_tex_bound=2; h_ctsi2(GL_TEXTURE_2D,0,0,0,512,512,0x9279,(GLsizei)A.size(),A.data());
  { std::lock_guard<std::mutex> lk(g_lvmu); CHECK(g_lvt.empty() && g_lvm.count(2) && g_lvm[2].hash==hA && g_lvm[2].w==512); }
  poll();                                                  /* baseline */
  g_calls.clear(); g_tp.clear();
  wr(LIVECF,("h "+hex16(hA)+"\n").c_str()); poll();
  CHECK(g_calls.size()==3);                                /* 3 levels blanked with sizes from the format, no copy needed */
  if(g_calls.size()==3){ CHECK(g_calls[0].n==262144 && g_calls[1].n==65536 && g_calls[2].n==16384 && g_calls[0].id==2 && g_calls[1].w==256); }
  CHECK(rd(P("codm_tex.log")).find("hidden=1 (without a kept copy=1")!=std::string::npos);
  CHECK(rd(P("codm_tex.status")).find("lv_meta=1")!=std::string::npos);
  /* Show needs the original data: nothing is sent, and it is reported */
  g_calls.clear(); wr(LIVECF,("u "+hex16(hA)+"\n").c_str()); T+=1; poll(); usleep(1100000);
  poll(); CHECK(g_calls.empty());
  CHECK(rd(P("codm_tex.status")).find("nocopy=1")!=std::string::npos);
  /* parameters can be put back without data */
  g_tp.clear(); wr(LIVECF,("r "+hex16(hA)+"\n").c_str()); usleep(1100000); poll(); poll(); CHECK(!g_tp.empty());
  /* unknown hash */
  g_calls.clear(); wr(LIVECF,"h 00000000000000ff\n"); usleep(1100000); poll(); poll(); CHECK(g_calls.empty());
  /* a deleted texture is forgotten */
  { GLuint ids[1]={2}; h_del(1,ids); }
  { std::lock_guard<std::mutex> lk(g_lvmu); CHECK(g_lvm.count(2)==0); }
  /* a texture that is also captured: the copy path is used, not the metadata path twice */
  wr(MARKF,"A\n"); usleep(1100000); poll(); poll();
  tl_bound[0]=3; g_tex_bound=3; h_ctsi2(GL_TEXTURE_2D,0,0,0,512,512,0x9279,(GLsizei)A.size(),A.data());
  g_calls.clear(); wr(LIVECF,("h "+hex16(hA)+"\n").c_str()); usleep(1100000); poll(); poll();
  CHECK(g_calls.size()==1 && g_calls[0].id==3);
  g_calls.clear(); wr(LIVECF,("u "+hex16(hA)+"\n").c_str()); usleep(1100000); poll(); poll();
  CHECK(g_calls.size()==1 && g_calls[0].first==11);        /* the original data is back */
  unlink(LIVEF); unlink(LIVECF); unlink(MARKF);
  if(fails){printf("TESTS FAILED %d\n",fails);return 1;}
  printf("v078 ok\n"); return 0;
}
