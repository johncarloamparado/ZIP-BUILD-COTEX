#!/bin/sh
# v0.91 host test for webroot/check.sh: builds a fake module folder (plain text standing in for the .so, since
# grep -a reads any file the same way), signs it with a throwaway key, and checks every status/reason it can
# give. Run by tests/run_host_tests.sh. No Android toolchain needed - this is the exact same shell script that
# ships in the module, just pointed at a folder we built by hand.
# v0.92: the shipped check.sh now REQUIRES a signed release (CODM_REQUIRE_SIGNED=1). The layer tests below that are about files,
# module.prop and the build mark use a copy of check.sh with that switched to 0 (CHK_OPEN), so they keep testing one thing each;
# the signed / unsigned behaviour itself is tested with the real file (check_real) and the throwaway-key copy (check_pinned).
# service.sh now lives in webroot/service.sh (that is where the build workflows ship it from).
set -u
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
CHK="$ROOT/webroot/check.sh"
fails=0
check() { # check <label> <expected status> <expected reason or "" for official> <module dir>
  label="$1"; wantstatus="$2"; wantreason="$3"; dir="$4"
  out="$(sh "$CHK_OPEN" "$dir" 2>&1)"
  gotstatus="$(printf '%s\n' "$out" | sed -n 's/^status=//p' | head -n 1)"
  gotreason="$(printf '%s\n' "$out" | sed -n 's/^reason=//p' | head -n 1)"
  if [ "$gotstatus" != "$wantstatus" ] || { [ -n "$wantreason" ] && [ "$gotreason" != "$wantreason" ]; }; then
    echo "FAIL [$label]: got status=$gotstatus reason=$gotreason, wanted status=$wantstatus reason=$wantreason"
    echo "$out" | sed 's/^/    /'
    fails=$((fails + 1))
  fi
}
check_real() { # same, but with the check.sh exactly as shipped (signed release required)
  label="$1"; wantstatus="$2"; wantreason="$3"; dir="$4"
  out="$(sh "$CHK" "$dir" 2>&1)"
  gotstatus="$(printf '%s\n' "$out" | sed -n 's/^status=//p' | head -n 1)"
  gotreason="$(printf '%s\n' "$out" | sed -n 's/^reason=//p' | head -n 1)"
  if [ "$gotstatus" != "$wantstatus" ] || { [ -n "$wantreason" ] && [ "$gotreason" != "$wantreason" ]; }; then
    echo "FAIL [$label]: got status=$gotstatus reason=$gotreason, wanted status=$wantstatus reason=$wantreason"
    fails=$((fails + 1))
  fi
}

TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
# v0.92: tools/sign_release.sh appends a "Signed release" block to $GITHUB_STEP_SUMMARY whenever it runs. In the GitHub build that
# variable is set, so every test that signs with a throw-away key would put a fake "Signed release" (with a throw-away key) into
# the real job summary, next to the real one. Tests never write there.
unset GITHUB_STEP_SUMMARY
CHK_OPEN="$TMP/check_open.sh"
sed 's/^CODM_REQUIRE_SIGNED=.*/CODM_REQUIRE_SIGNED=0/' "$CHK" > "$CHK_OPEN"
grep -q '^CODM_REQUIRE_SIGNED=0$' "$CHK_OPEN" || { echo "FAIL: could not make the unsigned-allowed copy of check.sh"; exit 1; }
grep -q '^CODM_REQUIRE_SIGNED=1$' "$CHK" || { echo "FAIL: the shipped check.sh is not CODM_REQUIRE_SIGNED=1"; exit 1; }

# --- restricted PATH dirs, for the "tool missing on this phone" cases -------------------------------------
BIN_NOSHA="$TMP/bin_nosha"; mkdir -p "$BIN_NOSHA"
for t in sh grep sed cut head tr date mv chmod cp mkdir dirname openssl; do ln -s "$(command -v "$t")" "$BIN_NOSHA/$t"; done
BIN_NOSSL="$TMP/bin_nossl"; mkdir -p "$BIN_NOSSL"
for t in sh grep sed cut head tr date mv chmod cp mkdir dirname sha256sum; do ln -s "$(command -v "$t")" "$BIN_NOSSL/$t"; done

# --- build one "official" module folder, return its path via $MOD ------------------------------------------
build_official() {
  MOD="$TMP/mod_$1"; rm -rf "$MOD"; mkdir -p "$MOD/webroot" "$MOD/zygisk"
  echo "<html>index v$1</html>"            > "$MOD/webroot/index.html"
  echo "notice"                             > "$MOD/webroot/NOTICE.txt"
  echo "license"                            > "$MOD/webroot/LICENSE.txt"
  echo "#!/system/bin/sh"                   > "$MOD/customize.sh"
  cp "$CHK" "$MOD/webroot/check.sh"
  echo "#!/system/bin/sh"                   > "$MOD/webroot/service.sh"
  {
    echo "id=codm_tex_logger"
    echo "name=CODM Blocky Textures"
    echo "version=v0.94"
    echo "versionCode=119"
    echo "author=Q9 Papyrus"
    echo "description=Texture filtering for CODM."
  } > "$MOD/module.prop"
  h() { sha256sum "$1" | cut -d' ' -f1; }
  NAMEH="$(printf '%s' "CODM Blocky Textures" | sha256sum | cut -d' ' -f1)"
  DESCH="$(printf '%s' "Texture filtering for CODM." | sha256sum | cut -d' ' -f1)"
  MARK="CODMSUM1 index=$(h "$MOD/webroot/index.html") notice=$(h "$MOD/webroot/NOTICE.txt") license=$(h "$MOD/webroot/LICENSE.txt") customize=$(h "$MOD/customize.sh") chk=$(h "$MOD/webroot/check.sh") svc=$(h "$MOD/webroot/service.sh") name=$NAMEH desc=$DESCH"
  echo "$MARK" > "$MOD/zygisk/arm64-v8a.so"
  cp "$MOD/zygisk/arm64-v8a.so" "$MOD/zygisk/armeabi-v7a.so"
}

# 1: a clean official build passes every layer
build_official 1
check "official" official "" "$MOD"

# 2: no sha256sum on this device -> unknown, not tampered (fail-open on a missing tool)
out="$(PATH="$BIN_NOSHA" sh "$CHK" "$MOD" 2>&1)"
got="$(printf '%s\n' "$out" | sed -n 's/^status=//p' | head -n 1)"
[ "$got" = "unknown" ] || { echo "FAIL [no_sha256sum]: got $out"; fails=$((fails + 1)); }

# 3: each protected file changed one at a time
build_official 2; echo "<html>edited</html>" > "$MOD/webroot/index.html"; check "changed index" tampered changed_index "$MOD"
build_official 2; echo "edited"              > "$MOD/webroot/NOTICE.txt"; check "changed notice" tampered changed_notice "$MOD"
build_official 2; echo "edited"              > "$MOD/webroot/LICENSE.txt"; check "changed license" tampered changed_license "$MOD"
build_official 2; echo "# edited"            > "$MOD/customize.sh"; check "changed customize" tampered changed_customize "$MOD"
build_official 2; echo "# edited" >> "$MOD/webroot/check.sh"
check "changed check.sh" tampered changed_chk "$MOD"
build_official 2; echo "# edited" >> "$MOD/webroot/service.sh"; check "changed webroot/service.sh" tampered changed_svc "$MOD"

# 4: module.prop name / description / id / author
build_official 2; sed -i 's/^name=.*/name=Ghost Textures/' "$MOD/module.prop"; check "renamed" tampered changed_name "$MOD"
build_official 2; sed -i 's/^description=.*/description=something else/' "$MOD/module.prop"; check "redescribed" tampered changed_description "$MOD"
build_official 2; sed -i 's/^id=.*/id=someone_else/' "$MOD/module.prop"; check "id changed" tampered id_changed "$MOD"
build_official 2; sed -i 's/^author=.*/author=Not Q9/' "$MOD/module.prop"; check "author changed" tampered author_changed "$MOD"

# 5: mark missing / mismatched between the two .so's
build_official 2; rm -f "$MOD"/zygisk/*.so; check "no .so" tampered no_mark "$MOD"
build_official 2; : > "$MOD/zygisk/arm64-v8a.so"; check "no mark inside .so" tampered no_mark "$MOD"
build_official 2
ZERO64="$(printf '0%.0s' $(seq 1 64))"   # 64 zero chars: valid hex, and no real SHA-256 of real content will ever equal it
sed -E "s/^CODMSUM1 index=[0-9a-f]{64}/CODMSUM1 index=$ZERO64/" "$MOD/zygisk/arm64-v8a.so" > "$MOD/zygisk/armeabi-v7a.so"
check "so's disagree" tampered so_mismatch "$MOD"

# 6: empty module folder entirely
check "empty folder" tampered no_mark "$TMP/does_not_exist"

# 7 (v0.92): what an installer really leaves on the phone
build_official 2; cp "$MOD/webroot/service.sh" "$MOD/service.sh"; check "root service.sh = identical copy of webroot/service.sh" official "" "$MOD"
build_official 2; cp "$MOD/webroot/service.sh" "$MOD/service.sh"; echo "# edited" >> "$MOD/service.sh"; check "root service.sh edited" tampered changed_svc "$MOD"
build_official 2; rm -f "$MOD/customize.sh"; check "customize.sh already deleted by the installer is NOT modified" official "" "$MOD"
# the root service.sh is replaced by a different one AND customize.sh is gone: still caught
build_official 2; rm -f "$MOD/customize.sh"; echo "echo bypass" > "$MOD/service.sh"; check "customize.sh gone + a different root service.sh" tampered changed_svc "$MOD"

# 8 (v0.92): a signed release is REQUIRED with the shipped check.sh
build_official 2; check_real "no RELEASE.* files at all (unsigned build)" tampered unsigned "$MOD"
build_official 2; echo x > "$MOD/RELEASE.pub"; check_real "only RELEASE.pub present" tampered unsigned "$MOD"
build_official 2; echo x > "$MOD/RELEASE.sig"; echo x > "$MOD/RELEASE.sha256"; check_real "RELEASE.pub missing" tampered unsigned "$MOD"
# the unsigned refusal does not need openssl: a phone without it must still refuse an unsigned zip
build_official 2
out="$(PATH="$BIN_NOSSL" sh "$CHK" "$MOD" 2>&1)"
[ "$(printf '%s\n' "$out" | sed -n 's/^reason=//p' | head -n 1)" = "unsigned" ] || { echo "FAIL [unsigned, no openssl on the phone]: got $out"; fails=$((fails + 1)); }

# --- signed-release layer ------------------------------------------------------------------------------
if command -v openssl >/dev/null 2>&1; then
  OWNER_KEY="$TMP/owner.pem"; OWNER_PUB="$TMP/owner.pub"
  OTHER_KEY="$TMP/other.pem"; OTHER_PUB="$TMP/other.pub"
  openssl genpkey -algorithm ED25519 -out "$OWNER_KEY" >/dev/null 2>&1
  openssl pkey -in "$OWNER_KEY" -pubout -out "$OWNER_PUB" >/dev/null 2>&1
  openssl genpkey -algorithm ED25519 -out "$OTHER_KEY" >/dev/null 2>&1
  openssl pkey -in "$OTHER_KEY" -pubout -out "$OTHER_PUB" >/dev/null 2>&1
  OWNER_FP="$(openssl pkey -pubin -in "$OWNER_PUB" -outform DER 2>/dev/null | sha256sum | cut -d' ' -f1)"

  # a check.sh pinned to the throwaway OWNER_FP, so the test does not depend on the real project key
  CHK_PINNED="$TMP/check_pinned.sh"
  sed "s/^CODM_PUBKEY_FP=.*/CODM_PUBKEY_FP=\"$OWNER_FP\"/" "$CHK" > "$CHK_PINNED"

  sign_into() { # sign_into <mod dir> <signing key>
    ( cd "$1" && find . -type f ! -name 'RELEASE.*' | sort | xargs sha256sum > RELEASE.sha256 )
    openssl pkeyutl -sign -rawin -inkey "$2" -in "$1/RELEASE.sha256" -out "$1/RELEASE.sig" >/dev/null 2>&1
  }
  check_pinned() { # mirrors check(), but calls the throwaway-pinned copy
    label="$1"; wantstatus="$2"; wantreason="$3"; dir="$4"
    out="$(sh "$CHK_PINNED" "$dir" 2>&1)"
    gotstatus="$(printf '%s\n' "$out" | sed -n 's/^status=//p' | head -n 1)"
    gotreason="$(printf '%s\n' "$out" | sed -n 's/^reason=//p' | head -n 1)"
    if [ "$gotstatus" != "$wantstatus" ] || { [ -n "$wantreason" ] && [ "$gotreason" != "$wantreason" ]; }; then
      echo "FAIL [$label]: got status=$gotstatus reason=$gotreason, wanted status=$wantstatus reason=$wantreason"
      fails=$((fails + 1))
    fi
  }

  # a) signed correctly with the pinned (owner) key -> still official
  build_official 3; cp "$OWNER_PUB" "$MOD/RELEASE.pub"; sign_into "$MOD" "$OWNER_KEY"
  check_pinned "signed with owner key" official "" "$MOD"

  # b) internally-consistent bundle signed with a DIFFERENT key -> refused, even though its own signature verifies against its own pub
  build_official 3; cp "$OTHER_PUB" "$MOD/RELEASE.pub"; sign_into "$MOD" "$OTHER_KEY"
  check_pinned "signed with swapped key" tampered pubkey_mismatch "$MOD"

  # c) owner key, but a file changed AFTER signing
  build_official 3; cp "$OWNER_PUB" "$MOD/RELEASE.pub"; sign_into "$MOD" "$OWNER_KEY"
  echo "post-sign edit" >> "$MOD/webroot/NOTICE.txt"
  h() { sha256sum "$1" | cut -d' ' -f1; }
  NAMEH="$(printf '%s' "CODM Blocky Textures" | sha256sum | cut -d' ' -f1)"
  DESCH="$(printf '%s' "Texture filtering for CODM." | sha256sum | cut -d' ' -f1)"
  MARK="CODMSUM1 index=$(h "$MOD/webroot/index.html") notice=$(h "$MOD/webroot/NOTICE.txt") license=$(h "$MOD/webroot/LICENSE.txt") customize=$(h "$MOD/customize.sh") chk=$(h "$MOD/webroot/check.sh") svc=$(h "$MOD/webroot/service.sh") name=$NAMEH desc=$DESCH"
  echo "$MARK" > "$MOD/zygisk/arm64-v8a.so"; cp "$MOD/zygisk/arm64-v8a.so" "$MOD/zygisk/armeabi-v7a.so"
  check_pinned "edited after signing (mark updated too)" tampered signed_file_mismatch "$MOD"

  # d) owner key, corrupt signature bytes
  build_official 3; cp "$OWNER_PUB" "$MOD/RELEASE.pub"; sign_into "$MOD" "$OWNER_KEY"; printf 'xx' >> "$MOD/RELEASE.sig"
  check_pinned "corrupt signature" tampered signature_invalid "$MOD"

  # e) openssl missing on-device -> the file-hash layer alone still decides (signed bundle present is ignored gracefully)
  build_official 3; cp "$OWNER_PUB" "$MOD/RELEASE.pub"; sign_into "$MOD" "$OWNER_KEY"
  out="$(PATH="$BIN_NOSSL" sh "$CHK_PINNED" "$MOD" 2>&1)"
  got="$(printf '%s\n' "$out" | sed -n 's/^status=//p' | head -n 1)"
  [ "$got" = "official" ] || { echo "FAIL [no openssl, signed bundle ignored]: got $out"; fails=$((fails + 1)); }

  # f) v0.92: no SIGNING_KEY at all (no RELEASE.* files) -> refused. This used to be "official" (v0.91: optional layer).
  build_official 3
  check_pinned "unsigned build" tampered unsigned "$MOD"

  # g) v0.92: the list the build machine signs also names META-INF/ files (never extracted by the installer) and customize.sh
  # (deleted by the installer when the install ends). On the phone neither is there, and the genuine release must still pass.
  build_official 3
  mkdir -p "$MOD/META-INF/com/google/android"
  echo "update-binary" > "$MOD/META-INF/com/google/android/update-binary"
  echo "#MAGISK"       > "$MOD/META-INF/com/google/android/updater-script"
  cp "$OWNER_PUB" "$MOD/RELEASE.pub"; sign_into "$MOD" "$OWNER_KEY"
  rm -rf "$MOD/META-INF"
  check_pinned "signed, flash time (META-INF not extracted)" official "" "$MOD"
  rm -f "$MOD/customize.sh"
  check_pinned "signed, runtime (customize.sh deleted too)" official "" "$MOD"
  # ... but a listed file that is NOT one of those two is still held to the signed list: module.prop is covered by the signature
  # but only partly by the build mark (name / description / id / author lines), so an edit to another line is caught by the signature alone
  build_official 3
  cp "$OWNER_PUB" "$MOD/RELEASE.pub"; sign_into "$MOD" "$OWNER_KEY"
  echo "versionCode=999" >> "$MOD/module.prop"
  check_pinned "signed, module.prop edited after signing" tampered signed_file_mismatch "$MOD"
else
  echo "(openssl not available on this host - skipping the signed-release layer tests)"
fi

if [ "$fails" = 0 ]; then echo "ALL TESTS PASSED (check.sh)"; else echo "TESTS FAILED $fails (check.sh)"; fi
exit $([ "$fails" = 0 ] && echo 0 || echo 1)
