#!/system/bin/sh
# Runs inside Magisk / Kitsune Magisk / KernelSU / SukiSU / APatch installers.
SKIPUNZIP=0
ui_print "- CODM Blocky Textures"
ui_print "- Author: Q9 Papyrus"
ui_print "- Contributors: zynn, Shari"
ui_print "- Needs Zygisk (Magisk: Settings > Zygisk ON, or ZygiskNext on KernelSU/APatch)"
# v0.40: there is no x86 / x86_64 library. Stop here instead of installing a module that never loads.
case "$ARCH" in
  x86|x64|x86_64)
    abort "! x86 / x86_64 devices are not supported (this device: $ARCH). The module only ships arm64-v8a and armeabi-v7a libraries."
    ;;
esac
case "$(getprop ro.product.cpu.abi)" in
  x86|x86_64)
    abort "! x86 / x86_64 devices are not supported (abi: $(getprop ro.product.cpu.abi)). The module only ships arm64-v8a and armeabi-v7a libraries."
    ;;
esac
# $ARCH comes from ro.product.cpu.abi, which other modules can spoof and which says "arm" on a 32-bit Android
# running on a 64-bit CPU. So look at what the phone can really run before deciding.
ABILIST64="$(getprop ro.product.cpu.abilist64)"
REAL64=0
if [ "$ARCH" = "arm64" ] || [ "$IS64BIT" = "true" ] || [ -n "$ABILIST64" ] || [ -e /system/bin/linker64 ]; then REAL64=1; fi
ui_print "- arch check: ARCH=$ARCH IS64BIT=$IS64BIT abi=$(getprop ro.product.cpu.abi) abilist64=${ABILIST64:-none} linker64=$([ -e /system/bin/linker64 ] && echo yes || echo no) zygote=$(getprop ro.zygote)"

# v0.39: the zip carries a 64-bit and a 32-bit library. Zygisk loads the one that matches the game's process.
HAVE64=0
HAVE32=0
[ -f "$MODPATH/zygisk/arm64-v8a.so" ] && HAVE64=1
[ -f "$MODPATH/zygisk/armeabi-v7a.so" ] && HAVE32=1
ui_print "- ABI package: arm64=$HAVE64 arm32=$HAVE32"
if [ "$HAVE64" = "0" ] && [ "$HAVE32" = "0" ]; then
  abort "! No zygisk/*.so in this zip (need arm64-v8a and/or armeabi-v7a). Re-download the module."
fi

if [ "$REAL64" = "1" ]; then
  if [ "$ARCH" != "arm64" ]; then
    ui_print "! Note: the installer reports ARCH=$ARCH but 64-bit support exists (abi property may be spoofed). Continuing."
  fi
  if [ "$HAVE64" = "0" ]; then
    if [ "$HAVE32" = "1" ]; then
      ui_print "! Warning: 64-bit phone but zygisk/arm64-v8a.so is missing. Only a 32-bit CODM would load the module."
    else
      abort "! zygisk/arm64-v8a.so is missing from this zip. Re-download the module."
    fi
  fi
else
  if [ "$ARCH" = "arm" ] || [ -n "$KSU" ] || [ -n "$APATCH" ]; then
    ui_print "- 32-bit Android detected: the module uses zygisk/armeabi-v7a.so"
    if [ "$HAVE32" = "0" ]; then
      abort "! zygisk/armeabi-v7a.so is missing from this zip. Re-download the module."
    fi
  else
    abort "! Only arm / arm64 phones are supported (this device: $ARCH)"
  fi
fi

# v0.86: build check, SHA-256 of the WebUI / notices / this script vs. the mark GitHub wrote into the .so ("CODMSUM1 index=..").
# v0.91: the actual check now lives in ONE place, webroot/check.sh (also run every boot by service.sh, and on demand by the WebUI
# itself through ksu.exec) - this just runs it and decides what the FLASH does with the result, so there is one place to fix, not
# three. See webroot/check.sh for what it checks (files, module.prop name/author/description, and an optional signed-release layer).
# STRICT_BUILD_CHECK=1 (default since v0.91): a MODIFIED zip stops here. No password, no prompt, the WebUI is never touched.
# Set it to 0 only for your OWN test installs of a copy you deliberately changed; the WebUI's own check (and service.sh) still call
# it MODIFIED either way - this only controls whether the FLASH itself is allowed to continue.
STRICT_BUILD_CHECK=1
# v0.92: the boot-time script ships as webroot/service.sh (the build workflows only copy webroot/, not a root-level file, so a
# root-level service.sh was never in the zip). The root solution runs <module>/service.sh, so put it there now, BEFORE the check, which
# compares that copy with the one the build mark covers. A failed copy is simply not fatal: the module then has no boot-time verdict.
if [ -f "$MODPATH/webroot/service.sh" ]; then
  cp -f "$MODPATH/webroot/service.sh" "$MODPATH/service.sh" 2>/dev/null && chmod 755 "$MODPATH/service.sh" 2>/dev/null
fi
CHK="$MODPATH/webroot/check.sh"
# v1.02: CODM_CHECK_ALL=1 makes check.sh look at EVERY layer and list every reason (reasons=...), not only the first one it finds.
# service.sh and the WebUI call check.sh without it (one reason, as before).
if [ -f "$CHK" ]; then
  CHKOUT="$(CODM_CHECK_ALL=1 sh "$CHK" "$MODPATH" 2>/dev/null)"
else
  CHKOUT="status=unknown
reason=check_sh_missing
reasons=check_sh_missing"
fi
CHKSTATUS="$(printf '%s\n' "$CHKOUT" | sed -n 's/^status=//p' | head -n 1)"
CHKREASON="$(printf '%s\n' "$CHKOUT" | sed -n 's/^reason=//p' | head -n 1)"
CHKREASONS="$(printf '%s\n' "$CHKOUT" | sed -n 's/^reasons=//p' | head -n 1)"
[ -n "$CHKREASONS" ] || CHKREASONS="$CHKREASON"
chk_text() {
  case "$1" in
    no_mark) echo "no build mark in the .so" ;;
    so_mismatch) echo "the .so files do not match each other" ;;
    changed_index) echo "WebUI (index.html) changed" ;;
    changed_notice) echo "NOTICE.txt changed" ;;
    changed_license) echo "LICENSE.txt changed" ;;
    changed_customize) echo "customize.sh changed" ;;
    changed_chk) echo "check.sh changed" ;;
    changed_svc) echo "service.sh changed" ;;
    changed_name) echo "module name changed" ;;
    changed_description) echo "module description changed" ;;
    id_changed) echo "module id changed" ;;
    author_changed) echo "author changed" ;;
    unsigned) echo "no release signature (RELEASE.sig / RELEASE.sha256 / RELEASE.pub)" ;;
    pubkey_mismatch) echo "signing key is not the owner's" ;;
    signature_invalid) echo "release signature is not valid" ;;
    signed_file_mismatch) echo "files differ from the signed list" ;;
    check_sh_missing) echo "check.sh is missing" ;;
    no_sha256sum) echo "no sha256sum on this phone" ;;
    *) echo "$1" ;;
  esac
}
# v1.02: one word when it is fine; when not, the word and the reasons under it, indented.
case "$CHKSTATUS" in
  official)
    ui_print "- Build check: OFFICIAL"
    ;;
  tampered)
    ui_print "! Build check: MODIFIED"
    for R in $CHKREASONS; do ui_print "    - $(chk_text "$R")"; done
    if [ "$STRICT_BUILD_CHECK" = "1" ]; then
      abort "! The install was stopped."
    else
      ui_print "! The module still installs (STRICT_BUILD_CHECK=0)."
    fi
    ;;
  *)
    ui_print "- Build check: UNKNOWN"
    for R in $CHKREASONS; do ui_print "    - $(chk_text "$R")"; done
    ;;
esac

ui_print "- Settings UI: KernelSU/SukiSU/APatch open it from the manager."
ui_print "  Magisk has no built-in WebUI: use KsuWebUI or MMRL to open this module's page."
ui_print "- Reboot, then open CODM once (until the lobby). The module writes codm_tex.status there."
ui_print "  If the WebUI later says the module never ran: check Zygisk is ON and CODM is not on the DenyList."
