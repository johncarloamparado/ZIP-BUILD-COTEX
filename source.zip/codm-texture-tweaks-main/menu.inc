/* v0.77: in-game menu loader. Included by main.cpp (not part of the host tests; see tests/menu_syntax.cpp).
   The menu itself is Java (menu/q9/Menu.java, built into a dex by menu/build_dex.sh and embedded as MENU_DEX).
   This code only: waits for the game to render, loads the dex with InMemoryDexClassLoader into the game's class loader, and calls
   q9.Menu.start(Application, folder). The Java side writes mark.txt / livecmd.txt (the Live test files) and reads the log.
   Safety: OFF unless menu.txt = 1 (WebUI); menu_try.txt is written before the load and removed by the Java side once the
   overlay is attached - if it is still there at the next start, the last start did not finish and the menu is skipped (crash guard).
   v0.89: the marker says how far the start got. "try N" = the process ended while the dex was being loaded (a real crash risk): skipped at once.
   "loaded N" = loading finished but the overlay never attached (the game was closed early, or no activity was found): the menu is tried again,
   and skipped only after 3 such starts in a row. Before, ONE early close (a swipe from recents) hid the Q9 button for good. */
#define MENUF P("menu.txt")
#define MENUTRYF P("menu_try.txt")
/* decides from the text of menu_try.txt: returns 1 = skip the menu, 0 = start it; *next_n = the count to write into the new marker */
static int menu_guard_skip(const char *txt, int *next_n) {
    *next_n = 0;
    if (!txt || !*txt) return 0;
    if (!strncmp(txt, "try", 3)) return 1;                           /* died while loading: never try again by itself */
    int n = 0;
    if (!strncmp(txt, "loaded", 6)) { if (sscanf(txt + 6, "%d", &n) != 1) n = 1; }
    else n = 1;                                                      /* old marker (just a time): one unfinished start */
    if (n < 1) n = 1;
    if (n >= 3) return 1;
    *next_n = n;
    return 0;
}
#ifdef CODM_HOST_TEST
static void menu_set_vm(JNIEnv *) {}
static void menu_launch() {}
static void winprobe_launch() {}
#else
#include "menu_dex.h"
static JavaVM *g_jvm = nullptr;
static int g_menu_n = 0;                                            /* v0.89: unfinished starts in a row before this one */
static void menu_set_vm(JNIEnv *e) { if (e && e->GetJavaVM(&g_jvm) != JNI_OK) g_jvm = nullptr; }
static bool menu_ex(JNIEnv *env) {
    if (!env->ExceptionCheck()) return false;
    env->ExceptionClear();
    return true;
}
/* returns nullptr on success, else the name of the step that failed */
static const char *menu_run(JNIEnv *env) {
    jclass at = env->FindClass("android/app/ActivityThread");
    if (!at || menu_ex(env)) return "find ActivityThread";
    jmethodID ca = env->GetStaticMethodID(at, "currentApplication", "()Landroid/app/Application;");
    if (!ca || menu_ex(env)) return "find currentApplication";
    jobject appo = nullptr;
    for (int i = 0; i < 30 && !appo; i++) {
        appo = env->CallStaticObjectMethod(at, ca);
        if (menu_ex(env)) return "call currentApplication";
        if (!appo) sleep(1);
    }
    if (!appo) return "no Application yet";
    jclass ctx = env->FindClass("android/content/Context");
    if (!ctx || menu_ex(env)) return "find Context";
    jmethodID gcl = env->GetMethodID(ctx, "getClassLoader", "()Ljava/lang/ClassLoader;");
    if (!gcl || menu_ex(env)) return "find getClassLoader";
    jobject loader = env->CallObjectMethod(appo, gcl);
    if (!loader || menu_ex(env)) return "get class loader";
    unsigned char *copy = (unsigned char *)malloc(MENU_DEX_LEN);      /* kept for the life of the process: ART may read it later */
    if (!copy) return "out of memory";
    memcpy(copy, MENU_DEX, MENU_DEX_LEN);
    jobject bb = env->NewDirectByteBuffer(copy, (jlong)MENU_DEX_LEN);
    if (!bb || menu_ex(env)) return "make byte buffer";
    jclass imc = env->FindClass("dalvik/system/InMemoryDexClassLoader");
    if (!imc || menu_ex(env)) return "find InMemoryDexClassLoader";
    jmethodID ctor = env->GetMethodID(imc, "<init>", "(Ljava/nio/ByteBuffer;Ljava/lang/ClassLoader;)V");
    if (!ctor || menu_ex(env)) return "find loader constructor";
    jobject dl = env->NewObject(imc, ctor, bb, loader);
    if (!dl || menu_ex(env)) return "load dex";
    jclass clc = env->FindClass("java/lang/ClassLoader");
    if (!clc || menu_ex(env)) return "find ClassLoader";
    jmethodID lc = env->GetMethodID(clc, "loadClass", "(Ljava/lang/String;)Ljava/lang/Class;");
    if (!lc || menu_ex(env)) return "find loadClass";
    jstring nm = env->NewStringUTF("q9.Menu");
    jclass mc = (jclass)env->CallObjectMethod(dl, lc, nm);
    if (!mc || menu_ex(env)) return "load class q9.Menu";
    jmethodID st = env->GetStaticMethodID(mc, "start", "(Landroid/app/Application;Ljava/lang/String;)V");
    if (!st || menu_ex(env)) return "find Menu.start";
    jstring jd = env->NewStringUTF(g_dir);
    env->CallStaticVoidMethod(mc, st, appo, jd);
    if (menu_ex(env)) return "call Menu.start";
    return nullptr;
}
#ifdef __ANDROID__
static jint menu_attach(JNIEnv **e) { return g_jvm->AttachCurrentThread(e, nullptr); }
#else
static jint menu_attach(JNIEnv **e) { return g_jvm->AttachCurrentThread((void **)e, nullptr); }      /* desktop jni.h (syntax check only) */
#endif
static void menu_thread() {
    for (int i = 0; i < 150 && g_t0.load() == 0; i++) sleep(2);       /* wait for the first rendered frame (5 minutes at most) */
    if (g_t0.load() == 0) { st_set("menu", "game never rendered"); return; }
    sleep(6);
    if (MENU_DEX_LEN < 64) { L("MENU no dex was built (the build had no android.jar / d8): the menu is unavailable\n"); st_set("menu", "no dex built"); return; }
    if (!g_jvm) { L("MENU no JavaVM\n"); st_set("menu", "no JavaVM"); return; }
    JNIEnv *env = nullptr; bool att = false;
    if (g_jvm->GetEnv((void **)&env, JNI_VERSION_1_6) != JNI_OK) {
        if (menu_attach(&env) != JNI_OK || !env) { L("MENU cannot attach to the JVM\n"); st_set("menu", "attach failed"); return; }
        att = true;
    }
    if (FILE *f = fopen(MENUTRYF, "w")) { fprintf(f, "try %d\n", g_menu_n); fclose(f); }
    const char *bad = menu_run(env);
    if (bad) { L("MENU failed at: %s\n", bad); st_set("menu", (std::string("failed: ") + bad).c_str()); unlink(MENUTRYF); }
    else {
        if (FILE *f = fopen(MENUTRYF, "w")) { fprintf(f, "loaded %d\n", g_menu_n + 1); fclose(f); }   /* the Java side deletes it when the overlay is attached */
        L("MENU loaded (dex %u bytes); the Java side attaches the overlay\n", (unsigned)MENU_DEX_LEN); st_set("menu", "loaded");
    }
    if (att) g_jvm->DetachCurrentThread();
}

/* v0.89 (diagnostic only, nothing is changed): who makes the window small?  The app's own display size (what the game is told) is compared with the
   system's real display size. If the app sees a smaller display with the same shape, Android itself (Game Mode downscale / compatibility scale) or a
   module that changes it shrinks the window; if the app AND the system metrics are both smaller than the real screen the whole process was scaled by the phone; if all are full size, the shrink is made by the game's own render setting. Logged as WINPROBE. */
static bool dm_read(JNIEnv *env, jobject res, int *w, int *h, int *d) {
    jclass rc = env->FindClass("android/content/res/Resources");
    if (!rc || menu_ex(env)) return false;
    jmethodID gdm = env->GetMethodID(rc, "getDisplayMetrics", "()Landroid/util/DisplayMetrics;");
    if (!gdm || menu_ex(env)) return false;
    jobject dm = env->CallObjectMethod(res, gdm);
    if (!dm || menu_ex(env)) return false;
    jclass dc = env->FindClass("android/util/DisplayMetrics");
    if (!dc || menu_ex(env)) return false;
    jfieldID fw = env->GetFieldID(dc, "widthPixels", "I"), fh = env->GetFieldID(dc, "heightPixels", "I"), fd = env->GetFieldID(dc, "densityDpi", "I");
    if (!fw || !fh || !fd || menu_ex(env)) return false;
    *w = env->GetIntField(dm, fw); *h = env->GetIntField(dm, fh); *d = env->GetIntField(dm, fd);
    return !menu_ex(env);
}
static void winprobe_once(JNIEnv *env, int round) {
    jclass at = env->FindClass("android/app/ActivityThread");
    if (!at || menu_ex(env)) { L("WINPROBE round %d: no ActivityThread\n", round); return; }
    jmethodID ca = env->GetStaticMethodID(at, "currentApplication", "()Landroid/app/Application;");
    if (!ca || menu_ex(env)) { L("WINPROBE round %d: no currentApplication\n", round); return; }
    jobject appo = env->CallStaticObjectMethod(at, ca);
    if (!appo || menu_ex(env)) { L("WINPROBE round %d: no Application yet\n", round); return; }
    jclass ctx = env->FindClass("android/content/Context");
    if (!ctx || menu_ex(env)) return;
    jmethodID gr = env->GetMethodID(ctx, "getResources", "()Landroid/content/res/Resources;");
    if (!gr || menu_ex(env)) return;
    jobject ares = env->CallObjectMethod(appo, gr);
    if (!ares || menu_ex(env)) return;
    jclass rc = env->FindClass("android/content/res/Resources");
    if (!rc || menu_ex(env)) return;
    jmethodID gs = env->GetStaticMethodID(rc, "getSystem", "()Landroid/content/res/Resources;");
    if (!gs || menu_ex(env)) return;
    jobject sres = env->CallStaticObjectMethod(rc, gs);
    if (!sres || menu_ex(env)) return;
    int aw = 0, ah = 0, ad = 0, sw = 0, sh = 0, sd = 0;
    if (!dm_read(env, ares, &aw, &ah, &ad) || !dm_read(env, sres, &sw, &sh, &sd)) { L("WINPROBE round %d: could not read the display metrics\n", round); return; }
    int al = aw > ah ? aw : ah, as = aw > ah ? ah : aw, sl = sw > sh ? sw : sh, ss = sw > sh ? sh : sw;
    /* v0.93: Resources.getSystem() is scaled TOO when Android gives the whole process a compatibility scale, so "app == system" does not mean "full size".
       The real screen size the module learned from the window (g_fullw x g_fullh) is the reference when it is known. */
    int nl = g_fullw.load() > g_fullh.load() ? g_fullw.load() : g_fullh.load(), ns = g_fullw.load() > g_fullh.load() ? g_fullh.load() : g_fullw.load();
    bool app_small = al > 0 && sl > 0 && al * 100 < sl * 95 && as * 100 < ss * 95;
    bool proc_small = !app_small && al > 0 && nl > 0 && ns > 0 && al * 100 < nl * 95 && as * 100 < ns * 95 && sl * 100 < nl * 95 && ss * 100 < ns * 95;
    const char *v;
    if (al <= 0 || sl <= 0) v = "unknown";
    else if (app_small) v = "THE SYSTEM shows this game a smaller display than the real one (Android Game Mode / compatibility downscale, or a module that sets it). It is not the game's own setting and not this module";
    else if (proc_small) v = "THE WHOLE PROCESS is told a smaller display than the real screen (the app AND the system metrics of this process are both small, and ours=0 means this module had changed nothing yet). Android or the phone maker's own feature scaled this process before the game or this module did anything. It is not the game's render setting";
    else v = "the app sees the full display: a smaller window comes from the game's own render setting, not from the system";
    L("WINPROBE round %d: app sees %dx%d @%ddpi, system display %dx%d @%ddpi, surface %dx%d, ours=%d, native=%dx%d render_scale=%d -> %s\n", round, aw, ah, ad, sw, sh, sd,
      g_surf_w.load(), g_surf_h.load(), g_ours.load(), g_fullw.load(), g_fullh.load(), g_scale.load(), v);
    st_set("winprobe", app_small ? "system downscale" : (proc_small ? "process downscale" : "app full size"));
}
static void winprobe_thread() {
    for (int i = 0; i < 150 && g_t0.load() == 0; i++) sleep(2);
    if (g_t0.load() == 0 || !g_jvm) return;
    static const int waits[3] = {8, 52, 120};                           /* 8 s, 60 s and 180 s after the first frame */
    for (int r = 0; r < 3; r++) {
        sleep(waits[r]);
        JNIEnv *env = nullptr; bool att = false;
        if (g_jvm->GetEnv((void **)&env, JNI_VERSION_1_6) != JNI_OK) {
            if (menu_attach(&env) != JNI_OK || !env) { L("WINPROBE cannot attach to the JVM\n"); return; }
            att = true;
        }
        winprobe_once(env, r + 1);
        if (att) g_jvm->DetachCurrentThread();
    }
}
static void winprobe_launch() { if (g_jvm && !g_safe) std::thread(winprobe_thread).detach(); }
static void menu_launch() {
    int v = 0;
    if (FILE *f = fopen(MENUF, "r")) { if (fscanf(f, "%d", &v) != 1) v = 0; fclose(f); }
    if (!v || g_safe) return;
    if (access(MENUTRYF, F_OK) == 0) {
        char mt[64] = ""; if (FILE *mf = fopen(MENUTRYF, "r")) { if (!fgets(mt, sizeof mt, mf)) mt[0] = 0; fclose(mf); }
        int nn = 0;
        if (menu_guard_skip(mt, &nn)) {
            L("MENU skipped: the last menu starts did not finish (crash guard, marker \"%.12s\"). Use Try again in the WebUI.\n", mt);
            st_set("menu", "skipped: last start did not finish");
            return;
        }
        L("MENU the last start did not finish (the game was probably closed early); trying again (%d of 3)\n", nn + 1);
        g_menu_n = nn;
    }
    std::thread(menu_thread).detach();
}
#endif
