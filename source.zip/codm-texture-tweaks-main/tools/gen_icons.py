#!/usr/bin/env python3
"""v1.10: builds the icon data from tools/icons/pack.json (the CODM Blocky Icons pack, original work, see tools/icons/LICENSE.txt).
   Writes  menu/q9/IconData.java  (every icon as absolute M / L / C / Q / Z path commands: the live menu draws them with android.graphics.Path)
   and     the sprite block inside webroot/index.html between <!--ICONS--> and <!--/ICONS--> (the WebUI uses <use href="#name">).
   Usage: python3 tools/gen_icons.py [--check]   (--check: only verifies that both outputs are up to date)"""
import json, math, os, re, sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PACK = os.path.join(ROOT, "tools", "icons", "pack.json")
OUTJ = os.path.join(ROOT, "menu", "q9", "IconData.java")
INDEX = os.path.join(ROOT, "webroot", "index.html")
NUM = re.compile(r"[-+]?(?:\d*\.\d+|\d+\.?)(?:[eE][-+]?\d+)?")

def fmt(v):
    s = ("%.3f" % v).rstrip("0").rstrip(".")
    return "0" if s in ("-0", "") else s

def arc_to_cubics(x1, y1, rx, ry, phi, fa, fs, x2, y2):
    if rx == 0 or ry == 0 or (x1 == x2 and y1 == y2):
        return [("L", x2, y2)] if (x1 != x2 or y1 != y2) else []
    rx, ry = abs(rx), abs(ry)
    ph = math.radians(phi); c, s = math.cos(ph), math.sin(ph)
    dx, dy = (x1 - x2) / 2, (y1 - y2) / 2
    x1p, y1p = c * dx + s * dy, -s * dx + c * dy
    lam = x1p ** 2 / rx ** 2 + y1p ** 2 / ry ** 2
    if lam > 1: rx *= math.sqrt(lam); ry *= math.sqrt(lam)
    num = rx ** 2 * ry ** 2 - rx ** 2 * y1p ** 2 - ry ** 2 * x1p ** 2
    den = rx ** 2 * y1p ** 2 + ry ** 2 * x1p ** 2
    co = math.sqrt(max(0, num / den)) * (-1 if fa == fs else 1)
    cxp, cyp = co * rx * y1p / ry, -co * ry * x1p / rx
    cx, cy = c * cxp - s * cyp + (x1 + x2) / 2, s * cxp + c * cyp + (y1 + y2) / 2
    def ang(ux, uy, vx, vy):
        a = math.atan2(ux * vy - uy * vx, ux * vx + uy * vy); return a
    th1 = ang(1, 0, (x1p - cxp) / rx, (y1p - cyp) / ry)
    dth = ang((x1p - cxp) / rx, (y1p - cyp) / ry, (-x1p - cxp) / rx, (-y1p - cyp) / ry)
    if not fs and dth > 0: dth -= 2 * math.pi
    elif fs and dth < 0: dth += 2 * math.pi
    n = max(1, int(math.ceil(abs(dth) / (math.pi / 2) - 1e-9)))
    d = dth / n; t = 4 / 3 * math.tan(d / 4); out = []
    for i in range(n):
        a1 = th1 + i * d; a2 = a1 + d
        def pt(a, k=0):
            return (cx + rx * math.cos(a) * c - ry * math.sin(a) * s, cy + rx * math.cos(a) * s + ry * math.sin(a) * c)
        def dv(a):
            return (-rx * math.sin(a) * c - ry * math.cos(a) * s, -rx * math.sin(a) * s + ry * math.cos(a) * c)
        p1, p2 = pt(a1), pt(a2); d1, d2 = dv(a1), dv(a2)
        out.append(("C", p1[0] + t * d1[0], p1[1] + t * d1[1], p2[0] - t * d2[0], p2[1] - t * d2[1], p2[0], p2[1]))
    return out

def path_ops(d):
    toks = re.findall(r"[A-Za-z]|" + NUM.pattern, d)
    i = 0; ops = []; cx = cy = sx = sy = 0.0; cmd = None; lc = None   # lc = last cubic / quad control for S
    def nums(k):
        nonlocal i
        v = [float(toks[i + j]) for j in range(k)]; i += k; return v
    while i < len(toks):
        if re.match(r"[A-Za-z]", toks[i]): cmd = toks[i]; i += 1
        elif cmd in ("M", "m"): cmd = "L" if cmd == "M" else "l"
        rel = cmd.islower(); C = cmd.upper()
        ox, oy = (cx, cy) if rel else (0, 0)
        if C == "Z": ops.append(("Z",)); cx, cy = sx, sy; lc = None; continue
        if C == "M": x, y = nums(2); x += ox; y += oy; ops.append(("M", x, y)); cx, cy = sx, sy = x, y; lc = None
        elif C == "L": x, y = nums(2); x += ox; y += oy; ops.append(("L", x, y)); cx, cy = x, y; lc = None
        elif C == "H": (x,) = nums(1); x += ox; ops.append(("L", x, cy)); cx = x; lc = None
        elif C == "V": (y,) = nums(1); y += oy; ops.append(("L", cx, y)); cy = y; lc = None
        elif C == "C":
            a, b, c2, d2, x, y = nums(6); a += ox; b += oy; c2 += ox; d2 += oy; x += ox; y += oy
            ops.append(("C", a, b, c2, d2, x, y)); lc = (c2, d2); cx, cy = x, y
        elif C == "S":
            c2, d2, x, y = nums(4); c2 += ox; d2 += oy; x += ox; y += oy
            a, b = (2 * cx - lc[0], 2 * cy - lc[1]) if lc else (cx, cy)
            ops.append(("C", a, b, c2, d2, x, y)); lc = (c2, d2); cx, cy = x, y
        elif C == "Q":
            a, b, x, y = nums(4); a += ox; b += oy; x += ox; y += oy
            ops.append(("Q", a, b, x, y)); cx, cy = x, y; lc = None
        elif C == "A":
            rx, ry, ph, fa, fs, x, y = nums(7); x += ox; y += oy
            ops += arc_to_cubics(cx, cy, rx, ry, ph, int(fa), int(fs), x, y); cx, cy = x, y; lc = None
        else: raise ValueError("path command " + cmd)
    return ops

def attrs(tag): return dict(re.findall(r'([\w-]+)="([^"]*)"', tag))

def shape_ops(markup):
    ops = []
    for m in re.finditer(r"<(\w+)([^>]*)/?>", markup):
        t, a = m.group(1), attrs(m.group(2))
        f = lambda k, dflt=0.0: float(a.get(k, dflt))
        if t == "path": ops += path_ops(a["d"])
        elif t == "line": ops += [("M", f("x1"), f("y1")), ("L", f("x2"), f("y2"))]
        elif t in ("polyline", "polygon"):
            p = [float(x) for x in NUM.findall(a["points"])]
            ops.append(("M", p[0], p[1]))
            for j in range(2, len(p), 2): ops.append(("L", p[j], p[j + 1]))
            if t == "polygon": ops.append(("Z",))
        elif t in ("circle", "ellipse"):
            cx, cy = f("cx"), f("cy"); rx = f("r") if t == "circle" else f("rx"); ry = f("r") if t == "circle" else f("ry")
            ops.append(("M", cx + rx, cy))
            ops += arc_to_cubics(cx + rx, cy, rx, ry, 0, 0, 1, cx, cy + ry) + arc_to_cubics(cx, cy + ry, rx, ry, 0, 0, 1, cx - rx, cy) \
                 + arc_to_cubics(cx - rx, cy, rx, ry, 0, 0, 1, cx, cy - ry) + arc_to_cubics(cx, cy - ry, rx, ry, 0, 0, 1, cx + rx, cy) + [("Z",)]
        elif t == "rect":
            x, y, w, h = f("x"), f("y"), f("width"), f("height"); rx = f("rx", a.get("ry", 0)); ry = f("ry", rx) if "ry" in a else rx
            if rx <= 0 and ry <= 0: ops += [("M", x, y), ("L", x + w, y), ("L", x + w, y + h), ("L", x, y + h), ("Z",)]
            else:
                rx, ry = min(rx, w / 2), min(ry, h / 2)
                ops.append(("M", x + rx, y)); ops.append(("L", x + w - rx, y))
                ops += arc_to_cubics(x + w - rx, y, rx, ry, 0, 0, 1, x + w, y + ry); ops.append(("L", x + w, y + h - ry))
                ops += arc_to_cubics(x + w, y + h - ry, rx, ry, 0, 0, 1, x + w - rx, y + h); ops.append(("L", x + rx, y + h))
                ops += arc_to_cubics(x + rx, y + h, rx, ry, 0, 0, 1, x, y + h - ry); ops.append(("L", x, y + ry))
                ops += arc_to_cubics(x, y + ry, rx, ry, 0, 0, 1, x + rx, y); ops.append(("Z",))
        else: raise ValueError("element " + t)
    return ops

def ops_text(ops):
    return "".join(o[0] + " ".join(fmt(v) for v in o[1:]) for o in ops).replace(" L", "L")

def build():
    pack = json.load(open(PACK))
    names = sorted(pack["icons"])
    data = {n: ops_text(shape_ops(pack["icons"][n])) for n in names}
    j = ["package q9;", "", "/** GENERATED by tools/gen_icons.py from tools/icons/pack.json (CODM Blocky Icons v1, original work, see tools/icons/LICENSE.txt). Do not edit by hand.",
         " *  Every icon is a 24 x 24 outline (stroke 2, round caps and joins) written as absolute M / L / C / Q / Z commands. */",
         "final class IconData {", "    private IconData() { }", "    static final String[] NAMES = {"]
    j += ['        "%s",' % n for n in names]
    j += ["    };", "    static final String[] PATHS = {"]
    j += ['        "%s",' % data[n] for n in names]
    j += ["    };", "}", ""]
    java = "\n".join(j)
    sprite = ['<!--ICONS-->', '<svg id="ctSprite" xmlns="http://www.w3.org/2000/svg" width="0" height="0" style="position:absolute;width:0;height:0;overflow:hidden" aria-hidden="true" focusable="false">']
    for n in names:
        sprite.append('<symbol id="ic-%s" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">%s</symbol>' % (n, pack["icons"][n]))
    sprite += ['</svg>', '<!--/ICONS-->']
    return java, "\n".join(sprite), data

def main():
    java, sprite, data = build()
    idx = open(INDEX).read()
    if "<!--ICONS-->" in idx:
        new = re.sub(r"<!--ICONS-->.*?<!--/ICONS-->", lambda m: sprite, idx, flags=re.S)
    else:
        new = idx.replace("<body>", "<body>\n" + sprite, 1)
    if "--check" in sys.argv:
        ok = os.path.exists(OUTJ) and open(OUTJ).read() == java and new == idx
        print("icons up to date" if ok else "icons OUT OF DATE (run tools/gen_icons.py)"); sys.exit(0 if ok else 1)
    open(OUTJ, "w").write(java); open(INDEX, "w").write(new)
    json.dump(data, open("/dev/stdout" if "--dump" in sys.argv else os.devnull, "w"))
    print("icons: %d written (IconData.java %d bytes, sprite %d bytes)" % (len(data), len(java), len(sprite)))

if __name__ == "__main__": main()
