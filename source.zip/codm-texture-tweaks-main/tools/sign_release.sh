#!/bin/sh
# v0.86: sign the finished module folder (build_src/out) with the owner's Ed25519 key. Used by the GitHub workflow; can also be run by hand:
#   SIGNING_KEY="$(cat my_private_key.pem)" sh tools/sign_release.sh out
# The private key comes ONLY from the SIGNING_KEY environment variable (a GitHub Secret). It is written to a private temp file that is deleted on exit
# and it is never printed. Without the secret the build is simply NOT signed (a notice, not an error).
# Adds to the folder: RELEASE.sha256 (SHA-256 of every file), RELEASE.sig (signature of that list), RELEASE.pub (public key), RELEASE.verify.sh, VERIFY.txt.
set -eu
OUT="${1:?usage: sign_release.sh <module folder>}"
HERE="$(cd "$(dirname "$0")" && pwd)"
if [ -z "${SIGNING_KEY:-}" ]; then
  echo "::notice::SIGNING_KEY secret is not set: this build is NOT signed."
  exit 0
fi
umask 077
KF="$(mktemp)"; trap 'rm -f "$KF"' EXIT INT TERM
printf '%s\n' "$SIGNING_KEY" > "$KF"
openssl pkey -in "$KF" -noout >/dev/null 2>&1 || { echo "::error::SIGNING_KEY is not a valid PEM private key (Ed25519)."; exit 1; }
openssl pkey -in "$KF" -noout -text 2>/dev/null | head -n 1 | grep -qi 'ED25519' || { echo "::error::SIGNING_KEY must be an Ed25519 key."; exit 1; }
cd "$OUT"
rm -f RELEASE.sha256 RELEASE.sig RELEASE.pub RELEASE.verify.sh VERIFY.txt
openssl pkey -in "$KF" -pubout -out RELEASE.pub
find . -type f ! -name 'RELEASE.*' -print0 | sort -z | xargs -0 sha256sum > RELEASE.sha256
openssl pkeyutl -sign -rawin -inkey "$KF" -in RELEASE.sha256 -out RELEASE.sig
openssl pkeyutl -verify -rawin -pubin -inkey RELEASE.pub -sigfile RELEASE.sig -in RELEASE.sha256 >/dev/null || { echo "::error::the new signature does not verify"; exit 1; }
cp "$HERE/verify_release.sh" RELEASE.verify.sh
FP="$(openssl pkey -pubin -in RELEASE.pub -outform DER | sha256sum | cut -d' ' -f1)"
RID="$(sha256sum RELEASE.sha256 | cut -d' ' -f1)"
NF="$(wc -l < RELEASE.sha256 | tr -d ' ')"
cat > VERIFY.txt <<VEOF
CODM Blocky Textures - how to check that this module is the official one
Owner: Q9 Papyrus

Public key fingerprint (SHA-256 of the key): $FP
Release ID (SHA-256 of RELEASE.sha256):       $RID
Files covered: $NF

1. Get the owner's PUBLISHED public key (do not use RELEASE.pub from this folder: whoever changed the module could have replaced it).
   Its fingerprint must equal the one above and the one the owner published.
2. On a PC or in Termux (needs openssl and sha256sum), from this folder run:
     sh RELEASE.verify.sh . owner_public_key.pem
   It says OK only when the signature is valid, every file matches and there is no extra file.
A module that fails this check, or has no RELEASE.sig, is NOT the official build.
VEOF
if [ -n "${GITHUB_STEP_SUMMARY:-}" ]; then
  { echo "### Signed release"; echo; echo "- Public key fingerprint: \`$FP\`"; echo "- Release ID: \`$RID\`"; echo "- Files covered: $NF"; echo; echo "Publish the public key and the Release ID with this version:"; echo; echo '```'; cat RELEASE.pub; echo '```'; } >> "$GITHUB_STEP_SUMMARY"
fi
echo "signed: $NF files, key fingerprint $FP, release id $RID"
