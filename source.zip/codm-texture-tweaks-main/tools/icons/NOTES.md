# CODM Blocky Icons v1 - notes

Counts: 160 names asked for in the brief -> 130 unique drawings + 30 names that share a drawing.
Format: SVG 24x24, stroke-only, stroke-width 2, round caps/joins, `currentColor`. Elements used: path, circle, rect, line, polyline, polygon, ellipse. Path commands used: M L H V C S Q A Z (upper and lower case).
Every geometry sits inside the 2..22 safe area (checked by script).

## Files
- `svg/<name>.svg` - one file per name (160 files; alias names are copies of the same drawing)
- `sprite.svg` - every name as `<symbol id="name" viewBox="0 0 24 24">`
- `pack.json` - `icons` = shape markup per name, `aliases` = which names share a drawing
- `preview.html` - grid at 14 / 20 / 32 px, on dark and on white
- `LICENSE.txt` - original work, free to use / modify

## How dots are drawn
Small dots are zero-length paths like `M12 12h.01` with a round cap (diameter = stroke width = 2). Used by: list, more, drag-grip, question, info, status-warn, delete-armed, lock, theme, normal-codm, save-current, show-hidden. In Java: draw a point/circle of radius 1 (or a line of length ~0 with Cap.ROUND).

## Names that share one drawing (as the brief allows)
- `card-history` = `history`
- `card-startup` = `power`
- `card-hider` = `hide`
- `card-restorer` = `restore`
- `card-mytextures` = `saved`
- `card-live` = `live`
- `card-quick` = `test`
- `card-gamecopy` = `copy`
- `card-saveaction` = `save`
- `card-log` = `file-text`
- `card-reset` = `reset`
- `card-about` = `info`
- `card-share` = `share`
- `card-shortcuts` = `auto`
- `card-compat` = `skip`
- `set-hook` = `wait`
- `set-fps` = `limit`
- `set-presets` = `card-presets`
- `set-swap` = `card-memory`
- `set-order` = `sort`
- `undo-last` = `undo`
- `start-search` = `finder-start`
- `narrow-down` = `filter`
- `loading` = `busy`
- `card-logging` = `file-text`
- `card-interface` = `layout`
- `marker-using` = `using`
- `marker-hidden` = `hidden-state`
- `marker-mode-off` = `power`
- `marker-mode-2gb` = `card-memory`

## Icons I am not fully sure about
- **settings**: Gear is a 6-tooth polygon (24 points), the only icon above ~6 segments; fewer teeth keep it readable at 14 px.
- **hidden-state / marker-hidden**: Drawn as a small ring with a slash (not a tiny eye-off): a real eye is unreadable at 10 px. If you want the eye, reuse 'hide' at 14 px+.
- **using / marker-using**: Triangle outline; with stroke 2 it looks nearly solid at 10-12 px. In Java you may fill it (Paint.Style.FILL_AND_STROKE) for a true solid marker.
- **cross vs close**: 'cross' is a smaller X. Real thinness needs a thinner stroke; in code you can draw 'cross' with stroke 1.5 if you want it lighter. Shape is already distinct.
- **restore / reset / history**: All three are the counter-clockwise arrow. Plain = restore, centre dot = reset, clock hands = history. Clear at 20 px, subtle at 14 px (the dot/hands are small).
- **expand-all / collapse-all**: Deliberately drawn by meaning: expand = chevrons pointing apart, collapse = chevrons pointing together (Lucide's literal names are the reverse).
- **group / ungroup**: Chain links: joined pills vs two separate pills. Simple on purpose; readable but not as obvious as a labelled button.
- **save-hidden**: Bookmark with a closed-eye arc. A real eye-off inside a bookmark does not fit at 24 px. Use the short text label next to it (the brief already says icon + short word for unclear buttons).
- **set-restore-finder**: Restore arrow around a very small magnifier; the magnifier is tiny at 14 px. Suggest keeping the row text beside it.
- **set-hide-finder**: Magnifier with a slash, looks like 'search off'.
- **verified**: 10-point seal with a check (meant to differ from 'skip' shield-check and 'status-ok' circle-check).
- **look-on**: Sparkle + small plus. Not an eye, so it cannot be confused with 'show'.
- **normal-codm**: Game controller only. A house-plus-gamepad does not fit in 24 px.
- **marker-mode-off / marker-mode-2gb**: Reused 'power' and 'card-memory' drawings. My recommendation: use text badges 'OFF' and '2GB' instead; they are clearer than any 10 px icon.
- **busy / loading**: Open circle, 270 degrees. Rotate it in code; the SVG itself is static.
- **half-first / half-second**: Left half / right half marked (square split vertically). If you need top/bottom halves, rotate by 90 degrees in code.

## SUGGESTED ADDITIONS
None. I did not add icons that are not in the list. One thing I noticed while drawing: `card-presets` and `advanced` both read as "sliders/tuning" in the brief; I used a bookmark-star for presets and horizontal sliders for advanced, vertical sliders for finetuning, so the three stay different.

## Table
| icon | looks like | where it is used |
|---|---|---|
| `home` | house with a door | W dock |
| `advanced` | 3 horizontal sliders | W dock |
| `tools` | wrench | W dock |
| `test` | lab flask with liquid line | M tab, W "Quick test"/"Side test" |
| `list` | 3 lines with bullet dots | M tab, W "Texture browser" |
| `saved` | bookmark | M tab, W "My textures" |
| `settings` | 6-tooth gear | M gear, W cards |
| `back` | arrow pointing left | M "←", W Back |
| `close` | X | M "✕", W Close |
| `chevron-down` | chevron down | W, M picker ▾ |
| `chevron-up` | chevron up | W |
| `chevron-right` | chevron right | W, M group rows "›" |
| `chevron-left` | chevron left | W |
| `more` | 3 dots in a row | W, M |
| `hide` | eye with slash | W, M "Hide" |
| `show` | open eye | W, M "Show" |
| `restore` | counter-clockwise arrow (rotate-ccw) | W, M "Restore" |
| `look-on` | sparkle star + small plus | M |
| `skip` | shield with check | M "Save as skip", W |
| `skipped-list` | lines + small shield | M "Skipped (n)" |
| `hidden-state` | small ring with slash | W row status |
| `using` | small triangle marker | M, W |
| `save` | floppy disk | W, M "Save", "Save texture" |
| `save-set` | stacked layers + plus | W "Save as ONE set", M "Save as set" |
| `save-each` | two squares + plus | W "Save one by one" |
| `rename` | pencil | W, M "Rename" |
| `delete` | trash can with lid | W, M "Delete", "Del" |
| `delete-armed` | trash can with ! inside | M, W (2nd tap) |
| `clear` | eraser | W "Clear log", "Clear history", "Clear selection" |
| `undo` | u-turn arrow to the left | W "Undo" |
| `reset` | rotate-ccw with centre dot | W "Reset", "Reset defaults" |
| `copy` | two overlapping squares | W "Copy" |
| `check` | check mark | W "Done", M "Yes" |
| `cross` | small x (smaller than close) | M "No" |
| `plus` | plus | W |
| `minus` | minus | W |
| `search` | magnifier | W, M |
| `finder-start` | scan corners + centre target | W "Scan again", M |
| `half-first` | square, left half highlighted | M |
| `half-second` | square, right half highlighted | M |
| `all` | four squares (2x2 grid) | M "Hide all" |
| `question` | circle with ? | M question bar |
| `cancel-search` | circle with stop square | W "Cancel the whole search", M "Cancel finder" |
| `refresh` | two circular arrows (clockwise) | W "Refresh list", "Refresh status", M "Reload list" |
| `filter` | funnel | W "Hide filters" |
| `side-test` | window split in two columns | W "Side test" |
| `end-test-keep` | flag with check | W "End the test, keep my switches" |
| `end-test-drop` | flag with x | W "End the test (discard)" |
| `group` | two joined chain links | M "Group…", W |
| `ungroup` | two separated links | W, M "Ungroup" |
| `folder` | folder | W "Folders", M "Folders" |
| `single` | single file / page | W "Singles", M "Singles" |
| `make-group` | folder with plus | M "Make group" |
| `drag-grip` | 6 dots (2x3) | W |
| `sort` | up arrow + down arrow | W, M Settings |
| `sort-new` | clock + arrow down | W, M |
| `sort-old` | clock + arrow up | W, M |
| `sort-az` | A on top, Z below, arrow down | W, M |
| `sort-za` | Z on top, A below, arrow down | W, M |
| `select-all` | checked box | W "Tick all" |
| `select-none` | empty box | W "Untick" |
| `window-size` | four outward corners | M Settings, W "Use my phone's screen size" |
| `icon-on` | circle with centre dot | M Settings |
| `icon-off` | circle with slash | M Settings |
| `theme` | paint palette | W Interface |
| `layout` | dashboard blocks | W Interface "Compact / Roomy" |
| `text-size` | big A + small A | W Interface |
| `language` | globe | W, kung meron |
| `wait` | stopwatch | M Settings |
| `limit` | gauge with needle | M Settings |
| `haptic` | phone with vibration bars | W Interface |
| `auto` | lightning bolt | W "Auto" |
| `manual` | pointer arrow (cursor) | W "Manual" |
| `expand-all` | two chevrons pointing apart | W "Open all" |
| `collapse-all` | two chevrons pointing together | W "Close all" |
| `share` | three connected nodes | W "Share my textures", "Share my ON shortcuts" |
| `import` | arrow down into a tray | W "Import", "Import code", "Import textures", "Import shortcuts" |
| `export` | arrow up out of a tray | W "Export report for support" |
| `code` | curly braces { } | W "Import code" |
| `file-text` | page with text lines | W "View log", "Clear log", "Log" card |
| `report` | clipboard with heartbeat line | W "View diagnostics" |
| `history` | rotate-ccw arrow around clock hands | W "History", "Clear history" |
| `backup` | archive box with up arrow | W Game copy / backup |
| `status-ok` | circle with check | W, M status dot |
| `status-warn` | triangle with ! | W, M |
| `status-error` | circle with x | W, M |
| `info` | circle with i | W, M |
| `shield` | shield | W "Compatibility", "Startup" |
| `lock` | padlock | W, M owner / integrity label |
| `verified` | 10-point seal with check | W, M — gagamitin sa v1.11 |
| `power` | power symbol | W "Turn all on", "Turn all off" |
| `turn-on` | toggle, knob on the right | W |
| `turn-off` | toggle, knob on the left | W |
| `busy` | open circle (spinner, rotate in code) | W, M |
| `live` | activity pulse line | W "Live test" |
| `normal-codm` | game controller | W "Back to normal CODM" |
| `retry` | two circular arrows (counter-clockwise) | W "Try the menu again" |
| `continue` | arrow pointing right | W "Continue anyway" |
| `understood` | thumbs up | W |
| `card-presets` | bookmark with a star | WebUI card: Presets |
| `card-look` | paintbrush | WebUI card: Look |
| `card-boxloot` | cube / package | WebUI card: Box loot |
| `card-display` | monitor on a stand | WebUI card: Display |
| `card-shortcuts` | lightning bolt (same drawing as `auto`) | WebUI card: Texture shortcuts |
| `card-summary` | clipboard with list lines | WebUI card: Session summary |
| `card-advice` | light bulb | WebUI card: Advice |
| `card-history` | rotate-ccw arrow around clock hands (same drawing as `history`) | WebUI card: History |
| `card-startup` | power symbol (same drawing as `power`) | WebUI card: Startup |
| `card-finetuning` | 3 vertical sliders | WebUI card: Fine tuning |
| `card-compat` | shield with check (same drawing as `skip`) | WebUI card: Compatibility |
| `card-hider` | eye with slash (same drawing as `hide`) | WebUI card: Texture hider |
| `card-restorer` | counter-clockwise arrow (rotate-ccw) (same drawing as `restore`) | WebUI card: Texture restorer |
| `card-browser` | two blocks with rows | WebUI card: Texture browser |
| `card-mytextures` | bookmark (same drawing as `saved`) | WebUI card: My textures |
| `card-groups` | tree: parent box, two branches | WebUI card: Texture groups |
| `card-renderer` | processor chip with pins | WebUI card: Renderer |
| `card-memory` | memory stick | WebUI card: Memory tweaks |
| `card-live` | activity pulse line (same drawing as `live`) | WebUI card: Live test |
| `card-logging` | page with text lines (same drawing as `file-text`) | WebUI card: Logging |
| `card-interface` | dashboard blocks (same drawing as `layout`) | WebUI card: Interface |
| `card-quick` | lab flask with liquid line (same drawing as `test`) | WebUI card: Quick test |
| `card-gamecopy` | two overlapping squares (same drawing as `copy`) | WebUI card: Game copy |
| `card-saveaction` | floppy disk (same drawing as `save`) | WebUI card: Save action |
| `card-log` | page with text lines (same drawing as `file-text`) | WebUI card: Log |
| `card-reset` | rotate-ccw with centre dot (same drawing as `reset`) | WebUI card: Reset |
| `card-about` | circle with i (same drawing as `info`) | WebUI card: About |
| `card-share` | three connected nodes (same drawing as `share`) | WebUI card: Share or import |
| `apply` | double check | W "Apply", "Set recommended settings (test)" |
| `show-more` | two chevrons down | W "Show N more" |
| `show-fewer` | two chevrons up | W "Show fewer" |
| `start-search` | scan corners + centre target (same drawing as `finder-start`) | W "Start search" |
| `narrow-down` | funnel (same drawing as `filter`) | M List tab |
| `save-hidden` | bookmark with a closed eye | M List tab |
| `show-hidden` | list lines + small eye | M List tab |
| `undo-last` | u-turn arrow to the left (same drawing as `undo`) | W |
| `back-to-test` | return arrow (corner down-left) | W, M "← Back to" |
| `save-current` | floppy disk with 3 dots | W "Save current…" |
| `use-size-last` | outward corners + clock hands | W |
| `loading` | open circle (spinner, rotate in code) (same drawing as `busy`) | M "Loading..." |
| `finder` | scan corners + magnifier | M label "Finder" |
| `name-user` | person (head and shoulders) | W |
| `set-edge-blend` | two overlapping circles | WebUI settings row |
| `set-explain` | speech bubble with ? | WebUI settings row |
| `set-fps` | gauge with needle (same drawing as `limit`) | WebUI settings row |
| `set-hook` | stopwatch (same drawing as `wait`) | WebUI settings row |
| `set-presets` | bookmark with a star (same drawing as `card-presets`) | WebUI settings row |
| `set-swap` | memory stick (same drawing as `card-memory`) | WebUI settings row |
| `set-order` | up arrow + down arrow (same drawing as `sort`) | WebUI settings row |
| `set-pixel` | 2x2 pixel grid | WebUI settings row |
| `set-strength` | 4 rising bars | WebUI settings row |
| `set-card-size` | two diagonal arrows apart | WebUI settings row |
| `set-smallest` | two diagonal arrows together | WebUI settings row |
| `marker-using` | small triangle marker (same drawing as `using`) | M, W |
| `marker-hidden` | small ring with slash (same drawing as `hidden-state`) | W rows |
| `marker-set` | small folder | W, M rows |
| `set-hide-finder` | magnifier with slash | WebUI settings row |
| `set-restore-finder` | restore arrow around a small magnifier | WebUI settings row |
| `marker-notfound` | magnifier with x | WebUI / menu |
| `marker-mode-off` | power symbol (same drawing as `power`) | WebUI / menu |
| `marker-mode-2gb` | memory stick (same drawing as `card-memory`) | WebUI / menu |
