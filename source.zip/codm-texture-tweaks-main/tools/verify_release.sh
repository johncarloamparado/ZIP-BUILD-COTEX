#!/bin/sh
# v0.86: check a module folder against the owner's PUBLISHED public key.   sh RELEASE.verify.sh <module folder> <owner_public_key.pem>
# OK only when the signature is valid, every listed file has the listed SHA-256 and no unlisted file exists.
DIR="${1:-.}"; PUB="${2:-}"
[ -n "$PUB" ] && [ -f "$PUB" ] || { echo "usage: sh RELEASE.verify.sh <module folder> <owner_public_key.pem>"; exit 2; }
PUB="$(cd "$(dirname "$PUB")" && pwd)/$(basename "$PUB")"      # the key path is relative to where you are now, not to the module folder
cd "$DIR" || exit 2
[ -f RELEASE.sha256 ] && [ -f RELEASE.sig ] || { echo "NOT OFFICIAL: RELEASE.sha256 / RELEASE.sig are missing (unsigned or changed)"; exit 1; }
openssl pkeyutl -verify -rawin -pubin -inkey "$PUB" -sigfile RELEASE.sig -in RELEASE.sha256 >/dev/null 2>&1 || { echo "NOT OFFICIAL: the signature does not match this public key"; exit 1; }
sha256sum -c RELEASE.sha256 --quiet >/dev/null 2>&1 || { echo "NOT OFFICIAL: a file differs from the signed list:"; sha256sum -c RELEASE.sha256 2>&1 | grep -v ': OK$'; exit 1; }
find . -type f ! -name 'RELEASE.*' ! -name VERIFY.txt | sort > "${TMPDIR:-/tmp}/rv_have.$$"
sed 's/^[0-9a-f]\{64\}  //' RELEASE.sha256 | sort > "${TMPDIR:-/tmp}/rv_want.$$"
EXTRA="$(comm -23 "${TMPDIR:-/tmp}/rv_have.$$" "${TMPDIR:-/tmp}/rv_want.$$")"; rm -f "${TMPDIR:-/tmp}/rv_have.$$" "${TMPDIR:-/tmp}/rv_want.$$"
[ -z "$EXTRA" ] || { echo "NOT OFFICIAL: extra file(s) that are not in the signed list:"; echo "$EXTRA"; exit 1; }
echo "OK: signature valid, all files match, no extra files (official build)"
