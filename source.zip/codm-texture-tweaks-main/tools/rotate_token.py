#!/usr/bin/env python3
"""v0.86: make a NEW owner token and swap its salt/hash in every place that holds them, then write the new MASTER_KEY.txt.
Run it yourself (Termux or PC) from the project root:
    python3 tools/rotate_token.py --handoff HANDOFF_codm_blocky.txt --master-out ../MASTER_KEY.txt
Afterwards:  sh tests/manifest.sh gen
The token is never written to any file except the master-key file, which MUST be outside the project folder (it would end up in source.zip otherwise).
Needs no old token: it works from the hash that is already in NOTICE.txt."""
import argparse, hashlib, os, re, secrets, sys

ap = argparse.ArgumentParser()
ap.add_argument("--master-out", required=True, help="where to write the new MASTER_KEY.txt (must be OUTSIDE the project folder)")
ap.add_argument("--handoff", action="append", default=[], help="HANDOFF file(s) that hold the hash too (can be repeated)")
a = ap.parse_args()

root = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
out = os.path.abspath(a.master_out)
if out == root or out.startswith(root + os.sep):
    sys.exit("refused: --master-out is inside the project folder; put the master key somewhere else (for example the folder above)")
files = [os.path.join(root, p) for p in ("webroot/index.html", "NOTICE.txt", "webroot/NOTICE.txt")] + [os.path.abspath(p) for p in a.handoff]
old = open(os.path.join(root, "NOTICE.txt"), encoding="utf-8").read()
m1 = re.search(r"bytes\.fromhex\('([0-9a-f]{32})'\)", old); m2 = re.search(r"must equal ([0-9a-f]{64}) exactly", old)
if not (m1 and m2):
    sys.exit("NOTICE.txt does not contain the salt / hash in the expected form")
osalt, ohash = m1.group(1), m2.group(1)
raw = secrets.token_hex(20); token = "-".join(raw[i:i + 8] for i in range(0, 40, 8))
salt = secrets.token_hex(16)
h = hashlib.pbkdf2_hmac("sha256", token.encode(), bytes.fromhex(salt), 600000).hex()
texts = {}
for f in files:
    s = open(f, encoding="utf-8").read()
    if osalt not in s or ohash not in s:
        sys.exit("the old salt / hash was not found in %s (nothing was changed)" % f)
    texts[f] = s.replace(osalt, salt).replace(ohash, h)
tpl = open(os.path.join(root, "tools", "master_key_template.txt"), encoding="utf-8").read()
master = tpl.replace("@@TOKEN@@", token).replace("@@SALT@@", salt).replace("@@HASH@@", h)
for f, s in texts.items():
    assert token not in s and osalt not in s and ohash not in s
    open(f, "w", encoding="utf-8").write(s)
open(out, "w", encoding="utf-8").write(master)
try: os.chmod(out, 0o600)
except OSError: pass
print("new token written ONLY to", out)
print("changed:", ", ".join(os.path.relpath(f) for f in files))
print("next: sh tests/manifest.sh gen   (then zip the project again; the old MASTER_KEY.txt no longer works)")
